# CGM 26.3 — Kaynak kod çıkarma paketi

Gönderdiğin JAR'ın 0.3.60 sürümündeki kodları çıkarıldı:

- **399 Java dosyası:** 238 CGM + 161 Framework.
- **599 derlenmiş sınıf:** iç içe sınıflar ilgili Java dosyalarında bulunur.
- **343 gömülü Java dosyası:** eski yama kaynakları ve testler korunmuştur.
- **589 assets/data dosyası:** modeller, dokular, sesler, tarifler ve diğer oyun verileri korunmuştur.
- JAR'daki toplam **1097 sınıf dışı dosya** birebir çıkarılmıştır.

## Nereden başlayabilirsin?

Ana mod kodu: `src/main/java/com/mrcrayfish/guns/`

Gömülü Framework: `src/main/java/com/mrcrayfish/framework/`

Modeller, dokular ve sesler: `src/main/resources/assets/cgm/`

Tarifler ve oyun verileri: `src/main/resources/data/`

Önceki yamaların kaynakları, testleri ve notları: `archive/embedded/`

## Paketin sınırı

`src/main/java` dosyaları derlenmiş koddan geri oluşturuldu. Özgün kaynak kodun
yorumları ve bazı değişken adları JAR'dan aynen geri alınamaz. Eski yama/test
dosyaları güncel kodun üstüne yazılmadı.

JAR içinde özgün `build.gradle`, `settings.gradle`, `gradle.properties` veya
Gradle wrapper bulunmuyor. Bu nedenle paket, yeniden derlendiği doğrulanmış bir
Forge projesi değildir. Kodları inceleyebilir ve düzenleyebilirsin; yeni JAR
derlemek için gerçek proje ayarları ve bağımlılıklar gerekir. Bu işlemde oyun
testi veya tam Forge derlemesi yapılmadı.

Ekran görüntüsündeki **Kaynak kod** alanı bir bağlantı istiyor. Kaynaklarının
bulunduğu herkese açık depoyu yayımladıktan sonra o deponun URL'sini kullan.
Bu paketin çıkarılmış olması, özgün projenin tüm kaynak ve derleme dosyalarının
geri kazanıldığı veya yayımlama koşullarının karşılandığı anlamına gelmez.

Ayrıntılı envanter ve kontrol sonuçları `reports/` klasöründedir. Girdi JAR'ı
`reference/` içinde değiştirilmeden korunmuştur.
