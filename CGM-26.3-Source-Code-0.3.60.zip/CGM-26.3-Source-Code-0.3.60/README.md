# CGM 26.3 — İlker's Unofficial Port: recovered source snapshot

This archive recovers the contents of the supplied **0.3.60** JAR. It contains
**238 CGM Java files**, **161 bundled Framework Java files**,
all **1097 original non-class files**, and an unchanged copy of the input JAR.

## Status

`src/main/java` is **decompiled Java**, reconstructed from all 599 runtime class files
using Vineflower 1.12.0. Nested/anonymous classes are represented in their enclosing
source files, giving 399 source units. These files are not the original author's
exact source. Some comments, local names, formatting and structure were not retained
in the bytecode and cannot be recreated exactly.

The original Gradle wrapper, build files and dependency configuration were **not
present in the JAR**. This is a recovery snapshot, **not a verified buildable Forge
workspace**. No full compilation or Minecraft runtime test was performed. Build
configuration and any decompiler type-inference issues must be resolved before a
new mod JAR can be built. No placeholder Gradle files have been invented.

## Contents

| Path | Contents |
| --- | --- |
| `src/main/java/com/mrcrayfish/guns/` | Current CGM implementation recovered from the JAR |
| `src/main/java/com/mrcrayfish/framework/` | Current bundled Framework implementation recovered from the JAR |
| `src/main/resources/` | Original models, textures, sounds, language files, recipes, tags, mixin configuration, services and mod metadata |
| `archive/embedded/` | Original patch sources, tests, fixtures, scripts and notes, with original JAR paths retained |
| `reference/` | Byte-for-byte original JAR |
| `reports/` | Per-file SHA-256 inventory, class-to-source mapping, recovery report and decompiler warning log |
| `tools/recover_sources.py` | Script to repeat the extraction with the original JAR and Vineflower |

The 343 existing Java files in `archive/embedded/` are historical files
already present in the JAR. Some are test fixtures or older revisions. They were
not copied over current runtime sources. Treat their historical test results as
archived records, not tests performed on this recovered project.

## Validation performed

- Checked input ZIP CRC and duplicate entry names.
- Mapped every one of the 599 class files to a recovered Java source unit.
- Verified all 1097 non-class files and the reference JAR byte for byte.
- Scanned generated source for failed-decompilation method markers: none found.
- Retained the decompiler's one warning about `MiniGunModel.lambda$render$0` being
  processed twice. A warning-free or marker-free output is not proof of semantic
  equivalence or successful compilation.

Input SHA-256: `22e0970140212117ba914cf876da6588ac01420ec701d3d0a64c003069efaa5c`

## Repeat the recovery

Use Python 3 and Java 17 or newer to run the recovery tool. Download
[Vineflower 1.12.0](https://github.com/Vineflower/vineflower/releases/tag/1.12.0),
then run from this folder:

```sh
python3 tools/recover_sources.py --jar reference/CGM-26.3-Forge-Ilker-Unofficial-Port-0.3.60-original.jar --decompiler /path/to/vineflower-1.12.0.jar --output recovered-again
```

The output directory must be new. This repeats extraction and decompilation; it
does not compile the Minecraft mod. Most original classes use Java 25 classfile
version 69. The preserved `META-INF/mods.toml` declares Minecraft 26.3, Forge
66.0.2 and bundled Framework 0.13.27 as the relevant targets/minima.

## Attribution and original notices

Original projects: MrCrayfish's Gun Mod and Framework by MrCrayfish.
Unofficial Minecraft 26.3 port: İlker. This recovery does not change authorship or
the original files' licensing declarations.

Original notices are preserved in `src/main/resources/LICENSE_framework`,
`src/main/resources/assets/cgm/sounds/SOUND-LICENSE.txt`, and
`src/main/resources/META-INF/mods.toml`. The supplied JAR's metadata declares
`GPL3 / LGPLv2.1 (bundled projects retain their original licenses)`; a separate
full CGM license text was not found in the supplied JAR. No replacement license
was selected during extraction.

This snapshot does not establish that all preferred source/build materials needed
for a complete corresponding-source distribution have been recovered. When
preparing a source release, preserve the actual port's original source and build
files when available; a decompiler output is not an exact substitute for them.
