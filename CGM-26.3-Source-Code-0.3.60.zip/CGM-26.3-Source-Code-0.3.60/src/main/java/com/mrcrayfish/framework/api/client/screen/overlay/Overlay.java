package com.mrcrayfish.framework.api.client.screen.overlay;

import com.google.common.annotations.Beta;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import net.minecraft.client.gui.screens.Screen;
import org.jetbrains.annotations.Nullable;

// $VF: Compiled from Overlay.java
@Beta
public abstract class Overlay {
    @Nullable
    Overlayable owner;

    public abstract ScreenRectangle getInteractableArea();

    public abstract List<? extends GuiEventListener> getWidgets();

    public abstract void render(GuiGraphicsExtractor var1, int var2, int var3, float var4);

    public void renderBackground(GuiGraphicsExtractor extractor) {
        com.mojang.blaze3d.platform.Window window = Minecraft.getInstance().getWindow();
        extractor.fill(0, 0, window.getWidth(), window.getHeight(), 1342177280);
    }

    protected void onOpened() {
    }

    protected void onClosed() {
    }

    public final void show(Consumer<ScreenRectangle> positioner) {
        Screen screen = Minecraft.getInstance().gui.screen();
        if (screen instanceof Overlayable overlayable && overlayable.getOverlayController().open(this)) {
            positioner.accept(screen.getRectangle());
        }
    }

    public final void close() {
        if (this.owner != null) {
            this.owner.getOverlayController().close(this);
        }
    }

    public final void deepClose() {
        if (this.owner != null) {
            this.owner.getOverlayController().closeAll();
        }
    }

    public final boolean isOpened() {
        return this.owner != null && this.owner.isDisplayed();
    }

    @Nullable
    public Overlayable getOwner() {
        return this.owner;
    }
}
