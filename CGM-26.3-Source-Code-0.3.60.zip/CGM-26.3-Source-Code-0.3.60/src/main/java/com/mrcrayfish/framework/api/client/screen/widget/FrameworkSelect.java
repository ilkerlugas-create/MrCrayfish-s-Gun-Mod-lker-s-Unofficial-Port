package com.mrcrayfish.framework.api.client.screen.widget;

import com.google.common.annotations.Beta;
import com.mrcrayfish.framework.api.client.screen.Anchor;
import com.mrcrayfish.framework.api.client.screen.overlay.impl.Dropdown;
import com.mrcrayfish.framework.api.client.screen.widget.element.Icon;
import com.mrcrayfish.framework.api.client.screen.widget.layout.Margin;
import com.mrcrayfish.framework.api.client.screen.widget.layout.Padding;
import com.mrcrayfish.framework.util.Utils;
import java.time.Duration;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Map.Entry;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.components.WidgetSprites;
import net.minecraft.client.gui.layouts.LinearLayout;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.util.ARGB;
import org.jetbrains.annotations.Nullable;

// $VF: Compiled from FrameworkSelect.java
@Beta
public final class FrameworkSelect<T> extends AbstractWidget {
    public static final WidgetSprites DEFAULT_SPRITES = new WidgetSprites(
        Identifier.withDefaultNamespace("widget/button"),
        Identifier.withDefaultNamespace("widget/button_disabled"),
        Identifier.withDefaultNamespace("widget/button_highlighted")
    );
    public static final Icon DEFAULT_ICON = Icon.sprite(Utils.rl("widget/select/arrow"), 8, 6);
    public static final Identifier DEFAULT_DROPDOWN_BACKGROUND = Utils.rl("widget/select/dropdown_background");
    public static final Padding DEFAULT_DROPDOWN_PADDING = Padding.of(5);
    public static final int DEFAULT_TOOLTIP_DELAY = 350;
    private static final List<Anchor> ANCHOR_ORDER = List.of(
        Anchor.BELOW_LEFT, Anchor.BELOW_RIGHT, Anchor.ABOVE_LEFT, Anchor.ABOVE_RIGHT, Anchor.END_TOP, Anchor.END_BOTTOM
    );
    private final Class<T> type;
    private final boolean searchable;
    @Nullable
    private final Anchor preferredAnchor;
    @Nullable
    private final WidgetSprites texture;
    private final Function<FrameworkSelect<T>, @Nullable Icon> iconFunction;
    @Nullable
    private final Identifier dropdownBackground;
    private final Padding dropdownPadding;
    @Nullable
    private final Supplier<Boolean> activeSupplier;
    @Nullable
    private final Function<FrameworkSelect<T>, Tooltip> tooltip;
    private final int tooltipOptions;
    @Nullable
    private final Consumer<Dropdown.Builder> buildDropdownListener;
    @Nullable
    private final Consumer<T> callback;
    private final LinkedHashMap<String, FrameworkSelect<T>.OptionItem> options;
    private final FrameworkSelectionList list;
    private final FrameworkEditBox searchField;
    @Nullable
    private Dropdown dropdown;
    @Nullable
    private FrameworkSelect.OptionItem selected;
    @Nullable
    private Tooltip currentTooltip;
    private boolean shiftWasDown;
    private boolean mouseIsHovering;

    private FrameworkSelect(
        int x,
        int y,
        int width,
        int height,
        Class<T> type,
        Function<T, Component> objectToLabel,
        List<T> values,
        boolean searchable,
        boolean allowEmpty,
        @Nullable T initialValue,
        @Nullable Consumer<T> callback,
        @Nullable Anchor preferredAnchor,
        @Nullable WidgetSprites texture,
        Function<FrameworkSelect<T>, @Nullable Icon> iconFunction,
        @Nullable Identifier dropdownBackground,
        Padding dropdownPadding,
        int dropdownMinWidth,
        int visibleListItems,
        @Nullable Supplier<Boolean> active,
        @Nullable Function<FrameworkSelect<T>, Tooltip> tooltip,
        int tooltipDelay,
        int tooltipOptions,
        @Nullable Consumer<FrameworkSelectionList.Builder> buildOptionListListener,
        @Nullable Consumer<FrameworkEditBox.Builder> buildSearchFieldListener,
        @Nullable Consumer<Dropdown.Builder> buildDropdownListener
    ) {
        super(x, y, width, height, CommonComponents.EMPTY);
        this.type = type;
        this.searchable = searchable;
        this.callback = callback;
        this.preferredAnchor = preferredAnchor;
        this.texture = texture;
        this.iconFunction = iconFunction;
        this.dropdownBackground = dropdownBackground;
        this.dropdownPadding = dropdownPadding;
        this.activeSupplier = active;
        this.tooltip = tooltip;
        this.tooltipOptions = tooltipOptions;
        this.buildDropdownListener = buildDropdownListener;
        Stream<FrameworkSelect<T>.OptionItem> stream = Stream.concat(
            allowEmpty ? Stream.of(new FrameworkSelect.OptionItem(null, Component.literal(""))) : Stream.empty(),
            values.stream().map(t -> new FrameworkSelect.OptionItem((T)t, objectToLabel.apply((T)t)))
        );
        this.options = stream.collect(Collectors.toMap(FrameworkSelect.OptionItem::getKey, Function.identity(), (a, b) -> a, LinkedHashMap::new));
        int horizontalDropdownPadding = dropdownPadding.left() + dropdownPadding.right();
        int widgetWidth = Math.max(width - horizontalDropdownPadding, dropdownMinWidth - horizontalDropdownPadding);
        FrameworkSelectionList.Builder listBuilder = FrameworkSelectionList.builder()
            .setSize(widgetWidth, 16 * visibleListItems)
            .setListPadding(Padding.ZERO)
            .setScrollBarSpacing(4)
            .setItemHeight(16);
        if (buildOptionListListener != null) {
            buildOptionListListener.accept(listBuilder);
        }

        this.list = listBuilder.build();
        this.list.replaceItems(this.options.values().stream().map(item -> (FrameworkSelectionList.Item)item).toList());
        FrameworkEditBox.Builder searchFieldBuilder = FrameworkEditBox.builder()
            .setSize(widgetWidth, 16)
            .setPadding(2, 0, 2, 0)
            .setIcon(Identifier.withDefaultNamespace("icon/search"), 12, 12)
            .setCallback(
                s -> {
                    List<FrameworkSelectionList.Item> newItems = this.options
                        .entrySet()
                        .stream()
                        .filter(entry -> entry.getKey().toLowerCase(Locale.ROOT).contains(s.toLowerCase(Locale.ROOT)))
                        .map(Entry::getValue)
                        .map(item -> (FrameworkSelectionList.Item)item)
                        .toList();
                    this.list.replaceItems(newItems);
                }
            );
        if (buildSearchFieldListener != null) {
            buildSearchFieldListener.accept(searchFieldBuilder);
        }

        this.searchField = searchFieldBuilder.build();
        if (initialValue != null) {
            this.options
                .values()
                .stream()
                .filter(item -> initialValue.equals(item.value))
                .findAny()
                .ifPresent(item -> this.selected = (FrameworkSelect<T>.OptionItem)item);
        }

        if (!allowEmpty && this.selected == null) {
            this.selected = Optional.ofNullable(this.options.firstEntry()).map(Entry::getValue).orElse(null);
        }

        if (!allowEmpty && this.selected == null) {
            throw new IllegalArgumentException("There must be at least one option when allowEmpty is false");
        }

        this.updateActiveState();
        this.rebuildTooltip();
        this.setTooltipDelay(Duration.ofMillis(tooltipDelay));
    }

    public Class<T> getType() {
        return this.type;
    }

    public void setSelected(T selected) {
        for (FrameworkSelect<T>.OptionItem option : this.options.values()) {
            if (option.value == selected) {
                this.selected = option;
                this.triggerCallback();
                break;
            }
        }
    }

    private void setSelected(FrameworkSelect<T>.OptionItem item) {
        if (this.options.containsValue(item)) {
            this.selected = item;
            this.triggerCallback();
        }
    }

    private void triggerCallback() {
        if (this.callback != null && this.selected != null) {
            this.callback.accept(this.selected.value);
        }
    }

    @Nullable
    public T getSelected() {
        return this.selected != null ? this.selected.value : null;
    }

    private void updateActiveState() {
        if (this.activeSupplier != null) {
            this.active = this.activeSupplier.get();
        }
    }

    public void rebuildTooltip() {
        if (this.tooltip != null) {
            this.currentTooltip = this.tooltip.apply(this);
        }
    }

    private void updateTooltip() {
        if ((this.tooltipOptions & 2) != 0 && !this.shiftWasDown && Minecraft.getInstance().hasShiftDown() && this.isHovered()) {
            this.rebuildTooltip();
            this.shiftWasDown = true;
        }

        if (this.shiftWasDown && !Minecraft.getInstance().hasShiftDown()) {
            this.rebuildTooltip();
            this.shiftWasDown = false;
        }

        if ((this.tooltipOptions & 4) != 0) {
            if (this.isHovered()) {
                if (!this.mouseIsHovering) {
                    this.rebuildTooltip();
                    this.mouseIsHovering = true;
                }
            } else {
                this.mouseIsHovering = false;
            }
        }

        if (!this.active && (this.tooltipOptions & 1) != 0) {
            this.setTooltip(null);
        } else {
            this.setTooltip(this.currentTooltip);
        }
    }

    protected void extractWidgetRenderState(GuiGraphicsExtractor extractor, int mouseX, int mouseY, float partialTick) {
        this.updateActiveState();
        this.updateTooltip();
        if (this.texture != null) {
            float alpha = this.active ? 1.0F : 0.75F;
            extractor.blitSprite(
                RenderPipelines.GUI_TEXTURED,
                this.texture.get(this.active, this.isHoveredOrFocused() && this.active),
                this.getX(),
                this.getY(),
                this.getWidth(),
                this.getHeight(),
                alpha
            );
        }

        int textEnd = -1;
        if (this.iconFunction != null) {
            Icon icon = this.iconFunction.apply(this);
            if (icon != null) {
                int margin = Math.max((this.getHeight() - icon.height()) / 2, 0);
                int iconX = this.getX() + this.getWidth() - icon.width() - margin;
                int iconY = this.getY() + margin;
                int alpha = ARGB.white(this.active ? 1.0F : 0.5F);
                icon.draw(extractor, iconX, iconY, alpha, partialTick);
                textEnd = this.getWidth() - icon.width() - margin;
            }
        }

        if (this.selected != null) {
            int margin = Math.max((this.getHeight() - 8) / 2, 0);
            int maxWidth = (textEnd == -1 ? this.getWidth() - margin : textEnd - 4) - margin;
            Font font = Minecraft.getInstance().font;
            String label = this.selected.label.getString();
            if (font.width(label) > maxWidth) {
                label = font.plainSubstrByWidth(label, maxWidth - font.width("...")) + "...";
            }

            extractor.text(Minecraft.getInstance().font, label, this.getX() + margin, this.getY() + margin, -1);
        }
    }

    protected void updateWidgetNarration(NarrationElementOutput output) {
    }

    public void onClick(MouseButtonEvent event, boolean doubleClick) {
        if (this.dropdown != null) {
            this.dropdown.close();
        }

        Dropdown.Builder dropdownBuilder = (Dropdown.Builder)((Dropdown.Builder)((Dropdown.Builder)Dropdown.builder().setBackground(this.dropdownBackground))
                .setContentPadding(this.dropdownPadding))
            .setContent(dropdown -> {
                LinearLayout root = LinearLayout.vertical().spacing(4);
                if (this.searchable) {
                    root.addChild(this.searchField);
                }

                root.addChild(this.list);
                return root;
            });
        if (this.buildDropdownListener != null) {
            this.buildDropdownListener.accept(dropdownBuilder);
        }

        this.dropdown = dropdownBuilder.build();
        this.dropdown.show(this::updatePosition);
        this.list.scrollToItem(this.selected);
    }

    private void updatePosition(ScreenRectangle screenArea) {
        if (this.dropdown != null) {
            Margin outerMargin = this.dropdown.getOuterMargin();
            ScreenRectangle validArea = new ScreenRectangle(
                screenArea.left() + outerMargin.left(),
                screenArea.top() + outerMargin.top(),
                screenArea.width() - (outerMargin.left() + outerMargin.right()),
                screenArea.height() - (outerMargin.top() + outerMargin.bottom())
            );
            if (this.preferredAnchor == null || !this.applyAnchor(this.dropdown, this.preferredAnchor, validArea)) {
                for (Anchor anchor : ANCHOR_ORDER) {
                    if (anchor != this.preferredAnchor && this.applyAnchor(this.dropdown, anchor, validArea)) {
                        return;
                    }
                }

                Anchor.CENTERED.apply(this.dropdown, screenArea);
            }
        }
    }

    private boolean applyAnchor(Dropdown dropdown, Anchor anchor, ScreenRectangle validArea) {
        anchor.apply(dropdown, this);
        return this.isRectangleWithin(dropdown.getRectangle(), validArea);
    }

    private boolean isRectangleWithin(ScreenRectangle inner, ScreenRectangle outer) {
        return inner.left() >= outer.left() && inner.top() >= outer.top() && inner.right() <= outer.right() && inner.bottom() <= outer.bottom();
    }

    public static <T> FrameworkSelect.Builder<T> builder(Class<T> type, Function<T, Component> valueToLabel) {
        return new FrameworkSelect.Builder<>(type, valueToLabel);
    }

    // $VF: Compiled from FrameworkSelect.java
    public static class Builder<T> {
        private final Class<T> type;
        private final Function<T, Component> valueToLabel;
        private Supplier<List<T>> values = ArrayList::new;
        private int x;
        private int y;
        private int width = 50;
        private int height = 20;
        private boolean allowEmpty;
        private boolean searchable = true;
        @Nullable
        private T initialValue;
        @Nullable
        private Consumer<T> callback;
        @Nullable
        private Anchor preferredAnchor;
        @Nullable
        private WidgetSprites buttonTexture = FrameworkSelect.DEFAULT_SPRITES;
        private Function<FrameworkSelect<T>, @Nullable Icon> iconFunction = btn -> FrameworkSelect.DEFAULT_ICON;
        @Nullable
        private Identifier dropdownBackground = FrameworkSelect.DEFAULT_DROPDOWN_BACKGROUND;
        private Padding dropdownPadding = FrameworkSelect.DEFAULT_DROPDOWN_PADDING;
        private int dropdownMinWidth;
        private int visibleListItems = 6;
        @Nullable
        private Supplier<Boolean> active;
        @Nullable
        private Function<FrameworkSelect<T>, Tooltip> tooltip;
        private int tooltipDelay = 350;
        private int tooltipOptions;
        @Nullable
        private Consumer<FrameworkSelectionList.Builder> buildOptionListListener;
        @Nullable
        private Consumer<FrameworkEditBox.Builder> buildSearchFieldListener;
        @Nullable
        private Consumer<Dropdown.Builder> buildDropdownListener;

        private Builder(Class<T> type, Function<T, Component> valueToLabel) {
            this.type = type;
            this.valueToLabel = valueToLabel;
        }

        public FrameworkSelect<T> build() {
            return new FrameworkSelect<>(
                this.x,
                this.y,
                this.width,
                this.height,
                this.type,
                this.valueToLabel,
                this.values.get(),
                this.searchable,
                this.allowEmpty,
                this.initialValue,
                this.callback,
                this.preferredAnchor,
                this.buttonTexture,
                this.iconFunction,
                this.dropdownBackground,
                this.dropdownPadding,
                this.dropdownMinWidth,
                this.visibleListItems,
                this.active,
                this.tooltip,
                this.tooltipDelay,
                this.tooltipOptions,
                this.buildOptionListListener,
                this.buildSearchFieldListener,
                this.buildDropdownListener
            );
        }

        public FrameworkSelect.Builder<T> setX(int x) {
            this.x = x;
            return this;
        }

        public FrameworkSelect.Builder<T> setY(int y) {
            this.y = y;
            return this;
        }

        public FrameworkSelect.Builder<T> setPosition(int x, int y) {
            this.x = x;
            this.y = y;
            return this;
        }

        public FrameworkSelect.Builder<T> setWidth(int width) {
            this.width = width;
            return this;
        }

        public FrameworkSelect.Builder<T> setHeight(int height) {
            this.height = height;
            return this;
        }

        public FrameworkSelect.Builder<T> setSize(int width, int height) {
            this.width = width;
            this.height = height;
            return this;
        }

        public FrameworkSelect.Builder<T> setValues(Supplier<List<T>> values) {
            this.values = values;
            return this;
        }

        public FrameworkSelect.Builder<T> setAllowEmpty(boolean allowEmpty) {
            this.allowEmpty = allowEmpty;
            return this;
        }

        public FrameworkSelect.Builder<T> setSearchable(boolean searchable) {
            this.searchable = searchable;
            return this;
        }

        public FrameworkSelect.Builder<T> setInitialValue(T initialValue) {
            this.initialValue = initialValue;
            return this;
        }

        public FrameworkSelect.Builder<T> setCallback(@Nullable Consumer<T> callback) {
            this.callback = callback;
            return this;
        }

        public FrameworkSelect.Builder<T> setPreferredAnchor(@Nullable Anchor anchor) {
            this.preferredAnchor = anchor;
            return this;
        }

        public FrameworkSelect.Builder<T> setButtonTexture(@Nullable WidgetSprites sprites) {
            this.buttonTexture = sprites;
            return this;
        }

        public FrameworkSelect.Builder<T> noButtonTexture() {
            this.buttonTexture = null;
            return this;
        }

        public FrameworkSelect.Builder<T> setButtonIcon(Function<FrameworkSelect<T>, Icon> icon) {
            this.iconFunction = icon;
            return this;
        }

        public FrameworkSelect.Builder<T> noButtonIcon() {
            this.iconFunction = select -> null;
            return this;
        }

        public FrameworkSelect.Builder<T> setDropdownBackground(@Nullable Identifier sprite) {
            this.dropdownBackground = sprite;
            return this;
        }

        public FrameworkSelect.Builder<T> setDropdownPadding(Padding padding) {
            this.dropdownPadding = padding;
            return this;
        }

        public FrameworkSelect.Builder<T> setDropdownMinWidth(int width) {
            this.dropdownMinWidth = width;
            return this;
        }

        public FrameworkSelect.Builder<T> setVisibleListItems(int visibleListItems) {
            this.visibleListItems = visibleListItems;
            return this;
        }

        public FrameworkSelect.Builder<T> setDependent(@Nullable Supplier<Boolean> active) {
            this.active = active;
            return this;
        }

        public FrameworkSelect.Builder<T> setTooltip(Tooltip tooltip) {
            this.tooltip = btn -> tooltip;
            return this;
        }

        public FrameworkSelect.Builder<T> setTooltip(@Nullable Function<FrameworkSelect<T>, Tooltip> tooltip) {
            this.tooltip = tooltip;
            return this;
        }

        public FrameworkSelect.Builder<T> setTooltipDelay(int delay) {
            this.tooltipDelay = delay;
            return this;
        }

        public FrameworkSelect.Builder<T> setTooltipOptions(int option, int... options) {
            for (int flag : options) {
                option |= flag;
            }

            this.tooltipOptions = option;
            return this;
        }

        public FrameworkSelect.Builder<T> setOnBuildOptionListListener(Consumer<FrameworkSelectionList.Builder> listener) {
            this.buildOptionListListener = listener;
            return this;
        }

        public FrameworkSelect.Builder<T> setOnBuildSearchFieldListener(Consumer<FrameworkEditBox.Builder> listener) {
            this.buildSearchFieldListener = listener;
            return this;
        }

        public FrameworkSelect.Builder<T> setOnBuildDropdownListener(Consumer<Dropdown.Builder> listener) {
            this.buildDropdownListener = listener;
            return this;
        }
    }

    // $VF: Compiled from FrameworkSelect.java
    private class OptionItem extends FrameworkSelectionList.Item {
        private final String key;
        private final Component label;
        @Nullable
        private final T value;

        public OptionItem(@Nullable T value, Component label) {
            this.key = label.getString();
            this.label = label;
            this.value = value;
        }

        public String getKey() {
            return this.key;
        }

        @Override
        public boolean isSelectable() {
            return false;
        }

        public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
            if (FrameworkSelect.this.dropdown != null) {
                FrameworkSelect.this.setSelected(this);
                FrameworkSelect.this.dropdown.close();
                return true;
            } else {
                return false;
            }
        }

        @Override
        protected void extractContent(GuiGraphicsExtractor extractor, int mouseX, int mouseY, boolean hovered, boolean selected, float partialTick) {
            extractor.centeredText(Minecraft.getInstance().font, this.label, this.getX() + this.getWidth() / 2, this.getY() + 4, -1);
        }

        @Override
        protected void extractBackground(
            FrameworkSelectionList.@Nullable ItemSprites sprites, GuiGraphicsExtractor extractor, int mouseX, int mouseY, boolean hovered, boolean selected
        ) {
            selected = FrameworkSelect.this.selected == this || hovered;
            super.extractBackground(sprites, extractor, mouseX, mouseY, hovered, selected);
        }
    }
}
