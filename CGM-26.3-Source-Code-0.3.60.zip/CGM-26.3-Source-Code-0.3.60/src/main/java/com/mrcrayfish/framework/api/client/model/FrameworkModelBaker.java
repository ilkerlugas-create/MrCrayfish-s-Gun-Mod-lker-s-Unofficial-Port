package com.mrcrayfish.framework.api.client.model;

import net.minecraft.client.resources.model.ModelBaker;
import net.minecraft.client.resources.model.ResolvedModel;

// $VF: Compiled from FrameworkModelBaker.java
public interface FrameworkModelBaker<T> {
    T bake(ResolvedModel var1, ModelBaker var2);
}
