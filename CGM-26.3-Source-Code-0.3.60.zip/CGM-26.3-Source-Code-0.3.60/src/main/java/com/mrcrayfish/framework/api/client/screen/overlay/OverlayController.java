package com.mrcrayfish.framework.api.client.screen.overlay;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.List;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.events.ContainerEventHandler;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.ApiStatus.Internal;
import org.joml.Matrix3x2fStack;

// $VF: Compiled from OverlayController.java
public final class OverlayController implements ContainerEventHandler {
    private final Overlayable overlayable;
    private final Deque<Overlay> stack = new ArrayDeque<>();
    @Nullable
    GuiEventListener focused;
    boolean dragging;

    public OverlayController(Overlayable overlayable) {
        this.overlayable = overlayable;
    }

    boolean open(Overlay overlay) {
        Overlayable owner = overlay.owner;
        if (owner != null && owner != this.overlayable) {
            return false;
        }

        if (this.stack.contains(overlay)) {
            return false;
        }

        this.setFocused(null);
        this.bind(overlay);
        this.stack.push(overlay);
        return true;
    }

    void close(Overlay overlay) {
        Overlayable owner = overlay.owner;
        if (owner != null && owner == this.overlayable) {
            if (this.stack.contains(overlay)) {
                while (!this.stack.isEmpty()) {
                    Overlay current = this.stack.pop();
                    this.unbind(current);
                    if (current.equals(overlay)) {
                        break;
                    }
                }

                this.setFocused(null);
            }
        }
    }

    public void closeAll() {
        while (!this.stack.isEmpty()) {
            Overlay overlay = this.stack.pop();
            this.unbind(overlay);
        }

        this.setFocused(null);
    }

    public void closeAbove(Overlay target) {
        if (this.stack.contains(target)) {
            while (!target.equals(this.stack.peek())) {
                this.unbind(this.stack.pop());
                this.setFocused(null);
            }
        }
    }

    private void bind(Overlay overlay) {
        overlay.owner = this.overlayable;
        overlay.onOpened();
    }

    private void unbind(Overlay overlay) {
        overlay.owner = null;
        overlay.onClosed();
    }

    @Internal
    public boolean blocksInput() {
        return !this.stack.isEmpty();
    }

    public void render(GuiGraphicsExtractor extractor, int mouseX, int mouseY, float partialTick) {
        Matrix3x2fStack pose = extractor.pose();

        for (Overlay overlay : this.stack) {
            extractor.nextStratum();
            overlay.renderBackground(extractor);
            overlay.render(extractor, mouseX, mouseY, partialTick);
        }
    }

    public List<? extends GuiEventListener> children() {
        Overlay top = this.stack.peek();
        return top != null ? top.getWidgets() : List.of();
    }

    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (super.mouseClicked(event, doubleClick)) {
            return true;
        }

        for (Overlay overlay : this.stack) {
            if (overlay.getInteractableArea().containsPoint((int)event.x(), (int)event.y())) {
                this.setFocused(null);
                this.closeAbove(overlay);
                return true;
            }
        }

        this.closeAll();
        return true;
    }

    public boolean keyPressed(KeyEvent event) {
        if (event.key() == 41) {
            Overlay overlay = this.stack.peek();
            if (overlay != null) {
                this.close(overlay);
                return true;
            }
        }

        return super.keyPressed(event);
    }

    @Nullable
    public GuiEventListener getFocused() {
        return this.focused;
    }

    public void setFocused(@Nullable GuiEventListener listener) {
        if (this.focused != null) {
            this.focused.setFocused(false);
        }

        if (listener != null) {
            listener.setFocused(true);
        }

        this.focused = listener;
    }

    public boolean isDragging() {
        return this.dragging;
    }

    public void setDragging(boolean dragging) {
        this.dragging = dragging;
    }
}
