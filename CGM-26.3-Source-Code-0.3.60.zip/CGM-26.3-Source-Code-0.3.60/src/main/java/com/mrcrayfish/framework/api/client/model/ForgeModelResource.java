package com.mrcrayfish.framework.api.client.model;

import net.minecraft.resources.Identifier;

// $VF: Compiled from ForgeModelResource.java
public class ForgeModelResource<T> extends FrameworkModelResource<T> {
    public ForgeModelResource(Identifier location, FrameworkModelBaker<T> modelBaker) {
        super(location, modelBaker);
    }
}
