package com.mrcrayfish.framework.api.client;

import com.mrcrayfish.framework.api.serialize.DataObject;
import com.mrcrayfish.framework.client.JsonDataManager;
import com.mrcrayfish.framework.client.model.OpenModelHelper;
import com.mrcrayfish.framework.client.resources.IDataLoader;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;

// $VF: Compiled from FrameworkClientAPI.java
public class FrameworkClientAPI {
    public static synchronized void registerDataLoader(IDataLoader<?> loader) {
        JsonDataManager.getInstance().addLoader(loader);
    }

    public static DataObject getOpenModelData(BlockState state) {
        return OpenModelHelper.getData(state);
    }

    public static DataObject getOpenModelData(Item item) {
        return OpenModelHelper.getData(item);
    }

    public static DataObject getOpenModelData(ItemStack stack) {
        return OpenModelHelper.getData(stack);
    }
}
