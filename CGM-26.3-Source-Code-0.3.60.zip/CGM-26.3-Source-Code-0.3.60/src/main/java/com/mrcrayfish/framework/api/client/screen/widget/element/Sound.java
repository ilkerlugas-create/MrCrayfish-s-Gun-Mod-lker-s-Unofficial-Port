package com.mrcrayfish.framework.api.client.screen.widget.element;

import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.core.Holder;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.util.RandomSource;

// $VF: Compiled from Sound.java
public abstract class Sound {
    public static final float DEFAULT_UI_VOLUME = 0.25F;
    public static final float DEFAULT_UI_PITCH = 1.0F;

    public abstract SoundEvent value();

    public abstract float volume();

    public abstract float pitch();

    public static Sound create(Holder<SoundEvent> holder) {
        return new Sound.Impl(holder::value, rand -> 0.25F, rand -> 1.0F);
    }

    public static Sound create(Holder<SoundEvent> holder, float volume, float pitch) {
        return new Sound.Impl(holder::value, rand -> volume, rand -> pitch);
    }

    public static Sound create(Holder<SoundEvent> holder, Function<RandomSource, Float> volumeFunction, Function<RandomSource, Float> pitchFunction) {
        return new Sound.Impl(holder::value, volumeFunction, pitchFunction);
    }

    public static Sound create(SoundEvent event) {
        return new Sound.Impl(() -> event, rand -> 0.25F, rand -> 1.0F);
    }

    public static Sound create(SoundEvent event, float volume, float pitch) {
        return new Sound.Impl(() -> event, rand -> volume, rand -> pitch);
    }

    public static Sound create(SoundEvent event, Function<RandomSource, Float> volumeFunction, Function<RandomSource, Float> pitchFunction) {
        return new Sound.Impl(() -> event, volumeFunction, pitchFunction);
    }

    public static Sound create(Supplier<SoundEvent> sound) {
        return new Sound.Impl(sound, rand -> 0.25F, rand -> 1.0F);
    }

    public static Sound create(Supplier<SoundEvent> sound, float volume, float pitch) {
        return new Sound.Impl(sound, rand -> volume, rand -> pitch);
    }

    public static Sound create(Supplier<SoundEvent> sound, Function<RandomSource, Float> volumeFunction, Function<RandomSource, Float> pitchFunction) {
        return new Sound.Impl(sound, volumeFunction, pitchFunction);
    }

    // $VF: Compiled from Sound.java
    private static class Impl extends Sound {
        private static final RandomSource RANDOM = RandomSource.create();
        private final Supplier<SoundEvent> soundSupplier;
        private final Function<RandomSource, Float> volumeFunction;
        private final Function<RandomSource, Float> pitchFunction;

        private Impl(Supplier<SoundEvent> soundSupplier, Function<RandomSource, Float> volumeFunction, Function<RandomSource, Float> pitchFunction) {
            this.soundSupplier = soundSupplier;
            this.volumeFunction = volumeFunction;
            this.pitchFunction = pitchFunction;
        }

        @Override
        public SoundEvent value() {
            return this.soundSupplier.get();
        }

        @Override
        public float volume() {
            return this.volumeFunction.apply(RANDOM);
        }

        @Override
        public float pitch() {
            return this.pitchFunction.apply(RANDOM);
        }
    }
}
