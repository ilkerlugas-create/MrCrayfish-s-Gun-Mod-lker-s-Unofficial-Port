package com.mrcrayfish.framework.api.client.screen.overlay.impl;

import com.google.common.annotations.Beta;
import com.mrcrayfish.framework.api.client.screen.Anchor;
import com.mrcrayfish.framework.api.client.screen.overlay.Window;
import com.mrcrayfish.framework.api.client.screen.widget.layout.Margin;
import com.mrcrayfish.framework.api.client.screen.widget.layout.Padding;
import java.util.function.Function;
import net.minecraft.client.gui.layouts.Layout;
import net.minecraft.client.gui.layouts.LayoutElement;
import net.minecraft.resources.Identifier;
import org.jetbrains.annotations.Nullable;

// $VF: Compiled from Dropdown.java
@Beta
public final class Dropdown extends Window {
    private Dropdown(@Nullable Function<Dropdown, Layout> content, Margin outerMargin, Padding contentPadding, Identifier background) {
        super(content, outerMargin, contentPadding, background);
    }

    public void show(LayoutElement element, Anchor anchor) {
        this.show(bounds -> {
            anchor.apply(this, element);
            this.clampToBounds(bounds);
        });
    }

    public static Dropdown.Builder builder() {
        return new Dropdown.Builder();
    }

    // $VF: Compiled from Dropdown.java
    public static final class Builder extends Window.Builder<Dropdown.Builder, Dropdown> {
        private Builder() {
        }

        public Dropdown build() {
            return new Dropdown(this.layout, this.outerMargin, this.contentPadding, this.background);
        }
    }
}
