package com.mrcrayfish.framework.api;

import com.mrcrayfish.framework.api.menu.IMenuData;
import com.mrcrayfish.framework.api.network.FrameworkNetworkBuilder;
import com.mrcrayfish.framework.api.sync.SyncedDataKey;
import com.mrcrayfish.framework.entity.sync.SyncedEntityData;
import com.mrcrayfish.framework.platform.Services;
import java.util.OptionalInt;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.Entity;

// $VF: Compiled from FrameworkAPI.java
public class FrameworkAPI {
    public static FrameworkNetworkBuilder createNetworkBuilder(Identifier id, int version) {
        return Services.NETWORK.createNetworkBuilder(id, version);
    }

    public static <D extends IMenuData<D>> OptionalInt openMenuWithData(ServerPlayer player, MenuProvider provider, D data) {
        return Services.NETWORK.openMenuWithData(player, provider, data);
    }

    public static <E extends Entity, T> void registerSyncedDataKey(SyncedDataKey<E, T> key) {
        SyncedEntityData.instance().registerDataKey(key);
    }

    public static Environment getEnvironment() {
        return Services.PLATFORM.getEnvironment();
    }
}
