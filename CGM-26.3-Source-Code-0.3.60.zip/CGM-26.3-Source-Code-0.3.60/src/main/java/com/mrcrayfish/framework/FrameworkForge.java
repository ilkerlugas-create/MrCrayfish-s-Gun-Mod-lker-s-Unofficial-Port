package com.mrcrayfish.framework;

import com.mrcrayfish.framework.api.registry.BlockRegistryEntry;
import com.mrcrayfish.framework.event.ForgeEvents;
import java.lang.invoke.MethodHandles;
import net.minecraft.core.registries.Registries;
import net.minecraftforge.eventbus.api.bus.BusGroup;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLLoadCompleteEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.RegisterEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

// $VF: Compiled from FrameworkForge.java
@Mod("framework")
public class FrameworkForge {
    public static final Logger LOGGER = LogManager.getLogger("Framework");

    public FrameworkForge(FMLJavaModLoadingContext context) {
        FrameworkSetup.run();
        BusGroup modBusGroup = context.getModBusGroup();
        FMLCommonSetupEvent.getBus(modBusGroup).addListener(this::onCommonSetup);
        FMLLoadCompleteEvent.getBus(modBusGroup).addListener(this::onLoadComplete);
        RegisterEvent.getBus(modBusGroup).addListener(this::onRegister);
        BusGroup.DEFAULT.register(MethodHandles.lookup(), new ForgeEvents());
    }

    private void onCommonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(FrameworkSetup::init);
    }

    private void onRegister(RegisterEvent event) {
        Registration.get(event.getRegistryKey())
            .forEach(entry -> entry.register((registryKey, key, valueSupplier) -> event.register(registryKey, key.identifier(), valueSupplier)));
        if (event.getRegistryKey().equals(Registries.ITEM)) {
            Registration.get(Registries.BLOCK).forEach(entry -> {
                if (entry instanceof BlockRegistryEntry<?, ?> blockEntry) {
                    blockEntry.item().ifPresent(item -> event.register(Registries.ITEM, entry.getId(), () -> item));
                }
            });
        }
    }

    private void onLoadComplete(FMLLoadCompleteEvent event) {
        FrameworkData.setLoaded();
    }
}
