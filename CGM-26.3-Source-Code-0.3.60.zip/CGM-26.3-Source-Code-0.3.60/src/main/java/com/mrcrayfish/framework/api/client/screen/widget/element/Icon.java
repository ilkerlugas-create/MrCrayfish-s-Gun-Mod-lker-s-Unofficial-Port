package com.mrcrayfish.framework.api.client.screen.widget.element;

import java.util.function.Supplier;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;

// $VF: Compiled from Icon.java
public abstract class Icon {
    public abstract int width();

    public abstract int height();

    public abstract void draw(GuiGraphicsExtractor var1, int var2, int var3, int var4, float var5);

    public static Icon sprite(Identifier resource, int width, int height) {
        return new Icon.Sprite(resource, width, height);
    }

    public static Icon sprite(Supplier<Identifier> resource, int width, int height) {
        return new Icon.Sprite(resource, width, height);
    }

    // $VF: Compiled from Icon.java
    private static final class Sprite extends Icon {
        private final Supplier<Identifier> resource;
        private final int width;
        private final int height;

        private Sprite(Supplier<Identifier> resource, int width, int height) {
            this.resource = resource;
            this.width = width;
            this.height = height;
        }

        private Sprite(Identifier resource, int width, int height) {
            this(() -> resource, width, height);
        }

        @Override
        public int width() {
            return this.width;
        }

        @Override
        public int height() {
            return this.height;
        }

        @Override
        public void draw(GuiGraphicsExtractor extractor, int x, int y, int alpha, float partialTick) {
            extractor.blitSprite(RenderPipelines.GUI_TEXTURED, this.resource.get(), x, y, this.width, this.height, alpha);
        }
    }
}
