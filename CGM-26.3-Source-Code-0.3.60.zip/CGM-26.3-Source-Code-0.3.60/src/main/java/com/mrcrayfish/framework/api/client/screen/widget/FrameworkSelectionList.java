package com.mrcrayfish.framework.api.client.screen.widget;

import com.google.common.collect.ImmutableMap;
import com.mrcrayfish.framework.api.client.screen.widget.layout.Border;
import com.mrcrayfish.framework.api.client.screen.widget.layout.Padding;
import com.mrcrayfish.framework.client.ClientUtils;
import com.mrcrayfish.framework.platform.ClientServices;
import com.mrcrayfish.framework.util.Utils;
import java.util.Collection;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.ObjectSelectionList;
import net.minecraft.client.gui.components.ObjectSelectionList.Entry;
import net.minecraft.client.gui.components.events.ContainerEventHandler;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.util.ARGB;
import net.minecraft.util.Mth;
import org.jetbrains.annotations.Nullable;

// $VF: Compiled from FrameworkSelectionList.java
public class FrameworkSelectionList extends ObjectSelectionList<FrameworkSelectionList.Item> {
    public static final Identifier DEFAULT_BACKGROUND = Utils.rl("widget/selection_list/background");
    public static final FrameworkSelectionList.ItemSprites DEFAULT_ITEM_SPRITE = FrameworkSelectionList.ItemSprites.builder()
        .setEnabledSelected(Utils.rl("widget/selection_list/item_enabled_selected"))
        .setEnabledHoveredSelected(Utils.rl("widget/selection_list/item_enabled_selected"))
        .build();
    public static final Padding DEFAULT_LIST_PADDING = Padding.of(4);
    public static final Border DEFAULT_LIST_BORDER = Border.of(0);
    public static final FrameworkSelectionList.ScrollerSprites DEFAULT_SCROLLER_SPRITE = FrameworkSelectionList.ScrollerSprites.of(
        Identifier.withDefaultNamespace("widget/scroller")
    );
    public static final Identifier DEFAULT_SCROLL_BAR_BACKGROUND = Identifier.withDefaultNamespace("widget/scroller_background");
    public static final Padding DEFAULT_SCROLL_BAR_PADDING = Padding.of(0);
    public static final Border DEFAULT_SCROLL_BAR_BORDER = Border.of(0);
    public static final Padding DEFAULT_SCROLL_BAR_CONTAINER_PADDING = Padding.of(0);
    public static final int DEFAULT_SCROLL_BAR_SPACING = 4;
    public static final int DEFAULT_SCROLLER_WIDTH = 6;
    public static final int DEFAULT_MIN_SCROLLER_HEIGHT = 32;
    public static final int DEFAULT_ITEM_HEIGHT = 20;
    public static final int DEFAULT_ITEM_SPACING = 0;
    @Nullable
    protected FrameworkSelectionList.ItemSprites itemSprites;
    protected int itemSpacing;
    @Nullable
    protected Identifier listBackground;
    protected Border listBorder = Border.ZERO;
    protected Padding listPadding = Padding.ZERO;
    protected boolean scrollBarAlwaysVisible;
    protected int scrollBarSpacing;
    protected FrameworkSelectionList.ScrollBarStyle scrollBarStyle = FrameworkSelectionList.ScrollBarStyle.DETACHED;
    @Nullable
    protected FrameworkSelectionList.ScrollerSprites scrollerSprites;
    protected int scrollerWidth = 6;
    protected int minScrollerHeight = 32;
    @Nullable
    protected Identifier scrollBarBackground;
    protected Border scrollBarBorder = Border.ZERO;
    protected Padding scrollBarPadding = Padding.ZERO;
    protected Padding scrollBarContainerPadding = Padding.ZERO;
    @Nullable
    protected Supplier<Boolean> activeSupplier;
    protected boolean scrolling;
    protected boolean ignoreReposition;

    protected FrameworkSelectionList(int width, int height, int x, int y, int itemHeight) {
        super(Minecraft.getInstance(), width, height, y, itemHeight);
    }

    private FrameworkSelectionList(
        int x,
        int y,
        int width,
        int height,
        int itemHeight,
        @Nullable FrameworkSelectionList.ItemSprites itemSprites,
        int itemSpacing,
        @Nullable Identifier listBackground,
        Border listBorder,
        Padding listPadding,
        boolean scrollBarAlwaysVisible,
        int scrollBarSpacing,
        FrameworkSelectionList.ScrollBarStyle scrollBarStyle,
        @Nullable FrameworkSelectionList.ScrollerSprites scrollerSprites,
        int scrollerWidth,
        int minScrollerHeight,
        @Nullable Identifier scrollBarBackground,
        Border scrollBarBorder,
        Padding scrollBarPadding,
        Padding scrollBarContainerPadding,
        @Nullable Supplier<Boolean> activeSupplier,
        @Nullable Consumer<Consumer<FrameworkSelectionList.Item>> itemsSupplier
    ) {
        this(width, height, x, y, itemHeight);
        this.itemSprites = itemSprites;
        this.itemSpacing = itemSpacing;
        this.listBackground = listBackground;
        this.listBorder = listBorder;
        this.listPadding = listPadding;
        this.scrollBarAlwaysVisible = scrollBarAlwaysVisible;
        this.scrollBarSpacing = scrollBarSpacing;
        this.scrollBarStyle = scrollBarStyle;
        this.scrollerSprites = scrollerSprites;
        this.scrollerWidth = scrollerWidth;
        this.minScrollerHeight = minScrollerHeight;
        this.scrollBarBackground = scrollBarBackground;
        this.scrollBarBorder = scrollBarBorder;
        this.scrollBarPadding = scrollBarPadding;
        this.scrollBarContainerPadding = scrollBarContainerPadding;
        this.activeSupplier = activeSupplier;
        if (itemsSupplier != null) {
            itemsSupplier.accept(this::addItem);
        }

        this.setPosition(x, y);
    }

    public void setPosition(int x, int y) {
        this.ignoreReposition = true;
        super.setPosition(x, y);
        this.ignoreReposition = false;
        this.repositionItems();
    }

    public void setX(int x) {
        super.setX(x);
        this.repositionItems();
    }

    public void setY(int y) {
        super.setY(y);
        this.repositionItems();
    }

    public boolean isMouseOver(double mouseX, double mouseY) {
        return mouseY >= this.getY() && mouseY <= this.getY() + this.getHeight() && mouseX >= this.getX() && mouseX <= this.getX() + this.getWidth();
    }

    public int getRowWidth() {
        return this.getRowRight() - this.getRowLeft();
    }

    public int getRowLeft() {
        return this.getX() + this.listBorder.left() + this.listPadding.left();
    }

    public int getRowRight() {
        if (this.maxScrollAmount() <= 0 && !this.scrollBarAlwaysVisible) {
            return this.getX() + this.getWidth() - this.listPadding.right() - this.listBorder.right();
        }

        int scrollBarArea = switch (this.scrollBarStyle) {
            case DETACHED -> this.listPadding.right()
                + this.listBorder.right()
                + this.scrollBarSpacing
                + this.scrollBarContainerPadding.left()
                + this.scrollBarBorder.left()
                + this.scrollBarPadding.left()
                + this.scrollerWidth
                + this.scrollBarPadding.right()
                + this.scrollBarBorder.right()
                + this.scrollBarContainerPadding.right();
            case MERGED -> this.scrollBarSpacing
                + this.scrollBarContainerPadding.left()
                + this.scrollBarBorder.left()
                + this.scrollBarPadding.left()
                + this.scrollerWidth
                + this.scrollBarPadding.right()
                + this.scrollBarBorder.right()
                + this.scrollBarContainerPadding.right()
                + this.listPadding.right()
                + this.listBorder.right();
        };
        return this.getX() + this.getWidth() - scrollBarArea;
    }

    public int getFirstItemY() {
        return this.getY() + this.listBorder.top() + this.listPadding.top();
    }

    public void repositionItems() {
        if (!this.ignoreReposition) {
            int nextY = this.getFirstItemY() - (int)this.scrollAmount();

            for (FrameworkSelectionList.Item item : this.children()) {
                item.setY(nextY);
                nextY += item.getHeight();
                nextY += this.itemSpacing;
                item.setX(this.getRowLeft());
                item.setWidth(this.getRowWidth());
            }
        }
    }

    public int getNextY() {
        int nextY = this.getFirstItemY() - (int)this.scrollAmount();

        for (FrameworkSelectionList.Item item : this.children()) {
            nextY += item.getHeight();
            nextY += this.itemSpacing;
        }

        return nextY;
    }

    protected int scrollBarX() {
        int offset = switch (this.scrollBarStyle) {
            case DETACHED -> this.scrollerWidth + this.scrollBarPadding.right() + this.scrollBarBorder.right() + this.scrollBarContainerPadding.right();
            case MERGED -> this.scrollerWidth
                + this.scrollBarPadding.right()
                + this.scrollBarBorder.right()
                + this.scrollBarContainerPadding.right()
                + this.listPadding.right()
                + this.listBorder.right();
        };
        return this.getX() + this.getWidth() - offset;
    }

    protected int getScrollbarHeight() {
        if (this.scrollBarAlwaysVisible && this.maxScrollAmount() <= 0) {
            return this.minScrollerHeight;
        }

        int scrollAreaHeight = this.getScrollAreaHeight();
        int scrollBarHeight = (int)((float)Mth.square(scrollAreaHeight) / this.contentHeight());
        return Mth.clamp(scrollBarHeight, this.minScrollerHeight, scrollAreaHeight);
    }

    protected int getScrollAreaHeight() {
        int offset = switch (this.scrollBarStyle) {
            case DETACHED -> this.scrollBarContainerPadding.top()
                + this.scrollBarBorder.top()
                + this.scrollBarPadding.top()
                + this.scrollBarPadding.bottom()
                + this.scrollBarBorder.bottom()
                + this.scrollBarContainerPadding.bottom();
            case MERGED -> this.listBorder.top()
                + this.listPadding.top()
                + this.scrollBarContainerPadding.top()
                + this.scrollBarBorder.top()
                + this.scrollBarPadding.top()
                + this.scrollBarPadding.bottom()
                + this.scrollBarBorder.bottom()
                + this.scrollBarContainerPadding.bottom()
                + this.listPadding.bottom()
                + this.listBorder.bottom();
        };
        return this.getHeight() - offset;
    }

    protected int getScrollAreaTop() {
        int offset = switch (this.scrollBarStyle) {
            case DETACHED -> this.scrollBarContainerPadding.top() + this.scrollBarBorder.top() + this.scrollBarPadding.top();
            case MERGED -> this.listBorder.top()
                + this.listPadding.top()
                + this.scrollBarContainerPadding.top()
                + this.scrollBarBorder.top()
                + this.scrollBarPadding.top();
        };
        return this.getY() + offset;
    }

    public int maxScrollAmount() {
        return Math.max(
            0, this.contentHeight() - this.height + this.listBorder.top() + this.listPadding.top() + this.listPadding.bottom() + this.listBorder.bottom()
        );
    }

    protected int contentHeight() {
        int height = 0;

        for (FrameworkSelectionList.Item item : this.children()) {
            height += item.getHeight();
            height += this.itemSpacing;
        }

        return Math.max(0, height - this.itemSpacing);
    }

    public void extractWidgetRenderState(GuiGraphicsExtractor extractor, int mouseX, int mouseY, float partialTick) {
        if (this.activeSupplier != null) {
            this.active = this.activeSupplier.get();
        }

        this.extractListBackground(extractor, mouseX, mouseY, partialTick);
        this.extractListItems(extractor, mouseX, mouseY, partialTick);
        this.extractScrollbar(extractor, mouseX, mouseY);
    }

    protected int getListBackgroundWidth() {
        return switch (this.scrollBarStyle) {
            case DETACHED -> this.listBorder.left() + this.listPadding.left() + this.getRowWidth() + this.listPadding.right() + this.listBorder.right();
            case MERGED -> this.getWidth();
        };
    }

    protected int getListBackgroundHeight() {
        return this.getHeight();
    }

    protected void extractListBackground(GuiGraphicsExtractor extractor, int mouseX, int mouseY, float partialTick) {
        if (this.listBackground != null) {
            extractor.blitSprite(
                RenderPipelines.GUI_TEXTURED, this.listBackground, this.getX(), this.getY(), this.getListBackgroundWidth(), this.getListBackgroundHeight()
            );
        }
    }

    protected void extractScrollbar(GuiGraphicsExtractor extractor, int mouseX, int mouseY) {
        int maxScroll = this.maxScrollAmount();
        if (maxScroll > 0 || this.scrollBarAlwaysVisible) {
            if (this.scrollBarBackground != null) {
                int scrollBarTop = this.getY();
                if (this.scrollBarStyle == FrameworkSelectionList.ScrollBarStyle.MERGED) {
                    scrollBarTop += this.listBorder.top() + this.listPadding.top() + this.scrollBarContainerPadding.top();
                }

                int scrollBarLeft = this.scrollBarX() - this.scrollBarPadding.left() - this.scrollBarBorder.left();
                int scrollBarAreaWidth = this.scrollBarBorder.left()
                    + this.scrollBarPadding.left()
                    + this.scrollerWidth
                    + this.scrollBarPadding.right()
                    + this.scrollBarBorder.right();
                int scrollBarAreaHeight = this.getHeight() - this.scrollBarContainerPadding.top() - this.scrollBarContainerPadding.bottom();
                if (this.scrollBarStyle == FrameworkSelectionList.ScrollBarStyle.MERGED) {
                    scrollBarAreaHeight -= this.listBorder.top() + this.listPadding.top() + this.listPadding.bottom() + this.listBorder.bottom();
                }

                extractor.blitSprite(
                    RenderPipelines.GUI_TEXTURED, this.scrollBarBackground, scrollBarLeft, scrollBarTop, scrollBarAreaWidth, scrollBarAreaHeight
                );
            }

            boolean scrollBarEnabled = maxScroll > 0 && this.isActive();
            int scrollBarStart = this.scrollBarX();
            int scrollBarEnd = scrollBarStart + this.scrollerWidth;
            int scrollBarHeight = this.getScrollbarHeight();
            int scrollBarTop = (int)(
                this.getScrollAreaTop() + (this.getScrollAreaHeight() - this.getScrollbarHeight()) * (this.scrollAmount() / Math.max(maxScroll, 1))
            );
            boolean scrollBarHovered = ClientUtils.isPointInArea(mouseX, mouseY, scrollBarStart, scrollBarTop, this.scrollerWidth, scrollBarHeight);
            if (this.scrollerSprites != null) {
                Identifier sprite = this.scrollerSprites.get(scrollBarEnabled, scrollBarHovered, this.scrolling);
                if (sprite != null) {
                    int alpha = ARGB.white(this.active ? 1.0F : 0.5F);
                    extractor.blitSprite(
                        RenderPipelines.GUI_TEXTURED, sprite, scrollBarStart, scrollBarTop, scrollBarEnd - scrollBarStart, scrollBarHeight, alpha
                    );
                }
            } else {
                int scrollBarColour = scrollBarHovered ? -13423059 : -12107714;
                extractor.fill(scrollBarStart, scrollBarTop, scrollBarEnd, scrollBarTop + scrollBarHeight, scrollBarColour);
            }
        }
    }

    protected void extractListItems(GuiGraphicsExtractor extractor, int mouseX, int mouseY, float partialTick) {
        extractor.enableScissor(
            this.getRowLeft(), this.getY() + this.listBorder.top(), this.getRowRight(), this.getY() + this.getHeight() - this.listBorder.bottom()
        );

        for (FrameworkSelectionList.Item item : this.children()) {
            if (item.getY() + item.getHeight() >= this.getY() && item.getY() <= this.getBottom()) {
                this.extractItem(extractor, mouseX, mouseY, partialTick, item);
            }
        }

        extractor.disableScissor();
    }

    protected void extractItem(GuiGraphicsExtractor extractor, int mouseX, int mouseY, float partialTick, FrameworkSelectionList.Item item) {
        boolean hovered = !this.scrolling && item.isMouseOver(mouseX, mouseY) && this.isMouseOver(mouseX, mouseY);
        boolean selected = this.getSelected() == item;
        item.setHovered(hovered);
        item.extractBackground(this.itemSprites, extractor, mouseX, mouseY, hovered, selected);
        item.extractContent(extractor, mouseX, mouseY, selected, partialTick);
    }

    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (this.isActive() && this.isValidClickButton(event.buttonInfo())) {
            this.updateScrolling(event);
            if (!this.isMouseOver(event.x(), event.y())) {
                return false;
            }

            FrameworkSelectionList.Item item = (FrameworkSelectionList.Item)this.getEntryAtPosition(event.x(), event.y());
            if (item != null && item.mouseClicked(event, doubleClick)) {
                FrameworkSelectionList.Item focused = (FrameworkSelectionList.Item)this.getFocused();
                if (focused != item && focused instanceof ContainerEventHandler handler) {
                    handler.setFocused(null);
                }

                this.setFocused(item);
                this.setDragging(true);
                return true;
            } else {
                return this.scrolling;
            }
        } else {
            return false;
        }
    }

    public boolean mouseReleased(MouseButtonEvent event) {
        this.scrolling = false;
        return super.mouseReleased(event);
    }

    public boolean mouseDragged(MouseButtonEvent event, double deltaX, double deltaY) {
        if (event.button() == 1) {
            if (this.getFocused() != null && this.isDragging() && ((FrameworkSelectionList.Item)this.getFocused()).mouseDragged(event, deltaX, deltaY)) {
                return true;
            }

            if (this.scrolling) {
                double unitsPerScroll = (double)this.maxScrollAmount() / Math.max(1, this.getScrollAreaHeight() - this.getScrollbarHeight());
                this.setScrollAmount(this.scrollAmount() + deltaY * unitsPerScroll);
                return true;
            }
        }

        return false;
    }

    public boolean mouseScrolled(double mouseX, double mouseY, double deltaX, double deltaY) {
        return this.active && super.mouseScrolled(mouseX, mouseY, deltaX, deltaY);
    }

    public void addItem(FrameworkSelectionList.Item item) {
        super.addEntry(item);
    }

    public void removeItem(int index) {
        List<FrameworkSelectionList.Item> children = this.children();
        if (index >= 0 && index < children.size()) {
            this.removeEntry(children.get(index));
        }
    }

    public void removeItem(FrameworkSelectionList.Item item) {
        super.removeEntry(item);
    }

    public void removeIf(Predicate<? super FrameworkSelectionList.Item> predicate) {
        List<FrameworkSelectionList.Item> remove = this.children().stream().filter(predicate).toList();
        if (!remove.isEmpty()) {
            this.ignoreReposition = true;
            this.removeEntries(remove);
            this.ignoreReposition = false;
            this.repositionItems();
        }
    }

    public void replaceItems(Collection<FrameworkSelectionList.Item> items) {
        super.replaceEntries(items);
    }

    public void scrollToItem(FrameworkSelectionList.Item item) {
        super.centerScrollOn(item);
    }

    public boolean updateScrolling(MouseButtonEvent event) {
        this.scrolling = this.scrollable()
            && event.button() == 1
            && ClientUtils.isPointInArea(
                (int)event.x(), (int)event.y(), this.scrollBarX(), this.getScrollAreaTop(), this.scrollerWidth, this.getScrollAreaHeight()
            );
        ClientServices.CLIENT.setScrollingState(this, this.scrolling);
        return this.scrolling;
    }

    @Nullable
    public FrameworkSelectionList.Item getSelected() {
        FrameworkSelectionList.Item selected = (FrameworkSelectionList.Item)super.getSelected();
        return selected != null && selected.isSelectable() ? selected : null;
    }

    public void setSelected(@Nullable FrameworkSelectionList.Item item) {
        if (item == null || item.isSelectable()) {
            super.setSelected(item);
        }
    }

    public static FrameworkSelectionList.Builder builder() {
        return new FrameworkSelectionList.Builder();
    }

    // $VF: Compiled from FrameworkSelectionList.java
    public static class Builder {
        private int x;
        private int y;
        private int width = 100;
        private int height = 100;
        private int itemHeight = 20;
        @Nullable
        private FrameworkSelectionList.ItemSprites itemSprites = FrameworkSelectionList.DEFAULT_ITEM_SPRITE;
        private int itemSpacing = 0;
        @Nullable
        private Identifier listBackground = FrameworkSelectionList.DEFAULT_BACKGROUND;
        private Border listBorder = FrameworkSelectionList.DEFAULT_LIST_BORDER;
        private Padding listPadding = FrameworkSelectionList.DEFAULT_LIST_PADDING;
        private boolean scrollBarAlwaysVisible;
        private int scrollBarSpacing = 4;
        private FrameworkSelectionList.ScrollBarStyle scrollBarStyle = FrameworkSelectionList.ScrollBarStyle.DETACHED;
        @Nullable
        private FrameworkSelectionList.ScrollerSprites scrollerSprites = FrameworkSelectionList.DEFAULT_SCROLLER_SPRITE;
        private int scrollerWidth = 6;
        private int minScrollerHeight = 32;
        @Nullable
        private Identifier scrollBarBackground = FrameworkSelectionList.DEFAULT_SCROLL_BAR_BACKGROUND;
        private Border scrollBarBorder = FrameworkSelectionList.DEFAULT_SCROLL_BAR_BORDER;
        private Padding scrollBarPadding = FrameworkSelectionList.DEFAULT_SCROLL_BAR_PADDING;
        private Padding scrollBarContainerPadding = FrameworkSelectionList.DEFAULT_SCROLL_BAR_CONTAINER_PADDING;
        @Nullable
        private Supplier<Boolean> activeSupplier;
        @Nullable
        private Consumer<Consumer<FrameworkSelectionList.Item>> itemsSupplier;

        private Builder() {
        }

        public FrameworkSelectionList build() {
            return new FrameworkSelectionList(
                this.x,
                this.y,
                this.width,
                this.height,
                this.itemHeight,
                this.itemSprites,
                this.itemSpacing,
                this.listBackground,
                this.listBorder,
                this.listPadding,
                this.scrollBarAlwaysVisible,
                this.scrollBarSpacing,
                this.scrollBarStyle,
                this.scrollerSprites,
                this.scrollerWidth,
                this.minScrollerHeight,
                this.scrollBarBackground,
                this.scrollBarBorder,
                this.scrollBarPadding,
                this.scrollBarContainerPadding,
                this.activeSupplier,
                this.itemsSupplier
            );
        }

        public FrameworkSelectionList.Builder setX(int x) {
            this.x = x;
            return this;
        }

        public FrameworkSelectionList.Builder setY(int y) {
            this.y = y;
            return this;
        }

        public FrameworkSelectionList.Builder setPosition(int x, int y) {
            this.x = x;
            this.y = y;
            return this;
        }

        public FrameworkSelectionList.Builder setWidth(int width) {
            this.width = width;
            return this;
        }

        public FrameworkSelectionList.Builder setHeight(int height) {
            this.height = height;
            return this;
        }

        public FrameworkSelectionList.Builder setSize(int width, int height) {
            this.width = width;
            this.height = height;
            return this;
        }

        public FrameworkSelectionList.Builder setItemHeight(int height) {
            this.itemHeight = height;
            return this;
        }

        public FrameworkSelectionList.Builder setItemSprites(@Nullable FrameworkSelectionList.ItemSprites sprites) {
            this.itemSprites = sprites;
            return this;
        }

        public FrameworkSelectionList.Builder noItemSprites() {
            this.itemSprites = null;
            return this;
        }

        public FrameworkSelectionList.Builder setItemSpacing(int spacing) {
            this.itemSpacing = spacing;
            return this;
        }

        public FrameworkSelectionList.Builder setListBackground(@Nullable Identifier texture) {
            this.listBackground = texture;
            return this;
        }

        public FrameworkSelectionList.Builder noListBackground() {
            this.listBackground = null;
            return this;
        }

        public FrameworkSelectionList.Builder setListBorder(Border border) {
            this.listBorder = border;
            return this;
        }

        public FrameworkSelectionList.Builder setListPadding(Padding padding) {
            this.listPadding = padding;
            return this;
        }

        public FrameworkSelectionList.Builder setScrollBarAlwaysVisible(boolean alwaysVisible) {
            this.scrollBarAlwaysVisible = alwaysVisible;
            return this;
        }

        public FrameworkSelectionList.Builder setScrollBarSpacing(int spacing) {
            this.scrollBarSpacing = spacing;
            return this;
        }

        public FrameworkSelectionList.Builder setScrollBarStyle(FrameworkSelectionList.ScrollBarStyle style) {
            this.scrollBarStyle = style;
            return this;
        }

        public FrameworkSelectionList.Builder setScrollerSprites(@Nullable FrameworkSelectionList.ScrollerSprites sprites) {
            this.scrollerSprites = sprites;
            return this;
        }

        public FrameworkSelectionList.Builder setScrollerWidth(int width) {
            this.scrollerWidth = width;
            return this;
        }

        public FrameworkSelectionList.Builder setMinScrollerHeight(int minHeight) {
            this.minScrollerHeight = minHeight;
            return this;
        }

        public FrameworkSelectionList.Builder setScrollBarBackground(@Nullable Identifier texture) {
            this.scrollBarBackground = texture;
            return this;
        }

        public FrameworkSelectionList.Builder setScrollBarBorder(Border border) {
            this.scrollBarBorder = border;
            return this;
        }

        public FrameworkSelectionList.Builder setScrollBarPadding(Padding padding) {
            this.scrollBarPadding = padding;
            return this;
        }

        public FrameworkSelectionList.Builder setScrollBarContainerPadding(Padding padding) {
            this.scrollBarContainerPadding = padding;
            return this;
        }

        public FrameworkSelectionList.Builder setDependent(Supplier<Boolean> active) {
            this.activeSupplier = active;
            return this;
        }

        public FrameworkSelectionList.Builder setInitialItems(Consumer<Consumer<FrameworkSelectionList.Item>> items) {
            this.itemsSupplier = items;
            return this;
        }
    }

    // $VF: Compiled from FrameworkSelectionList.java
    public abstract static class Item extends Entry<FrameworkSelectionList.Item> {
        private boolean hovered;

        protected abstract void extractContent(GuiGraphicsExtractor var1, int var2, int var3, boolean var4, boolean var5, float var6);

        private void setHovered(boolean hovered) {
            this.hovered = hovered;
        }

        public boolean isSelectable() {
            return true;
        }

        public int getContentX() {
            return this.getX();
        }

        public int getContentY() {
            return this.getY();
        }

        public int getContentHeight() {
            return this.getHeight();
        }

        public int getContentWidth() {
            return this.getWidth();
        }

        public Component getNarration() {
            return CommonComponents.EMPTY;
        }

        public final void extractContent(GuiGraphicsExtractor extractor, int mouseX, int mouseY, boolean selected, float partialTick) {
            this.extractContent(extractor, mouseX, mouseY, this.hovered, selected, partialTick);
        }

        protected void extractBackground(
            @Nullable FrameworkSelectionList.ItemSprites sprites, GuiGraphicsExtractor extractor, int mouseX, int mouseY, boolean hovered, boolean selected
        ) {
            if (sprites != null) {
                Identifier sprite = sprites.getSprite(true, hovered, selected);
                if (sprite != null) {
                    extractor.blitSprite(RenderPipelines.GUI_TEXTURED, sprite, this.getX(), this.getY(), this.getWidth(), this.getHeight());
                }
            }
        }
    }

    // $VF: Compiled from FrameworkSelectionList.java
    public static final class ItemSprites {
        private final ImmutableMap<Integer, Identifier> map;

        private ItemSprites(
            @Nullable Identifier enabled,
            @Nullable Identifier disabled,
            @Nullable Identifier enabledHovered,
            @Nullable Identifier disabledHovered,
            @Nullable Identifier enabledSelected,
            @Nullable Identifier disabledSelected,
            @Nullable Identifier enabledHoveredSelected,
            @Nullable Identifier disabledHoveredSelected
        ) {
            com.google.common.collect.ImmutableMap.Builder<Integer, Identifier> builder = ImmutableMap.builder();
            if (disabled != null) {
                builder.put(this.calculateKey(false, false, false), disabled);
            }

            if (enabled != null) {
                builder.put(this.calculateKey(true, false, false), enabled);
            }

            if (disabledHovered != null) {
                builder.put(this.calculateKey(false, true, false), disabledHovered);
            }

            if (enabledHovered != null) {
                builder.put(this.calculateKey(true, true, false), enabledHovered);
            }

            if (disabledSelected != null) {
                builder.put(this.calculateKey(false, false, true), disabledSelected);
            }

            if (enabledSelected != null) {
                builder.put(this.calculateKey(true, false, true), enabledSelected);
            }

            if (disabledHoveredSelected != null) {
                builder.put(this.calculateKey(false, true, true), disabledHoveredSelected);
            }

            if (enabledHoveredSelected != null) {
                builder.put(this.calculateKey(true, true, true), enabledHoveredSelected);
            }

            this.map = builder.build();
        }

        private int calculateKey(boolean enabled, boolean hovered, boolean selected) {
            int key = 0;
            if (enabled) {
                key |= 1;
            }

            if (hovered) {
                key |= 2;
            }

            if (selected) {
                key |= 4;
            }

            return key;
        }

        @Nullable
        public Identifier getSprite(boolean enabled, boolean hovered, boolean selected) {
            return (Identifier)this.map.get(this.calculateKey(enabled, hovered, selected));
        }

        public static FrameworkSelectionList.ItemSprites of(@Nullable Identifier all) {
            return new FrameworkSelectionList.ItemSprites(all, all, all, all, all, all, all, all);
        }

        public static FrameworkSelectionList.ItemSprites of(@Nullable Identifier enabled, @Nullable Identifier disabled, @Nullable Identifier enabledSelected) {
            return new FrameworkSelectionList.ItemSprites(enabled, disabled, enabled, disabled, enabledSelected, disabled, enabledSelected, disabled);
        }

        public static FrameworkSelectionList.ItemSprites.Builder builder() {
            return new FrameworkSelectionList.ItemSprites.Builder();
        }

        // $VF: Compiled from FrameworkSelectionList.java
        public static class Builder {
            @Nullable
            private Identifier enabled;
            @Nullable
            private Identifier disabled;
            @Nullable
            private Identifier enabledHovered;
            @Nullable
            private Identifier disabledHovered;
            @Nullable
            private Identifier enabledSelected;
            @Nullable
            private Identifier disabledSelected;
            @Nullable
            private Identifier enabledHoveredSelected;
            @Nullable
            private Identifier disabledHoveredSelected;

            public FrameworkSelectionList.ItemSprites build() {
                return new FrameworkSelectionList.ItemSprites(
                    this.enabled,
                    this.disabled,
                    this.enabledHovered,
                    this.disabledHovered,
                    this.enabledSelected,
                    this.disabledSelected,
                    this.enabledHoveredSelected,
                    this.disabledHoveredSelected
                );
            }

            public FrameworkSelectionList.ItemSprites.Builder setEnabled(@Nullable Identifier texture) {
                this.enabled = texture;
                return this;
            }

            public FrameworkSelectionList.ItemSprites.Builder setDisabled(@Nullable Identifier texture) {
                this.disabled = texture;
                return this;
            }

            public FrameworkSelectionList.ItemSprites.Builder setEnabledHovered(@Nullable Identifier texture) {
                this.enabledHovered = texture;
                return this;
            }

            public FrameworkSelectionList.ItemSprites.Builder setDisabledHovered(@Nullable Identifier texture) {
                this.disabledHovered = texture;
                return this;
            }

            public FrameworkSelectionList.ItemSprites.Builder setEnabledSelected(@Nullable Identifier texture) {
                this.enabledSelected = texture;
                return this;
            }

            public FrameworkSelectionList.ItemSprites.Builder setDisabledSelected(@Nullable Identifier texture) {
                this.disabledSelected = texture;
                return this;
            }

            public FrameworkSelectionList.ItemSprites.Builder setEnabledHoveredSelected(@Nullable Identifier texture) {
                this.enabledHoveredSelected = texture;
                return this;
            }

            public FrameworkSelectionList.ItemSprites.Builder setDisabledHoveredSelected(@Nullable Identifier texture) {
                this.disabledHoveredSelected = texture;
                return this;
            }
        }
    }

    // $VF: Compiled from FrameworkSelectionList.java
    public enum ScrollBarStyle {
        DETACHED,
        MERGED;
    }

    // $VF: Compiled from FrameworkSelectionList.java
    public static final class ScrollerSprites {
        private final Identifier enabled;
        @Nullable
        private final Identifier disabled;
        private final Identifier hovered;
        private final Identifier dragging;

        private ScrollerSprites(Identifier enabled, @Nullable Identifier disabled, Identifier hovered, Identifier dragging) {
            this.enabled = enabled;
            this.disabled = disabled;
            this.hovered = hovered;
            this.dragging = dragging;
        }

        public static FrameworkSelectionList.ScrollerSprites of(Identifier all) {
            return new FrameworkSelectionList.ScrollerSprites(all, all, all, all);
        }

        public static FrameworkSelectionList.ScrollerSprites of(Identifier enabled, Identifier disabled, Identifier hovered) {
            return new FrameworkSelectionList.ScrollerSprites(enabled, disabled, hovered, hovered);
        }

        public static FrameworkSelectionList.ScrollerSprites of(Identifier enabled, Identifier disabled, Identifier hovered, Identifier dragging) {
            return new FrameworkSelectionList.ScrollerSprites(enabled, disabled, hovered, dragging);
        }

        @Nullable
        public Identifier get(boolean enabled, boolean hovered, boolean dragging) {
            if (!enabled) {
                return this.disabled;
            } else if (hovered) {
                return this.hovered;
            } else {
                return dragging ? this.dragging : this.enabled;
            }
        }
    }
}
