package com.mrcrayfish.framework.api.client.model;

import com.mrcrayfish.framework.platform.ClientServices;
import net.minecraft.client.renderer.block.dispatch.BlockStateModelPart;
import net.minecraft.client.renderer.block.dispatch.Variant.SimpleModelState;
import net.minecraft.client.resources.model.SimpleModelWrapper;
import net.minecraft.resources.Identifier;
import org.jetbrains.annotations.Nullable;

// $VF: Compiled from FrameworkModelResource.java
public abstract class FrameworkModelResource<T> {
    private final Identifier location;
    private final FrameworkModelBaker<T> baker;
    private T cachedModel;

    FrameworkModelResource(Identifier location, FrameworkModelBaker<T> baker) {
        this.location = location;
        this.baker = baker;
    }

    public final Identifier getLocation() {
        return this.location;
    }

    public final FrameworkModelBaker<T> getBaker() {
        return this.baker;
    }

    @Override
    public boolean equals(Object o) {
        if (o != null && this.getClass() == o.getClass()) {
            FrameworkModelResource<?> that = (FrameworkModelResource<?>)o;
            return this.location.equals(that.location);
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        return this.location.hashCode();
    }

    @Nullable
    public T getModel() {
        if (this.cachedModel == null) {
            this.cachedModel = ClientServices.CLIENT.getStandaloneModel(this);
        }

        return this.cachedModel;
    }

    public void clearCache() {
        this.cachedModel = null;
    }

    public static FrameworkModelResource<FrameworkBakedModel> create(Identifier location) {
        return createCustom(location, FrameworkBakedModel.BAKER);
    }

    public static FrameworkModelResource<BlockStateModelPart> createVanilla(Identifier location) {
        return createCustom(location, (model, baker) -> SimpleModelWrapper.bake(baker, location, SimpleModelState.DEFAULT.asModelState()));
    }

    public static <T> FrameworkModelResource<T> createCustom(Identifier location, FrameworkModelBaker<T> baker) {
        return ClientServices.CLIENT.createModelResource(location, baker);
    }
}
