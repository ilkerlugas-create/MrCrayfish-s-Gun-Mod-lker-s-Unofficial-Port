package com.mrcrayfish.framework.api.client.screen;

import java.util.function.BiConsumer;
import net.minecraft.client.gui.layouts.LayoutElement;
import net.minecraft.client.gui.navigation.ScreenRectangle;

// $VF: Compiled from Anchor.java
public enum Anchor {
    ABOVE_LEFT((element, rectangle) -> {
        element.setX(rectangle.left());
        element.setY(rectangle.top() - element.getHeight());
    }),
    ABOVE_RIGHT((element, rectangle) -> {
        element.setX(rectangle.right() - element.getWidth());
        element.setY(rectangle.top() - element.getHeight());
    }),
    BELOW_LEFT((element, rectangle) -> {
        element.setX(rectangle.left());
        element.setY(rectangle.bottom());
    }),
    BELOW_RIGHT((element, rectangle) -> {
        element.setX(rectangle.right() - element.getWidth());
        element.setY(rectangle.bottom());
    }),
    END_TOP((element, rectangle) -> {
        element.setX(rectangle.right());
        element.setY(rectangle.top());
    }),
    END_BOTTOM((element, rectangle) -> {
        element.setX(rectangle.right());
        element.setY(rectangle.bottom() - element.getHeight());
    }),
    CENTERED((element, rectangle) -> {
        int x = (rectangle.width() - element.getWidth()) / 2;
        int y = (rectangle.height() - element.getHeight()) / 2;
        element.setPosition(x, y);
    });

    private final BiConsumer<LayoutElement, ScreenRectangle> aligner;

    Anchor(BiConsumer<LayoutElement, ScreenRectangle> positioner) {
        this.aligner = positioner;
    }

    public void apply(LayoutElement element, LayoutElement source) {
        this.apply(element, source.getRectangle());
    }

    public void apply(LayoutElement element, ScreenRectangle source) {
        this.aligner.accept(element, source);
    }
}
