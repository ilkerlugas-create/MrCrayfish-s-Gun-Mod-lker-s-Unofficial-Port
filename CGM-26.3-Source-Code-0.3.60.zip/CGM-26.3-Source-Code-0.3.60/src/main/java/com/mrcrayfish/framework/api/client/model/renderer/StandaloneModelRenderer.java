package com.mrcrayfish.framework.api.client.model.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.QuadInstance;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack.Pose;
import java.util.List;
import net.minecraft.client.renderer.Sheets;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.block.dispatch.BlockStateModelPart;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.resources.model.geometry.BakedQuad;
import net.minecraft.core.Direction;

// $VF: Compiled from StandaloneModelRenderer.java
public class StandaloneModelRenderer {
    private static final Direction[] DIRECTIONS = Direction.values();

    public static void submitDraw(SubmitNodeCollector var0, BlockStateModelPart var1, PoseStack var2, float var3, float var4, float var5, int var6, int var7) {
        submitDraw(var0, var1, ChunkSectionLayer.SOLID, var2, var3, var4, var5, var6, var7);
    }

    public static void submitDraw(
        SubmitNodeCollector var0, BlockStateModelPart var1, ChunkSectionLayer var2, PoseStack var3, float var4, float var5, float var6, int var7, int var8
    ) {
        int var9 = 0xFF000000
            | Math.max(0, Math.min(255, Math.round(var4 * 255.0F))) << 16
            | Math.max(0, Math.min(255, Math.round(var5 * 255.0F))) << 8
            | Math.max(0, Math.min(255, Math.round(var6 * 255.0F)));
        var0.submitCustomGeometry(var3, getSheet(var1), (var4x, var5x) -> {
            QuadInstance var6x = new QuadInstance();
            var6x.setLightCoords(var7);
            var6x.setOverlayCoords(var8);

            for (Direction var10 : DIRECTIONS) {
                putQuads(var4x, var5x, var9, var1.getQuads(var10), var6x);
            }

            putQuads(var4x, var5x, var9, var1.getQuads(null), var6x);
        });
    }

    private static void putQuads(Pose var0, VertexConsumer var1, int var2, List<BakedQuad> var3, QuadInstance var4) {
        for (BakedQuad var6 : var3) {
            var4.setColor(var6.materialInfo().isTinted() ? var2 : -1);
            var1.putBakedQuad(var0, var6, var4);
        }
    }

    private static RenderType getSheet(BlockStateModelPart var0) {
        return (var0.materialFlags() & 1) != 0 ? Sheets.translucentBlockItemSheet() : Sheets.cutoutBlockItemSheet();
    }
}
