package com.mrcrayfish.framework.api.client.screen.overlay;

import net.minecraft.client.Minecraft;

// $VF: Compiled from Overlayable.java
public interface Overlayable {
    OverlayController getOverlayController();

    default boolean isDisplayed() {
        return Minecraft.getInstance().gui.screen() == this;
    }
}
