package com.mrcrayfish.framework;

// $VF: Compiled from FrameworkData.java
public class FrameworkData {
    private static boolean gameLoaded;

    public static void setLoaded() {
        gameLoaded = true;
    }

    public static boolean isLoaded() {
        return gameLoaded;
    }
}
