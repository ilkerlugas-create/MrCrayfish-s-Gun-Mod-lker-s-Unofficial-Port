package com.mrcrayfish.framework.api.client.screen.widget;

// $VF: Compiled from TooltipOptions.java
public final class TooltipOptions {
    public static final int DISABLE_TOOLTIP_WHEN_WIDGET_INACTIVE = 1;
    public static final int REBUILD_TOOLTIP_ON_SHIFT = 2;
    public static final int REBUILD_TOOLTIP_ON_WIDGET_HOVER = 4;

    private TooltipOptions() {
    }
}
