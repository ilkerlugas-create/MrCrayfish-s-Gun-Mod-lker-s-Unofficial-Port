package com.mrcrayfish.framework.api.client.screen.widget;

import com.google.common.annotations.Beta;
import com.google.common.primitives.Doubles;
import com.google.common.primitives.Floats;
import com.google.common.primitives.Ints;
import com.google.common.primitives.Longs;
import com.mrcrayfish.framework.api.client.screen.widget.element.Icon;
import com.mrcrayfish.framework.util.Utils;
import java.text.DecimalFormat;
import java.util.List;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractContainerWidget;
import net.minecraft.client.gui.components.AbstractScrollArea;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.WidgetSprites;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.Identifier;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;
import org.jetbrains.annotations.Nullable;

// $VF: Compiled from FrameworkStepper.java
@Beta
public class FrameworkStepper<T> extends AbstractContainerWidget {
    private static final Identifier BACKWARDS_SPRITE = Utils.rl("widget/stepper/backwards");
    private static final Identifier FORWARDS_SPRITE = Utils.rl("widget/stepper/forwards");
    public static final FrameworkStepper.Type<FrameworkStepper.IntBuilder> INT = new FrameworkStepper.Type<>(FrameworkStepper.IntBuilder::new);
    public static final FrameworkStepper.Type<FrameworkStepper.LongBuilder> LONG = new FrameworkStepper.Type<>(FrameworkStepper.LongBuilder::new);
    public static final FrameworkStepper.Type<FrameworkStepper.FloatBuilder> FLOAT = new FrameworkStepper.Type<>(FrameworkStepper.FloatBuilder::new);
    public static final FrameworkStepper.Type<FrameworkStepper.DoubleBuilder> DOUBLE = new FrameworkStepper.Type<>(FrameworkStepper.DoubleBuilder::new);
    private final FrameworkStepper.Controller<T> controller;
    private final FrameworkEditBox valueEditBox;
    private final FrameworkButton backwardsButton;
    private final FrameworkButton forwardsButton;
    @Nullable
    private final Supplier<Boolean> activeSupplier;
    private final int spacing;
    private boolean errored;

    private FrameworkStepper(
        int x,
        int y,
        int width,
        int height,
        FrameworkStepper.Controller<T> controller,
        WidgetSprites editBoxBackground,
        WidgetSprites buttonTexture,
        int spacing,
        Icon backwardsIcon,
        Icon forwardsIcon,
        int textColour,
        int erroredTextColour,
        @Nullable Supplier<Boolean> activeSupplier
    ) {
        super(x, y, width, height, CommonComponents.EMPTY, AbstractScrollArea.defaultSettings(0));
        int buttonSize = Math.max(10, height);
        this.spacing = spacing;
        this.controller = controller;
        this.activeSupplier = activeSupplier;
        Style normalStyle = Style.EMPTY.withColor(textColour);
        Style errorStyle = Style.EMPTY.withColor(erroredTextColour);
        this.valueEditBox = FrameworkEditBox.builder()
            .setDependent(() -> this.isActive() && controller.allowsTextEditing())
            .setInitialText(controller.toText())
            .setSize(width - buttonSize * 2 - spacing * 2, buttonSize)
            .setPosition(x + buttonSize + spacing, y)
            .setBackground(editBoxBackground)
            .setCallback(s -> {
                this.errored = false;
                T value = controller.parseText(s);
                if (value != null) {
                    controller.set(value);
                } else {
                    this.errored = true;
                }
            })
            .setTextFormatter((text, index) -> FormattedCharSequence.forward(text, this.errored ? errorStyle : normalStyle))
            .setClearOnRightClick(false)
            .build();
        this.backwardsButton = FrameworkButton.builder()
            .setDependent(() -> this.isActive() && controller.canStep(FrameworkStepper.StepDirection.BACKWARDS))
            .setAction(btn -> {
                controller.step(FrameworkStepper.StepDirection.BACKWARDS, Minecraft.getInstance().hasShiftDown());
                this.valueEditBox.getEditBox().setValue(controller.toText());
            })
            .setSize(buttonSize, buttonSize)
            .setPosition(x, y)
            .setTexture(buttonTexture)
            .setIcon(backwardsIcon)
            .build();
        this.forwardsButton = FrameworkButton.builder()
            .setDependent(() -> this.isActive() && controller.canStep(FrameworkStepper.StepDirection.FORWARDS))
            .setAction(btn -> {
                controller.step(FrameworkStepper.StepDirection.FORWARDS, Minecraft.getInstance().hasShiftDown());
                this.valueEditBox.getEditBox().setValue(controller.toText());
            })
            .setSize(buttonSize, buttonSize)
            .setPosition(x + width - buttonSize, y)
            .setTexture(buttonTexture)
            .setIcon(forwardsIcon)
            .build();
        this.valueEditBox.getEditBox().setValue(controller.toText());
    }

    public T getValue() {
        return this.controller.get();
    }

    public boolean isErrored() {
        return this.errored;
    }

    protected void extractWidgetRenderState(GuiGraphicsExtractor extractor, int mouseX, int mouseY, float partialTick) {
        if (this.activeSupplier != null) {
            this.active = this.activeSupplier.get();
        }

        this.children().forEach(listener -> {
            if (listener instanceof AbstractWidget widget) {
                widget.extractRenderState(extractor, mouseX, mouseY, partialTick);
            }
        });
    }

    protected void updateWidgetNarration(NarrationElementOutput output) {
    }

    public void setX(int x) {
        super.setX(x);
        this.updateWidgets();
    }

    public void setY(int y) {
        super.setY(y);
        this.updateWidgets();
    }

    public void setWidth(int width) {
        super.setWidth(width);
        this.updateWidgets();
    }

    public void setHeight(int height) {
        super.setHeight(height);
        this.updateWidgets();
    }

    public void setSize(int width, int height) {
        super.setSize(width, height);
        this.updateWidgets();
    }

    private void updateWidgets() {
        int buttonSize = Math.max(10, this.getHeight());
        this.valueEditBox.setPosition(this.getX() + buttonSize + this.spacing, this.getY());
        this.valueEditBox.setSize(this.getWidth() - buttonSize * 2 - this.spacing * 2, buttonSize);
        this.backwardsButton.setPosition(this.getX(), this.getY());
        this.backwardsButton.setSize(buttonSize, buttonSize);
        this.forwardsButton.setPosition(this.getX() + this.getWidth() - buttonSize, this.getY());
        this.forwardsButton.setSize(buttonSize, buttonSize);
    }

    public List<? extends GuiEventListener> children() {
        return List.of(this.backwardsButton, this.valueEditBox, this.forwardsButton);
    }

    public void setFocused(boolean focused) {
        super.setFocused(focused);
        if (!focused) {
            this.children().forEach(listener -> listener.setFocused(false));
        } else if (this.getFocused() != null) {
            this.getFocused().setFocused(true);
        }
    }

    protected int contentHeight() {
        return this.getHeight();
    }

    protected double scrollRate() {
        return 0.0;
    }

    public static <B extends FrameworkStepper.Builder<B, ?>> B builder(FrameworkStepper.Type<B> type) {
        return type.factory.get();
    }

    // $VF: Compiled from FrameworkStepper.java
    public abstract static sealed class Builder<B extends FrameworkStepper.Builder<B, T>, T> permits FrameworkStepper.NumberBuilder {
        protected int x;
        protected int y;
        protected int width;
        protected int height;
        protected int spacing;
        protected WidgetSprites editBoxBackground = FrameworkEditBox.DEFAULT_SPRITES;
        protected WidgetSprites buttonTexture = FrameworkButton.DEFAULT_SPRITES;
        protected Icon backwardsIcon = Icon.sprite(FrameworkStepper.BACKWARDS_SPRITE, 6, 8);
        protected Icon forwardsIcon = Icon.sprite(FrameworkStepper.FORWARDS_SPRITE, 6, 8);
        @Nullable
        protected Consumer<T> callback;
        protected int textColour = -1;
        protected int erroredTextColour = -43691;
        @Nullable
        protected Supplier<Boolean> activeSupplier;

        private Builder() {
        }

        protected abstract FrameworkStepper<T> build();

        protected B self() {
            return (B)this;
        }

        public B setX(int x) {
            this.x = x;
            return this.self();
        }

        public B setY(int y) {
            this.y = y;
            return this.self();
        }

        public B setPosition(int x, int y) {
            this.x = x;
            this.y = y;
            return this.self();
        }

        public B setWidth(int width) {
            this.width = width;
            return this.self();
        }

        public B setHeight(int height) {
            this.height = height;
            return this.self();
        }

        public B setSize(int width, int height) {
            this.width = width;
            this.height = height;
            return this.self();
        }

        public B setSpacing(int spacing) {
            this.spacing = spacing;
            return this.self();
        }

        public B setEditBoxBackground(@Nullable WidgetSprites background) {
            this.editBoxBackground = background;
            return this.self();
        }

        public B setButtonTexture(WidgetSprites texture) {
            this.buttonTexture = texture;
            return this.self();
        }

        public B setBackwardsIcon(Icon icon) {
            this.backwardsIcon = icon;
            return this.self();
        }

        public B setForwardsIcon(Icon icon) {
            this.forwardsIcon = icon;
            return this.self();
        }

        public B setCallback(@Nullable Consumer<T> callback) {
            this.callback = callback;
            return this.self();
        }

        public B setTextColour(int colour) {
            this.textColour = colour;
            return this.self();
        }

        public B setErroredTextColour(int colour) {
            this.erroredTextColour = colour;
            return this.self();
        }

        public B setDependent(Supplier<Boolean> active) {
            this.activeSupplier = active;
            return this.self();
        }
    }

    // $VF: Compiled from FrameworkStepper.java
    private abstract static class Controller<T> {
        protected abstract T get();

        protected abstract void set(T var1);

        protected abstract boolean allowsTextEditing();

        @Nullable
        protected abstract T parseText(String var1);

        protected abstract String toText();

        protected abstract boolean canStep(FrameworkStepper.StepDirection var1);

        protected abstract void step(FrameworkStepper.StepDirection var1, boolean var2);
    }

    // $VF: Compiled from FrameworkStepper.java
    public static final class DoubleBuilder extends FrameworkStepper.NumberBuilder<FrameworkStepper.DoubleBuilder, Double> {
        private static final DecimalFormat DEFAULT_FORMATTER = new DecimalFormat("0.#");
        private DecimalFormat formatter = DEFAULT_FORMATTER;

        private DoubleBuilder() {
            this.initialValue = 0.0;
            this.minValue = -Double.MAX_VALUE;
            this.maxValue = Double.MAX_VALUE;
            this.step = 1.0;
            this.bigStep = 10.0;
        }

        public FrameworkStepper.DoubleBuilder setFormatter(DecimalFormat formatter) {
            this.formatter = formatter;
            return this.self();
        }

        @Override
        public FrameworkStepper<Double> build() {
            return new FrameworkStepper<>(
                this.x,
                this.y,
                this.width,
                this.height,
                new FrameworkStepper.DoubleController(this.minValue, this.maxValue, this.step, this.bigStep, this.initialValue, this.callback, this.formatter),
                this.editBoxBackground,
                this.buttonTexture,
                this.spacing,
                this.backwardsIcon,
                this.forwardsIcon,
                this.textColour,
                this.erroredTextColour,
                this.activeSupplier
            );
        }

        static {
            DEFAULT_FORMATTER.setMinimumFractionDigits(1);
            DEFAULT_FORMATTER.setMaximumFractionDigits(3);
            DEFAULT_FORMATTER.setDecimalSeparatorAlwaysShown(true);
        }
    }

    // $VF: Compiled from FrameworkStepper.java
    private static final class DoubleController extends FrameworkStepper.NumberController<Double> {
        private final DecimalFormat formatter;

        private DoubleController(
            Double minValue, Double maxValue, Double step, Double bigStep, Double initialValue, @Nullable Consumer<Double> callback, DecimalFormat formatter
        ) {
            super(minValue, maxValue, step, bigStep, initialValue, callback, Doubles::tryParse, value -> Double.toString(value), Double::compare, Mth::clamp);
            this.formatter = formatter;
        }

        @Override
        protected String toText() {
            return this.formatter.format(this.value);
        }

        protected Double applyStep(Double value, FrameworkStepper.StepDirection direction, boolean shift) {
            double step = shift ? this.bigStep : this.step;
            return direction == FrameworkStepper.StepDirection.BACKWARDS ? value - step : value + step;
        }
    }

    // $VF: Compiled from FrameworkStepper.java
    public static final class FloatBuilder extends FrameworkStepper.NumberBuilder<FrameworkStepper.FloatBuilder, Float> {
        private static final DecimalFormat DEFAULT_FORMATTER = new DecimalFormat("0.#");
        private DecimalFormat formatter = DEFAULT_FORMATTER;

        private FloatBuilder() {
            this.initialValue = 0.0F;
            this.minValue = -Float.MAX_VALUE;
            this.maxValue = Float.MAX_VALUE;
            this.step = 1.0F;
            this.bigStep = 10.0F;
        }

        public FrameworkStepper.FloatBuilder setFormatter(DecimalFormat formatter) {
            this.formatter = formatter;
            return this.self();
        }

        @Override
        public FrameworkStepper<Float> build() {
            return new FrameworkStepper<>(
                this.x,
                this.y,
                this.width,
                this.height,
                new FrameworkStepper.FloatController(this.minValue, this.maxValue, this.step, this.bigStep, this.initialValue, this.callback, this.formatter),
                this.editBoxBackground,
                this.buttonTexture,
                this.spacing,
                this.backwardsIcon,
                this.forwardsIcon,
                this.textColour,
                this.erroredTextColour,
                this.activeSupplier
            );
        }

        static {
            DEFAULT_FORMATTER.setMinimumFractionDigits(1);
            DEFAULT_FORMATTER.setMaximumFractionDigits(3);
            DEFAULT_FORMATTER.setDecimalSeparatorAlwaysShown(true);
        }
    }

    // $VF: Compiled from FrameworkStepper.java
    private static final class FloatController extends FrameworkStepper.NumberController<Float> {
        private final DecimalFormat formatter;

        private FloatController(
            Float minValue, Float maxValue, Float step, Float bigStep, Float initialValue, @Nullable Consumer<Float> callback, DecimalFormat formatter
        ) {
            super(minValue, maxValue, step, bigStep, initialValue, callback, Floats::tryParse, value -> Float.toString(value), Double::compare, Mth::clamp);
            this.formatter = formatter;
        }

        @Override
        protected String toText() {
            return this.formatter.format(this.value);
        }

        protected Float applyStep(Float value, FrameworkStepper.StepDirection direction, boolean shift) {
            float step = shift ? this.bigStep : this.step;
            return direction == FrameworkStepper.StepDirection.BACKWARDS ? value - step : value + step;
        }
    }

    // $VF: Compiled from FrameworkStepper.java
    public static final class IntBuilder extends FrameworkStepper.NumberBuilder<FrameworkStepper.IntBuilder, Integer> {
        private IntBuilder() {
            this.initialValue = 0;
            this.minValue = Integer.MIN_VALUE;
            this.maxValue = Integer.MAX_VALUE;
            this.step = 1;
            this.bigStep = 10;
        }

        @Override
        public FrameworkStepper<Integer> build() {
            return new FrameworkStepper<>(
                this.x,
                this.y,
                this.width,
                this.height,
                new FrameworkStepper.IntController(this.minValue, this.maxValue, this.step, this.bigStep, this.initialValue, this.callback),
                this.editBoxBackground,
                this.buttonTexture,
                this.spacing,
                this.backwardsIcon,
                this.forwardsIcon,
                this.textColour,
                this.erroredTextColour,
                this.activeSupplier
            );
        }
    }

    // $VF: Compiled from FrameworkStepper.java
    private static final class IntController extends FrameworkStepper.NumberController<Integer> {
        private IntController(Integer minValue, Integer maxValue, Integer step, Integer bigStep, Integer initialValue, @Nullable Consumer<Integer> callback) {
            super(minValue, maxValue, step, bigStep, initialValue, callback, Ints::tryParse, value -> Integer.toString(value), Integer::compare, Mth::clamp);
        }

        protected Integer applyStep(Integer value, FrameworkStepper.StepDirection direction, boolean shift) {
            int step = shift ? this.bigStep : this.step;
            return direction == FrameworkStepper.StepDirection.BACKWARDS ? value - step : value + step;
        }
    }

    // $VF: Compiled from FrameworkStepper.java
    public static final class LongBuilder extends FrameworkStepper.NumberBuilder<FrameworkStepper.LongBuilder, Long> {
        private LongBuilder() {
            this.initialValue = 0L;
            this.minValue = Long.MIN_VALUE;
            this.maxValue = Long.MAX_VALUE;
            this.step = 1L;
            this.bigStep = 10L;
        }

        @Override
        public FrameworkStepper<Long> build() {
            return new FrameworkStepper<>(
                this.x,
                this.y,
                this.width,
                this.height,
                new FrameworkStepper.LongController(this.minValue, this.maxValue, this.step, this.bigStep, this.initialValue, this.callback),
                this.editBoxBackground,
                this.buttonTexture,
                this.spacing,
                this.backwardsIcon,
                this.forwardsIcon,
                this.textColour,
                this.erroredTextColour,
                this.activeSupplier
            );
        }
    }

    // $VF: Compiled from FrameworkStepper.java
    private static final class LongController extends FrameworkStepper.NumberController<Long> {
        private LongController(Long minValue, Long maxValue, Long step, Long bigStep, Long initialValue, @Nullable Consumer<Long> callback) {
            super(minValue, maxValue, step, bigStep, initialValue, callback, Longs::tryParse, value -> Long.toString(value), Long::compare, Mth::clamp);
        }

        protected Long applyStep(Long value, FrameworkStepper.StepDirection direction, boolean shift) {
            long step = shift ? this.bigStep : this.step;
            return direction == FrameworkStepper.StepDirection.BACKWARDS ? value - step : value + step;
        }
    }

    // $VF: Compiled from FrameworkStepper.java
    private abstract static non-sealed class NumberBuilder<B extends FrameworkStepper.NumberBuilder<B, V>, V extends Number>
        extends FrameworkStepper.Builder<B, V> {
        protected V initialValue;
        protected V minValue;
        protected V maxValue;
        protected V step;
        protected V bigStep;

        public B setInitialValue(V initialValue) {
            this.initialValue = initialValue;
            return this.self();
        }

        public B setMinValue(V minValue) {
            this.minValue = minValue;
            return this.self();
        }

        public B setMaxValue(V maxValue) {
            this.maxValue = maxValue;
            return this.self();
        }

        public B setStep(V step) {
            this.step = step;
            return this.self();
        }

        public B setBigStep(V bigStep) {
            this.bigStep = bigStep;
            return this.self();
        }
    }

    // $VF: Compiled from FrameworkStepper.java
    private abstract static class NumberController<V extends Number> extends FrameworkStepper.Controller<V> {
        protected final V minValue;
        protected final V maxValue;
        protected final V step;
        protected final V bigStep;
        @Nullable
        protected final Consumer<V> callback;
        protected final Function<String, V> parser;
        protected final Function<V, String> stringify;
        protected final BiFunction<V, V, Integer> compare;
        private final FrameworkStepper.NumberController.Clamper<V, V, V, V> clamper;
        protected V value;

        private NumberController(
            V minValue,
            V maxValue,
            V step,
            V bigStep,
            V initialValue,
            @Nullable Consumer<V> callback,
            Function<String, V> parser,
            Function<V, String> stringify,
            BiFunction<V, V, Integer> compare,
            FrameworkStepper.NumberController.Clamper<V, V, V, V> clamper
        ) {
            this.minValue = minValue;
            this.maxValue = maxValue;
            this.step = step;
            this.bigStep = bigStep;
            this.callback = callback;
            this.parser = parser;
            this.stringify = stringify;
            this.compare = compare;
            this.clamper = clamper;
            this.value = clamper.apply(initialValue, this.minValue, this.maxValue);
        }

        protected V get() {
            return this.value;
        }

        protected void set(V value) {
            this.value = this.clamper.apply(value, this.minValue, this.maxValue);
            if (this.callback != null) {
                this.callback.accept(this.value);
            }
        }

        @Override
        protected boolean allowsTextEditing() {
            return true;
        }

        @Nullable
        protected V parseText(String s) {
            return this.parser.apply(s);
        }

        @Override
        protected String toText() {
            return this.stringify.apply(this.value);
        }

        @Override
        protected boolean canStep(FrameworkStepper.StepDirection direction) {
            return switch (direction) {
                case BACKWARDS -> this.compare.apply(this.value, this.minValue) > 0;
                case FORWARDS -> this.compare.apply(this.value, this.maxValue) < 0;
            };
        }

        @Override
        protected void step(FrameworkStepper.StepDirection direction, boolean shift) {
            this.value = this.clamper.apply(this.applyStep(this.value, direction, shift), this.minValue, this.maxValue);
        }

        protected abstract V applyStep(V var1, FrameworkStepper.StepDirection var2, boolean var3);

        // $VF: Compiled from FrameworkStepper.java
        @FunctionalInterface
        protected interface Clamper<V, L, U, R> {
            R apply(V var1, L var2, U var3);
        }
    }

    // $VF: Compiled from FrameworkStepper.java
    private enum StepDirection {
        BACKWARDS,
        FORWARDS;
    }

    // $VF: Compiled from FrameworkStepper.java
    public record Type<B extends FrameworkStepper.Builder<B, ?>>(Supplier<B> factory) {
    }
}
