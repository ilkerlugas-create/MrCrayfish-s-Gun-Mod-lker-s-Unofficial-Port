package com.mrcrayfish.framework.api.client.screen.widget;

import com.mrcrayfish.framework.api.client.screen.widget.element.Icon;
import com.mrcrayfish.framework.api.client.screen.widget.element.Label;
import com.mrcrayfish.framework.api.client.screen.widget.element.Sound;
import com.mrcrayfish.framework.api.client.screen.widget.input.Action;
import com.mrcrayfish.framework.api.client.screen.widget.input.MouseInput;
import java.time.Duration;
import java.util.EnumMap;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractButton;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.components.WidgetSprites;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.input.InputWithModifiers;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.input.MouseButtonInfo;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.sounds.SoundManager;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.ARGB;
import org.jetbrains.annotations.Nullable;

// $VF: Compiled from FrameworkButton.java
public final class FrameworkButton extends AbstractButton {
    public static final WidgetSprites DEFAULT_SPRITES = new WidgetSprites(
        Identifier.withDefaultNamespace("widget/button"),
        Identifier.withDefaultNamespace("widget/button_disabled"),
        Identifier.withDefaultNamespace("widget/button_highlighted")
    );
    public static final int DEFAULT_TOOLTIP_DELAY = 350;
    public static final FrameworkButton.ContentRenderer<FrameworkButton> DEFAULT_CONTENT_RENDERER = new FrameworkButton.DefaultContentRenderer();
    private final Label label;
    @Nullable
    private final Icon icon;
    private final int spacing;
    @Nullable
    private final EnumMap<MouseInput, Action<FrameworkButton>> actions;
    @Nullable
    private final Supplier<WidgetSprites> texture;
    @Nullable
    private final Supplier<Boolean> activeSupplier;
    @Nullable
    private final Function<FrameworkButton, Tooltip> tooltip;
    private final int tooltipOptions;
    @Nullable
    private Tooltip currentTooltip;
    private boolean shiftWasDown;
    private boolean mouseIsHovering;
    @Nullable
    private final FrameworkButton.ContentRenderer<FrameworkButton> contentRenderer;

    private FrameworkButton(
        int x,
        int y,
        int width,
        int height,
        Label label,
        Function<FrameworkButton, Icon> icon,
        int spacing,
        @Nullable EnumMap<MouseInput, Action<FrameworkButton>> actions,
        @Nullable Supplier<WidgetSprites> texture,
        @Nullable Supplier<Boolean> activeSupplier,
        @Nullable Function<FrameworkButton, Tooltip> tooltip,
        int tooltipDelay,
        int tooltipOptions,
        @Nullable FrameworkButton.ContentRenderer<FrameworkButton> contentRenderer
    ) {
        super(x, y, width, height, CommonComponents.EMPTY);
        this.label = label;
        this.icon = icon.apply(this);
        this.spacing = spacing;
        this.actions = actions;
        this.texture = texture;
        this.activeSupplier = activeSupplier;
        this.tooltip = tooltip;
        this.tooltipOptions = tooltipOptions;
        this.contentRenderer = contentRenderer;
        this.updateActiveState();
        this.rebuildTooltip();
        this.setTooltipDelay(Duration.ofMillis(tooltipDelay));
    }

    public Component getMessage() {
        return this.label.text();
    }

    public Label getLabel() {
        return this.label;
    }

    @Nullable
    public Icon getIcon() {
        return this.icon;
    }

    @Nullable
    public WidgetSprites getTexture() {
        return this.texture != null ? this.texture.get() : null;
    }

    public int getSpacing() {
        return this.spacing;
    }

    private void onAction(int button) {
        Action<FrameworkButton> action = this.actions != null ? this.actions.get(MouseInput.fromButton(button)) : null;
        if (action != null) {
            action.handler().accept(this);
            Sound sound = action.sound();
            if (sound != null) {
                Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(sound.value(), sound.pitch(), sound.volume()));
            }
        } else {
            Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0F));
        }

        this.rebuildTooltip();
    }

    private void updateActiveState() {
        if (this.activeSupplier != null) {
            this.active = this.activeSupplier.get();
        }
    }

    public void rebuildTooltip() {
        if (this.tooltip != null) {
            this.currentTooltip = this.tooltip.apply(this);
        }
    }

    private void updateTooltip() {
        if ((this.tooltipOptions & 2) != 0 && !this.shiftWasDown && Minecraft.getInstance().hasShiftDown() && this.isHovered()) {
            this.rebuildTooltip();
            this.shiftWasDown = true;
        }

        if (this.shiftWasDown && !Minecraft.getInstance().hasShiftDown()) {
            this.rebuildTooltip();
            this.shiftWasDown = false;
        }

        if ((this.tooltipOptions & 4) != 0) {
            if (this.isHovered()) {
                if (!this.mouseIsHovering) {
                    this.rebuildTooltip();
                    this.mouseIsHovering = true;
                }
            } else {
                this.mouseIsHovering = false;
            }
        }

        if (!this.active && (this.tooltipOptions & 1) != 0) {
            this.setTooltip(null);
        } else {
            this.setTooltip(this.currentTooltip);
        }
    }

    public void onPress(InputWithModifiers input) {
        this.onAction(input.input());
    }

    public void playDownSound(SoundManager manager) {
    }

    protected void extractContents(GuiGraphicsExtractor extractor, int mouseX, int mouseY, float partialTick) {
        this.updateActiveState();
        this.updateTooltip();
        if (this.contentRenderer != null) {
            this.contentRenderer.extractContents(this, extractor, mouseX, mouseY, partialTick);
        }
    }

    protected void updateWidgetNarration(NarrationElementOutput output) {
        this.defaultButtonNarrationText(output);
    }

    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (this.isActive() && this.isValidClickButton(event.buttonInfo()) && this.isMouseOver(event.x(), event.y())) {
            this.onAction(event.button());
            return true;
        } else {
            return false;
        }
    }

    protected boolean isValidClickButton(MouseButtonInfo info) {
        return info.button() == 0 || this.actions != null && this.actions.containsKey(MouseInput.fromButton(info.button()));
    }

    public static FrameworkButton.Builder builder() {
        return new FrameworkButton.Builder();
    }

    // $VF: Compiled from FrameworkButton.java
    public static final class Builder {
        private int x;
        private int y;
        private int width = 20;
        private int height = 20;
        private Label label = Label.EMPTY;
        private Function<FrameworkButton, Icon> icon = btn -> null;
        private int spacing = 4;
        @Nullable
        private EnumMap<MouseInput, Action<FrameworkButton>> actions;
        @Nullable
        private Supplier<WidgetSprites> texture = () -> FrameworkButton.DEFAULT_SPRITES;
        @Nullable
        private Supplier<Boolean> active;
        @Nullable
        private Function<FrameworkButton, Tooltip> tooltip;
        private int tooltipDelay = 350;
        private int tooltipOptions;
        @Nullable
        private FrameworkButton.ContentRenderer<FrameworkButton> contentRenderer = FrameworkButton.DEFAULT_CONTENT_RENDERER;

        private Builder() {
        }

        public FrameworkButton build() {
            return new FrameworkButton(
                this.x,
                this.y,
                this.width,
                this.height,
                this.label,
                this.icon,
                this.spacing,
                this.actions,
                this.texture,
                this.active,
                this.tooltip,
                this.tooltipDelay,
                this.tooltipOptions,
                this.contentRenderer
            );
        }

        private EnumMap<MouseInput, Action<FrameworkButton>> actions() {
            if (this.actions == null) {
                this.actions = new EnumMap<>(MouseInput.class);
            }

            return this.actions;
        }

        public FrameworkButton.Builder setX(int x) {
            this.x = x;
            return this;
        }

        public FrameworkButton.Builder setY(int y) {
            this.y = y;
            return this;
        }

        public FrameworkButton.Builder setPosition(int x, int y) {
            this.x = x;
            this.y = y;
            return this;
        }

        public FrameworkButton.Builder setWidth(int width) {
            this.width = width;
            return this;
        }

        public FrameworkButton.Builder setHeight(int height) {
            this.height = height;
            return this;
        }

        public FrameworkButton.Builder setSize(int width, int height) {
            this.width = width;
            this.height = height;
            return this;
        }

        public FrameworkButton.Builder setLabel(Component text) {
            this.label = Label.constant(text);
            return this;
        }

        public FrameworkButton.Builder setLabel(Supplier<Component> supplier) {
            this.label = Label.dynamic(supplier);
            return this;
        }

        public FrameworkButton.Builder setLabel(Label label) {
            this.label = label;
            return this;
        }

        public FrameworkButton.Builder setIcon(Identifier sprite, int width, int height) {
            this.icon = btn -> Icon.sprite(sprite, width, height);
            return this;
        }

        public FrameworkButton.Builder setIcon(Supplier<Identifier> sprite, int width, int height) {
            this.icon = btn -> Icon.sprite(sprite, width, height);
            return this;
        }

        public FrameworkButton.Builder setIcon(Function<FrameworkButton, Supplier<Identifier>> sprite, int width, int height) {
            this.icon = btn -> Icon.sprite(sprite.apply(btn), width, height);
            return this;
        }

        public FrameworkButton.Builder setIcon(Icon icon) {
            this.icon = btn -> icon;
            return this;
        }

        public FrameworkButton.Builder setIcon(Function<FrameworkButton, Icon> icon) {
            this.icon = icon;
            return this;
        }

        public FrameworkButton.Builder setSpacing(int spacing) {
            this.spacing = spacing;
            return this;
        }

        public FrameworkButton.Builder setAction(Consumer<FrameworkButton> action) {
            this.actions().put(MouseInput.LEFT_CLICK, Action.create(action));
            return this;
        }

        public FrameworkButton.Builder setPrimaryAction(Consumer<FrameworkButton> action) {
            this.actions().put(MouseInput.LEFT_CLICK, Action.create(action));
            return this;
        }

        public FrameworkButton.Builder setPrimaryAction(Action<FrameworkButton> action) {
            this.actions().put(MouseInput.LEFT_CLICK, action);
            return this;
        }

        public FrameworkButton.Builder setSecondaryAction(Consumer<FrameworkButton> action) {
            this.actions().put(MouseInput.RIGHT_CLICK, Action.create(action));
            return this;
        }

        public FrameworkButton.Builder setSecondaryAction(Action<FrameworkButton> action) {
            this.actions().put(MouseInput.RIGHT_CLICK, action);
            return this;
        }

        public FrameworkButton.Builder setTertiaryAction(Consumer<FrameworkButton> action) {
            this.actions().put(MouseInput.MIDDLE_CLICK, Action.create(action));
            return this;
        }

        public FrameworkButton.Builder setTertiaryAction(Action<FrameworkButton> action) {
            this.actions().put(MouseInput.MIDDLE_CLICK, action);
            return this;
        }

        public FrameworkButton.Builder setAction(MouseInput input, Action<FrameworkButton> action) {
            this.actions().put(input, action);
            return this;
        }

        public FrameworkButton.Builder setTexture(WidgetSprites texture) {
            this.texture = () -> texture;
            return this;
        }

        public FrameworkButton.Builder setTexture(Supplier<WidgetSprites> texture) {
            this.texture = texture;
            return this;
        }

        public FrameworkButton.Builder noTexture() {
            this.texture = null;
            return this;
        }

        public FrameworkButton.Builder setDependent(Supplier<Boolean> active) {
            this.active = active;
            return this;
        }

        public FrameworkButton.Builder setTooltip(Tooltip tooltip) {
            this.tooltip = btn -> tooltip;
            return this;
        }

        public FrameworkButton.Builder setTooltip(Function<FrameworkButton, Tooltip> tooltip) {
            this.tooltip = tooltip;
            return this;
        }

        public FrameworkButton.Builder setTooltipDelay(int delay) {
            this.tooltipDelay = delay;
            return this;
        }

        public FrameworkButton.Builder setTooltipOptions(int options) {
            this.tooltipOptions = options;
            return this;
        }

        public FrameworkButton.Builder setContentRenderer(@Nullable FrameworkButton.ContentRenderer<FrameworkButton> renderer) {
            this.contentRenderer = renderer;
            return this;
        }
    }

    // $VF: Compiled from FrameworkButton.java
    public interface ContentRenderer<T> {
        void extractContents(T var1, GuiGraphicsExtractor var2, int var3, int var4, float var5);
    }

    // $VF: Compiled from FrameworkButton.java
    public static class DefaultContentRenderer implements FrameworkButton.ContentRenderer<FrameworkButton> {
        public void extractContents(FrameworkButton button, GuiGraphicsExtractor extractor, int mouseX, int mouseY, float partialTick) {
            WidgetSprites texture = button.getTexture();
            if (texture != null) {
                int alpha = ARGB.white(button.active ? 1.0F : 0.5F);
                extractor.blitSprite(
                    RenderPipelines.GUI_TEXTURED,
                    texture.get(button.active, button.isHoveredOrFocused() && button.active),
                    button.getX(),
                    button.getY(),
                    button.getWidth(),
                    button.getHeight(),
                    alpha
                );
            }

            Label label = button.getLabel();
            int contentWidth = label.width();
            int contentHeight = contentWidth > 0 ? label.height() + 1 : 0;
            if (button.icon != null) {
                if (contentWidth > 0) {
                    contentWidth += button.spacing;
                }

                contentWidth += button.icon.width();
                contentHeight = Math.max(contentHeight, button.icon.height());
            }

            int contentLeft = button.getX() + (button.getWidth() - contentWidth) / 2;
            int contentTop = button.getY() + (button.getHeight() - contentHeight) / 2;
            int textX = contentLeft + (button.icon != null ? button.spacing + button.icon.width() : 0);
            int textY = contentTop + (contentHeight - label.height()) / 2 + 1;
            int textColour = button.active ? -1 : -10066330;
            boolean textShadow = button.active;
            label.draw(extractor, textX, textY, textColour, textShadow);
            if (button.icon != null) {
                int iconX = contentLeft;
                int iconY = contentTop + (contentHeight - button.icon.height()) / 2;
                int alpha = ARGB.white(button.active ? 1.0F : 0.5F);
                button.icon.draw(extractor, iconX, iconY, alpha, partialTick);
            }
        }
    }

    // $VF: Compiled from FrameworkButton.java
    public static class ToggleContentRenderer implements FrameworkButton.ContentRenderer<FrameworkButton> {
        private static final int TOGGLE_SIZE = 6;
        private static final WidgetSprites TOGGLE_SPRITES = new WidgetSprites(
            Identifier.fromNamespaceAndPath("framework", "widget/button/toggle_on"),
            Identifier.fromNamespaceAndPath("framework", "widget/button/toggle_off"),
            Identifier.fromNamespaceAndPath("framework", "widget/button/toggle_on")
        );
        private final Supplier<Boolean> state;

        public ToggleContentRenderer(Supplier<Boolean> state) {
            this.state = state;
        }

        public void extractContents(FrameworkButton button, GuiGraphicsExtractor extractor, int mouseX, int mouseY, float partialTick) {
            WidgetSprites texture = button.getTexture();
            if (texture != null) {
                int alpha = ARGB.white(button.active ? 1.0F : 0.5F);
                extractor.blitSprite(
                    RenderPipelines.GUI_TEXTURED,
                    texture.get(button.active, button.isHoveredOrFocused() && button.active),
                    button.getX(),
                    button.getY(),
                    button.getWidth(),
                    button.getHeight(),
                    alpha
                );
            }

            Label label = button.getLabel();
            int contentLeft = button.getX() + 6;
            int textX = contentLeft + (button.icon != null ? button.spacing + button.icon.width() : 0);
            int textY = button.getY() + (button.getHeight() - label.height()) / 2 + 1;
            int textColour = button.active ? -1 : -10066330;
            boolean textShadow = button.active;
            label.draw(extractor, textX, textY, textColour, textShadow);
            if (button.icon != null) {
                int iconX = contentLeft;
                int iconY = button.getY() + (button.getHeight() - button.icon.height()) / 2;
                int alpha = ARGB.white(button.active ? 1.0F : 0.5F);
                button.icon.draw(extractor, iconX, iconY, alpha, partialTick);
            }

            int yOffset = (button.getHeight() - 6) / 2;
            int stateIconY = button.getY() + yOffset;
            int stateIconX = button.getX() + button.getWidth() - 6 - yOffset;
            int alpha = ARGB.white(button.active ? 1.0F : 0.5F);
            extractor.blitSprite(RenderPipelines.GUI_TEXTURED, TOGGLE_SPRITES.get(this.state.get(), button.isHovered()), stateIconX, stateIconY, 6, 6, alpha);
        }
    }
}
