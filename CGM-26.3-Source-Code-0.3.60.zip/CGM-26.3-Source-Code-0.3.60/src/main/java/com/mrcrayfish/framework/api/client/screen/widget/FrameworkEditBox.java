package com.mrcrayfish.framework.api.client.screen.widget;

import com.mrcrayfish.framework.api.client.screen.widget.element.Icon;
import com.mrcrayfish.framework.api.client.screen.widget.layout.Border;
import com.mrcrayfish.framework.api.client.screen.widget.layout.Padding;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractContainerWidget;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.WidgetSprites;
import net.minecraft.client.gui.components.EditBox.TextFormatter;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.layouts.LinearLayout;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.util.ARGB;
import org.jetbrains.annotations.Nullable;

// $VF: Compiled from FrameworkEditBox.java
public final class FrameworkEditBox extends AbstractContainerWidget {
    public static final WidgetSprites DEFAULT_SPRITES = new WidgetSprites(
        Identifier.withDefaultNamespace("widget/text_field"), Identifier.withDefaultNamespace("widget/text_field_highlighted")
    );
    public static final Padding DEFAULT_PADDING = Padding.of(4, 0, 4, 0);
    public static final Border DEFAULT_BORDER = Border.of(1);
    private final LinearLayout layout = LinearLayout.horizontal();
    @Nullable
    private final Icon icon;
    @Nullable
    private final FrameworkEditBox.CenteredSpriteWidget iconWidget;
    private final Border border;
    private final Padding padding;
    private final int spacing;
    @Nullable
    private final WidgetSprites background;
    @Nullable
    private final Supplier<Boolean> activeSupplier;
    private final EditBox editBox;
    private final boolean clearOnRightClick;

    private FrameworkEditBox(
        int x,
        int y,
        int width,
        int height,
        Function<FrameworkEditBox, Icon> icon,
        Padding padding,
        int spacing,
        @Nullable WidgetSprites background,
        Border border,
        String text,
        @Nullable String suggestion,
        @Nullable Component hint,
        @Nullable Consumer<String> callback,
        @Nullable TextFormatter textFormatter,
        @Nullable Supplier<Boolean> activeSupplier,
        @Nullable Integer maxTextLength,
        boolean clearOnRightClick,
        @Nullable Integer iconWidthOverride
    ) {
        super(x, y, width, height, CommonComponents.EMPTY, defaultSettings(0));
        this.icon = icon.apply(this);
        this.padding = padding;
        this.spacing = spacing;
        this.background = background;
        this.border = border;
        this.activeSupplier = activeSupplier;
        this.clearOnRightClick = clearOnRightClick;
        this.layout.spacing(spacing);
        if (this.icon != null) {
            int iconWidth = iconWidthOverride != null ? iconWidthOverride : this.icon.width();
            this.iconWidget = (FrameworkEditBox.CenteredSpriteWidget)this.layout
                .addChild(
                    new FrameworkEditBox.CenteredSpriteWidget(iconWidth, 0, this.icon),
                    layoutSettings -> layoutSettings.paddingTop(border.top() + padding.top())
                        .paddingBottom(border.bottom() + padding.bottom())
                        .paddingLeft(padding.left() + border.left())
                );
        } else {
            this.iconWidget = null;
        }

        this.editBox = (EditBox)this.layout
            .addChild(
                new FrameworkEditBox.Impl(this),
                layoutSettings -> {
                    layoutSettings.paddingRight(border.right() + padding.right())
                        .paddingTop(border.top() + padding.top())
                        .paddingBottom(border.bottom() + padding.bottom());
                    if (this.icon == null) {
                        layoutSettings.paddingLeft(border.left() + padding.left());
                    }
                }
            );
        this.updateEditBoxWidth();
        if (maxTextLength != null) {
            this.editBox.setMaxLength(maxTextLength);
        }

        this.editBox.setValue(text);
        this.editBox.setSuggestion(suggestion);
        if (hint != null) {
            this.editBox.setHint(hint);
        }

        if (callback != null) {
            this.editBox.setResponder(callback);
        }

        if (textFormatter != null) {
            this.editBox.addFormatter(textFormatter);
        }

        this.setSize(width, height);
    }

    private void updateEditBoxWidth() {
        if (this.iconWidget != null) {
            this.editBox
                .setWidth(
                    this.getWidth()
                        - (this.border.left() + this.padding.left() + this.iconWidget.getWidth() + this.spacing + this.padding.right() + this.border.right())
                );
        } else {
            this.editBox.setWidth(this.getWidth() - (this.border.left() + this.padding.left() + this.padding.right() + this.border.right()));
        }
    }

    public void setX(int x) {
        super.setX(x);
        this.layout.setX(x);
    }

    public void setY(int y) {
        super.setY(y);
        this.layout.setY(y);
    }

    public void setWidth(int width) {
        super.setWidth(width);
        this.updateEditBoxWidth();
        this.layout.arrangeElements();
    }

    public void setHeight(int height) {
        super.setHeight(height);
        this.updateEditBoxWidth();
        int contentHeight = height - (this.border.top() + this.padding.top() + this.padding.bottom() + this.border.bottom());
        this.editBox.setHeight(contentHeight);
        if (this.iconWidget != null) {
            this.iconWidget.setHeight(contentHeight);
        }

        this.layout.arrangeElements();
    }

    public void setSize(int width, int height) {
        this.setWidth(width);
        this.setHeight(height);
    }

    protected void extractWidgetRenderState(GuiGraphicsExtractor extractor, int mouseX, int mouseY, float partialTick) {
        if (this.activeSupplier != null) {
            boolean active = this.activeSupplier.get();
            this.active = active;
            this.editBox.active = active;
        }

        if (this.background != null) {
            int alpha = ARGB.white(this.editBox.isActive() ? 1.0F : 0.5F);
            Identifier background = this.background.get(this.editBox.isActive(), this.editBox.isFocused());
            extractor.blitSprite(RenderPipelines.GUI_TEXTURED, background, this.getX(), this.getY(), this.getWidth(), this.getHeight(), alpha);
        }

        this.layout.visitWidgets(widget -> widget.extractRenderState(extractor, mouseX, mouseY, partialTick));
    }

    protected void updateWidgetNarration(NarrationElementOutput output) {
        this.editBox.updateNarration(output);
    }

    public List<? extends GuiEventListener> children() {
        return List.of(this.editBox);
    }

    public void setFocused(boolean focused) {
        super.setFocused(focused);
        this.editBox.setFocused(focused);
    }

    public String getText() {
        return this.editBox.getValue();
    }

    public EditBox getEditBox() {
        return this.editBox;
    }

    public static FrameworkEditBox.Builder builder() {
        return new FrameworkEditBox.Builder();
    }

    protected int contentHeight() {
        return this.height;
    }

    protected double scrollRate() {
        return 0.0;
    }

    // $VF: Compiled from FrameworkEditBox.java
    public static class Builder {
        private int x;
        private int y;
        private int width = 100;
        private int height = 16;
        private Function<FrameworkEditBox, Icon> icon = editBox1 -> null;
        private Border border = FrameworkEditBox.DEFAULT_BORDER;
        private Padding padding = FrameworkEditBox.DEFAULT_PADDING;
        private int spacing = 4;
        @Nullable
        private WidgetSprites background = FrameworkEditBox.DEFAULT_SPRITES;
        private String text = "";
        @Nullable
        private String suggestion;
        @Nullable
        private Consumer<String> callback;
        @Nullable
        private TextFormatter textFormatter;
        @Nullable
        private Component hint;
        @Nullable
        private Supplier<Boolean> active;
        @Nullable
        private Integer maxTextLength;
        private boolean clearOnRightClick = true;
        @Nullable
        private Integer iconWidthOverride;

        public FrameworkEditBox build() {
            return new FrameworkEditBox(
                this.x,
                this.y,
                this.width,
                this.height,
                this.icon,
                this.padding,
                this.spacing,
                this.background,
                this.border,
                this.text,
                this.suggestion,
                this.hint,
                this.callback,
                this.textFormatter,
                this.active,
                this.maxTextLength,
                this.clearOnRightClick,
                this.iconWidthOverride
            );
        }

        public FrameworkEditBox.Builder setX(int x) {
            this.x = x;
            return this;
        }

        public FrameworkEditBox.Builder setY(int y) {
            this.y = y;
            return this;
        }

        public FrameworkEditBox.Builder setPosition(int x, int y) {
            this.x = x;
            this.y = y;
            return this;
        }

        public FrameworkEditBox.Builder setWidth(int width) {
            this.width = width;
            return this;
        }

        public FrameworkEditBox.Builder setHeight(int height) {
            this.height = height;
            return this;
        }

        public FrameworkEditBox.Builder setSize(int width, int height) {
            this.width = width;
            this.height = height;
            return this;
        }

        public FrameworkEditBox.Builder setIcon(Identifier sprite, int width, int height) {
            this.icon = editBox -> Icon.sprite(sprite, width, height);
            return this;
        }

        public FrameworkEditBox.Builder setIcon(Supplier<Identifier> sprite, int width, int height) {
            this.icon = editBox -> Icon.sprite(sprite, width, height);
            return this;
        }

        public FrameworkEditBox.Builder setIcon(Function<FrameworkEditBox, Supplier<Identifier>> sprite, int width, int height) {
            this.icon = editBox -> Icon.sprite(sprite.apply(editBox), width, height);
            return this;
        }

        public FrameworkEditBox.Builder setIcon(@Nullable Icon icon) {
            this.icon = editBox -> icon;
            return this;
        }

        public FrameworkEditBox.Builder setIcon(Function<FrameworkEditBox, Icon> icon) {
            this.icon = icon;
            return this;
        }

        public FrameworkEditBox.Builder setIconWidth(int width) {
            this.iconWidthOverride = width;
            return this;
        }

        public FrameworkEditBox.Builder setSpacing(int spacing) {
            this.spacing = spacing;
            return this;
        }

        public FrameworkEditBox.Builder setPadding(int padding) {
            this.padding = Padding.of(padding, padding, padding, padding);
            return this;
        }

        public FrameworkEditBox.Builder setPadding(int left, int top, int right, int bottom) {
            this.padding = Padding.of(left, top, right, bottom);
            return this;
        }

        public FrameworkEditBox.Builder setPadding(Padding padding) {
            this.padding = padding;
            return this;
        }

        public FrameworkEditBox.Builder setBackground(@Nullable WidgetSprites background) {
            this.background = background;
            return this;
        }

        public FrameworkEditBox.Builder noBackground() {
            this.background = null;
            return this;
        }

        public FrameworkEditBox.Builder setBorder(int border) {
            this.border = Border.of(border);
            return this;
        }

        public FrameworkEditBox.Builder setBorder(int left, int top, int right, int bottom) {
            this.border = Border.of(left, top, right, bottom);
            return this;
        }

        public FrameworkEditBox.Builder setBorder(Border border) {
            this.border = border;
            return this;
        }

        public FrameworkEditBox.Builder setInitialText(String text) {
            this.text = text;
            return this;
        }

        public FrameworkEditBox.Builder setMaxTextLength(int maxTextLength) {
            this.maxTextLength = maxTextLength;
            return this;
        }

        public FrameworkEditBox.Builder setCallback(@Nullable Consumer<String> callback) {
            this.callback = callback;
            return this;
        }

        @Deprecated(since = "26.1", forRemoval = true)
        public FrameworkEditBox.Builder setValueFilter(@Nullable Predicate<String> valueFilter) {
            return this;
        }

        public FrameworkEditBox.Builder setTextFormatter(@Nullable TextFormatter textFormatter) {
            this.textFormatter = textFormatter;
            return this;
        }

        public FrameworkEditBox.Builder setHint(@Nullable Component hint) {
            this.hint = hint;
            return this;
        }

        public FrameworkEditBox.Builder setDependent(Supplier<Boolean> active) {
            this.active = active;
            return this;
        }

        public FrameworkEditBox.Builder setClearOnRightClick(boolean clearOnRightClick) {
            this.clearOnRightClick = clearOnRightClick;
            return this;
        }
    }

    // $VF: Compiled from FrameworkEditBox.java
    private static final class CenteredSpriteWidget extends AbstractWidget {
        private final Icon icon;

        public CenteredSpriteWidget(int width, int height, Icon icon) {
            super(0, 0, width, height, CommonComponents.EMPTY);
            this.icon = icon;
        }

        protected void extractWidgetRenderState(GuiGraphicsExtractor extractor, int mouseX, int mouseY, float partialTick) {
            int iconX = this.getX() + (this.getWidth() - this.icon.width()) / 2;
            int iconY = this.getY() + (this.getHeight() - this.icon.height()) / 2;
            this.icon.draw(extractor, iconX, iconY, ARGB.white(1.0F), partialTick);
        }

        protected void updateWidgetNarration(NarrationElementOutput output) {
        }
    }

    // $VF: Compiled from FrameworkEditBox.java
    public static class Impl extends EditBox {
        private final FrameworkEditBox parent;

        private Impl(FrameworkEditBox parent) {
            super(Minecraft.getInstance().font, 0, 0, CommonComponents.EMPTY);
            this.setBordered(false);
            this.parent = parent;
        }

        public boolean isBordered() {
            return false;
        }

        public boolean isMouseOver(double mouseX, double mouseY) {
            return mouseX >= this.parent.getX()
                && mouseY >= this.parent.getY()
                && mouseX < this.parent.getX() + this.parent.getWidth()
                && mouseY < this.parent.getY() + this.parent.getHeight();
        }

        public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
            if (this.parent.clearOnRightClick && this.isActive() && event.button() == 1 && this.isMouseOver(event.x(), event.y())) {
                this.setValue("");
                return true;
            } else {
                return super.mouseClicked(event, doubleClick);
            }
        }
    }
}
