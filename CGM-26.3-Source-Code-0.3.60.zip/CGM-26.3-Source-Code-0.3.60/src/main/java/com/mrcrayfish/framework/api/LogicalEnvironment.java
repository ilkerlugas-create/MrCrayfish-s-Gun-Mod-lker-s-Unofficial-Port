package com.mrcrayfish.framework.api;

// $VF: Compiled from LogicalEnvironment.java
public enum LogicalEnvironment {
    CLIENT,
    SERVER;
}
