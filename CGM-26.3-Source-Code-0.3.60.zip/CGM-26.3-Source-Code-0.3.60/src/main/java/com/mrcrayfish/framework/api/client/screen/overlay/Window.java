package com.mrcrayfish.framework.api.client.screen.overlay;

import com.google.common.annotations.Beta;
import com.google.common.collect.ImmutableList;
import com.mrcrayfish.framework.api.client.screen.widget.layout.Margin;
import com.mrcrayfish.framework.api.client.screen.widget.layout.Padding;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.layouts.FrameLayout;
import net.minecraft.client.gui.layouts.Layout;
import net.minecraft.client.gui.layouts.LayoutElement;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import org.jetbrains.annotations.Nullable;

// $VF: Compiled from Window.java
@Beta
public abstract class Window extends Overlay implements LayoutElement {
    private final Layout layout;
    private final List<AbstractWidget> widgets;
    private final Margin outerMargin;
    private final Identifier background;

    protected <T extends Window> Window(Function<T, Layout> content, Margin outerMargin, Padding contentPadding, Identifier background) {
        FrameLayout wrapper = new FrameLayout();
        if (content != null) {
            Layout layout = content.apply((T)this);
            wrapper.addChild(layout, s -> s.padding(contentPadding.left(), contentPadding.top(), contentPadding.right(), contentPadding.bottom()));
            wrapper.arrangeElements();
        }

        this.layout = wrapper;
        this.widgets = captureWidgets(wrapper);
        this.outerMargin = outerMargin;
        this.background = background;
    }

    public Margin getOuterMargin() {
        return this.outerMargin;
    }

    public void setX(int x) {
        this.layout.setX(x);
    }

    public void setY(int y) {
        this.layout.setY(y);
    }

    public int getX() {
        return this.layout.getX();
    }

    public int getY() {
        return this.layout.getY();
    }

    public int getWidth() {
        return this.layout.getWidth();
    }

    public int getHeight() {
        return this.layout.getHeight();
    }

    @Override
    public ScreenRectangle getInteractableArea() {
        return this.layout.getRectangle();
    }

    public void visitWidgets(Consumer<AbstractWidget> consumer) {
        this.layout.visitWidgets(consumer);
    }

    @Override
    public final void render(GuiGraphicsExtractor extractor, int mouseX, int mouseY, float partialTick) {
        if (this.background != null) {
            extractor.blitSprite(
                RenderPipelines.GUI_TEXTURED, this.background, this.layout.getX(), this.layout.getY(), this.layout.getWidth(), this.layout.getHeight()
            );
        }

        this.widgets.forEach(widget -> widget.extractRenderState(extractor, mouseX, mouseY, partialTick));
    }

    @Override
    public List<? extends GuiEventListener> getWidgets() {
        return this.widgets;
    }

    protected void clampToBounds(ScreenRectangle bounds) {
        int x = Mth.clamp(this.getX(), this.outerMargin.left(), bounds.width() - this.getWidth() - this.outerMargin.right());
        int y = Mth.clamp(this.getY(), this.outerMargin.top(), bounds.height() - this.getHeight() - this.outerMargin.bottom());
        this.layout.setPosition(x, y);
    }

    private static List<AbstractWidget> captureWidgets(Layout layout) {
        List<AbstractWidget> widgets = new ArrayList<>();
        layout.visitWidgets(widgets::add);
        return ImmutableList.copyOf(widgets);
    }

    // $VF: Compiled from Window.java
    protected abstract static class Builder<B extends Window.Builder<B, T>, T extends Window> {
        @Nullable
        protected Function<T, Layout> layout;
        @Nullable
        protected Identifier background;
        protected Margin outerMargin = Margin.of(5);
        protected Padding contentPadding = Padding.ZERO;

        public abstract T build();

        public B setContent(Layout layout) {
            this.layout = ignored -> layout;
            return this.self();
        }

        public B setContent(Function<T, Layout> layout) {
            this.layout = layout;
            return this.self();
        }

        public B setContentPadding(Padding contentPadding) {
            this.contentPadding = contentPadding;
            return this.self();
        }

        public B setBackground(@Nullable Identifier background) {
            this.background = background;
            return this.self();
        }

        public B setOuterMargin(Margin outerMargin) {
            this.outerMargin = outerMargin;
            return this.self();
        }

        public B self() {
            return (B)this;
        }
    }
}
