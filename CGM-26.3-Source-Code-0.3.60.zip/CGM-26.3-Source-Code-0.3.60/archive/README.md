# Original embedded patch history

The files under `embedded/` are exact copies of historical patch sources, test
fixtures, tools and notes present in the supplied JAR. Original entry paths are
retained beneath this directory. They may describe older mod revisions and old
local paths. They are not the active recovered source tree and are not newly
executed validation. Do not add this directory to a production Java source set.
