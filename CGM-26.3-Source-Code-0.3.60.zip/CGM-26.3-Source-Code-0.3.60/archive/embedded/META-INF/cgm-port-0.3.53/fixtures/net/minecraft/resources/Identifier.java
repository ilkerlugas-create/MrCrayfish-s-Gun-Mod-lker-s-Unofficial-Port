package net.minecraft.resources;
/** Test-only value object. Never packaged as a runtime class in the mod JAR. */
public record Identifier(String namespace, String path) {
    public static Identifier fromNamespaceAndPath(String namespace, String path) {
        return new Identifier(namespace, path);
    }
}
