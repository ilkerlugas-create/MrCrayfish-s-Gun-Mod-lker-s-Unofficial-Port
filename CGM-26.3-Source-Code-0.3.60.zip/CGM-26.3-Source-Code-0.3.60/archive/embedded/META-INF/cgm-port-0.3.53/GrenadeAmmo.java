package com.mrcrayfish.guns.port;

import net.minecraft.resources.Identifier;

/** Source equivalent of the class emitted by Patch53.java. */
public final class GrenadeAmmo {
    private static final Identifier LEGACY = Identifier.fromNamespaceAndPath("cgm", "grenade_round");
    private static final Identifier GRENADE = Identifier.fromNamespaceAndPath("cgm", "grenade");

    public static Identifier normalize(Identifier ammo) {
        return LEGACY.equals(ammo) ? GRENADE : ammo;
    }
}
