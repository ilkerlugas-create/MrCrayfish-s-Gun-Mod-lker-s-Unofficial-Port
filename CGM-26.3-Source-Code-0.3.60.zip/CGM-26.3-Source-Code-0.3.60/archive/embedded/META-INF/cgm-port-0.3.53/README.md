# CGM 26.3 port 0.3.53 — six hand grenades

Input: user-supplied 0.3.52 Z-3D-EKLENTI-FIX JAR.

- The grenade launcher now consumes `cgm:grenade` (the throwable hand grenade).
- Capacity and reload amount remain six. The existing runtime six-round floors
  also cover older saved guns with a one-round capacity/reload value.
- A full reload consumes six hand grenades, or only the available quantity / empty
  chambers when fewer are available. Shooting still consumes one loaded unit.
- Retired `cgm:grenade_round`: removed item registration, projectile alias setup,
  workbench recipe, item assets, preview entry and translation labels.
- Old gun NBT referencing the retired ammunition ID resolves to `cgm:grenade` for
  reloading, unloading, tooltips and projectile selection. Existing loaded ammo
  counts remain intact. The retired loose ammunition item itself is no longer
  registered; this is not an automatic inventory conversion of loose old rounds.
- The original hand-grenade projectile factory and throwing behavior are retained.
- All unrelated weapon, sound, pose, animation and attachment classes/resources
  are unchanged. No game rendering or animation is stubbed or replaced.

Validation: ASM BasicVerifier on every patched/generated method, isolated execution
of the real normalization helper against a test-only Identifier fixture, complete
archive and JSON checks, and byte comparison against the supplied JAR.

The local environment has Java 17 tooling, without a Minecraft 26.3 / Forge 66.0.2
runtime. Production class files retain their original class-file versions for
use on the user's Java 25 runtime. The test fixture
is never installed as a production class. No full Forge build or in-game test was run.

Reproduction: run Patch53.java against the extracted input JAR with the JDK's
internal ASM and ASM tree exports, Verify53.java with the additional ASM tree
analysis export, then build53.py using the input/output paths documented there.
