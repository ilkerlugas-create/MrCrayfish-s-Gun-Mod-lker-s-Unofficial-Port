import java.nio.file.*;
import java.util.*;
import jdk.internal.org.objectweb.asm.*;
import jdk.internal.org.objectweb.asm.tree.*;

/** Narrow binary patch of the supplied 0.3.52 JAR. Requires only JDK 17 tooling. */
public final class Patch53 implements Opcodes {
    static final String BASE = "com/mrcrayfish/guns/";
    static final String ID = "net/minecraft/resources/Identifier";
    static final String ID_DESC = "L" + ID + ";";
    static final String HELPER = BASE + "port/GrenadeAmmo";
    static Path input, output;

    static void check(boolean condition, String message) {
        if (!condition) throw new IllegalStateException(message);
    }
    static ClassNode read(String name) throws Exception {
        byte[] bytes = Files.readAllBytes(input.resolve(name + ".class"));
        int major = ((bytes[6] & 255) << 8) | (bytes[7] & 255);
        bytes[6] = 0; bytes[7] = 61; // Let JDK 17 ASM parse, retain production Java version below.
        ClassNode node = new ClassNode();
        new ClassReader(bytes).accept(node, 0);
        node.version = major;
        return node;
    }
    static void write(ClassNode node) throws Exception {
        ClassWriter writer = new ClassWriter(ClassWriter.COMPUTE_MAXS);
        node.accept(writer);
        Path path = output.resolve(node.name + ".class");
        Files.createDirectories(path.getParent());
        Files.write(path, writer.toByteArray());
    }
    static MethodNode method(ClassNode node, String name, String descriptor) {
        return node.methods.stream().filter(m -> m.name.equals(name) && m.desc.equals(descriptor))
            .findFirst().orElseThrow(() -> new IllegalStateException(node.name + "." + name));
    }
    static List<AbstractInsnNode> opcodes(MethodNode m) {
        return Arrays.stream(m.instructions.toArray()).filter(n -> n.getOpcode() >= 0).toList();
    }
    static void constant(InsnList code, int n) {
        code.add(n <= 5 ? new InsnNode(ICONST_0 + n) : new IntInsnNode(BIPUSH, n));
    }
    static String fieldDescriptor(String type) { return "L" + type + ";"; }

    public static void main(String[] args) throws Exception {
        input = Path.of(args[0]); output = Path.of(args[1]);

        // Remove the extra ammunition registration. Every original CGM item stays registered.
        ClassNode items = read(BASE + "init/ModItems");
        MethodNode init = method(items, "<clinit>", "()V");
        int removed = 0;
        for (AbstractInsnNode n : init.instructions.toArray()) {
            if (n instanceof MethodInsnNode call && call.owner.equals(BASE + "port/ExtraAmmo") && call.name.equals("register")) {
                AbstractInsnNode previous = n.getPrevious();
                check(previous instanceof FieldInsnNode f && f.getOpcode() == GETSTATIC && f.name.equals("REGISTER"), "Unexpected registration argument");
                init.instructions.remove(previous);
                init.instructions.remove(n);
                removed++;
            }
        }
        check(removed == 1, "Expected exactly one extra ammunition registration");
        write(items);

        // Keep the original grenade projectile factory; remove only the unused round factory hook.
        ClassNode mod = read(BASE + "GunMod");
        removed = 0;
        for (MethodNode m : mod.methods) for (AbstractInsnNode n : m.instructions.toArray()) {
            if (n instanceof MethodInsnNode call && call.owner.equals(BASE + "port/ExtraAmmo") && call.name.equals("setup")) {
                check(call.desc.equals("()V"), "Unexpected ExtraAmmo setup descriptor");
                m.instructions.remove(n); removed++;
            }
        }
        check(removed == 1, "Expected exactly one extra ammunition setup hook");
        write(mod);

        // Remove the retired item's preview model entry without changing other preview behavior.
        ClassNode preview = read(BASE + "port/WorkbenchPreview");
        MethodNode previewInit = method(preview, "<clinit>", "()V");
        List<AbstractInsnNode> ops = opcodes(previewInit);
        check(ops.get(0) instanceof IntInsnNode count && count.operand == 25, "Unexpected preview list size");
        check(ops.get(1) instanceof TypeInsnNode array && array.getOpcode() == ANEWARRAY && array.desc.equals("java/lang/String"), "Unexpected preview list");
        List<String> names = new ArrayList<>();
        for (int i = 0; i < 25; i++) {
            int offset = 2 + i * 4;
            check(ops.get(offset).getOpcode() == DUP && ops.get(offset + 3).getOpcode() == AASTORE, "Unexpected preview entry");
            check(ops.get(offset + 2) instanceof LdcInsnNode, "Unexpected preview name");
            names.add((String)((LdcInsnNode)ops.get(offset + 2)).cst);
        }
        check(names.remove("grenade_round") && names.size() == 24, "Missing retired preview entry");
        AbstractInsnNode setCall = ops.get(102);
        check(setCall instanceof MethodInsnNode call && call.owner.equals("java/util/Set") && call.name.equals("of"), "Unexpected preview set creation");
        InsnList newArray = new InsnList();
        constant(newArray, names.size());
        newArray.add(new TypeInsnNode(ANEWARRAY, "java/lang/String"));
        for (int i = 0; i < names.size(); i++) {
            newArray.add(new InsnNode(DUP)); constant(newArray, i);
            newArray.add(new LdcInsnNode(names.get(i))); newArray.add(new InsnNode(AASTORE));
        }
        previewInit.instructions.insertBefore(ops.get(0), newArray);
        for (int i = 0; i < 102; i++) previewInit.instructions.remove(ops.get(i));
        write(preview);

        // Old item-stack Gun NBT can still contain cgm:grenade_round.
        // Normalize it at the one accessor used for reload, unload, tooltip and projectile selection.
        ClassNode projectile = read(BASE + "common/Gun$Projectile");
        MethodNode getter = method(projectile, "getItem", "()" + ID_DESC);
        removed = 0;
        for (AbstractInsnNode n : getter.instructions.toArray()) if (n.getOpcode() == ARETURN) {
            getter.instructions.insertBefore(n, new MethodInsnNode(INVOKESTATIC, HELPER, "normalize", "(" + ID_DESC + ")" + ID_DESC, false));
            removed++;
        }
        check(removed == 1, "Unexpected projectile item accessor");
        write(projectile);

        // Cache both identifiers once; normalization allocates nothing per frame or shot.
        ClassNode helper = new ClassNode();
        helper.version = projectile.version;
        helper.access = ACC_PUBLIC | ACC_FINAL | ACC_SUPER;
        helper.name = HELPER; helper.superName = "java/lang/Object";
        helper.fields.add(new FieldNode(ACC_PRIVATE | ACC_STATIC | ACC_FINAL, "LEGACY", ID_DESC, null, null));
        helper.fields.add(new FieldNode(ACC_PRIVATE | ACC_STATIC | ACC_FINAL, "GRENADE", ID_DESC, null, null));
        MethodNode helperInit = new MethodNode(ACC_STATIC, "<clinit>", "()V", null, null);
        for (String[] entry : new String[][] {{"LEGACY", "grenade_round"}, {"GRENADE", "grenade"}}) {
            helperInit.instructions.add(new LdcInsnNode("cgm"));
            helperInit.instructions.add(new LdcInsnNode(entry[1]));
            helperInit.instructions.add(new MethodInsnNode(INVOKESTATIC, ID, "fromNamespaceAndPath", "(Ljava/lang/String;Ljava/lang/String;)" + ID_DESC, false));
            helperInit.instructions.add(new FieldInsnNode(PUTSTATIC, HELPER, entry[0], ID_DESC));
        }
        helperInit.instructions.add(new InsnNode(RETURN));
        helper.methods.add(helperInit);
        MethodNode normalize = new MethodNode(ACC_PUBLIC | ACC_STATIC, "normalize", "(" + ID_DESC + ")" + ID_DESC, null, null);
        LabelNode original = new LabelNode();
        normalize.instructions.add(new FieldInsnNode(GETSTATIC, HELPER, "LEGACY", ID_DESC));
        normalize.instructions.add(new VarInsnNode(ALOAD, 0));
        normalize.instructions.add(new MethodInsnNode(INVOKEVIRTUAL, ID, "equals", "(Ljava/lang/Object;)Z", false));
        normalize.instructions.add(new JumpInsnNode(IFEQ, original));
        normalize.instructions.add(new FieldInsnNode(GETSTATIC, HELPER, "GRENADE", ID_DESC));
        normalize.instructions.add(new InsnNode(ARETURN));
        normalize.instructions.add(original);
        normalize.instructions.add(new FrameNode(F_SAME, 0, null, 0, null));
        normalize.instructions.add(new VarInsnNode(ALOAD, 0));
        normalize.instructions.add(new InsnNode(ARETURN));
        helper.methods.add(normalize);
        write(helper);
        System.out.println("PASS: four narrowly patched classes and one cached ammunition compatibility helper");
    }
}
