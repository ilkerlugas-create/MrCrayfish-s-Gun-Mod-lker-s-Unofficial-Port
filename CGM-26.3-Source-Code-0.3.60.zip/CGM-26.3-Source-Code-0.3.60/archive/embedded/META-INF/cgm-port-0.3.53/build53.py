from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib
import json

root = Path(__file__).resolve().parent.parent
source = root / 'upload/CGM-26.3-Forge66.0.2-0.3.52-Z-3D-EKLENTI-FIX(1).jar'
output = root / 'CGM-26.3-Forge66.0.2-0.3.53-BOMBAATAR-6-ELBOMBASI.jar'
removed = {
    'com/mrcrayfish/guns/port/ExtraAmmo.class',
    'data/cgm/recipe/grenade_round.json',
    'assets/cgm/items/grenade_round.json',
    'assets/cgm/models/item/grenade_round.json',
    'assets/cgm/items/workbench_preview/grenade_round.json',
    'assets/cgm/models/workbench_preview/grenade_round.json',
}
updates = {}
for path in (root / 'patch53/classes').rglob('*.class'):
    updates[path.relative_to(root / 'patch53/classes').as_posix()] = path.read_bytes()

with ZipFile(source) as original:
    assert removed <= set(original.namelist())
    gun_path = 'data/cgm/guns/grenade_launcher.json'
    gun = json.loads(original.read(gun_path))
    assert gun['general']['maxAmmo'] == gun['general']['reloadAmount'] == 6
    assert gun['projectile']['item'] == 'cgm:grenade_round'
    gun['projectile']['item'] = 'cgm:grenade'
    updates[gun_path] = (json.dumps(gun, indent=2) + '\n').encode()
    for lang in ('en_us', 'tr_tr'):
        path = f'assets/cgm/lang/{lang}.json'
        messages = json.loads(original.read(path))
        del messages['item.cgm.grenade_round']
        updates[path] = (json.dumps(messages, ensure_ascii=False, indent=2) + '\n').encode()
    for path in ('META-INF/MANIFEST.MF', 'META-INF/mods.toml'):
        data = original.read(path)
        assert data.count(b'0.3.52') == 1
        updates[path] = data.replace(b'0.3.52', b'0.3.53')

    with ZipFile(output, 'w', ZIP_DEFLATED, compresslevel=9) as result:
        for entry in original.infolist():
            if entry.filename not in removed:
                result.writestr(entry, updates.pop(entry.filename, original.read(entry.filename)))
        for name, data in updates.items():
            result.writestr(name, data)
        for path in (root / 'patch53').rglob('*'):
            if path.is_file() and path.suffix in ('.java', '.py', '.md', '.txt'):
                result.writestr('META-INF/cgm-port-0.3.53/' + path.relative_to(root / 'patch53').as_posix(), path.read_bytes())

with ZipFile(source) as original, ZipFile(output) as result:
    assert result.testzip() is None
    assert len(result.namelist()) == len(set(result.namelist()))
    assert not (removed & set(result.namelist()))
    changed = [n for n in original.namelist() if n in result.namelist() and original.read(n) != result.read(n)]
    expected_changes = {
        'com/mrcrayfish/guns/init/ModItems.class',
        'com/mrcrayfish/guns/GunMod.class',
        'com/mrcrayfish/guns/port/WorkbenchPreview.class',
        'com/mrcrayfish/guns/common/Gun$Projectile.class',
        'data/cgm/guns/grenade_launcher.json',
        'assets/cgm/lang/en_us.json',
        'assets/cgm/lang/tr_tr.json',
        'META-INF/MANIFEST.MF',
        'META-INF/mods.toml',
    }
    assert set(changed) == expected_changes, changed
    for name in result.namelist():
        if name.endswith('.json'):
            json.loads(result.read(name))
        if name.startswith(('assets/', 'data/')) and name.endswith('.json'):
            assert b'grenade_round' not in result.read(name), name
        if name.startswith('com/') and name.endswith('.class'):
            assert b'com/mrcrayfish/guns/port/ExtraAmmo' not in result.read(name), name
    # Existing six-round capacity/reload enforcement and one-unit shot decrement are byte-identical.
    for name in (
        'com/mrcrayfish/guns/util/GunEnchantmentHelper.class',
        'com/mrcrayfish/guns/common/ReloadTracker.class',
        'com/mrcrayfish/guns/common/network/ServerPlayHandler.class',
        'com/mrcrayfish/guns/item/GrenadeItem.class',
        'com/mrcrayfish/guns/port/AttachmentPreview.class',
        'com/mrcrayfish/guns/client/handler/GunRenderingHandler.class',
    ):
        assert result.read(name) == original.read(name), name

print('PASS: ZIP CRCs, unique entries, every JSON resource, retired item removal, isolated change set')
print('PASS: capacity/reload/shooting/hand-grenade/attachment/FPS renderer preserved byte-for-byte')
print('Changed existing entries:', len(changed), '; removed retired item entries:', len(removed))
print('SHA256:', hashlib.sha256(output.read_bytes()).hexdigest())
print('Output:', output)
