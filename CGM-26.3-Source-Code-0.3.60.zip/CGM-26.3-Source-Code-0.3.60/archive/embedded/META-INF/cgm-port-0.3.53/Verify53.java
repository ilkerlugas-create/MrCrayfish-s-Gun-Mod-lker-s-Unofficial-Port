import java.nio.file.*;
import java.lang.reflect.*;
import jdk.internal.org.objectweb.asm.*;
import jdk.internal.org.objectweb.asm.tree.*;
import jdk.internal.org.objectweb.asm.tree.analysis.*;

public final class Verify53 {
    static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
    static class HelperLoader extends ClassLoader {
        Class<?> loadHelper(Path file) throws Exception {
            byte[] bytes = Files.readAllBytes(file);
            bytes[6] = 0; bytes[7] = 61;
            // Only the isolated test copy is lowered for this machine's Java 17 runtime.
            return defineClass("com.mrcrayfish.guns.port.GrenadeAmmo", bytes, 0, bytes.length);
        }
    }
    public static void main(String[] args) throws Exception {
        Path root = Path.of(args[0]);
        int classes = 0, methods = 0;
        try (var paths = Files.walk(root)) {
            for (Path path : paths.filter(p -> p.toString().endsWith(".class")).toList()) {
                byte[] bytes = Files.readAllBytes(path);
                Path original = Path.of(args[1]).resolve(root.relativize(path));
                if (!Files.exists(original)) original = Path.of(args[1]).resolve("com/mrcrayfish/guns/common/Gun$Projectile.class");
                check(java.util.Arrays.equals(java.util.Arrays.copyOf(bytes, 8), java.util.Arrays.copyOf(Files.readAllBytes(original), 8)), "Production class-file version changed: " + path);
                bytes[6] = 0; bytes[7] = 61;
                ClassNode node = new ClassNode();
                new ClassReader(bytes).accept(node, 0);
                for (MethodNode method : node.methods) {
                    if (method.instructions.size() > 0) {
                        new Analyzer<BasicValue>(new BasicVerifier()).analyze(node.name, method);
                        methods++;
                    }
                    for (AbstractInsnNode n : method.instructions.toArray()) {
                        if (n instanceof MethodInsnNode call) check(!call.owner.endsWith("/ExtraAmmo"), "Retired factory reference remains");
                        if (n instanceof FieldInsnNode field) check(!field.owner.endsWith("/ExtraAmmo"), "Retired item reference remains");
                    }
                }
                classes++;
            }
        }
        Class<?> helper = new HelperLoader().loadHelper(root.resolve("com/mrcrayfish/guns/port/GrenadeAmmo.class"));
        var id = net.minecraft.resources.Identifier.class;
        Method normalize = helper.getMethod("normalize", id);
        Object legacy = net.minecraft.resources.Identifier.fromNamespaceAndPath("cgm", "grenade_round");
        Object grenade = normalize.invoke(null, legacy);
        check(grenade.equals(net.minecraft.resources.Identifier.fromNamespaceAndPath("cgm", "grenade")), "Legacy ammunition must normalize to hand grenade");
        check(normalize.invoke(null, legacy) == grenade, "Normalized identifiers must be cached");
        check(normalize.invoke(null, grenade) == grenade, "Current hand grenade identity must stay unchanged");
        for (String name : new String[] {"basic_bullet", "advanced_bullet", "shell", "missile", "stun_grenade"}) {
            Object other = net.minecraft.resources.Identifier.fromNamespaceAndPath("cgm", name);
            check(normalize.invoke(null, other) == other, "Unrelated ammunition changed: " + name);
        }
        Object foreign = net.minecraft.resources.Identifier.fromNamespaceAndPath("other_mod", "grenade_round");
        check(normalize.invoke(null, foreign) == foreign, "Other mod ammunition changed");
        check(normalize.invoke(null, new Object[] {null}) == null, "Null behavior changed");
        System.out.println("PASS: ASM bytecode data-flow verification for " + methods + " methods in " + classes + " classes");
        System.out.println("PASS: executed production compatibility helper with an isolated Identifier fixture (legacy, current, other ammo, namespace, null and allocation checks)");
        System.out.println("LIMIT: Minecraft/Forge game runtime was not available; no in-game launch performed");
    }
}
