#!/usr/bin/env python3
"""Patch CGM 0.3.17's effect atlas sources for Minecraft 26.3.

Usage: python patch_atlas.py input.jar output.jar
Only blocks.json and the build-version manifest are changed in existing entries.
"""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import struct
import zipfile

BASE_SHA256 = 'f0549f53dda549b28aefbbc2dc1d53fe8056cbbfdf21942b59d4671a71a00b3e'
ATLAS = 'assets/minecraft/atlases/blocks.json'
MANIFEST = 'META-INF/MANIFEST.MF'
EFFECTS = [
    'holo_reticle', 'holo_reticle_glow', 'long_scope_reticle',
    'muzzle_flash', 'red_dot_reticle', 'red_dot_reticle_glow', 'scope_vignette',
]
OLD_VERSION = b'1.3.7-26.3-port-0.3.17+framework-0.13.27'
NEW_VERSION = b'1.3.7-26.3-port-0.3.18+framework-0.13.27'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    assert args.input.resolve() != args.output.resolve()
    assert hashlib.sha256(args.input.read_bytes()).hexdigest() == BASE_SHA256
    sources = [{'type': 'minecraft:single', 'resource': 'cgm:effect/' + n}
               for n in EFFECTS]
    new_atlas = (json.dumps({'sources': sources}, indent=2) + '\n').encode()
    with zipfile.ZipFile(args.input) as original:
        assert original.testzip() is None
        names = original.namelist()
        assert len(names) == len(set(names))
        assert json.loads(original.read(ATLAS)) == {'sources': [
            {'type': 'minecraft:directory', 'source': 'effect', 'prefix': 'effect/'}
        ]}
        expected_paths = {'assets/cgm/textures/effect/' + n + '.png' for n in EFFECTS}
        actual_paths = {n for n in names if n.startswith('assets/cgm/textures/effect/')
                        and n.endswith('.png')}
        assert actual_paths == expected_paths, 'Unexpected effect texture inventory'
        texture_sizes = {}
        for n in sorted(expected_paths):
            png = original.read(n)
            assert png[:8] == b'\x89PNG\r\n\x1a\n'
            width, height = struct.unpack('>II', png[16:24])
            assert min(width, height) >= 16
            assert max(width, height).bit_length() >= 5
            texture_sizes[n] = [width, height]
        notes = (
            'CGM Minecraft 26.3 / Forge 66.0.2 - runtime hotfix 0.3.18\n\n'
            'Fix: restrict the effect sprite sources in the block atlas to the\n'
            'seven cgm:effect/* textures actually shipped by CGM.\n'
            'The old unqualified effect directory scan also selected Minecraft\n'
            '26.3\'s 4x4 minecraft:effect/dither sprite. TextureAtlas attempted to\n'
            'allocate five mip levels for it, causing the reported exception.\n'
            'Single-file sources keep the original CGM sprite identifiers and\n'
            'resource-pack overrides. All seven textures support five levels.\n\n'
            'All class files, models, textures, sounds, mixins and Framework files\n'
            'are retained byte-for-byte. The 0.3.17 reflection fixes are retained.\n'
            'No Minecraft texture is replaced; mipmap settings are unchanged.\n'
            'This patch only changes atlas JSON and the build-version manifest.\n\n'
            'Validation: atlas schema checked against Minecraft 26.3 DirectoryLister\n'
            'and SingleFile classes; texture coverage and dimensions checked;\n'
            'archive CRC and unchanged entries checked. No game launch test.\n\n'
            'Kurulum: Onceki CGM JAR dosyasini mods klasorunden disari tasiyin.\n'
            'Bu JAR dosyasini mods klasorune koyun. Framework zaten icindedir.\n'
        ).encode('utf-8')
        report = {
            'base_sha256': BASE_SHA256,
            'version': NEW_VERSION.decode(),
            'changed_existing_entries': [ATLAS, MANIFEST],
            'sources': sources,
            'texture_dimensions': texture_sizes,
            'preserves_all_original_entries': True,
            'class_files_changed': 0,
            'game_launch_test': 'not performed',
        }
        args.output.parent.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(args.output, 'w', compression=zipfile.ZIP_DEFLATED) as output:
            output.comment = original.comment
            for entry in original.infolist():
                data = original.read(entry.filename)
                if entry.filename == ATLAS:
                    data = new_atlas
                elif entry.filename == MANIFEST:
                    assert data.count(OLD_VERSION) == 1
                    data = data.replace(OLD_VERSION, NEW_VERSION)
                output.writestr(copy.copy(entry), data)
            output.writestr('CGM-26.3-RUNTIME-HOTFIX-0.3.18.txt', notes)
            output.writestr('META-INF/cgm-port-0.3.18-patch.py', Path(__file__).read_bytes())
            output.writestr('META-INF/cgm-port-0.3.18-validation.json',
                            json.dumps(report, indent=2) + '\n')
        with zipfile.ZipFile(args.output) as output:
            assert output.testzip() is None
            assert set(names) <= set(output.namelist())
            assert len(output.namelist()) == len(set(output.namelist()))
            changes = [n for n in names if original.read(n) != output.read(n)]
            assert set(changes) == {ATLAS, MANIFEST}
            assert json.loads(output.read(ATLAS))['sources'] == sources
            assert all(source['resource'].startswith('cgm:effect/') for source in sources)
            class_count = sum(n.endswith('.class') for n in names)
    print(json.dumps({
        'output': str(args.output.resolve()),
        'sha256': hashlib.sha256(args.output.read_bytes()).hexdigest(),
        'changed_existing_entries': changes,
        'preserved_original_entries': len(names) - 2,
        'preserved_class_files': class_count,
        'cgm_effect_textures': len(EFFECTS),
        'game_launch_test': 'not performed',
    }, indent=2))


if __name__ == '__main__':
    main()
