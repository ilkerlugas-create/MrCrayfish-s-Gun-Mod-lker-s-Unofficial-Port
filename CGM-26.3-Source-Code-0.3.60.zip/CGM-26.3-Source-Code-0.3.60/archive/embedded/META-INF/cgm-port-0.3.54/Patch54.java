import java.nio.file.*;
import java.util.*;
import jdk.internal.org.objectweb.asm.*;
import jdk.internal.org.objectweb.asm.tree.*;

public final class Patch54 implements Opcodes {
    static Path input, output;
    static final String FW = "com/mrcrayfish/framework/";
    static final String CTX = FW + "api/network/ConfigurationMessageContext";
    static final Handle META = new Handle(H_INVOKESTATIC, "java/lang/invoke/LambdaMetafactory", "metafactory",
        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite;", false);
    static ClassNode read(String name) throws Exception {
        byte[] bytes = Files.readAllBytes(input.resolve(name + ".class"));
        int major = ((bytes[6] & 255) << 8) | (bytes[7] & 255);
        bytes[6] = 0; bytes[7] = 61;
        ClassNode node = new ClassNode(); new ClassReader(bytes).accept(node, 0);
        node.version = major; return node;
    }
    static void write(ClassNode node) throws Exception {
        ClassWriter writer = new ClassWriter(ClassWriter.COMPUTE_MAXS);
        node.accept(writer);
        Path path = output.resolve(node.name + ".class");
        Files.createDirectories(path.getParent()); Files.write(path, writer.toByteArray());
    }
    static MethodNode method(ClassNode node, String name, String desc) {
        return node.methods.stream().filter(m -> m.name.equals(name) && m.desc.equals(desc)).findFirst().orElseThrow();
    }
    static void patchHandler(String simple, String manager, String instanceName, String operation, String errorKey) throws Exception {
        String name = FW + "network/message/configuration/" + simple;
        ClassNode node = read(name);
        MethodNode old = method(node, "handle", "(L" + name + ";L" + CTX + ";)V");
        long waitCalls = Arrays.stream(old.instructions.toArray()).filter(n -> n instanceof MethodInsnNode m && m.owner.equals("java/util/concurrent/CountDownLatch") && m.name.equals("await")).count();
        if (waitCalls != 1) throw new IllegalStateException("Unexpected original synchronization handler: " + name);
        // Keep public method metadata; replace only its method body and the old private worker.
        old.instructions.clear(); old.tryCatchBlocks.clear(); old.localVariables = null;
        old.visibleLocalVariableAnnotations = null; old.invisibleLocalVariableAnnotations = null;
        InsnList code = old.instructions;
        code.add(new VarInsnNode(ALOAD, 1));
        code.add(new InvokeDynamicInsnNode("execute", "(L" + CTX + ";)Ljava/util/concurrent/Executor;", META,
            Type.getMethodType("(Ljava/lang/Runnable;)V"),
            new Handle(H_INVOKEVIRTUAL, CTX, "execute", "(Ljava/lang/Runnable;)V", false),
            Type.getMethodType("(Ljava/lang/Runnable;)V")));
        code.add(new VarInsnNode(ALOAD, 0));
        code.add(new InvokeDynamicInsnNode("getAsBoolean", "(L" + name + ";)Ljava/util/function/BooleanSupplier;", META,
            Type.getMethodType("()Z"),
            new Handle(H_INVOKESTATIC, name, "applySynchronization54", "(L" + name + ";)Z", false),
            Type.getMethodType("()Z")));
        code.add(new MethodInsnNode(INVOKESTATIC, FW + "port/SynchronizationGuard", "run", "(Ljava/util/concurrent/Executor;Ljava/util/function/BooleanSupplier;)Z", false));
        LabelNode done = new LabelNode();
        code.add(new JumpInsnNode(IFNE, done));
        code.add(new VarInsnNode(ALOAD, 1));
        code.add(new LdcInsnNode(errorKey));
        code.add(new MethodInsnNode(INVOKESTATIC, "net/minecraft/network/chat/Component", "translatable", "(Ljava/lang/String;)Lnet/minecraft/network/chat/MutableComponent;", true));
        code.add(new MethodInsnNode(INVOKEVIRTUAL, CTX, "disconnect", "(Lnet/minecraft/network/chat/Component;)V", false));
        code.add(done); code.add(new FrameNode(F_SAME, 0, null, 0, null)); code.add(new InsnNode(RETURN));
        node.methods.removeIf(m -> m.name.equals("lambda$handle$0"));
        MethodNode worker = new MethodNode(ACC_PRIVATE | ACC_STATIC | ACC_SYNTHETIC, "applySynchronization54", "(L" + name + ";)Z", null, null);
        worker.instructions.add(new MethodInsnNode(INVOKESTATIC, manager, instanceName, "()L" + manager + ";", false));
        worker.instructions.add(new VarInsnNode(ALOAD, 0));
        worker.instructions.add(new MethodInsnNode(INVOKEVIRTUAL, manager, operation, "(L" + name + ";)Z", false));
        worker.instructions.add(new InsnNode(IRETURN)); node.methods.add(worker);
        write(node);
    }
    public static void main(String[] args) throws Exception {
        input = Path.of(args[0]); output = Path.of(args[1]);
        patchHandler("S2CSyncedEntityData", FW + "entity/sync/SyncedEntityData", "instance", "updateMappings", "framework.gui.sync_entity_data_failed");
        patchHandler("S2CConfigData", FW + "config/FrameworkConfigManager", "getInstance", "processConfigData", "framework.gui.sync_config_failed");
        ClassNode setup = read(FW + "FrameworkSetup");
        MethodNode run = method(setup, "run", "()V");
        if ((run.access & ACC_SYNCHRONIZED) != 0) throw new IllegalStateException("Setup is already synchronized");
        run.access |= ACC_SYNCHRONIZED;
        write(setup);
        System.out.println("Patched both configuration handlers and serialized one-time Framework setup");
    }
}
