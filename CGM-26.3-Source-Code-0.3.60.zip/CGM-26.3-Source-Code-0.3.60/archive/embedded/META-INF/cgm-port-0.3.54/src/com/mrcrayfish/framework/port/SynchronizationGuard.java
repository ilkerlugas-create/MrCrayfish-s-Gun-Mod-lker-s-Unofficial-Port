package com.mrcrayfish.framework.port;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.function.BooleanSupplier;

/** Runs configuration work without leaving the network thread waiting forever. */
public final class SynchronizationGuard {
    private SynchronizationGuard() {}

    public static boolean run(Executor executor, BooleanSupplier operation) {
        return run(executor, operation, 30_000L);
    }

    static boolean run(Executor executor, BooleanSupplier operation, long timeoutMillis) {
        CompletableFuture<Boolean> completion = new CompletableFuture<>();
        try {
            executor.execute(() -> {
                // Timed-out or interrupted queued work must not alter a later connection.
                if (completion.isDone()) return;
                try {
                    completion.complete(operation.getAsBoolean());
                } catch (Throwable failure) {
                    completion.completeExceptionally(failure);
                    if (failure instanceof Error error) throw error;
                }
            });
            return completion.get(timeoutMillis, TimeUnit.MILLISECONDS);
        } catch (InterruptedException interrupted) {
            completion.cancel(false);
            Thread.currentThread().interrupt();
            return false;
        } catch (ExecutionException | TimeoutException | RuntimeException failure) {
            completion.cancel(false);
            System.getLogger("Framework").log(System.Logger.Level.ERROR,
                "Framework configuration synchronization failed", failure);
            return false;
        }
    }
}
