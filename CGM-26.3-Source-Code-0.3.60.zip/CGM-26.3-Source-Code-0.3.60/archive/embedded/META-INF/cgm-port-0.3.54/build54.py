from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib
import json
import shutil

root = Path(__file__).resolve().parent.parent
source = root / 'CGM-26.3-Forge66.0.2-0.3.53-BOMBAATAR-6-ELBOMBASI.jar'
output = root / 'CGM-26.3-Forge66.0.2-0.3.54-FRAMEWORK-SYNC-FIX.jar'
updates = {p.relative_to(root/'patch54/classes').as_posix(): p.read_bytes()
           for p in (root/'patch54/classes').rglob('*.class')}
assert len(updates) == 4
with ZipFile(source) as original:
    for name in ['META-INF/MANIFEST.MF', 'META-INF/mods.toml']:
        data = original.read(name)
        assert data.count(b'0.3.53') == 1
        updates[name] = data.replace(b'0.3.53', b'0.3.54')
    with ZipFile(output, 'w', ZIP_DEFLATED, compresslevel=9) as result:
        for entry in original.infolist():
            result.writestr(entry, updates.pop(entry.filename, original.read(entry.filename)))
        for name, data in updates.items():
            result.writestr(name, data)
        for path in (root/'patch54').rglob('*'):
            if path.is_file() and path.suffix in ('.java', '.py', '.md', '.txt') and path.name != 'expected-test-errors.txt':
                result.writestr('META-INF/cgm-port-0.3.54/'+path.relative_to(root/'patch54').as_posix(), path.read_bytes())
with ZipFile(source) as original, ZipFile(output) as result:
    assert result.testzip() is None
    assert len(result.namelist()) == len(set(result.namelist()))
    assert set(original.namelist()) <= set(result.namelist())
    changed = {n for n in original.namelist() if original.read(n) != result.read(n)}
    assert changed == {
        'META-INF/MANIFEST.MF', 'META-INF/mods.toml',
        'com/mrcrayfish/framework/FrameworkSetup.class',
        'com/mrcrayfish/framework/network/message/configuration/S2CConfigData.class',
        'com/mrcrayfish/framework/network/message/configuration/S2CSyncedEntityData.class',
    }, changed
    for name in result.namelist():
        if name.endswith('.json'): json.loads(result.read(name))
        assert not name.startswith('net/minecraft/'), name
    assert json.loads(result.read('data/cgm/guns/grenade_launcher.json'))['projectile']['item'] == 'cgm:grenade'
    for name in result.namelist():
        if name.startswith('META-INF/services/') and not name.endswith('/'):
            for provider in result.read(name).decode().splitlines():
                provider = provider.split('#',1)[0].strip()
                if provider: assert provider.replace('.','/')+'.class' in result.namelist(), provider
    result.extractall(root/'audit54/candidate')
print('PASS: ZIP/JSON, service providers, no dropped entries, no test classes in runtime namespaces')
print('PASS: three Framework classes changed; every CGM class and gameplay asset unchanged')
print('SHA256:', hashlib.sha256(output.read_bytes()).hexdigest())
print(output)
