import java.nio.file.*;
import java.lang.reflect.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import com.mrcrayfish.framework.api.network.ConfigurationMessageContext;
import com.mrcrayfish.framework.config.FrameworkConfigManager;
import com.mrcrayfish.framework.entity.sync.SyncedEntityData;
import com.mrcrayfish.framework.Registration;

public class ProductionMethodsTest {
 static void check(boolean b,String message){if(!b)throw new AssertionError(message);}
 static class Isolated extends ClassLoader {
  Path root;Isolated(Path root){this.root=root;}
  Class<?> methodClass(String name)throws Exception{
   byte[] data=Files.readAllBytes(root.resolve(name.replace('.','/')+".class"));return defineClass(name,data,0,data.length);
  }
 }
 static void setupTest(Path root,int expected)throws Exception{
  Registration.reset();
  Method run=new Isolated(root).methodClass("com.mrcrayfish.framework.FrameworkSetup").getMethod("run");
  AtomicReference<Throwable> failure=new AtomicReference<>();
  Runnable invoke=()->{try{run.invoke(null);}catch(Throwable e){failure.set(e);}};
  Thread one=new Thread(invoke),two=new Thread(invoke);
  one.start();check(Registration.first.await(1,TimeUnit.SECONDS),"First initialization did not start");
  two.start();boolean duplicate=Registration.second.await(100,TimeUnit.MILLISECONDS);
  Registration.release.countDown();one.join(1000);two.join(1000);
  check(!one.isAlive()&&!two.isAlive()&&failure.get()==null,"Initialization failed");
  check(Registration.count.get()==expected,"Expected initialization count "+expected+", found "+Registration.count.get());
  check(duplicate==(expected==2),"Unexpected duplicate registration");
 }
 public static void main(String[] args)throws Exception{
  setupTest(Path.of(args[0]),2);
  setupTest(Path.of(args[1]),1);
  System.out.println("PASS: actual FrameworkSetup.run reproduces duplicate initialization before patch; exactly one after patch");
  for(String name:new String[]{"S2CConfigData","S2CSyncedEntityData"}){
   Class<?> message=Class.forName("com.mrcrayfish.framework.network.message.configuration."+name);
   Object value=message.getConstructor().newInstance();
   Method handler=message.getMethod("handle",message,ConfigurationMessageContext.class);
   for(int mode=0;mode<3;mode++){
    FrameworkConfigManager.mode=SyncedEntityData.mode=mode;
    var context=new ConfigurationMessageContext(Runnable::run);
    handler.invoke(null,value,context);
    check(context.disconnects==(mode==0?0:1),"Wrong handler outcome: "+name+" mode "+mode);
    if(mode!=0)check(context.error.equals(name.equals("S2CConfigData")?"framework.gui.sync_config_failed":"framework.gui.sync_entity_data_failed"),"Wrong disconnect reason");
   }
  }
  System.out.println("PASS: both actual patched message handlers invoke their managers and disconnect on rejection/exception");
 }
}
