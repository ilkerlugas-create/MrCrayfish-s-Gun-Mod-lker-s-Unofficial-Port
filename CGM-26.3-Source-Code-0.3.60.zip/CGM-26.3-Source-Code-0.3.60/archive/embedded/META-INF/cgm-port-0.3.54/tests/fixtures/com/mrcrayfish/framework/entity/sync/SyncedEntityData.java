package com.mrcrayfish.framework.entity.sync;
import com.mrcrayfish.framework.network.message.configuration.S2CSyncedEntityData;
public class SyncedEntityData {
 public static int mode;private static final SyncedEntityData INSTANCE=new SyncedEntityData();
 public static SyncedEntityData instance(){return INSTANCE;}
 public boolean updateMappings(S2CSyncedEntityData message){if(mode==2)throw new IllegalArgumentException("Test malformed mapping");return mode==0;}
}
