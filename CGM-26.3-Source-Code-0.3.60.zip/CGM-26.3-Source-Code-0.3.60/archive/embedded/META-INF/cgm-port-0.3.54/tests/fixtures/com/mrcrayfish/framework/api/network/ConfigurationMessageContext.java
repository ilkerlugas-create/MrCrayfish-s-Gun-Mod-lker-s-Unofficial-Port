package com.mrcrayfish.framework.api.network;
import java.util.concurrent.Executor;
import net.minecraft.network.chat.Component;
public class ConfigurationMessageContext {
 public int disconnects;public String error;private final Executor executor;
 public ConfigurationMessageContext(Executor executor){this.executor=executor;}
 public final void execute(Runnable runnable){executor.execute(runnable);}
 public final void disconnect(Component component){disconnects++;error=component.key();}
}
