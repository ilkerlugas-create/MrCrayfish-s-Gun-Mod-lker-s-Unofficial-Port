package com.mrcrayfish.framework;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
public class Registration {
 public static AtomicInteger count=new AtomicInteger();
 public static CountDownLatch first,second,release;
 public static void reset(){count.set(0);first=new CountDownLatch(1);second=new CountDownLatch(1);release=new CountDownLatch(1);}
 public static void init(){int n=count.incrementAndGet();first.countDown();if(n>1)second.countDown();try{release.await();}catch(InterruptedException e){throw new RuntimeException(e);}}
}
