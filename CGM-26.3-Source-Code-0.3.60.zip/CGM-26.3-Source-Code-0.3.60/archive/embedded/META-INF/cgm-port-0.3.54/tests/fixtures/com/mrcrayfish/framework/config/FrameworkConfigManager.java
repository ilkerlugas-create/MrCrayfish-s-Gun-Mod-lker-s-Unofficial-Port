package com.mrcrayfish.framework.config;
import com.mrcrayfish.framework.network.message.configuration.S2CConfigData;
public class FrameworkConfigManager {
 public static int mode;private static final FrameworkConfigManager INSTANCE=new FrameworkConfigManager();
 public static FrameworkConfigManager getInstance(){return INSTANCE;}
 public boolean processConfigData(S2CConfigData message){if(mode==2)throw new IllegalArgumentException("Test malformed config");return mode==0;}
}
