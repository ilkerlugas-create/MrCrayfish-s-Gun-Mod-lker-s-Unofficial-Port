package net.minecraft.network.chat;
public interface Component {
 String key();
 static MutableComponent translatable(String key){return new MutableComponent(key);}
}
