package net.minecraft.network.chat;
public record MutableComponent(String key) implements Component {}
