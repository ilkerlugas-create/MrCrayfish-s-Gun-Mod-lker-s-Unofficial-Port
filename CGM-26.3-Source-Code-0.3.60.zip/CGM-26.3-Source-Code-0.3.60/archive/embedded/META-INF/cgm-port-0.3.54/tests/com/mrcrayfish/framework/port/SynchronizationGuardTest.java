package com.mrcrayfish.framework.port;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

public class SynchronizationGuardTest {
    static void check(boolean ok, String message) { if (!ok) throw new AssertionError(message); }
    public static void main(String[] args) throws Exception {
        check(SynchronizationGuard.run(Runnable::run, () -> true, 1000), "Direct success");
        check(!SynchronizationGuard.run(Runnable::run, () -> false, 1000), "Processing rejection");
        ExecutorService service = Executors.newSingleThreadExecutor();
        try {
            check(SynchronizationGuard.run(service, () -> true, 1000), "Scheduled success");
            check(!SynchronizationGuard.run(service, () -> { throw new IllegalArgumentException("invalid server mapping"); }, 1000), "Worker exception must unblock caller");
        } finally { service.shutdownNow(); }
        check(!SynchronizationGuard.run(r -> { throw new RejectedExecutionException("closed connection"); }, () -> true, 1000), "Rejected scheduling");
        AtomicReference<Runnable> queued = new AtomicReference<>();
        AtomicInteger mutations = new AtomicInteger();
        check(!SynchronizationGuard.run(queued::set, () -> { mutations.incrementAndGet(); return true; }, 20), "Unserviced queue must time out");
        queued.get().run();
        check(mutations.get() == 0, "Expired queued work must not mutate state");
        Thread.currentThread().interrupt();
        check(!SynchronizationGuard.run(queued::set, () -> true, 1000), "Interrupted waiting must fail");
        check(Thread.currentThread().isInterrupted(), "Interrupt status must be restored");
        Thread.interrupted();
        System.out.println("PASS: success, server-data rejection, worker exception, executor rejection, timeout, late-work suppression and interruption");
    }
}
