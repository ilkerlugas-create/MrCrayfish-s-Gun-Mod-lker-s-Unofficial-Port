# Framework denetimi — CGM 0.3.54

Temel dosya: CGM-26.3-Forge66.0.2-0.3.53-BOMBAATAR-6-ELBOMBASI.jar.
Bu sürüm, Framework uyarlamasının tamamlandığı anlamına gelmez.

## Düzeltilen iki sorun

1. **Eşitleme sırasında süresiz bekleme ve kesme bilgisinin kaybı.**
   `S2CSyncedEntityData` işçisi hata fırlatırsa `CountDownLatch.countDown()`
   çalışmıyordu; bekleyen ağ iş parçacığı süresiz kalabiliyordu.
   Her iki eşitleme mesajında zaman sınırı olmadan bekleme ve kesilme bilgisini
   yutma vardı. İş sonucu artık hata durumunda da tamamlanan bir future ile
   izleniyor; bekleme 30 saniyeyle sınırlı. Reddedilen işler/hatalar bağlantıyı
   mevcut uygun eşitleme hatasıyla kapatıyor. Kesilme bayrağı geri yükleniyor.
   Zaman aşımından sonra hâlâ kuyrukta olan iş çalıştırılmıyor.
   Başlamış bir iş zorla durdurulmuyor.
2. **Paralel başlangıçta çift Framework kaydı.** `FrameworkSetup.run()` içindeki
   kontrol ve başlatma atomik değildi. Aynı üretim metoduyla iki iş parçacıklı
   testte iki başlangıç yeniden üretildi. Metot senkronize edildi; aynı testte
   başlatma sayısı bire düştü.

## Doğrulanan fakat bu sürümde tamamlanmayan iki uyarlama

- `ForgeClientHelper.getStandaloneModel()` koşulsuz `null` döndürüyor.
  `FrameworkModelResource.getModel()` bu sağlayıcıyı çağırıyor. CGM reload
  parçaları, minigun gövde/namlu ve bombaatar gövde/silindir kodu bu modelleri
  talep ediyor. Gerçek model yükleme/bake/yenileme bağlantısı kurulmalı.
- `ForgeNetworkBuilder.registerConfigurationMessage(..., boolean)` hiçbir
  kayıt yapmadan geri dönüyor. `ForgeNetwork` yapıcısı verilen configuration
  task listesini işlemiyor. Başlangıç ayarları ve entity-key eşitleme yolu
  eksik. Yukarıdaki mesaj bekleme düzeltmesi bu eksik kayıt yolunu açmaz ve
  tek başına çok oyunculu eşitlemeyi tamamlamaz.

Bu iki sistemi rastgele metot adlarıyla bağlamak açılışı/dünyaya girişi bozabilir.
Doğru uyarlama için gereken Minecraft 26.3 ve Forge 66.0.2 çalışma zamanı/API
dosyaları ortamda yok; resmi kaynaklara ağ erişimi de başarısız oldu. Kullanıcının
Minecraft 26.3 istemci JAR'ı ile Forge 66.0.2 universal JAR'ı sağlandığında gerçek
sınıf/metot imzaları doğrulanıp model ve configuration-task bağlantıları kurulabilir.

## Yapılan denetim ve testler

- Girdi JAR'ında 267 Framework sınıfı, 1.850 kod içeren metot üzerinde ASM temel
  veri akışı kontrolü: hata yok. Bu, oyun çalışma zamanı uyumluluğu testi değildir.
- 588 paket sınıfındaki 11.842 paket içi üye başvurusu incelendi. Kesin eksik
  paket içi üye bulunmadı. Minecraft/Forge üst sınıflarından miras kalan üyeler,
  bağımlılık JAR'ları bulunmadığından doğrulanmış sayılmadı.
- 6 servis sağlayıcı dosyası ve Mixin yapılandırmaları arşivde mevcut.
- Gerçek yeni eşitleme yardımcısıyla başarı, işlem reddi, işçi istisnası,
  iş kuyruğu reddi, zaman aşımı, gecikmiş işi atlama ve kesilme testleri geçti.
- Gerçek iki yeni mesaj işleyici metodunun izole kopyaları test bağımlılıklarıyla
  çalıştırıldı: doğru yönetici çağrısı, hata ve ret durumunda bağlantı kapatma geçti.
- Gerçek `FrameworkSetup.run()` metodu üzerinde önce/sonra çift başlatma testi geçti.
- Üretim dosyasına test sınıfları eklenmedi. Test kaynakları yalnızca META-INF
  altında tekrar üretim bilgisi olarak yer alır.
- Tam Forge derlemesi ve oyun içi test yapılmadı.

## Korunanlar

CGM kodu, tüm silah kaynakları, Z/eklenti menüsü, animasyonlar, sesler ve 0.3.53'ün
6 el bombalı bombaatar değişikliği byte-for-byte korunur. Yalnızca üç Framework
sınıfı değiştirilir ve bir eşitleme yardımcısı eklenir. Framework sürüm kimliği
0.13.27 olarak kalır; paket CGM sürümü 0.3.54 olur.

Kurulum: önceki CGM JAR'ını kaldırıp bu JAR'ı kullanın. Framework paketin içindedir.
