import java.nio.file.*;
import jdk.internal.org.objectweb.asm.*;
import jdk.internal.org.objectweb.asm.tree.*;
/** Isolates actual production method bodies for execution without Minecraft libraries. */
public class ExtractTests implements Opcodes {
 public static void main(String[] args)throws Exception {
  for(String simple:new String[]{"FrameworkSetup","network/message/configuration/S2CConfigData","network/message/configuration/S2CSyncedEntityData"}) {
   Path path=Path.of(args[0],"com/mrcrayfish/framework/"+simple+".class");
   byte[] bytes=Files.readAllBytes(path);bytes[6]=0;bytes[7]=61;
   ClassNode source=new ClassNode();new ClassReader(bytes).accept(source,0);
   ClassNode test=new ClassNode();test.name=source.name;test.version=61;test.access=ACC_PUBLIC|ACC_SUPER;test.superName="java/lang/Object";
   MethodNode ctor=new MethodNode(ACC_PUBLIC,"<init>","()V",null,null);
   ctor.instructions.add(new VarInsnNode(ALOAD,0));ctor.instructions.add(new MethodInsnNode(INVOKESPECIAL,"java/lang/Object","<init>","()V",false));ctor.instructions.add(new InsnNode(RETURN));test.methods.add(ctor);
   for(MethodNode m:source.methods)if(m.name.equals("run")||m.name.equals("handle")||m.name.equals("applySynchronization54"))test.methods.add(m);
   for(FieldNode f:source.fields)if(f.name.equals("initialized"))test.fields.add(f);
   ClassWriter writer=new ClassWriter(ClassWriter.COMPUTE_MAXS);test.accept(writer);
   Path out=Path.of(args[1],source.name+".class");Files.createDirectories(out.getParent());Files.write(out,writer.toByteArray());
  }
 }
}
