import zipfile,json,copy,math,itertools,re,hashlib
from pathlib import Path
base=Path('output/CGM-26.3-Forge66.0.2-0.3.30-DOKU-3D-TEZGAH-FIX.jar');out=Path('output/CGM-26.3-Forge66.0.2-0.3.31-NET-3D-YUMUSAK-DONUS.jar')
updates={p.relative_to('work31/classes').as_posix():p.read_bytes() for p in Path('work31/classes').rglob('*.class')}
def enc(d):return (json.dumps(d,indent=2)+'\n').encode()
def vertices(e):
 for p in itertools.product(*zip(e['from'],e['to'])):
  p=list(p);rot=e.get('rotation')
  if rot:
   axis='xyz'.index(rot['axis']);u,v=[a for a in range(3) if a!=axis];t=math.radians(rot['angle']);o=rot['origin'];a=p[u]-o[u];b=p[v]-o[v]
   if axis==1:t=-t
   r=1/math.cos(t) if rot.get('rescale') else 1
   p[u]=o[u]+r*(a*math.cos(t)-b*math.sin(t));p[v]=o[v]+r*(a*math.sin(t)+b*math.cos(t))
  yield p
fits={}
with zipfile.ZipFile(base) as z:
 guns=['pistol','shotgun','rifle','grenade_launcher','bazooka','mini_gun','assault_rifle','machine_pistol','heavy_rifle']
 for gun in guns:
  parts={'mini_gun':['mini_gun_base','mini_gun_barrels'],'grenade_launcher':['grenade_launcher_base','grenade_launcher_cylinder']}.get(gun,['gun/'+gun])
  elements=[];textures={};sources=[]
  for index,part in enumerate(parts):
   n='assets/cgm/models/special/'+part+'.json';src=json.loads(z.read(n));sources.append(n)
   for k,v in src['textures'].items():textures[str(index)+'_'+k]=('#'+str(index)+'_'+v[1:]) if v.startswith('#') else v
   for original in src['elements']:
    e=copy.deepcopy(original)
    for face in e['faces'].values():
     t=face['texture'];face['texture']='#'+str(index)+'_'+t[1:] if t.startswith('#') else t
    elements.append(e)
  points=[p for e in elements for p in vertices(e)];center=[(min(p[a] for p in points)+max(p[a] for p in points))/2 for a in range(3)]
  for e in elements:
   for k in ['from','to']:e[k]=[v+8-center[a] for a,v in enumerate(e[k])]
   if 'rotation' in e:e['rotation']['origin']=[v+8-center[a] for a,v in enumerate(e['rotation']['origin'])]
  # Same meshes/UVs as the first-person renderer, translated only to the preview pivot.
  w=h=0
  for angle in range(52,89):
   t=math.radians(angle);pitch=math.radians(12)
   projected=[]
   for p in points:
    x,y,zv=[p[a]-center[a] for a in range(3)];xx=x*math.cos(t)+zv*math.sin(t);zz=-x*math.sin(t)+zv*math.cos(t);yy=y*math.cos(pitch)-zz*math.sin(pitch);projected.append((xx,yy))
   # Keep the pivot at the screen center, so asymmetric extents cannot clip.
   w=max(w,2*max(abs(v[0]) for v in projected));h=max(h,2*max(abs(v[1]) for v in projected))
  scale=min(132/w,40/h)*.98
  guiScale=scale/3.6;assert guiScale<=4
  d={'gui_light':'side','textures':textures,'elements':elements,'display':{'gui':{'rotation':[12,70,0],'translation':[0,0,0],'scale':[guiScale]*3}}}
  updates['assets/cgm/models/workbench_preview/'+gun+'.json']=enc(d)
  fits[gun]={'first_person_sources':sources,'elements':len(elements),'width':w*scale,'height':h*scale}
  assert min(w*scale,h*scale)>16,'Must use native oversized 3D target'
 for n in ['META-INF/MANIFEST.MF','META-INF/mods.toml']:updates[n]=re.sub(rb'port-0\.3\.30',b'port-0.3.31',z.read(n))
 for p in Path('work31/src').rglob('*.java'):updates['META-INF/cgm-port-0.3.31/src/'+p.relative_to('work31/src').as_posix()]=p.read_bytes()
 for name in ['Patch31.java','package31.py','Regression31.java','linkage.txt']:
  p=Path('work31')/name
  if p.exists():updates['META-INF/cgm-port-0.3.31/'+name]=p.read_bytes()
 updates['META-INF/cgm-port-0.3.31/validation.json']=enc({'preview_bounds':fits,'in_game_test':False})
 updates['CGM-0.3.31-OKU.txt']='''0.3.31 — Net 3D tezgâh ve yumuşak kamera dönüşü
Tezgâh modeli artık küçük envanter resmi büyütülerek çizilmez; büyük 3D çizim hedefi kullanılır.
Dokuz önizleme, FPS çizimindeki özgün model parçaları ve UV/dokularıyla oluşturuldu.
Modelin ince uç görünümüne dönmesi yerine sınırlı, yavaş 3D dönüş kullanılır.
Kamera dönüşü karakter baş açısı yerine kamera açısını kullanır. Açı farkı hassasiyet uygulanmadan önce normalize edilir; sallanma yumuşak sınırlanır.
Reload, atış, boya, mühimmat ve özgün dokular korunur.
Eski CGM JAR'ını mods klasöründen çıkarıp bunu koy; oyunu yeniden başlat.
Framework dahildir. İstemci/sunucuda aynı sürümü kullan.
Kod ve model kontrolleri yapıldı; oyun içi görsel test yapılmadı.
'''.encode()
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as target:
  for n in z.namelist():target.writestr(n,updates.pop(n,z.read(n)))
  for n,v in updates.items():target.writestr(n,v)
with zipfile.ZipFile(base) as a,zipfile.ZipFile(out) as b:
 assert b.testzip() is None
 for n in a.namelist():
  if n.startswith(('assets/cgm/textures/','data/','assets/cgm/items/')):assert a.read(n)==b.read(n)
 for n in b.namelist():
  if n.endswith('.json'):json.loads(b.read(n))
print('PASS: 9 FPS-sourced models fit native 3D targets; textures, dye, ammo and gameplay data preserved')
print(out.resolve());print(hashlib.sha256(out.read_bytes()).hexdigest())
