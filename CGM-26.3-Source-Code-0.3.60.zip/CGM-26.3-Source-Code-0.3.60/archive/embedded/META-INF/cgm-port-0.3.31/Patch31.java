import java.nio.file.*;import java.util.*;import java.util.jar.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;
public class Patch31 implements Opcodes {
 public static void main(String[] args)throws Exception {
  int scales=0,diffs=0,fields=0,limits=0;
  try(JarFile jar=new JarFile(args[0])) {
   for(String path:List.of("client/handler/GunRenderingHandler","client/screen/WorkbenchScreen")) {
    String name="com/mrcrayfish/guns/"+path;ClassNode c=new ClassNode();new ClassReader(jar.getInputStream(jar.getJarEntry(name+".class"))).accept(c,0);
    for(MethodNode m:c.methods) {
     if(m.name.equals("applySwayTransforms")) {
      int sway=0;
      for(var i:m.instructions.toArray()) {
       if(i instanceof FieldInsnNode f && f.name.equals("yHeadRotO")){f.name="yRotO";fields++;}
       else if(i instanceof FieldInsnNode f && f.name.equals("yHeadRot")){m.instructions.set(i,new MethodInsnNode(INVOKEVIRTUAL,"net/minecraft/client/player/LocalPlayer","getYRot","()F",false));fields++;}
       else if(i.getOpcode()==FSUB){m.instructions.set(i,new MethodInsnNode(INVOKESTATIC,"com/mrcrayfish/guns/port/LookSway","difference","(FF)F",false));diffs++;}
       else if(i instanceof MethodInsnNode call && call.owner.equals("com/mrcrayfish/guns/port/MotionLimits") && call.name.equals("sway")) {
        if(++sway>1){call.owner="com/mrcrayfish/guns/port/LookSway";call.name="limit";limits++;}
       }
      }
     }
     if(m.name.equals("extractBackground"))for(var i:m.instructions.toArray())if(i instanceof MethodInsnNode call && call.owner.equals("org/joml/Matrix3x2fStack") && call.name.equals("scale") && i.getPrevious() instanceof LdcInsnNode ldc && ldc.cst.equals(3.6f)) {
      m.instructions.insertBefore(i,new VarInsnNode(ALOAD,7));
      call.setOpcode(INVOKESTATIC);call.owner="com/mrcrayfish/guns/port/WorkbenchPreview";call.name="scale";call.desc="(Lorg/joml/Matrix3x2fStack;FFLnet/minecraft/world/item/ItemStack;)Lorg/joml/Matrix3x2f;";scales++;
     }
    }
    ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);Path out=Path.of(args[1],name+".class");Files.createDirectories(out.getParent());Files.write(out,w.toByteArray());
   }
  }
  if(scales!=1||diffs!=2||fields!=2||limits!=2)throw new AssertionError(List.of(scales,diffs,fields,limits));
  System.out.println("PASS: native-sized gun preview; camera yaw; 2 wrapped differences before sensitivity; 2 smooth look limits");
 }
}
