package com.mrcrayfish.guns.port;
public final class LookSway {
 public static float difference(float head,float bob) {
  float d=head-bob;
  if(!Float.isFinite(d))return 0;
  d%=360;
  if(d>=180)d-=360;
  if(d< -180)d+=360;
  return d;
 }
 public static float limit(float degrees) {
  return Float.isFinite(degrees)?(float)(1.75*Math.tanh(degrees/7.0)):0;
 }
}
