package com.mrcrayfish.guns.port;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
public final class WorkbenchPreview {
 public static void animate(net.minecraft.client.renderer.item.ItemStackRenderState state,ItemStack stack) {
  Identifier model=stack.get(DataComponents.ITEM_MODEL);
  if(model==null || !model.getNamespace().equals("cgm") || !model.getPath().startsWith("workbench_preview/"))return;
  var mc=net.minecraft.client.Minecraft.getInstance();
  if(mc.level==null)return;
  float partial=mc.getDeltaTracker().getGameTimeDeltaPartialTick(true);
  float angle=(float)Math.toRadians(18.0*Math.sin(((mc.level.getGameTime()%240)+partial)*Math.PI/120.0));
  var transform=new org.joml.Matrix4f().translate(.5F,.5F,.5F).rotateY(angle).scale(3.6F).translate(-.5F,-.5F,-.5F);
  var access=(com.mrcrayfish.guns.mixin.client.PreviewLayersAccessor)(Object)state;
  var layers=access.cgmPreviewLayers();
  for(int i=0;i<access.cgmPreviewLayerCount();i++)layers[i].setLocalTransform(transform);
  state.setOversizedInGui(true);
  state.setAnimated();
 }
 public static org.joml.Matrix3x2f scale(org.joml.Matrix3x2fStack pose,float x,float y,ItemStack stack) {
  if(stack!=null && stack.getItem() instanceof com.mrcrayfish.guns.item.GunItem)return pose;
  return pose.scale(x,y);
 }
 public static ItemStack create(ItemStack original) {
  ItemStack result=original.copy();
  var id=BuiltInRegistries.ITEM.getKey(original.getItem());
  if(id.getNamespace().equals("cgm") && java.util.Set.of("pistol","shotgun","rifle","grenade_launcher","bazooka","mini_gun","assault_rifle","machine_pistol","heavy_rifle").contains(id.getPath()))
   result.set(DataComponents.ITEM_MODEL,Identifier.parse("cgm:workbench_preview/"+id.getPath()));
  DyeBridge.sync(result);
  return result;
 }
}
