import com.mrcrayfish.guns.port.LookSway;
import net.minecraft.client.renderer.item.TrackingItemStackRenderState;
import net.minecraft.client.renderer.state.gui.GuiItemRenderState;
import net.minecraft.client.resources.model.cuboid.ItemTransform;
import net.minecraft.world.item.ItemDisplayContext;
import org.joml.*;
public class Regression31 {
 public static void main(String[] args) {
  if(LookSway.difference(-179,179)!=2||LookSway.difference(179,-179)!=-2)throw new AssertionError("yaw seam");
  for(float v=-1080;v<1080;v+=.125f) {
   float a=LookSway.limit(LookSway.difference(v,0)*1.7f);
   if(!Float.isFinite(a)||java.lang.Math.abs(a)>2.5f)throw new AssertionError("unbounded look sway");
  }
  if(LookSway.limit(Float.NaN)!=0)throw new AssertionError("nonfinite");
  var state=new TrackingItemStackRenderState();
  var layer=state.newLayer();
  layer.setItemTransform(new ItemTransform(new Vector3f(),new Vector3f(),new Vector3f(1)));
  layer.setExtents(()->new Vector3fc[]{new Vector3f(0,0,0),new Vector3f(1,1,1)});
  layer.setLocalTransform(new Matrix4f().translate(.5f,.5f,.5f).scale(3.6f).translate(-.5f,-.5f,-.5f));
  state.setOversizedInGui(true);state.setAnimated();
  var gui=new GuiItemRenderState(new Matrix3x2f(),state,-8,-8,null);
  if(gui.oversizedItemBounds()==null||gui.oversizedItemBounds().width()<57)throw new AssertionError("Still low-resolution item atlas");
  System.out.println("PASS: actual Minecraft GUI state uses 58px native target, not scaled 16px atlas; seam-safe bounded look sway");
 }
}
