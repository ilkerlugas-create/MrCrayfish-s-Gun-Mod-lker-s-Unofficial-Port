"""Apply the grenade launcher capacity fix to the full 0.3.40 port."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent / 'output/CGM-26.3-Forge66.0.2-0.3.40-SUSTURUCU-POMPALI.jar'
OUT = ROOT.parent / 'output/CGM-26.3-Forge66.0.2-0.3.41-BOMBAATAR-6.jar'
GUN = 'data/cgm/guns/grenade_launcher.json'

with zipfile.ZipFile(BASE) as source:
    original = json.loads(source.read(GUN))
    assert original['general']['maxAmmo'] == 1
    assert original['general']['reloadAmount'] == 1
    updated = json.loads(source.read(GUN))
    updated['general']['maxAmmo'] = 6
    updated['general']['reloadAmount'] = 6
    changes = {GUN: (json.dumps(updated, indent=2) + '\n').encode()}
    for name in ['META-INF/MANIFEST.MF', 'META-INF/mods.toml']:
        value = source.read(name)
        assert b'port-0.3.40' in value, name
        changes[name] = value.replace(b'port-0.3.40', b'port-0.3.41')

    changes['CGM-0.3.41-OKU.txt'] = '''0.3.41 — Bombaatar kapasitesi
Minecraft 26.3 / Forge 66.0.2 / Java 25
Taban: 0.3.40 SUSTURUCU-POMPALI.

Bombaatarın normal kapasitesi 1 yerine 6 bombadır.
R ile doldururken yeterli cgm:grenade_round varsa tek doldurmada 6'ya tamamlanır.
Eksik cephanede yalnızca envanterdeki miktar yüklenir; tamamlarken yalnızca eksik miktar tüketilir.
Her normal atış bir bomba tüketir; tam dolu standart bombaatar altı kez ateş edebilir.

Oyunu kapatıp eski CGM JAR'ını bu dosyayla değiştir; aynı anda iki CGM JAR'ı bırakma.
Oyuna girince envanterinde bombaatar cephanesi bulundurup R ile doldur.
Çok oyunculuda istemci ve sunucuya aynı sürümü kur.

Bu değişiklik silahın veri dosyasındaki kapasite ve doldurma miktarını günceller.
Mevcut sunucu doldurma/tüketim kodu incelendi; arşiv bütünlüğü ve değişiklik kapsamı doğrulandı.
Oyun içinde test yapılmadı.
'''.encode()
    changes['META-INF/cgm-port-0.3.41/package.py'] = Path(__file__).read_bytes()
    validation = {
        'base_sha256': hashlib.sha256(BASE.read_bytes()).hexdigest(),
        'resource': GUN,
        'changes': {'general.maxAmmo': {'old': 1, 'new': 6},
                    'general.reloadAmount': {'old': 1, 'new': 6}},
        'inspection': [
            'NetworkGunManager loads data/cgm/guns/grenade_launcher.json',
            'GunEnchantmentHelper derives capacity from general.maxAmmo',
            'ReloadTracker clamps reloadAmount to available ammo and remaining capacity',
            'ServerPlayHandler decrements normal shots by one',
        ],
        'verification': 'Archive CRC, exact changed entry set, exact gun field changes; all classes and other gun data preserved',
        'in_game_test': False,
    }
    changes['META-INF/cgm-port-0.3.41/validation.json'] = json.dumps(validation, ensure_ascii=False, indent=2).encode()
    with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED) as target:
        for info in source.infolist():
            target.writestr(info, changes.pop(info.filename, source.read(info.filename)))
        for name, value in changes.items():
            target.writestr(name, value)

with zipfile.ZipFile(BASE) as source, zipfile.ZipFile(OUT) as target:
    assert target.testzip() is None
    assert len(target.namelist()) == len(set(target.namelist()))
    changed = {name for name in source.namelist() if source.read(name) != target.read(name)}
    assert changed == {GUN, 'META-INF/MANIFEST.MF', 'META-INF/mods.toml'}, changed
    actual = json.loads(target.read(GUN))
    assert actual['general']['maxAmmo'] == actual['general']['reloadAmount'] == 6
    actual['general']['maxAmmo'] = actual['general']['reloadAmount'] = 1
    assert actual == original

print('PASS: capacity and reload amount 6; gun fields and JAR integrity verified; all classes and other resources preserved')
print(OUT)
print('SHA256', hashlib.sha256(OUT.read_bytes()).hexdigest())
