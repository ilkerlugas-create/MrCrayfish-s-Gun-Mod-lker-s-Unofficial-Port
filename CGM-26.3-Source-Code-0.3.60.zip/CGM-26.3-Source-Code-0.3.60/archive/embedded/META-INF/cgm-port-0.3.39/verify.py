from pathlib import Path
import subprocess
ROOT=Path(__file__).resolve().parent
JAVA=Path('/workspace/scratch/01db9c6bc1ca/work-0.3.20/toolchain/jdk-25.0.4.1+1/bin')
cp=str(ROOT/'classes')+':'+(ROOT/'classpath.txt').read_text()
subprocess.run([str(JAVA/'javac'),'-proc:none','-cp',cp,'-d',str(ROOT/'test-classes'),str(ROOT/'tests/Sway39Test.java')],check=True)
subprocess.run([str(JAVA/'java'),'-cp',str(ROOT/'test-classes')+':'+cp,'com.mrcrayfish.guns.port.Sway39Test'],check=True)
