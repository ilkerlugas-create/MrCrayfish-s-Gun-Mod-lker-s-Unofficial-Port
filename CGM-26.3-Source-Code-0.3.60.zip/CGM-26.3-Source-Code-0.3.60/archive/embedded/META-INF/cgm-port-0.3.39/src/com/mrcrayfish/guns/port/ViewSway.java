package com.mrcrayfish.guns.port;

import java.util.Map;
import java.util.WeakHashMap;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.mrcrayfish.guns.Config;
import com.mrcrayfish.guns.client.SwayType;
import com.mrcrayfish.guns.client.handler.AimingHandler;
import com.mrcrayfish.guns.common.Gun;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;

/** Cosmetic view-model smoothing; never changes camera, player or shot rotation. */
public final class ViewSway {
    private static final Map<LocalPlayer, State> STATES = new WeakHashMap<>();
    private static final double RESPONSE_TICKS = 2.2; // smoother FPS view-model response; reduces rapid left/right jitter
    private ViewSway() {}

    static final class State {
        double time;
        float pitch, yaw;
        boolean ready;

        void sample(double now, float targetPitch, float targetYaw) {
            if (!Double.isFinite(now)) { ready = false; pitch = yaw = 0F; return; }
            if (!ready || now < time || now - time > 5.0) {
                ready = true;
                time = now;
                pitch = yaw = 0F;
                return;
            }
            double elapsed = now - time;
            if (elapsed <= 0.0) return; // repeated hand/render pass, no double advance
            time = now;
            float alpha = (float) -Math.expm1(-elapsed / RESPONSE_TICKS);
            pitch += (finite(targetPitch) - pitch) * alpha;
            yaw += (finite(targetYaw) - yaw) * alpha;
        }
    }

    private static float finite(float value) { return Float.isFinite(value) ? value : 0F; }

    static float target(float view, float bob, float sensitivity, float ads) {
        float strength = 1F - .5F * Math.max(0F, Math.min(1F, finite(ads)));
        return LookSway.limit(LookSway.difference(view, bob) * finite(sensitivity) * strength);
    }

    public static void apply(PoseStack pose, Gun gun, LocalPlayer player,
            float x, float y, float z, float partial, float previousFall, float fall) {
        if (player == null) return;
        if (!Config.CLIENT.display.weaponSway.get()) {
            STATES.remove(player);
            return;
        }
        partial = Mth.clamp(finite(partial), 0F, 1F);
        float sensitivity = Config.CLIENT.display.swaySensitivity.get().floatValue();
        float ads = (float) AimingHandler.get().getNormalisedAdsProgress();
        // Read the same view angles as Minecraft 26.3's hand renderer. Its bob
        // values are continuous angles; wrap the difference, not each endpoint.
        float targetPitch = target(player.getViewXRot(partial),
                Mth.lerp(partial, player.xBobO, player.xBob), sensitivity, ads);
        float targetYaw = target(player.getViewYRot(partial),
                Mth.lerp(partial, player.yBobO, player.yBob), sensitivity, ads);
        State state = STATES.get(player);
        if (state == null) { state = new State(); STATES.put(player, state); }
        // Double precision prevents time quantization in long play sessions.
        state.sample(player.tickCount + (double) partial, targetPitch, targetYaw);

        pose.translate(x, y, z);
        double fallPivot = gun.getGeneral().getGripType().getHeldAnimation().getFallSwayZOffset();
        pose.translate(0.0, -.25, fallPivot);
        pose.rotateDegrees(Axis.XP, MotionLimits.sway(Mth.lerp(partial, previousFall, fall)));
        pose.translate(0.0, .25, -fallPivot);
        SwayType type = Config.CLIENT.display.swayType.get();
        pose.rotateDegrees(type.getPitchRotation(), state.pitch);
        pose.rotateDegrees(type.getYawRotation(), state.yaw);
        pose.translate(-x, -y, -z);
    }
}
