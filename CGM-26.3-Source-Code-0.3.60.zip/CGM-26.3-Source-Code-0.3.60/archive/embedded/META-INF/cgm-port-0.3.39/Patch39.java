import java.nio.file.*;
import java.util.zip.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.tree.analysis.*;

public class Patch39 implements Opcodes {
    public static void main(String[] args) throws Exception {
        String path = "com/mrcrayfish/guns/client/handler/GunRenderingHandler.class";
        byte[] bytes;
        try (ZipFile jar = new ZipFile(args[0])) { bytes = jar.getInputStream(jar.getEntry(path)).readAllBytes(); }
        ClassNode c = new ClassNode(); new ClassReader(bytes).accept(c, 0);
        int changed = 0, pistolArm = 0, f5 = 0;
        for (MethodNode m : c.methods) {
            if (m.name.equals("applySwayTransforms")) {
                String expected = "(Lcom/mojang/blaze3d/vertex/PoseStack;Lcom/mrcrayfish/guns/common/Gun;Lnet/minecraft/client/player/LocalPlayer;FFFF)V";
                if (!m.desc.equals(expected)) throw new AssertionError(m.desc);
                m.instructions.clear(); m.tryCatchBlocks.clear(); m.localVariables = null;
                m.visibleLocalVariableAnnotations = null; m.invisibleLocalVariableAnnotations = null;
                for(int i=1;i<=3;i++) m.instructions.add(new VarInsnNode(ALOAD,i));
                for(int i=4;i<=7;i++) m.instructions.add(new VarInsnNode(FLOAD,i));
                m.instructions.add(new VarInsnNode(ALOAD,0));
                m.instructions.add(new FieldInsnNode(GETFIELD,c.name,"prevFallSway","F"));
                m.instructions.add(new VarInsnNode(ALOAD,0));
                m.instructions.add(new FieldInsnNode(GETFIELD,c.name,"fallSway","F"));
                m.instructions.add(new MethodInsnNode(INVOKESTATIC,"com/mrcrayfish/guns/port/ViewSway","apply",
                    "(Lcom/mojang/blaze3d/vertex/PoseStack;Lcom/mrcrayfish/guns/common/Gun;Lnet/minecraft/client/player/LocalPlayer;FFFFFF)V",false));
                m.instructions.add(new InsnNode(RETURN));
                m.maxStack = 9; m.maxLocals = 8;
                changed++;
            }
            for(var ins:m.instructions) if(ins instanceof MethodInsnNode call) {
                if(call.owner.equals("com/mrcrayfish/guns/port/PistolHold") && call.name.equals("renderArms")) pistolArm++;
                if(call.owner.equals("com/mrcrayfish/guns/port/F5Aim") && call.name.equals("before")) f5++;
            }
            if((m.access&(ACC_ABSTRACT|ACC_NATIVE))==0) new Analyzer<>(new BasicVerifier()).analyze(c.name,m);
        }
        if(changed!=1 || pistolArm!=1 || f5!=1)throw new AssertionError(changed+"/"+pistolArm+"/"+f5);
        ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);
        Path out=Path.of(args[1],path);Files.createDirectories(out.getParent());Files.write(out,w.toByteArray());
        System.out.println("PASS: one sway method replaced, pistol/F5 hooks preserved, handler bytecode verified");
    }
}
