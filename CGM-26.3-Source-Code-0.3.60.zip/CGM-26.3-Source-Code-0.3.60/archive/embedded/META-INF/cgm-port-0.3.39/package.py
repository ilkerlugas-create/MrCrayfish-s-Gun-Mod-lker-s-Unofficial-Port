from pathlib import Path
import zipfile,hashlib,json
ROOT=Path(__file__).resolve().parent
base=ROOT.parent/'output/CGM-26.3-Forge66.0.2-0.3.38-TUTUS-F5.jar'
old=ROOT.parent/'upload/CGM-26.3-Forge66.0.2-0.3.37-OPTIMIZE.jar'
out=ROOT.parent/'output/CGM-26.3-Forge66.0.2-0.3.39-F5-ESKI-SWAY-FIX.jar'
restored=['com/mrcrayfish/guns/port/F5Aim.class','com/mrcrayfish/guns/port/RunAnimation.class','com/mrcrayfish/guns/port/RunAnimation$State.class']
updates={}
with zipfile.ZipFile(old) as z:
 for name in restored: updates[name]=z.read(name)
for folder in ['classes','patched']:
 for p in (ROOT/folder).rglob('*.class'):updates[p.relative_to(ROOT/folder).as_posix()]=p.read_bytes()
expected=set(restored)|{'com/mrcrayfish/guns/client/handler/GunRenderingHandler.class','com/mrcrayfish/guns/port/ViewSway.class','com/mrcrayfish/guns/port/ViewSway$State.class'}
assert set(updates)==expected
for folder in ['src','tests']:
 for p in (ROOT/folder).rglob('*.java'):updates['META-INF/cgm-port-0.3.39/'+p.relative_to(ROOT).as_posix()]=p.read_bytes()
for name in ['Patch39.java','build.py','package.py','verify.py']:
 updates['META-INF/cgm-port-0.3.39/'+name]=(ROOT/name).read_bytes()
updates['META-INF/cgm-port-0.3.39/validation.json']=json.dumps({
 'base_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),
 'f5_restored_from':'0.3.37 OPTIMIZE, three exact class replacements',
 'changes':['F5 torso/aim/sprint behavior restored byte-for-byte from 0.3.37','0.3.38 pistol hand alignment preserved','View sway samples the same view-angle API as Minecraft 26.3 hands','Cosmetic turn sway has frame-rate-independent 60ms damping','Weak player state reused across frames; no per-frame arrays or matrices','Same-time duplicate render passes do not integrate twice'],
 'validation':['Compiled against real Minecraft 26.3 and Forge 66.0.2 APIs using Java 25','Synthetic 30/60/144/240 FPS, rapid reversals, wrap-around, reset, ADS and long-session checks passed','Patched renderer passes ASM verification','All unrelated entries preserved byte-for-byte'],
 'in_game_visual_test':False,'in_game_performance_benchmark':False},ensure_ascii=False,indent=2).encode()
updates['CGM-0.3.39-OKU.txt']='''0.3.39 — Eski F5 görünümü / sağ-sol salınımı
Minecraft 26.3 / Forge 66.0.2 / Java 25

- F5 görünümü 0.3.37 OPTIMIZE sürümündeki haline döndürüldü.
  0.3.38'de eklenen F5 yürüyüş sallanması, yeni gövde yönü ve dönüş hesabı geri alındı.
- Sağ-sol dönüşteki silah salınımına kare hızından bağımsız yumuşatma eklendi.
- Salınım artık Minecraft 26.3'ün el çizicisindeki bakış açılarını kullanır.
- Aynı karede birden fazla çizim animasyonu iki kez ilerletmez.
- Uzun oturumlarda salınım zamanının hassasiyeti korunur; dünya veya çizim arası değiştiğinde eski hareket sıfırlanır.
- Bu işlem yalnızca görünen silah salınımını etkiler; oyuncunun bakışını ve atış yönünü geciktirmez.
- Tabanca tutuşu, varsayılan Z ve önceki önbellek/çizim optimizasyonları korundu.

Oyunu kapat; önceki CGM JAR'ının yerine bunu koy. Birden fazla CGM sürümü bırakma.
Derleme ve teknik kontroller geçti. Oyun içi görsel test ve FPS performans ölçümü yapılmadı.
'''.encode()
with zipfile.ZipFile(base) as z:
 for name in ['META-INF/MANIFEST.MF','META-INF/mods.toml']:
  updates[name]=z.read(name).replace(b'port-0.3.38',b'port-0.3.39')
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as d:
  for info in z.infolist():d.writestr(info,updates.pop(info.filename,z.read(info.filename)))
  for name,data in updates.items():d.writestr(name,data)
with zipfile.ZipFile(base) as a,zipfile.ZipFile(old) as o,zipfile.ZipFile(out) as b:
 assert b.testzip() is None
 assert len(b.namelist())==len(set(b.namelist()))
 changed={n for n in a.namelist() if a.read(n)!=b.read(n)}
 assert changed==set(restored)|{'com/mrcrayfish/guns/client/handler/GunRenderingHandler.class','META-INF/MANIFEST.MF','META-INF/mods.toml'},changed
 for name in restored: assert b.read(name)==o.read(name)
 assert b.read('com/mrcrayfish/guns/port/PistolHold.class')==a.read('com/mrcrayfish/guns/port/PistolHold.class')
 assert not any(n.startswith(('net/minecraft/','org/joml/')) for n in b.namelist())
 for name in b.namelist():
  if name.endswith('.json'):json.loads(b.read(name))
print('PASS: exact 0.3.37 F5 restoration, 0.3.38 pistol preservation, archive integrity and unrelated-entry preservation')
print(out)
print('SHA256',hashlib.sha256(out.read_bytes()).hexdigest())
