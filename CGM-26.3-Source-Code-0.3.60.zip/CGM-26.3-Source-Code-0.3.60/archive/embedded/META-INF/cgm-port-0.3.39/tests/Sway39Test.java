package com.mrcrayfish.guns.port;

public final class Sway39Test {
    static int checks;
    static void check(boolean ok,String message) { if(!ok)throw new AssertionError(message); checks++; }
    static void near(double a,double b,double tolerance,String message) { check(Double.isFinite(a)&&Math.abs(a-b)<=tolerance,message+": "+a+" vs "+b); }
    public static void main(String[] args) {
        // A fixed elapsed duration must have the same response at different FPS.
        for(int fps:new int[]{30,60,144,240}) {
            ViewSway.State state=new ViewSway.State();state.sample(0,2,-2);
            for(int frame=1;frame<=fps;frame++)state.sample(frame*20.0/fps,2,-2);
            near(state.pitch,2*(1-Math.exp(-20/1.2)),2E-6,"frame-rate-independent pitch "+fps);
            near(state.yaw,-2*(1-Math.exp(-20/1.2)),2E-6,"frame-rate-independent yaw "+fps);
        }
        ViewSway.State jitter=new ViewSway.State();jitter.sample(0,0,0);
        double filteredEnergy=0,rawEnergy=0,largestStep=0;float old=0;
        for(int i=1;i<=600;i++) {
            float raw=(i%2==0?2.5F:-2.5F);
            jitter.sample(i/3.0,raw,raw);
            filteredEnergy+=jitter.yaw*jitter.yaw;rawEnergy+=raw*raw;
            largestStep=Math.max(largestStep,Math.abs(jitter.yaw-old));old=jitter.yaw;
            check(Math.abs(jitter.yaw)<=2.5,"bounded alternating input");
        }
        check(filteredEnergy<rawEnergy*.08,"rapid direction changes attenuated");
        check(largestStep<1,"no full-range 5 degree jumps");
        float last=jitter.yaw;jitter.sample(200,2.5F,-2.5F);
        near(jitter.yaw,last,0,"same frame does not advance a second hand pass");
        jitter.sample(200.3,0,0);
        check(Math.abs(jitter.yaw)<Math.abs(last),"returns towards neutral after motion stops");
        jitter.sample(500,2,2);near(jitter.yaw,0,0,"reset after render gap");
        jitter.sample(2,2,2);near(jitter.yaw,0,0,"reset after world time changes");
        jitter.sample(Double.NaN,2,2);check(!jitter.ready,"bad time resets");
        near(ViewSway.target(179,-179,1,0),ViewSway.target(-181,-179,1,0),1E-6,"yaw wrap continuity");
        near(ViewSway.target(Float.NaN,0,1,0),0,0,"bad input cannot poison state");
        near(ViewSway.target(0,0,1,0),0,0,"stationary view is neutral");
        check(Math.abs(ViewSway.target(2,0,1,1))<Math.abs(ViewSway.target(2,0,1,0)),"ADS attenuation retained");
        ViewSway.State longSession=new ViewSway.State();
        longSession.sample(10000000.0,1,1);longSession.sample(10000000.0+20.0/240,1,1);
        check(longSession.yaw>0,"240 FPS sub-frame precision survives a long session");
        System.out.println("PASS: "+checks+" smoothing checks; 30/60/144/240 FPS, direction reversals, reset, yaw wrap, ADS and long-session precision");
        System.out.println("Synthetic alternating-input RMS ratio: "+Math.sqrt(filteredEnergy/rawEnergy)+" (not an in-game benchmark)");
    }
}
