import com.mrcrayfish.guns.port.*;
import com.mrcrayfish.guns.common.Gun;
import com.mrcrayfish.guns.item.GunItem;
import com.mrcrayfish.guns.item.attachment.IAttachment;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.*;
import net.minecraft.world.item.*;
import net.minecraft.nbt.CompoundTag;
public class InventoryRegression {
 static class Scope extends Item implements IAttachment {boolean allowed=true;public Type getType(){return Type.SCOPE;}public boolean canAttachTo(ItemStack s){return allowed;}}
 static class Fixture {
  Player player=new Player();GunItem gun=new GunItem();Scope scope=new Scope();Slot slot=new Slot();
  ItemStack weapon=new ItemStack(gun,1),cursor=new ItemStack(scope,1);boolean rejectCursor;
  Fixture(){player.held=weapon;weapon.data.values.put("AmmoCount",4);}
  boolean click(ClickAction action){return InventoryActions.attach(weapon,cursor,slot,action,player,s->{if(rejectCursor)return false;cursor=s;return true;});}
  ItemStack installed(){return Gun.getAttachment(IAttachment.Type.SCOPE,weapon);}
  void old(){CompoundTag a=new CompoundTag();ItemStack old=new ItemStack(new Scope(),1);old.data.values.put("custom",42);a.values.put("SCOPE",old);a.values.put("BARREL",new ItemStack(new Item(),1));weapon.data.values.put("Attachments",a);}
 }
 static int checks;
 static void check(boolean b){checks++;if(!b)throw new AssertionError("check "+checks);}
 public static void main(String[] args) {
  Fixture f=new Fixture();check(f.click(ClickAction.SECONDARY));check(f.installed().getCount()==1&&f.cursor.isEmpty());check(f.weapon.data.getIntOr("AmmoCount",0)==4);check(f.player.world.sounds==1);
  f=new Fixture();f.old();Item oldItem=f.installed().getItem();f.click(ClickAction.SECONDARY);check(f.cursor.getItem()==oldItem&&f.cursor.data.getIntOr("custom",0)==42);check(f.installed().getItem()==f.scope);check(!Gun.getAttachment(IAttachment.Type.BARREL,f.weapon).isEmpty());
  f=new Fixture();f.cursor.count=3;f.click(ClickAction.SECONDARY);check(f.cursor.getCount()==2&&f.installed().getCount()==1);
  for(int mode=0;mode<8;mode++) {
   f=new Fixture();if(mode==0)f.gun.gun.compatible=false;if(mode==1)f.scope.allowed=false;if(mode==2)f.slot.allowed=false;if(mode==3)f.player.spectator=true;if(mode==4)f.player.reloading=true;if(mode==5)f.rejectCursor=true;if(mode==6)ItemStack.encodeFails=true;
   if(mode==7){f.old();f.cursor.count=2;}
   ItemStack original=f.cursor;Item old=f.installed().getItem();f.click(ClickAction.SECONDARY);check(f.cursor==original&&f.installed().getItem()==old&&f.player.world.sounds==0);ItemStack.encodeFails=false;
  }
  f=new Fixture();f.old();f.installed().cursed=true;ItemStack cur=f.cursor;f.click(ClickAction.SECONDARY);check(f.cursor==cur);
  f=new Fixture();check(!f.click(ClickAction.PRIMARY)&&f.installed().isEmpty());
  f=new Fixture();f.player.world.client=true;f.click(ClickAction.SECONDARY);check(f.player.world.sounds==0&&f.player.localSounds==0);
  f=new Fixture();f.player.world.client=true;f.player.creative=true;f.click(ClickAction.SECONDARY);check(f.player.localSounds==1);
  f=new Fixture();check(!ReloadRules.canReload(f.player));f.player.creative=true;check(!ReloadRules.canReload(f.player));f.player.ammo=new ItemStack(new Item(),2);check(ReloadRules.canReload(f.player));f.weapon.data.values.put("AmmoCount",10);check(!ReloadRules.canReload(f.player));f.weapon.data.values.put("AmmoCount",0);f.player.spectator=true;check(!ReloadRules.canReload(f.player));f.player.spectator=false;f.player.alive=false;check(!ReloadRules.canReload(f.player));check(!ReloadRules.canReload(null));
  System.out.println("PASS: "+checks+" isolated checks of production attachment/reload source; conservation, swap metadata, rejected actions, sound paths and reload eligibility.");
 }
}
