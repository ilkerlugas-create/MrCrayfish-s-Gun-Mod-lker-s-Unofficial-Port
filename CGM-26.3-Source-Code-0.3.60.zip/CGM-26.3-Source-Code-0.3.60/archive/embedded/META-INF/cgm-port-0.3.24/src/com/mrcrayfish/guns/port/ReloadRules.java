package com.mrcrayfish.guns.port;
import com.mrcrayfish.guns.common.Gun;
import com.mrcrayfish.guns.item.GunItem;
import com.mrcrayfish.guns.util.GunEnchantmentHelper;
import com.mrcrayfish.guns.util.StackData;
import net.minecraft.world.entity.player.Player;
public final class ReloadRules {
 public static boolean canReload(Player player) {
  if(player==null||player.isSpectator()||!player.isAlive())return false;
  var stack=player.getMainHandItem();
  if(!(stack.getItem() instanceof GunItem item))return false;
  Gun gun=item.getModifiedGun(stack);
  if(StackData.copy(stack).getIntOr("AmmoCount",0)>=GunEnchantmentHelper.getAmmoCapacity(stack,gun))return false;
  return !Gun.findAmmo(player,gun.getProjectile().getItem()).stack().isEmpty();
 }
}
