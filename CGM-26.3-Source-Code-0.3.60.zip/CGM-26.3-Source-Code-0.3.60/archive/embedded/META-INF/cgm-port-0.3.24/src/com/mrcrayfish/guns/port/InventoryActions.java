package com.mrcrayfish.guns.port;

import com.mrcrayfish.guns.common.Gun;
import com.mrcrayfish.guns.init.ModSounds;
import com.mrcrayfish.guns.init.ModSyncedDataKeys;
import com.mrcrayfish.guns.item.GunItem;
import com.mrcrayfish.guns.item.attachment.IAttachment;
import com.mrcrayfish.guns.util.StackData;
import net.minecraft.nbt.NbtOps;
import net.minecraft.resources.RegistryOps;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.SlotAccess;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ClickAction;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.EnchantmentEffectComponents;
import net.minecraft.world.item.enchantment.EnchantmentHelper;

/** Vanilla's item-click hook runs in the authoritative menu and client prediction. */
public final class InventoryActions {
 public static boolean attach(ItemStack weapon,ItemStack cursor,Slot slot,ClickAction action,Player player,SlotAccess carried) {
  if(action!=ClickAction.SECONDARY||!(cursor.getItem() instanceof IAttachment attachment))return false;
  // Consume incompatible attempts too: don't accidentally swap the gun and scope.
  if(player.isSpectator()||!slot.allowModification(player)||!(weapon.getItem() instanceof GunItem item))return true;
  Gun gun=item.getModifiedGun(weapon);
  if(!gun.canAttachType(attachment.getType())||!attachment.canAttachTo(weapon))return true;
  if(weapon==player.getMainHandItem()&&ModSyncedDataKeys.RELOADING.getValue(player))return true;
  ItemStack old=Gun.getAttachment(attachment.getType(),weapon);
  if(!old.isEmpty()&&!player.isCreative()&&EnchantmentHelper.has(old,EnchantmentEffectComponents.PREVENT_ARMOR_CHANGE))return true;
  if(!old.isEmpty()&&cursor.getCount()!=1)return true;
  ItemStack installed=cursor.copyWithCount(1);
  var encoded=ItemStack.CODEC.encodeStart(RegistryOps.create(NbtOps.INSTANCE,player.registryAccess()),installed).result();
  if(encoded.isEmpty())return true;
  var data=StackData.copy(weapon);
  var attachments=data.getCompoundOrEmpty("Attachments").copy();
  attachments.put(attachment.getType().getTagKey(),encoded.get());
  ItemStack remainder=old.isEmpty()?cursor.copyWithCount(cursor.getCount()-1):old.copy();
  // If a menu refuses cursor changes, leave the weapon untouched.
  if(!carried.set(remainder))return true;
  StackData.update(weapon,tag->tag.put("Attachments",attachments));
  slot.setChanged();
  player.getInventory().setChanged();
  if(!player.level().isClientSide())
   player.level().playSound(null,player.getX(),player.getY()+1,player.getZ(),ModSounds.UI_WEAPON_ATTACH.get(),SoundSource.PLAYERS,.5F,1F);
  else if(player.isCreative())
   player.playSound(ModSounds.UI_WEAPON_ATTACH.get(),.5F,1F);
  return true;
 }
}
