package com.mrcrayfish.guns.network.message;

import com.mrcrayfish.guns.network.legacy.LegacyMessageContext;
import com.mrcrayfish.guns.network.legacy.LegacyPlayMessage;
import com.mrcrayfish.guns.event.GunReloadEvent;
import com.mrcrayfish.guns.init.ModSyncedDataKeys;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.common.MinecraftForge;

import java.util.function.Supplier;

/**
 * Author: MrCrayfish
 */
public class C2SMessageReload extends LegacyPlayMessage<C2SMessageReload>
{
    private boolean reload;

    public C2SMessageReload() {}

    public C2SMessageReload(boolean reload)
    {
        this.reload = reload;
    }

    @Override
    public void encode(C2SMessageReload message, FriendlyByteBuf buffer)
    {
        buffer.writeBoolean(message.reload);
    }

    @Override
    public C2SMessageReload decode(FriendlyByteBuf buffer)
    {
        return new C2SMessageReload(buffer.readBoolean());
    }

    @Override
    public void handle(C2SMessageReload message, LegacyMessageContext context)
    {
        context.execute(() ->
        {
            ServerPlayer player = context.getPlayer();
            if(player != null && !player.isSpectator())
            {
                if(!message.reload)
                {
                    ModSyncedDataKeys.RELOADING.setValue(player, false);
                    return;
                }
                if(ModSyncedDataKeys.RELOADING.getValue(player))
                    return;
                if(!com.mrcrayfish.guns.port.ReloadRules.canReload(player))
                    return;
                ModSyncedDataKeys.RELOADING.setValue(player, true);

                ItemStack gun = player.getMainHandItem();
                if(GunReloadEvent.Pre.BUS.post(new GunReloadEvent.Pre(player, gun)))
                {
                    ModSyncedDataKeys.RELOADING.setValue(player, false);
                    return;
                }
                GunReloadEvent.Post.BUS.post(new GunReloadEvent.Post(player, gun));
            }
        });
        context.setHandled(true);
    }
}
