import java.nio.file.*;import java.util.*;import java.util.jar.*;
import org.objectweb.asm.*;import org.objectweb.asm.tree.*;import org.objectweb.asm.tree.analysis.*;
public class Patch24 implements Opcodes {
 public static void main(String[] args)throws Exception {
  try(JarFile jar=new JarFile(args[0])) {
   for(String name:List.of("com/mrcrayfish/guns/item/GunItem","com/mrcrayfish/guns/client/handler/GunRenderingHandler")) {
    ClassNode c=new ClassNode();new ClassReader(jar.getInputStream(jar.getJarEntry(name+".class"))).accept(c,0);
    if(name.endsWith("/GunItem")) {
     if(c.methods.stream().anyMatch(m->m.name.equals("overrideOtherStackedOnMe")))throw new IllegalStateException("already patched");
     String desc="(Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/inventory/Slot;Lnet/minecraft/world/inventory/ClickAction;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/entity/SlotAccess;)Z";
     MethodNode m=new MethodNode(ACC_PUBLIC,"overrideOtherStackedOnMe",desc,null,null);
     for(int i=1;i<=6;i++)m.instructions.add(new VarInsnNode(ALOAD,i));
     m.instructions.add(new MethodInsnNode(INVOKESTATIC,"com/mrcrayfish/guns/port/InventoryActions","attach",desc,false));m.instructions.add(new InsnNode(IRETURN));c.methods.add(m);
    }else {
     MethodNode m=new MethodNode(ACC_PUBLIC,"cgmBeforeLivingRender","(Lnet/minecraftforge/client/event/RenderLivingEvent$Pre;)Z",null,null);
     m.visibleAnnotations=new ArrayList<>();m.visibleAnnotations.add(new AnnotationNode("Lnet/minecraftforge/eventbus/api/listener/SubscribeEvent;"));
     m.instructions.add(new VarInsnNode(ALOAD,1));m.instructions.add(new MethodInsnNode(INVOKESTATIC,"com/mrcrayfish/guns/port/F5Aim","before",m.desc,false));m.instructions.add(new InsnNode(IRETURN));c.methods.add(m);
    }
    ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);byte[] b=w.toByteArray();ClassNode check=new ClassNode();new ClassReader(b).accept(check,0);
    for(MethodNode m:check.methods)if((m.access&(ACC_NATIVE|ACC_ABSTRACT))==0)new Analyzer<>(new BasicVerifier()).analyze(check.name,m);
    Path p=Path.of(args[1],name+".class");Files.createDirectories(p.getParent());Files.write(p,b);
   }
  }
  System.out.println("PASS: vanilla item-click hook and cancellable render event hook added; bytecode verified.");
 }
}
