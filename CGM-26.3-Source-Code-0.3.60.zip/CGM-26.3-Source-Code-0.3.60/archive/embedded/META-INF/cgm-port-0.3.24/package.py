import json,zipfile,pathlib,hashlib
base=pathlib.Path('output/CGM-26.3-Forge66.0.2-0.3.23-HAREKET-BAZOOKA-FIX.jar')
out=pathlib.Path('output/CGM-26.3-Forge66.0.2-0.3.24-R-EKLENTI-F5.jar')
with zipfile.ZipFile(base) as z:data={n:z.read(n) for n in z.namelist()}
def put(n,d):data[n]=(json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode()
for lang in ['tr_tr','en_us']:
 n=f'assets/cgm/lang/{lang}.json';d=json.loads(data[n]);d.update({'info.cgm.reload_help':'Silah elindeyken %s: envanterdeki mühimmatla doldur.','info.cgm.ammo_for':'Kullanan silah: %s','info.cgm.attachment_help':'Eklentiyi al, silaha sağ tıkla tak. Sökme menüsü: %s'});put(n,d)
for p in pathlib.Path('work/fix24/classes').rglob('*.class'):
 if p.relative_to('work/fix24/classes').as_posix().startswith('com/mrcrayfish/'):
  data[p.relative_to('work/fix24/classes').as_posix()]=p.read_bytes()
for n in ['META-INF/mods.toml','META-INF/MANIFEST.MF']:data[n]=data[n].replace(b'port-0.3.23',b'port-0.3.24')
for p in pathlib.Path('work/fix24').rglob('*'):
 if p.suffix in ['.java','.py']:data['META-INF/cgm-port-0.3.24/'+p.relative_to('work/fix24').as_posix()]=p.read_bytes()

# Resolve every registered item's inherited textures, not just files on disk.
def model(n,seen=None):
 seen=set() if seen is None else seen
 assert n not in seen,('cycle',n)
 seen.add(n);ns,path=n.split(':');d=json.loads(data[f'assets/{ns}/models/{path}.json'])
 parent=d.get('parent','');merged={}
 if parent.startswith('cgm:'):merged=model(parent,seen)
 merged.update(d.get('textures',{}));return merged
checked=0
for n in data:
 if n.startswith('assets/cgm/items/') and n.endswith('.json'):
  definition=json.loads(data[n])['model'];textures=model(definition['model'])
  for k,t in textures.items():
   seen=set()
   while t.startswith('#'):
    assert t not in seen,(n,t);seen.add(t);t=textures[t[1:]]
   if t.startswith('cgm:'):
    assert t.startswith(('cgm:item/','cgm:block/')),(n,t,'wrong atlas')
    assert f'assets/cgm/textures/{t.split(":",1)[1]}.png' in data,(n,t)
  checked+=1
assert checked==25,checked
for n,b in data.items():
 if n.endswith('.json'):json.loads(b)
report={'version':'0.3.24','base_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),
 'changes':['R matches the pressed key and starts reload without toggling; inventory ammo checked on client and server','Native right-click attachment installation and replacement with old attachment returned to cursor','Compatibility, slot permission, curse and reload checks; existing gun and attachment data preserved','Weapon attachment sound, including creative inventory prediction','Restore pose-specific body yaw through Forge render state; immediate third-person aiming pose'],
 'item_texture_chains_checked':checked,'runtime_gameplay_test':'not run'}
results=pathlib.Path('work/fix24/test-results.json')
if results.exists():report['validation']=json.loads(results.read_text())
put('META-INF/cgm-port-0.3.24-validation.json',report)
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for n,b in data.items():z.writestr(n,b)
with zipfile.ZipFile(out) as z:assert z.testzip() is None
print(out);print('PASS: all 25 item texture chains use item-atlas sprites; all JSON and ZIP entries valid.')
