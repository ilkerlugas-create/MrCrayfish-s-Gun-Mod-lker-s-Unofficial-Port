package com.mrcrayfish.guns.port;
import com.mrcrayfish.guns.item.GunItem;
import com.mrcrayfish.guns.util.StackData;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
/** Detach the active inventory entry before mutating a gun shared by a creative copy. */
public final class WeaponInstance {
 public static ItemStack selected(Player player) {
  var inv=player.getInventory();
  int slot=inv.getSelectedSlot();
  ItemStack held=inv.getSelectedItem();
  if(!(held.getItem() instanceof GunItem))return held;
  String key=StackData.copy(held).getStringOr("CGMInstance", "");
  boolean duplicate=key.isEmpty();
  for(int i=0;i<inv.getContainerSize();i++) {
   if(i==slot)continue;
   ItemStack other=inv.getItem(i);
   if(other==held || (!key.isEmpty() && other.getItem() instanceof GunItem && key.equals(StackData.copy(other).getStringOr("CGMInstance", "")))) {
    duplicate=true;break;
   }
  }
  if(duplicate) {
   held=held.copy();
   String id=java.util.UUID.randomUUID().toString();
   StackData.update(held,tag->tag.putString("CGMInstance",id));
   inv.setItem(slot,held);
   inv.setChanged();
  }
  return held;
 }
}
