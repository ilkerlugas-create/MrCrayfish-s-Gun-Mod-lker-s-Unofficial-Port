package com.mrcrayfish.guns.common;

import com.mrcrayfish.framework.api.network.LevelLocation;
import com.mrcrayfish.guns.Config;
import com.mrcrayfish.guns.Reference;
import com.mrcrayfish.guns.init.ModSyncedDataKeys;
import com.mrcrayfish.guns.item.GunItem;
import com.mrcrayfish.guns.network.PacketHandler;
import com.mrcrayfish.guns.network.message.S2CMessageGunSound;
import com.mrcrayfish.guns.util.GunEnchantmentHelper;
import com.mrcrayfish.guns.util.StackData;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.packs.repository.Pack;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.listener.SubscribeEvent;

import net.minecraftforge.network.PacketDistributor;

import java.util.Map;
import java.util.WeakHashMap;

/**
 * Author: MrCrayfish
 */
@SuppressWarnings("unused")
// Runtime subscriber annotation is preserved from the original class by Patch27.
public class ReloadTracker
{
    private static final Map<Player, ReloadTracker> RELOAD_TRACKER_MAP = new WeakHashMap<>();

    private int nextLoadTick;
    private final int slot;
    private final ItemStack stack;
    private final Gun gun;

    private ReloadTracker(Player player)
    {
        this.nextLoadTick = player.tickCount + Math.max(1, GunEnchantmentHelper.getReloadInterval(player.getMainHandItem()));
        this.slot = player.getInventory().getSelectedSlot();
        this.stack = com.mrcrayfish.guns.port.WeaponInstance.selected(player);
        this.gun = ((GunItem) stack.getItem()).getModifiedGun(stack);
    }

    /**
     * Tests if the current item the player is holding is the same as the one being reloaded
     *
     * @param player the player to check
     * @return True if it's the same weapon and slot
     */
    private boolean isSameWeapon(Player player)
    {
        return !this.stack.isEmpty() && player.getInventory().getSelectedSlot() == this.slot && player.getInventory().getSelectedItem() == this.stack;
    }

    /**
     * @return
     */
    private boolean isWeaponFull()
    {
        CompoundTag tag = StackData.copy(this.stack);
        return tag.getIntOr("AmmoCount", 0) >= GunEnchantmentHelper.getAmmoCapacity(this.stack, this.gun);
    }

    private boolean hasNoAmmo(Player player)
    {
        return Gun.findAmmo(player, this.gun.getProjectile().getItem()).stack().isEmpty();
    }

    private boolean canReload(Player player)
    {
        if(player.tickCount < this.nextLoadTick) return false;
        this.nextLoadTick = player.tickCount + Math.max(1, GunEnchantmentHelper.getReloadInterval(this.stack));
        return true;
    }

    private void increaseAmmo(Player player)
    {
        int current = StackData.copy(this.stack).getIntOr("AmmoCount", 0);
        int capacity = GunEnchantmentHelper.getAmmoCapacity(this.stack, this.gun);
        int remaining = Math.min(Math.max(1, this.gun.getGeneral().getReloadAmount()), Math.max(0, capacity - current));
        int added = 0;
        while(remaining > 0) {
            AmmoContext context = Gun.findAmmo(player, this.gun.getProjectile().getItem());
            ItemStack ammo = context.stack();
            if(ammo.isEmpty()) break;
            int amount = Math.min(ammo.getCount(), remaining);
            if(amount <= 0) break;
            ammo.shrink(amount);
            added += amount;
            remaining -= amount;
            if(context.container() != null) context.container().setChanged();
        }
        if(added <= 0) { cancel(player); return; }
        final int count = current + added;
        StackData.update(this.stack, data -> data.putInt("AmmoCount", count));
        player.getInventory().setChanged();

        Identifier reloadSound = this.gun.getSounds().getReload();
        if(reloadSound != null)
        {
            double radius = Config.SERVER.reloadMaxDistance.get();
            double soundX = player.getX();
            double soundY = player.getY() + 1.0;
            double soundZ = player.getZ();
            S2CMessageGunSound message = new S2CMessageGunSound(reloadSound, SoundSource.PLAYERS, (float) soundX, (float) soundY, (float) soundZ, 1.0F, 1.0F, player.getId(), false, true);
            PacketHandler.getPlayChannel().sendToNearbyPlayers(() -> LevelLocation.create((ServerLevel) player.level(), soundX, soundY, soundZ, radius), message);
        }
    }

    public static void cancel(Player player) {
        RELOAD_TRACKER_MAP.remove(player);
        ModSyncedDataKeys.RELOADING.setValue(player, false);
    }

    public static void begin(Player player) {
        RELOAD_TRACKER_MAP.put(player, new ReloadTracker(player));
        ModSyncedDataKeys.RELOADING.setValue(player, true);
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent.Pre event)
    {
        Player player = event.player();
        if(!player.level().isClientSide())
        {
            if(ModSyncedDataKeys.RELOADING.getValue(player))
            {
                if(!RELOAD_TRACKER_MAP.containsKey(player))
                {
                    if(!(player.getInventory().getSelectedItem().getItem() instanceof GunItem))
                    {
                        ModSyncedDataKeys.RELOADING.setValue(player, false);
                        return;
                    }
                    RELOAD_TRACKER_MAP.put(player, new ReloadTracker(player));
                }
                ReloadTracker tracker = RELOAD_TRACKER_MAP.get(player);
                if(!player.isAlive() || player.isSpectator() || !tracker.isSameWeapon(player) || tracker.isWeaponFull() || tracker.hasNoAmmo(player))
                {
                    RELOAD_TRACKER_MAP.remove(player);
                    ModSyncedDataKeys.RELOADING.setValue(player, false);
                    return;
                }
                if(tracker.canReload(player))
                {
                    tracker.increaseAmmo(player);
                    if(tracker.isWeaponFull() || tracker.hasNoAmmo(player))
                    {
                        RELOAD_TRACKER_MAP.remove(player);
                        ModSyncedDataKeys.RELOADING.setValue(player, false);

                        final Player finalPlayer = player;
                        final Gun gun = tracker.gun;
                        DelayedTask.runAfter(4, () ->
                        {
                            Identifier cockSound = gun.getSounds().getCock();
                            if(cockSound != null && finalPlayer.isAlive())
                            {
                                double soundX = finalPlayer.getX();
                                double soundY = finalPlayer.getY() + 1.0;
                                double soundZ = finalPlayer.getZ();
                                double radius = Config.SERVER.reloadMaxDistance.get();
                                S2CMessageGunSound messageSound = new S2CMessageGunSound(cockSound, SoundSource.PLAYERS, (float) soundX, (float) soundY, (float) soundZ, 1.0F, 1.0F, finalPlayer.getId(), false, true);
                                PacketHandler.getPlayChannel().sendToNearbyPlayers(() -> LevelLocation.create((ServerLevel) finalPlayer.level(), soundX, soundY, soundZ, radius), messageSound);
                            }
                        });
                    }
                }
            }
            else if(RELOAD_TRACKER_MAP.containsKey(player))
            {
                RELOAD_TRACKER_MAP.remove(player);
            }
        }
    }

    @SubscribeEvent
    public static void onPlayerTick(PlayerEvent.PlayerLoggedOutEvent event)
    {
        if(event.getEntity().level() instanceof ServerLevel serverLevel)
        {
            serverLevel.getServer().execute(() -> RELOAD_TRACKER_MAP.remove(event.getEntity()));
        }
    }
}
