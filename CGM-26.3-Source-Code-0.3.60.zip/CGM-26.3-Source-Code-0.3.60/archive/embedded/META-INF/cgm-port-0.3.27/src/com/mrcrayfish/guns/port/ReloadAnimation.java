package com.mrcrayfish.guns.port;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.mrcrayfish.framework.api.client.model.FrameworkBakedModel;
import com.mrcrayfish.guns.client.SpecialModels;
import com.mrcrayfish.guns.client.handler.ReloadHandler;
import com.mrcrayfish.guns.client.util.RenderUtil;
import com.mrcrayfish.guns.client.util.SubmitRenderUtil;
import com.mrcrayfish.guns.common.Gun;
import com.mrcrayfish.guns.util.GunEnchantmentHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemDisplayContext;

/** Original keyframed CGM animation inspired by the user's CS2 reference.
 * No CS2 assets; the original weapon geometry, skins and attachments are retained.
 * Both visuals and server loading use GunEnchantmentHelper.getReloadInterval.
 */
public final class ReloadAnimation {
 public static float smooth(float v){v=Math.max(0F,Math.min(1F,v));return v*v*(3F-2F*v);}
 public static float ramp(float p,float a,float b){return smooth((p-a)/(b-a));}
 public static float travel(float p){return ramp(p,.15F,.36F)*(1F-ramp(p,.51F,.72F));}
 public static float cock(float p){return ramp(p,.76F,.84F)*(1F-ramp(p,.86F,.97F));}
 public static float phase(ItemStack stack,float partial){
  LocalPlayer player=Minecraft.getInstance().player;
  int start=ReloadHandler.get().getStartReloadTick();
  if(player==null||start<0)return 1F;
  float interval=Math.max(1,GunEnchantmentHelper.getReloadInterval(stack));
  float elapsed=Math.max(0,player.tickCount-start+partial);
  return ReloadTiming.kind(stack).equals("shotgun") ? (elapsed%interval)/interval : Math.min(1F,elapsed/interval);
 }
 private static float weight(float partial){return smooth(ReloadHandler.get().getReloadProgress(partial));}
 private static boolean active(float partial){return Minecraft.getInstance().player!=null&&weight(partial)>.001F;}
 public static void weapon(PoseStack pose,float partial){
  LocalPlayer player=Minecraft.getInstance().player;
  if(player==null)return;
  ItemStack stack=player.getMainHandItem();
  transform(pose,ReloadTiming.kind(stack),phase(stack,partial),weight(partial),player.getMainArm()==HumanoidArm.RIGHT?1F:-1F);
 }
 private static void transform(PoseStack pose,String kind,float p,float w,float side){
  float tilt=switch(kind){case "pistol","machine_pistol"->-24F;case "shotgun"->32F;case "bazooka"->-12F;case "mini_gun"->-14F;default->-27F;};
  float lift=switch(kind){case "pistol","machine_pistol"->20F;case "shotgun"->14F;case "bazooka"->-14F;default->12F;};
  pose.translate(-.06F*side*w,.07F*w,.06F*w);
  pose.rotateDegrees(Axis.ZP,tilt*side*w);
  pose.rotateDegrees(Axis.YP,12F*side*w);
  pose.rotateDegrees(Axis.XP,(lift-5F*cock(p))*w);
  pose.translate(0,-.025F*cock(p)*w,.045F*cock(p)*w);
 }
 public static void gripArm(LocalPlayer player,HumanoidArm arm,PoseStack pose,SubmitNodeCollector collector,int light){
  // The support hand has its own reload track. Keep the firing hand attached.
  float partial=Minecraft.getInstance().getDeltaTracker().getGameTimeDeltaPartialTick(true);
  if(active(partial)&&arm!=player.getMainArm())return;
  RenderUtil.renderFirstPersonArm(player,arm,pose,collector,light);
 }
 public static void supportArm(PoseStack pose,SubmitNodeCollector collector,int light,Gun gun,ItemStack stack,HumanoidArm hand,float translateX){
  Minecraft mc=Minecraft.getInstance();LocalPlayer player=mc.player;if(player==null)return;
  float partial=mc.getDeltaTracker().getGameTimeDeltaPartialTick(true),w=weight(partial);if(w<=.001F)return;
  float p=phase(stack,partial),drop=travel(p),cock=cock(p),side=hand==HumanoidArm.RIGHT?1F:-1F;
  String kind=ReloadTiming.kind(stack);boolean shells=kind.equals("shotgun"),rocket=kind.equals("bazooka"),launcher=kind.equals("grenade_launcher");
  pose.pushPose();
  pose.translate(.56F*side,-.52F,-.72F);
  transform(pose,kind,p,w,side);
  // Match CGM's normal support-arm coordinate system, then reach for magazine/bolt.
  pose.rotateDegrees(Axis.YP,180F);
  pose.translate(.3125F*side,0,0);
  pose.translate(-.08F*side*w,-.38F*drop*w,.18F*drop*w);
  if(shells)pose.translate(.05F*side*w,.1F*(1F-drop)*w,.14F*w);
  if(rocket)pose.translate(-.12F*side*w,.2F*w,.28F*(1F-drop)*w);
  pose.translate(.14F*side*cock*w,.17F*cock*w,-.18F*cock*w);
  pose.scale(.5F,.5F,.5F);
  pose.translate(.06F*side,-.1F,-.4375F);
  pose.rotateDegrees(Axis.XP,45F+25F*drop*w-20F*cock*w);
  pose.rotateDegrees(Axis.YP,15F*side-25F*side*drop*w);
  pose.rotateDegrees(Axis.ZP,15F*side);
  RenderUtil.renderFirstPersonArm(player,hand.getOpposite(),pose,collector,light);
  if((shells||rocket||launcher||kind.equals("mini_gun"))&&p>.25F&&p<.73F){
   pose.pushPose();pose.translate(-.1F*side,.85F,-.06F);pose.scale(.65F,.65F,.65F);
   pose.rotateDegrees(Axis.XP,180F);
   ItemStack ammo=new ItemStack(BuiltInRegistries.ITEM.getValue(gun.getProjectile().getItem()));
   RenderUtil.renderModel(ammo,ItemDisplayContext.THIRD_PERSON_LEFT_HAND,pose,collector,light,OverlayTexture.NO_OVERLAY,null);
   pose.popPose();
  }
  pose.popPose();
 }
 public static boolean model(float partial,ItemDisplayContext display,ItemStack stack,PoseStack pose,SubmitNodeCollector collector,int light,int overlay){
  if(display!=ItemDisplayContext.FIRST_PERSON_RIGHT_HAND&&display!=ItemDisplayContext.FIRST_PERSON_LEFT_HAND)return false;
  if(!active(partial)||stack!=Minecraft.getInstance().player.getMainHandItem())return false;
  FrameworkBakedModel body,magazine;
  switch(ReloadTiming.kind(stack)){
   case "pistol":body=SpecialModels.RELOAD_PISTOL_BODY.getModel();magazine=SpecialModels.RELOAD_PISTOL_MAGAZINE.getModel();break;
   case "machine_pistol":body=SpecialModels.RELOAD_MACHINE_PISTOL_BODY.getModel();magazine=SpecialModels.RELOAD_MACHINE_PISTOL_MAGAZINE.getModel();break;
   case "assault_rifle":body=SpecialModels.RELOAD_ASSAULT_RIFLE_BODY.getModel();magazine=SpecialModels.RELOAD_ASSAULT_RIFLE_MAGAZINE.getModel();break;
   case "rifle":body=SpecialModels.RELOAD_RIFLE_BODY.getModel();magazine=SpecialModels.RELOAD_RIFLE_MAGAZINE.getModel();break;
   case "heavy_rifle":body=SpecialModels.RELOAD_HEAVY_RIFLE_BODY.getModel();magazine=SpecialModels.RELOAD_HEAVY_RIFLE_MAGAZINE.getModel();break;
   default:return false;
  }
  if(body==null||magazine==null)return false;
  SubmitRenderUtil.submitStandalone(body,pose,collector,light,overlay);
  float p=phase(stack,partial),drop=travel(p)*weight(partial);
  float side=display==ItemDisplayContext.FIRST_PERSON_RIGHT_HAND?1F:-1F;
  pose.pushPose();pose.translate(-.12F*side*drop,-.5F*drop,.12F*drop);
  pose.rotateDegrees(Axis.ZP,12F*side*drop);
  SubmitRenderUtil.submitStandalone(magazine,pose,collector,light,overlay);pose.popPose();
  return true;
 }
}
