package com.mrcrayfish.guns.client.screen;

import com.google.common.collect.ImmutableList;
import com.mrcrayfish.guns.blockentity.WorkbenchBlockEntity;
import com.mrcrayfish.guns.client.util.RenderUtil;
import com.mrcrayfish.guns.common.NetworkGunManager;
import com.mrcrayfish.guns.common.container.WorkbenchContainer;
import com.mrcrayfish.guns.crafting.WorkbenchIngredient;
import com.mrcrayfish.guns.crafting.WorkbenchRecipe;
import com.mrcrayfish.guns.crafting.WorkbenchRecipes;
import com.mrcrayfish.guns.init.ModItems;
import com.mrcrayfish.guns.item.GunItem;
import com.mrcrayfish.guns.item.IAmmo;
import com.mrcrayfish.guns.item.IColored;
import com.mrcrayfish.guns.item.attachment.IAttachment;
import com.mrcrayfish.guns.network.PacketHandler;
import com.mrcrayfish.guns.network.message.C2SMessageCraft;
import com.mrcrayfish.guns.util.InventoryUtil;
import com.mrcrayfish.guns.util.StackData;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.core.NonNullList;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.DyeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.registries.ForgeRegistries;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Author: MrCrayfish
 */
public class WorkbenchScreen extends AbstractContainerScreen<WorkbenchContainer>
{
    private static final Identifier GUI_BASE = Identifier.parse("cgm:textures/gui/workbench.png");
    private static boolean showRemaining = false;

    private Tab currentTab;
    private List<Tab> tabs = new ArrayList<>();
    private List<MaterialItem> materials;
    private List<MaterialItem> filteredMaterials;
    private Inventory playerInventory;
    private WorkbenchBlockEntity workbench;
    private Button btnCraft;
    private CheckBox checkBoxMaterials;
    private ItemStack displayStack;

    public WorkbenchScreen(WorkbenchContainer container, Inventory playerInventory, Component title)
    {
        super(container, playerInventory, title, 275, 212);
        this.playerInventory = playerInventory;
        this.workbench = container.getWorkbench();
        this.materials = new ArrayList<>();
        this.filteredMaterials = NonNullList.withSize(6, MaterialItem.EMPTY);
        this.displayStack = ItemStack.EMPTY;
        this.createTabs(com.mrcrayfish.guns.port.MenuRecipes.get(container));
    }

    private void createTabs(NonNullList<WorkbenchRecipe> recipes)
    {
        List<WorkbenchRecipe> weapons = new ArrayList<>();
        List<WorkbenchRecipe> attachments = new ArrayList<>();
        List<WorkbenchRecipe> ammo = new ArrayList<>();
        List<WorkbenchRecipe> misc = new ArrayList<>();

        for(WorkbenchRecipe recipe : recipes)
        {
            ItemStack output = recipe.getItem();
            if(output.getItem() instanceof GunItem)
            {
                weapons.add(recipe);
            }
            else if(output.getItem() instanceof IAttachment)
            {
                attachments.add(recipe);
            }
            else if(this.isAmmo(output))
            {
                ammo.add(recipe);
            }
            else
            {
                misc.add(recipe);
            }
        }

        if(!weapons.isEmpty())
        {
            ItemStack icon = new ItemStack(ModItems.ASSAULT_RIFLE.get());
            StackData.update(icon, tag -> tag.putInt("AmmoCount", ModItems.ASSAULT_RIFLE.get().getGun().getGeneral().getMaxAmmo()));
            this.tabs.add(new Tab(icon, "weapons", weapons));
        }

        if(!attachments.isEmpty())
        {
            this.tabs.add(new Tab(new ItemStack(ModItems.LONG_SCOPE.get()), "attachments", attachments));
        }

        if(!ammo.isEmpty())
        {
            this.tabs.add(new Tab(new ItemStack(ModItems.SHELL.get()), "ammo", ammo));
        }

        if(!misc.isEmpty())
        {
            this.tabs.add(new Tab(new ItemStack(Items.BARRIER), "misc", misc));
        }

        if(!this.tabs.isEmpty())
        {
            this.currentTab = this.tabs.get(0);
        }
    }

    private boolean isAmmo(ItemStack stack)
    {
        if(stack.getItem() instanceof IAmmo)
        {
            return true;
        }
        Identifier id = ForgeRegistries.ITEMS.getKey(stack.getItem());
        Objects.requireNonNull(id);
        for(GunItem gunItem : NetworkGunManager.getClientRegisteredGuns())
        {
            if(id.equals(gunItem.getModifiedGun(stack).getProjectile().getItem()))
            {
                return true;
            }
        }
        return false;
    }

    @Override
    public void init()
    {
        super.init();
        if(!this.tabs.isEmpty())
        {
            this.topPos += 28;
        }
        this.addRenderableWidget(Button.builder(Component.literal("<"), button ->
        {
            if(this.currentTab == null) return;
            int index = this.currentTab.getCurrentIndex();
            if(index - 1 < 0)
            {
                this.loadItem(this.currentTab.getRecipes().size() - 1);
            }
            else
            {
                this.loadItem(index - 1);
            }
        }).pos(this.leftPos + 9, this.topPos + 18).size(15, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal(">"), button ->
        {
            if(this.currentTab == null) return;
            int index = this.currentTab.getCurrentIndex();
            if(index + 1 >= this.currentTab.getRecipes().size())
            {
                this.loadItem(0);
            }
            else
            {
                this.loadItem(index + 1);
            }
        }).pos(this.leftPos + 153, this.topPos + 18).size(15, 20).build());
        this.btnCraft = this.addRenderableWidget(Button.builder(Component.translatable("gui.cgm.workbench.assemble"), button ->
        {
            if(this.currentTab == null) return;
            int index = this.currentTab.getCurrentIndex();
            WorkbenchRecipe recipe = this.currentTab.getRecipes().get(index);
            Identifier registryName = recipe.getId();
            PacketHandler.getPlayChannel().sendToServer(new C2SMessageCraft(registryName, this.workbench.getBlockPos()));
        }).pos(this.leftPos + 195, this.topPos + 16).size(74, 20).build());
        this.btnCraft.active = false;
        this.checkBoxMaterials = this.addRenderableWidget(new CheckBox(this.leftPos + 172, this.topPos + 51, Component.translatable("gui.cgm.workbench.show_remaining")));
        this.checkBoxMaterials.setToggled(WorkbenchScreen.showRemaining);
        if(this.currentTab != null) this.loadItem(this.currentTab.getCurrentIndex());
    }

    @Override
    public void containerTick()
    {
        super.containerTick();

        for(MaterialItem material : this.materials)
        {
            material.tick();
        }

        boolean canCraft = this.currentTab != null;
        for(MaterialItem material : this.materials)
        {
            if(!material.isEnabled())
            {
                canCraft = false;
                break;
            }
        }

        this.btnCraft.active = canCraft;
        this.updateColor();
    }

    private void updateColor()
    {
        if(this.currentTab != null)
        {
            ItemStack item = this.displayStack;
            if(IColored.isDyeable(item))
            {
                IColored colored = (IColored) item.getItem();
                if(!this.workbench.getItem(0).isEmpty())
                {
                    ItemStack dyeStack = this.workbench.getItem(0);
                    if(dyeStack.getItem() instanceof DyeItem)
                    {
                        DyeColor color = dyeStack.get(DataComponents.DYE);
                        if(color != null)
                        {
                            colored.setColor(item, color.getTextureDiffuseColor() & 0xFFFFFF);
                        }
                    }
                    else
                    {
                        colored.removeColor(item);
                    }
                }
                else
                {
                    colored.removeColor(item);
                }
            }
        }
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick)
    {
        boolean result = super.mouseClicked(event, doubleClick);
        WorkbenchScreen.showRemaining = this.checkBoxMaterials.isToggled();
        double mouseX = event.x();
        double mouseY = event.y();

        for(int i = 0; i < this.tabs.size(); i++)
        {
            if(RenderUtil.isMouseWithin((int) mouseX, (int) mouseY, this.leftPos + 28 * i, this.topPos - 28, 28, 28))
            {
                this.currentTab = this.tabs.get(i);
                if(this.currentTab != null) this.loadItem(this.currentTab.getCurrentIndex());
                this.minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0F));
                return true;
            }
        }

        return result;
    }

    private void loadItem(int index)
    {
        WorkbenchRecipe recipe = this.currentTab.getRecipes().get(index);
        this.displayStack = recipe.getItem().copy();
        this.updateColor();

        this.materials.clear();

        List<WorkbenchIngredient> ingredients = recipe.getMaterials();
        if(ingredients != null)
        {
            for(WorkbenchIngredient ingredient : ingredients)
            {
                MaterialItem item = new MaterialItem(ingredient);
                item.updateEnabledState();
                this.materials.add(item);
            }

            this.currentTab.setCurrentIndex(index);
        }
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTicks)
    {
        super.extractRenderState(graphics, mouseX, mouseY, partialTicks);

        int startX = this.leftPos;
        int startY = this.topPos;
        for(int i = 0; i < this.tabs.size(); i++)
        {
            if(RenderUtil.isMouseWithin(mouseX, mouseY, startX + 28 * i, startY - 28, 28, 28))
            {
                graphics.setTooltipForNextFrame(Component.translatable(this.tabs.get(i).getTabKey()), mouseX, mouseY);
                return;
            }
        }

        for(int i = 0; i < this.filteredMaterials.size(); i++)
        {
            int itemX = startX + 172;
            int itemY = startY + i * 19 + 63;
            if(RenderUtil.isMouseWithin(mouseX, mouseY, itemX, itemY, 97, 19))
            {
                MaterialItem materialItem = this.filteredMaterials.get(i);
                if(materialItem != MaterialItem.EMPTY)
                {
                    graphics.setTooltipForNextFrame(this.font, materialItem.getDisplayStack(), mouseX, mouseY);
                    return;
                }
            }
        }

        if(RenderUtil.isMouseWithin(mouseX, mouseY, startX + 8, startY + 38, 160, 48) && !this.displayStack.isEmpty())
        {
            graphics.setTooltipForNextFrame(this.font, this.displayStack, mouseX, mouseY);
        }
    }

    @Override
    protected void extractLabels(GuiGraphicsExtractor graphics, int mouseX, int mouseY)
    {
        int offset = this.tabs.isEmpty() ? 0 : 28;
        graphics.text(this.font, this.title, this.titleLabelX, this.titleLabelY - 28 + offset, 0xFF404040, false);
        graphics.text(this.font, this.playerInventory.getDisplayName(), this.inventoryLabelX, this.inventoryLabelY - 9 + offset, 0xFF404040, false);
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTicks)
    {
        int startX = this.leftPos;
        int startY = this.topPos;

        for(int i = 0; i < this.tabs.size(); i++)
        {
            Tab tab = this.tabs.get(i);
            if(tab != this.currentTab)
            {
                graphics.blit(RenderPipelines.GUI_TEXTURED, GUI_BASE, startX + 28 * i, startY - 28, 80.0F, 184.0F, 28, 32, 256, 256);
                graphics.item(tab.getIcon(), startX + 28 * i + 6, startY - 20);
                graphics.itemDecorations(this.font, tab.getIcon(), startX + 28 * i + 6, startY - 20);
            }
        }

        graphics.blit(RenderPipelines.GUI_TEXTURED, GUI_BASE, startX, startY, 0.0F, 0.0F, 173, 184, 256, 256);
        graphics.fill(startX + 173, startY, startX + 273, startY + 182, 0xFFC6C6C6);
        graphics.fill(startX + 173, startY, startX + 273, startY + 2, 0xFFFFFFFF);
        graphics.fill(startX + 273, startY + 2, startX + 275, startY + 184, 0xFF373737);
        graphics.fill(startX + 173, startY + 182, startX + 273, startY + 184, 0xFF373737);
        for(int row = 0; row < 6; row++) {
            int y = startY + 63 + row * 19;
            graphics.fill(startX + 172, y, startX + 269, y + 19, 0xFF373737);
            graphics.fill(startX + 173, y + 1, startX + 268, y + 18, 0xFF555555);
            graphics.fill(startX + 173, y + 18, startX + 269, y + 19, 0xFFFFFFFF);
        }
        graphics.fill(startX + 172, startY + 16, startX + 192, startY + 36, 0xFF373737);
        graphics.fill(startX + 173, startY + 17, startX + 192, startY + 36, 0xFF8B8B8B);

        if(this.currentTab != null)
        {
            int i = this.tabs.indexOf(this.currentTab);
            int u = i == 0 ? 80 : 108;
            graphics.blit(RenderPipelines.GUI_TEXTURED, GUI_BASE, startX + 28 * i, startY - 28, (float) u, 214.0F, 28, 32, 256, 256);
            graphics.item(this.currentTab.getIcon(), startX + 28 * i + 6, startY - 20);
            graphics.itemDecorations(this.font, this.currentTab.getIcon(), startX + 28 * i + 6, startY - 20);
        }

        if(this.workbench.getItem(0).isEmpty())
        {
            graphics.blit(RenderPipelines.GUI_TEXTURED, GUI_BASE, startX + 174, startY + 18, 165.0F, 199.0F, 16, 16, 256, 256);
        }

        ItemStack currentItem = this.displayStack == null ? ItemStack.EMPTY : this.displayStack;
        if(!currentItem.isEmpty())
        {
            StringBuilder builder = new StringBuilder(currentItem.getHoverName().getString());
            if(currentItem.getCount() > 1)
            {
                builder.append(ChatFormatting.GOLD).append(ChatFormatting.BOLD).append(" x ").append(currentItem.getCount());
            }
            graphics.centeredText(this.font, builder.toString(), startX + 88, startY + 22, Color.WHITE.getRGB());

            graphics.enableScissor(startX + 8, startY + 38, startX + 168, startY + 86);
            var pose = graphics.pose();
            pose.pushMatrix();
            pose.translate(startX + 88, startY + 60);
            // Keep the preview upright, matching the reference workbench.
            pose.scale(3.6F, 3.6F);
            graphics.item(currentItem, -8, -8);
            pose.popMatrix();
            graphics.disableScissor();
        }

        this.filteredMaterials = this.getMaterials();
        for(int i = 0; i < this.filteredMaterials.size(); i++)
        {
            MaterialItem materialItem = this.filteredMaterials.get(i);
            ItemStack stack = materialItem.getDisplayStack();
            if(!stack.isEmpty())
            {
                int rowY = startY + i * 19 + 63;
                float v = materialItem.isEnabled() ? 184.0F : 222.0F;
                graphics.fill(startX + 173, rowY + 1, startX + 268, rowY + 18, materialItem.isEnabled() ? 0xFF7F7F7F : 0xFFB84F32);

                String name = stack.getHoverName().getString();
                if(this.font.width(name) > 70)
                {
                    name = this.font.plainSubstrByWidth(name, 65).trim() + "...";
                }
                graphics.text(this.font, name, startX + 194, rowY + 6, Color.WHITE.getRGB(), false);
                graphics.item(stack, startX + 174, rowY + 1);

                ItemStack decorated = stack;
                if(this.checkBoxMaterials != null && this.checkBoxMaterials.isToggled() && this.minecraft.player != null)
                {
                    int count = InventoryUtil.getItemStackAmount(this.minecraft.player, stack);
                    decorated = stack.copy();
                    decorated.setCount(Math.max(0, stack.getCount() - count));
                }
                graphics.itemDecorations(this.font, decorated, startX + 174, rowY + 1);
            }
        }
    }

    private List<MaterialItem> getMaterials()
    {
        List<MaterialItem> materials = NonNullList.withSize(6, MaterialItem.EMPTY);
        List<MaterialItem> filteredMaterials = this.materials.stream().filter(materialItem -> this.checkBoxMaterials.isToggled() ? !materialItem.isEnabled() : materialItem != MaterialItem.EMPTY).collect(Collectors.toList());
        for(int i = 0; i < filteredMaterials.size() && i < materials.size(); i++)
        {
            materials.set(i, filteredMaterials.get(i));
        }
        return materials;
    }

    public List<Tab> getTabs()
    {
        return ImmutableList.copyOf(this.tabs);
    }

    public static class MaterialItem
    {
        public static final MaterialItem EMPTY = new MaterialItem();

        private long lastTime = System.currentTimeMillis();
        private int displayIndex;
        private boolean enabled = false;
        private WorkbenchIngredient ingredient;
        private final List<ItemStack> displayStacks = new ArrayList<>();

        private MaterialItem() {}

        private MaterialItem(WorkbenchIngredient ingredient)
        {
            this.ingredient = ingredient;
            Stream.of(ingredient.getItems()).forEach(stack -> {
                ItemStack displayStack = stack.copy();
                displayStack.setCount(ingredient.getCount());
                this.displayStacks.add(displayStack);
            });
        }

        public WorkbenchIngredient getIngredient()
        {
            return this.ingredient;
        }

        public void tick()
        {
            if(this.ingredient == null)
                return;

            this.updateEnabledState();
            long currentTime = System.currentTimeMillis();
            if(currentTime - this.lastTime >= 1000)
            {
                this.displayIndex = (this.displayIndex + 1) % this.displayStacks.size();
                this.lastTime = currentTime;
            }
        }

        public ItemStack getDisplayStack()
        {
            return this.ingredient != null ? this.displayStacks.get(this.displayIndex) : ItemStack.EMPTY;
        }

        public void updateEnabledState()
        {
            this.enabled = InventoryUtil.hasWorkstationIngredient(Minecraft.getInstance().player, this.ingredient);
        }

        public boolean isEnabled()
        {
            return this.ingredient == null || this.enabled;
        }
    }

    private static class Tab
    {
        private final ItemStack icon;
        private final String id;
        private final List<WorkbenchRecipe> items;
        private int currentIndex;

        public Tab(ItemStack icon, String id, List<WorkbenchRecipe> items)
        {
            this.icon = icon;
            this.id = id;
            this.items = items;
        }

        public ItemStack getIcon()
        {
            return this.icon;
        }

        public String getTabKey()
        {
            return "gui.cgm.workbench.tab." + this.id;
        }

        public void setCurrentIndex(int currentIndex)
        {
            this.currentIndex = currentIndex;
        }

        public int getCurrentIndex()
        {
            return this.currentIndex;
        }

        public List<WorkbenchRecipe> getRecipes()
        {
            return this.items;
        }
    }
}
