package com.mrcrayfish.guns.client.handler;

import com.mrcrayfish.guns.client.KeyBinds;
import com.mrcrayfish.guns.common.Gun;
import com.mrcrayfish.guns.event.GunReloadEvent;
import com.mrcrayfish.guns.init.ModSyncedDataKeys;
import com.mrcrayfish.guns.item.GunItem;
import com.mrcrayfish.guns.network.PacketHandler;
import com.mrcrayfish.guns.network.message.C2SMessageReload;
import com.mrcrayfish.guns.network.message.C2SMessageUnload;
import com.mrcrayfish.guns.util.GunEnchantmentHelper;
import com.mrcrayfish.guns.util.StackData;
import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.listener.SubscribeEvent;

/**
 * Author: MrCrayfish
 */
public class ReloadHandler
{
    private static ReloadHandler instance;

    public static ReloadHandler get()
    {
        if(instance == null)
        {
            instance = new ReloadHandler();
        }
        return instance;
    }

    private int startReloadTick = -1;
    private int lastAmmo = -1;
    private int lastProgressTick;
    private int reloadTimer;
    private int prevReloadTimer;
    private int reloadingSlot = -1;

    private ReloadHandler()
    {
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent.Post event)
    {

        this.prevReloadTimer = this.reloadTimer;

        Player player = Minecraft.getInstance().player;
        if(player != null)
        {
            if(ModSyncedDataKeys.RELOADING.getValue(player))
            {
                ItemStack held = player.getMainHandItem();
                int ammo = StackData.copy(held).getIntOr("AmmoCount", 0);
                if(ammo != this.lastAmmo) { this.lastAmmo = ammo; this.lastProgressTick = player.tickCount; }
                int interval = held.getItem() instanceof GunItem ? Math.max(1, GunEnchantmentHelper.getReloadInterval(held)) : 1;
                if(this.reloadingSlot != player.getInventory().getSelectedSlot()
                    || !(held.getItem() instanceof GunItem) || !player.isAlive()
                    || player.tickCount - this.lastProgressTick > interval * 2 + 60)
                {
                    this.setReloading(false);
                }
            }

            this.updateReloadTimer(player);
        }
        else { this.startReloadTick = -1; this.reloadTimer = 0; this.prevReloadTimer = 0; this.reloadingSlot = -1; }
    }

    @SubscribeEvent
    public void onKeyPressed(InputEvent.Key event)
    {
        Minecraft mc = Minecraft.getInstance();
        if(mc.player == null || event.getAction() != 1)
            return;
        // Don't interpret R typed into chat, creative search or other text fields.
        if(mc.gui.screen() != null && !(mc.gui.screen() instanceof net.minecraft.client.gui.screens.inventory.InventoryScreen)
            && !(mc.gui.screen() instanceof net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen creative && creative.isInventoryOpen()))
            return;
        if(KeyBinds.KEY_RELOAD.matches(event.getInfo()))
        {
            this.setReloading(true);
        }
        else if(KeyBinds.KEY_UNLOAD.matches(event.getInfo()))
        {
            this.setReloading(false);
            PacketHandler.getPlayChannel().sendToServer(new C2SMessageUnload());
        }
    }

    public void setReloading(boolean reloading)
    {
        Player player = Minecraft.getInstance().player;
        if(player != null)
        {
            if(reloading)
            {
                ItemStack stack = player.getMainHandItem();
                if(stack.getItem() instanceof GunItem)
                {
                    CompoundTag tag = StackData.copy(stack);
                    if(!ModSyncedDataKeys.RELOADING.getValue(player) && com.mrcrayfish.guns.port.ReloadRules.canReload(player))
                    {
                        Gun gun = ((GunItem) stack.getItem()).getModifiedGun(stack);
                        if(tag.getIntOr("AmmoCount", 0) >= GunEnchantmentHelper.getAmmoCapacity(stack, gun))
                            return;
                        if(GunReloadEvent.Pre.BUS.post(new GunReloadEvent.Pre(player, stack)))
                            return;
                        this.startReloadTick = player.tickCount;
                        this.lastProgressTick = player.tickCount;
                        this.lastAmmo = tag.getIntOr("AmmoCount", 0);
                        ModSyncedDataKeys.RELOADING.setValue(player, true);
                        PacketHandler.getPlayChannel().sendToServer(new C2SMessageReload(true));
                        this.reloadingSlot = player.getInventory().getSelectedSlot();
                        GunReloadEvent.Post.BUS.post(new GunReloadEvent.Post(player, stack));
                    }
                }
            }
            else
            {
                ModSyncedDataKeys.RELOADING.setValue(player, false);
                PacketHandler.getPlayChannel().sendToServer(new C2SMessageReload(false));
                this.reloadingSlot = -1;
            }
        }
    }

    private void updateReloadTimer(Player player)
    {
        if(ModSyncedDataKeys.RELOADING.getValue(player))
        {
            if(this.startReloadTick == -1)
            {
                this.startReloadTick = player.tickCount;
            }
            if(this.reloadTimer < 5)
            {
                this.reloadTimer++;
            }
        }
        else
        {
            if(this.startReloadTick != -1)
            {
                this.startReloadTick = -1;
            }
            if(this.reloadTimer > 0)
            {
                this.reloadTimer--;
            }
        }
    }

    public int getStartReloadTick()
    {
        return this.startReloadTick;
    }

    public int getReloadTimer()
    {
        return this.reloadTimer;
    }

    public float getReloadProgress(float partialTicks)
    {
        return (this.prevReloadTimer + (this.reloadTimer - this.prevReloadTimer) * partialTicks) / 5F;
    }
}
