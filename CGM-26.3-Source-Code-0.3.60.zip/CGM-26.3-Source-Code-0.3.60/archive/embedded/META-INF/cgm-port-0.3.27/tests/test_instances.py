from pathlib import Path
import subprocess
sources={
'net/minecraft/world/item/Item':'public class Item{}',
'com/mrcrayfish/guns/item/GunItem':'public class GunItem extends net.minecraft.world.item.Item{}',
'net/minecraft/nbt/CompoundTag':'''public class CompoundTag{public java.util.Map<String,Object> map=new java.util.HashMap<>();public String getStringOr(String k,String d){return (String)map.getOrDefault(k,d);}public void putString(String k,String v){map.put(k,v);}public int getIntOr(String k,int d){return (int)map.getOrDefault(k,d);}public void putInt(String k,int v){map.put(k,v);}public CompoundTag copy(){var n=new CompoundTag();n.map.putAll(map);return n;}}''',
'net/minecraft/world/item/ItemStack':'''public class ItemStack{public Item item;public net.minecraft.nbt.CompoundTag tag=new net.minecraft.nbt.CompoundTag();public ItemStack(Item i){item=i;}public Item getItem(){return item;}public ItemStack copy(){var n=new ItemStack(item);n.tag=tag.copy();return n;}}''',
'net/minecraft/world/entity/player/Inventory':'''public class Inventory{public net.minecraft.world.item.ItemStack[] slots=new net.minecraft.world.item.ItemStack[3]; public int selected;public int getSelectedSlot(){return selected;}public net.minecraft.world.item.ItemStack getSelectedItem(){return slots[selected];}public int getContainerSize(){return slots.length;}public net.minecraft.world.item.ItemStack getItem(int i){return slots[i];}public void setItem(int i,net.minecraft.world.item.ItemStack s){slots[i]=s;}public void setChanged(){}}''',
'net/minecraft/world/entity/player/Player':'public class Player{public Inventory inv=new Inventory();public Inventory getInventory(){return inv;}}',
'com/mrcrayfish/guns/util/StackData':'''public class StackData{public static net.minecraft.nbt.CompoundTag copy(net.minecraft.world.item.ItemStack s){return s.tag.copy();}public static void update(net.minecraft.world.item.ItemStack s,java.util.function.Consumer<net.minecraft.nbt.CompoundTag> c){var t=s.tag.copy();c.accept(t);s.tag=t;}}'''
}
for n,s in sources.items():
 p=Path('work27/testsrc/'+n+'.java');p.parent.mkdir(parents=True,exist_ok=True);p.write_text('package '+n.rsplit('/',1)[0].replace('/','.')+';'+s)
Path('work27/testsrc/InstanceTest.java').write_text('''import com.mrcrayfish.guns.port.WeaponInstance;
import com.mrcrayfish.guns.util.StackData;
import net.minecraft.world.entity.player.*;
import net.minecraft.world.item.*;
public class InstanceTest{
 public static void main(String[] args){
 var p=new Player();var gun=new com.mrcrayfish.guns.item.GunItem();var shared=new ItemStack(gun);shared.tag.putInt("AmmoCount",40);
 p.inv.slots[0]=shared;p.inv.slots[1]=shared;p.inv.slots[2]=new ItemStack(new Item());
 var active=WeaponInstance.selected(p);StackData.update(active,t->t.putInt("AmmoCount",39));
 if(p.inv.slots[1].tag.getIntOr("AmmoCount",0)!=40)throw new AssertionError("shared gun consumed");
 if(active!=WeaponInstance.selected(p))throw new AssertionError("stable instance replaced");
 p.inv.slots[1]=active.copy();p.inv.selected=1;
 var second=WeaponInstance.selected(p);if(second.tag.getStringOr("CGMInstance","").equals(active.tag.getStringOr("CGMInstance","")))throw new AssertionError("copied ID retained");
 StackData.update(second,t->t.putInt("AmmoCount",40));if(active.tag.getIntOr("AmmoCount",0)!=39)throw new AssertionError("reload crossed slots");
 p.inv.selected=0;StackData.update(WeaponInstance.selected(p),t->t.putInt("AmmoCount",0));if(second.tag.getIntOr("AmmoCount",0)!=40)throw new AssertionError("unload crossed slots");
 p.inv.selected=2;if(WeaponInstance.selected(p)!=p.inv.slots[2])throw new AssertionError("non gun changed");
 System.out.println("PASS actual WeaponInstance bytecode with API stubs: shared references, identical copied IDs, independent fire/reload/unload, stable identity, non-gun unchanged");
 }}''')
subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-cp','work27/classes','-d','work27/testclasses',*map(str,Path('work27/testsrc').rglob('*.java'))],check=True)
subprocess.run(['java','-cp','work27/testclasses:work27/classes','InstanceTest'],check=True)
