import java.nio.file.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
public class ExtractTiming implements Opcodes{
 public static void main(String[] a)throws Exception{
  ClassNode c=new ClassNode();new ClassReader(Files.readAllBytes(Path.of("work27/classes/com/mrcrayfish/guns/common/ReloadTracker.class"))).accept(c,0);
  c.visibleAnnotations=null;c.invisibleAnnotations=null;c.innerClasses.clear();
  c.fields.removeIf(f->!f.name.equals("nextLoadTick")&&!f.name.equals("stack"));
  c.fields.forEach(f->f.access=ACC_PUBLIC);
  c.methods.removeIf(m->!m.name.equals("canReload"));c.methods.get(0).access=ACC_PUBLIC;
  MethodNode ctor=new MethodNode(ACC_PUBLIC,"<init>","()V",null,null);ctor.instructions.add(new VarInsnNode(ALOAD,0));ctor.instructions.add(new MethodInsnNode(INVOKESPECIAL,"java/lang/Object","<init>","()V",false));ctor.instructions.add(new InsnNode(RETURN));c.methods.add(ctor);
  ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);Path p=Path.of("work27/testclasses/com/mrcrayfish/guns/common/ReloadTracker.class");Files.createDirectories(p.getParent());Files.write(p,w.toByteArray());
 }
}
