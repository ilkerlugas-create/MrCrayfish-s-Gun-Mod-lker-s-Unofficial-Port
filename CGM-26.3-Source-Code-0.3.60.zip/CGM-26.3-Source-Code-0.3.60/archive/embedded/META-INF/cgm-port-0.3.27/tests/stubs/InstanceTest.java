import com.mrcrayfish.guns.port.WeaponInstance;
import com.mrcrayfish.guns.util.StackData;
import net.minecraft.world.entity.player.*;
import net.minecraft.world.item.*;
public class InstanceTest{
 public static void main(String[] args){
 var p=new Player();var gun=new com.mrcrayfish.guns.item.GunItem();var shared=new ItemStack(gun);shared.tag.putInt("AmmoCount",40);
 p.inv.slots[0]=shared;p.inv.slots[1]=shared;p.inv.slots[2]=new ItemStack(new Item());
 var active=WeaponInstance.selected(p);StackData.update(active,t->t.putInt("AmmoCount",39));
 if(p.inv.slots[1].tag.getIntOr("AmmoCount",0)!=40)throw new AssertionError("shared gun consumed");
 if(active!=WeaponInstance.selected(p))throw new AssertionError("stable instance replaced");
 p.inv.slots[1]=active.copy();p.inv.selected=1;
 var second=WeaponInstance.selected(p);if(second.tag.getStringOr("CGMInstance","").equals(active.tag.getStringOr("CGMInstance","")))throw new AssertionError("copied ID retained");
 StackData.update(second,t->t.putInt("AmmoCount",40));if(active.tag.getIntOr("AmmoCount",0)!=39)throw new AssertionError("reload crossed slots");
 p.inv.selected=0;StackData.update(WeaponInstance.selected(p),t->t.putInt("AmmoCount",0));if(second.tag.getIntOr("AmmoCount",0)!=40)throw new AssertionError("unload crossed slots");
 p.inv.selected=2;if(WeaponInstance.selected(p)!=p.inv.slots[2])throw new AssertionError("non gun changed");
 System.out.println("PASS actual WeaponInstance bytecode with API stubs: shared references, identical copied IDs, independent fire/reload/unload, stable identity, non-gun unchanged");
 }}