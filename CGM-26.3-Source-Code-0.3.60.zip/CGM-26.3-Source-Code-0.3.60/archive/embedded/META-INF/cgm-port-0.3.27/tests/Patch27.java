import java.nio.file.*;
import java.util.*;
import java.util.jar.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.tree.analysis.*;
public class Patch27 implements Opcodes {
 public static void main(String[] args)throws Exception {
  try(JarFile jar=new JarFile(args[0])){
   String n="com/mrcrayfish/guns/common/network/ServerPlayHandler";
   ClassNode c=new ClassNode();new ClassReader(jar.getInputStream(jar.getJarEntry(n+".class"))).accept(c,0);
   int shoot=0,unload=0;
   for(MethodNode m:c.methods) {
    for(var ins:m.instructions.toArray())if(ins instanceof MethodInsnNode a){
     if(m.name.equals("handleShoot")&&a.name.equals("getItemInHand")&&a.desc.equals("(Lnet/minecraft/world/InteractionHand;)Lnet/minecraft/world/item/ItemStack;")){
      m.instructions.insertBefore(ins,new InsnNode(POP));
      m.instructions.set(ins,new MethodInsnNode(INVOKESTATIC,"com/mrcrayfish/guns/port/WeaponInstance","selected","(Lnet/minecraft/world/entity/player/Player;)Lnet/minecraft/world/item/ItemStack;",false));shoot++;
     }
     if(m.name.equals("handleUnload")&&a.name.equals("getMainHandItem")){
      m.instructions.set(ins,new MethodInsnNode(INVOKESTATIC,"com/mrcrayfish/guns/port/WeaponInstance","selected","(Lnet/minecraft/world/entity/player/Player;)Lnet/minecraft/world/item/ItemStack;",false));unload++;
     }
    }
   }
   if(shoot!=1)throw new IllegalStateException("shoot sites "+shoot);
   save(c);
   n="com/mrcrayfish/guns/common/ReloadTracker";
   ClassNode old=new ClassNode();new ClassReader(jar.getInputStream(jar.getJarEntry(n+".class"))).accept(old,0);
   ClassNode updated=new ClassNode();new ClassReader(Files.readAllBytes(Path.of("work27/classes/"+n+".class"))).accept(updated,0);
   updated.visibleAnnotations=old.visibleAnnotations;updated.invisibleAnnotations=old.invisibleAnnotations;save(updated);
   System.out.println("Patched shooting="+shoot+", unload="+unload+"; preserved subscriber annotations");
  }
  int count=0;
  try(var paths=Files.walk(Path.of("work27/classes"))) {
   for(Path p:paths.filter(x->x.toString().endsWith(".class")).toList()) {
    ClassNode c=new ClassNode();new ClassReader(Files.readAllBytes(p)).accept(c,0);
    for(MethodNode m:c.methods) {new Analyzer<BasicValue>(new BasicVerifier()).analyze(c.name,m);count++;}
   }
  }
  System.out.println("ASM BasicVerifier passed "+count+" methods");
 }
 static void save(ClassNode c)throws Exception {ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);Path p=Path.of("work27/classes/"+c.name+".class");Files.createDirectories(p.getParent());Files.write(p,w.toByteArray());}
}
