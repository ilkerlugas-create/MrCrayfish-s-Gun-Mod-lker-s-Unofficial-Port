import json,zipfile,pathlib,hashlib,re
base=pathlib.Path('output/CGM-26.3-Forge66.0.2-0.3.21-CRASH-F5-FIX.jar')
out=pathlib.Path('output/CGM-26.3-Forge66.0.2-0.3.22-TURKCE-ANIMASYON-MUHIMMAT.jar')
with zipfile.ZipFile(base) as z:original={n:z.read(n) for n in z.namelist()}
data=original.copy()
def put(n,d):data[n]=(json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode()
translation=json.loads(pathlib.Path('work/fix22/tr_tr.json').read_text())
english=json.loads(data['assets/cgm/lang/en_us.json'])
assert not set(english)-set(translation),set(english)-set(translation)
for k,v in english.items():
    assert re.findall(r'%(?:\d+\$)?[sd]',v)==re.findall(r'%(?:\d+\$)?[sd]',translation[k]),k
# Turkish is the requested default for the mod, including fallback strings.
for lang in ['tr_tr','en_us']:put(f'assets/cgm/lang/{lang}.json',translation)
framework={
'framework.gui.sync_config_failed':'(Framework) Sunucunun ayarları eşitlenemedi. Ayrıntılar için oyun günlüğüne bak.',
'framework.gui.sync_entity_data_failed':'(Framework) Tanınmayan varlık verileri alındı. Ayrıntılar için oyun günlüğüne bak.',
'framework.validator.resource_location.hint':'Geçerli bir kaynak konumu gir.\nBiçim: "<ad_alanı>:<yol>"',
'framework.validator.resource_location.hint_with_namespace':'Kaynağın ad alanı %1$s olmalı.\nBiçim: "%1$s:<yol>"',
'framework.validator.identifier.hint':'Geçerli bir tanımlayıcı gir.\nBiçim: "<ad_alanı>:<yol>"',
'framework.validator.identifier.hint_with_namespace':'Tanımlayıcının ad alanı %1$s olmalı.\nBiçim: "%1$s:<yol>"'}
for lang in ['tr_tr','en_us']:put(f'assets/framework/lang/{lang}.json',framework)

# A model's body and transparent reticle must use the same item atlas.
# Keep effect sprites for the effects renderer; add item-atlas copies for scopes.
for scope,reticle in [('short_scope','red_dot_reticle'),('medium_scope','holo_reticle'),('long_scope','long_scope_reticle')]:
    target=f'item/{scope}_reticle'
    data[f'assets/cgm/textures/{target}.png']=data[f'assets/cgm/textures/effect/{reticle}.png']
    n=f'assets/cgm/models/item/{scope}.json';d=json.loads(data[n]);d['textures']['2']='cgm:'+target;d['textures']['particle']='cgm:item/'+scope;put(n,d)

for p in pathlib.Path('work/fix22/classes').rglob('*.class'):data[p.relative_to('work/fix22/classes').as_posix()]=p.read_bytes()
data['META-INF/mods.toml']=data['META-INF/mods.toml'].replace(b'port-0.3.21',b'port-0.3.22').replace(b'displayName="MrCrayfish\'s Gun Mod"','displayName="MrCrayfish Silah Modu"'.encode())
data['META-INF/MANIFEST.MF']=data['META-INF/MANIFEST.MF'].replace(b'port-0.3.21',b'port-0.3.22')
for p in ['work/fix22/PatchGameplay.java','work/fix22/package.py','work/fix22/src/com/mrcrayfish/guns/port/RunAnimation.java','work/fix22/testsrc/GameplayRegression.java','work/fix22/CheckRunLinks.java']:
    data['META-INF/cgm-port-0.3.22/'+pathlib.Path(p).name]=pathlib.Path(p).read_bytes()

for n,b in data.items():
    if n.endswith('.json'):json.loads(b)
for scope in ['short_scope','medium_scope','long_scope']:
    d=json.loads(data[f'assets/cgm/models/item/{scope}.json'])
    assert all(v.startswith('cgm:item/') for v in d['textures'].values())
    for t in d['textures'].values():assert 'assets/cgm/textures/'+t.split(':',1)[1]+'.png' in data
guns=[n for n in data if n.startswith('data/cgm/guns/') and n.endswith('.json')]
ammo={pathlib.Path(n).stem:json.loads(data[n])['projectile']['item'] for n in guns}
for a in ammo.values():assert f'assets/cgm/items/{a.split(":")[1]}.json' in data
assert ammo['bazooka']=='cgm:missile'
report={'version':'0.3.22','base_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),
'changes':['Remove creative ammunition bypass on client and server, including artificial infinite inventory ammo','Require positive AmmoCount, ignoring legacy IgnoreAmmo flags','Enable smooth sprint lowering for all nine weapons and vanilla running arm animation in F5','Put all three scope reticles in the same item atlas as their bodies','Provide complete Turkish CGM and Framework text, preserving format placeholders'],
'ammo_mapping':ammo,'translated_base_keys':len(english),'translation_total_keys':len(translation),
'changed_classes':[n for n in original if n.endswith('.class') and data[n]!=original[n]],
'validation':{'bytecode_verifier':'passed','turkish_key_coverage':'148/148','format_placeholders':'passed','scope_texture_files_and_atlas':'passed','all_gun_ammo_ids':'passed','ammo_count_ignore_flag_regression':'8 cases passed','sprint_transition_regression':'ramp-in/pause/ramp-out/bounds passed','muzzle_vertex_regression':'preserved fix passed','new_helper_api_links':'passed','full_gameplay_and_visual_test':'not run'}}
put('META-INF/cgm-port-0.3.22-validation.json',report)
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
    for n,b in data.items():z.writestr(n,b)
with zipfile.ZipFile(out) as z:assert z.testzip() is None
print(json.dumps({'output':str(out),'translation_keys':len(translation),'ammo':ammo,'sha256':hashlib.sha256(out.read_bytes()).hexdigest()},ensure_ascii=False,indent=2))
