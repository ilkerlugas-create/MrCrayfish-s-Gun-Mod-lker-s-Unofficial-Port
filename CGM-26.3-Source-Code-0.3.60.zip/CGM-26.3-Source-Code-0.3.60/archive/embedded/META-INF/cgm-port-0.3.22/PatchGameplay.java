import java.nio.file.*;import java.util.*;import java.util.jar.*;
import org.objectweb.asm.*;import org.objectweb.asm.tree.*;import org.objectweb.asm.tree.analysis.*;
public class PatchGameplay implements Opcodes {
 static void body(MethodNode m){m.instructions.clear();m.tryCatchBlocks.clear();if(m.localVariables!=null)m.localVariables.clear();}
 public static void main(String[] args)throws Exception {
  int creative=0,ignore=0,animation=0,third=0;
  Set<String> ammo=Set.of("com/mrcrayfish/guns/common/Gun","com/mrcrayfish/guns/common/network/ServerPlayHandler","com/mrcrayfish/guns/client/handler/ShootingHandler","com/mrcrayfish/guns/client/handler/ReloadHandler","com/mrcrayfish/guns/item/GunItem","com/mrcrayfish/guns/client/render/gun/model/MiniGunModel");
  try(JarFile j=new JarFile(args[0])){var es=j.entries();while(es.hasMoreElements()){
   var e=es.nextElement();if(!e.getName().endsWith(".class"))continue;String name=e.getName().replace(".class","");
   if(!ammo.contains(name)&&!name.endsWith("GunRenderingHandler")&&!name.endsWith("PlayerModelMixin")&&!name.endsWith("ItemInHandLayerMixin"))continue;
   ClassNode c=new ClassNode();new ClassReader(j.getInputStream(e)).accept(c,0);boolean changed=false;
   for(MethodNode m:c.methods){
    if(ammo.contains(name))for(var n:m.instructions.toArray())if(n instanceof MethodInsnNode call){
     if(call.name.equals("isCreative")&&call.desc.equals("()Z")){
      InsnList add=new InsnList();add.add(new InsnNode(POP));add.add(new InsnNode(ICONST_0));m.instructions.insert(n,add);creative++;changed=true;
     }
     if(call.owner.equals("net/minecraft/nbt/CompoundTag")&&(call.name.equals("getBooleanOr")||call.name.equals("contains"))){
      var prev=n.getPrevious();boolean found=false;for(int k=0;k<2&&prev!=null;k++,prev=prev.getPrevious())if(prev instanceof LdcInsnNode ldc&&"IgnoreAmmo".equals(ldc.cst))found=true;
      if(found){InsnList add=new InsnList();add.add(new InsnNode(POP));add.add(new InsnNode(ICONST_0));m.instructions.insert(n,add);ignore++;changed=true;}
     }
    }
    if(name.endsWith("GunRenderingHandler")&&m.name.equals("applySprintingTransforms")){
     body(m);m.instructions.add(new VarInsnNode(ALOAD,1));m.instructions.add(new VarInsnNode(ALOAD,2));m.instructions.add(new VarInsnNode(ALOAD,3));m.instructions.add(new VarInsnNode(FLOAD,4));
     m.instructions.add(new MethodInsnNode(INVOKESTATIC,"com/mrcrayfish/guns/port/RunAnimation","firstPerson",m.desc,false));m.instructions.add(new InsnNode(RETURN));animation++;changed=true;
    }
    if(name.endsWith("PlayerModelMixin")||name.endsWith("ItemInHandLayerMixin"))for(var n:m.instructions.toArray())if(n instanceof MethodInsnNode call&&call.owner.equals("com/mrcrayfish/guns/client/render/IHeldAnimation")){
     if(call.name.equals("applyPlayerModelRotation")||call.name.equals("applyHeldItemTransforms")){
      String method=call.name.equals("applyPlayerModelRotation")?"thirdPerson":"heldItem";
      call.desc="(Lcom/mrcrayfish/guns/client/render/IHeldAnimation;"+call.desc.substring(1);call.owner="com/mrcrayfish/guns/port/RunAnimation";call.name=method;call.setOpcode(INVOKESTATIC);call.itf=false;third++;changed=true;
     }
    }
   }
   if(changed){ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);byte[] b=w.toByteArray();ClassNode checked=new ClassNode();new ClassReader(b).accept(checked,0);for(MethodNode m:checked.methods)if((m.access&(ACC_ABSTRACT|ACC_NATIVE))==0)new Analyzer<>(new BasicVerifier()).analyze(checked.name,m);Path p=Path.of(args[1],e.getName());Files.createDirectories(p.getParent());Files.write(p,b);System.out.println("Verified "+name);}
  }}
  if(creative!=6||ignore!=5||animation!=1||third!=2)throw new IllegalStateException("Review counts: "+creative+","+ignore+","+animation+","+third);
  System.out.println("Six creative exemptions removed, five IgnoreAmmo exemptions removed, first-person and both third-person hooks connected.");
 }
}
