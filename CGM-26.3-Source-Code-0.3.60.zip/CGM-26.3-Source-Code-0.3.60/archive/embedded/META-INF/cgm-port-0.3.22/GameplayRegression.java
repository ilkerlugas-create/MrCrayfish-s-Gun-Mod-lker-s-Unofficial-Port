import java.nio.file.*;import java.util.jar.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;import net.minecraft.world.item.ItemStack;
public class GameplayRegression {
 static class Loader extends ClassLoader {Class<?> def(byte[] b){return defineClass(null,b,0,b.length);}}
 static Class<?> extract(byte[] bytes,String method,String name)throws Exception {
  ClassNode c=new ClassNode();new ClassReader(bytes).accept(c,0);MethodNode m=c.methods.stream().filter(x->x.name.equals(method)).findFirst().orElseThrow();
  m.access=Opcodes.ACC_PUBLIC|Opcodes.ACC_STATIC;ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);w.visit(Opcodes.V17,Opcodes.ACC_PUBLIC,name,null,"java/lang/Object",null);m.accept(w);w.visitEnd();return new Loader().def(w.toByteArray());
 }
 public static void main(String[] a)throws Exception {
  try(JarFile j=new JarFile(a[0])) {
   var ammo=extract(j.getInputStream(j.getJarEntry("com/mrcrayfish/guns/common/Gun.class")).readAllBytes(),"hasAmmo","AmmoCase").getMethod("hasAmmo",ItemStack.class);
   int cases=0;for(int count:new int[]{-1,0,1,30})for(boolean ignore:new boolean[]{false,true}){ItemStack s=new ItemStack();s.data.ammo=count;s.data.ignore=ignore;if((boolean)ammo.invoke(null,s)!=(count>0))throw new AssertionError("ammo "+count+" ignore "+ignore);cases++;}
   var step=extract(j.getInputStream(j.getJarEntry("com/mrcrayfish/guns/port/RunAnimation.class")).readAllBytes(),"approach","SprintCase").getMethod("approach",float.class,boolean.class,float.class);
   float progress=0;for(int i=0;i<5;i++)progress=(float)step.invoke(null,progress,true,1F);if(Math.abs(progress-1)>1e-5)throw new AssertionError("ramp in");
   if((float)step.invoke(null,progress,false,0F)!=progress)throw new AssertionError("pause");
   for(int i=0;i<5;i++)progress=(float)step.invoke(null,progress,false,1F);if(Math.abs(progress)>1e-5)throw new AssertionError("ramp out");
   for(int i=0;i<100;i++)progress=(float)step.invoke(null,progress,false,10F);if(progress<0||progress>1)throw new AssertionError("bounds");
   System.out.println("PASS: "+cases+" ammo-count/IgnoreAmmo cases; sprint ramp-in, pause, ramp-out, and bounds.");
  }
 }
}