package com.mrcrayfish.guns.port;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.mrcrayfish.guns.client.KeyBinds;
import com.mrcrayfish.guns.client.handler.AimingHandler;
import com.mrcrayfish.guns.client.render.IHeldAnimation;
import com.mrcrayfish.guns.common.Gun;
import com.mrcrayfish.guns.common.GripType;
import com.mrcrayfish.guns.init.ModSyncedDataKeys;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.player.Player;

public final class RunAnimation {
 private static Player tracked;
 private static float previousTime,progress;
 public static float approach(float value,boolean running,float elapsed) {
  float step=Math.max(0F,Math.min(elapsed,1F))/5F;
  return running?Math.min(1F,value+step):Math.max(0F,value-step);
 }
 public static void firstPerson(Gun gun,HumanoidArm arm,PoseStack pose,float partial) {
  Player player=Minecraft.getInstance().player;
  if(player==null){tracked=null;progress=0;return;}
  float time=player.tickCount+partial;
  if(tracked!=player){tracked=player;previousTime=time;progress=0;}
  boolean running=player.isSprinting()&&!AimingHandler.get().isAiming()
    &&!KeyBinds.getShootMapping().isDown()&&!ModSyncedDataKeys.RELOADING.getValue(player);
  progress=approach(progress,running,time-previousTime);previousTime=time;
  float eased=progress*progress*(3F-2F*progress);
  float side=arm==HumanoidArm.LEFT?-1F:1F;
  GripType grip=gun.getGeneral().getGripType();
  boolean heavy=grip==GripType.BAZOOKA||grip==GripType.MINI_GUN;
  boolean pistol=grip==GripType.ONE_HANDED;
  float amount=heavy?.4F:(pistol?.7F:1F);
  pose.translate(-.25F*side*eased*amount,-.1F*eased+Math.sin(time*.9F)*.018F*eased,0);
  pose.rotateDegrees(Axis.YP,45F*side*eased*amount);
  pose.rotateDegrees(Axis.XP,-25F*eased*amount);
 }
 private static boolean running(Player player,float aim) {
  return player.isSprinting()&&aim<.05F&&!ModSyncedDataKeys.RELOADING.getValue(player)
     &&!ModSyncedDataKeys.SHOOTING.getValue(player);
 }
 public static void thirdPerson(IHeldAnimation animation,Player player,ModelPart right,ModelPart left,
     ModelPart head,InteractionHand hand,float aim) {
  // Vanilla has already animated the running arms. Keep that movement while
  // sprinting, and resume CGM aiming/holding poses as soon as sprinting ends.
  if(!running(player,aim))animation.applyPlayerModelRotation(player,right,left,head,hand,aim);
 }
 public static void heldItem(IHeldAnimation animation,Player player,InteractionHand hand,float aim,
     PoseStack pose,SubmitNodeCollector collector) {
  if(!running(player,aim))animation.applyHeldItemTransforms(player,hand,aim,pose,collector);
 }
}
