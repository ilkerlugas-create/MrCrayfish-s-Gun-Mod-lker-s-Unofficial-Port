CGM 26.3 / Forge 66.0.2 / port 0.3.56
Base: user-supplied 0.3.55 R-RELOAD JAR.

All IScope attachment tooltips now include exactly +Uzağı görme.
This covers the registered short_scope, medium_scope, and long_scope.
The silenced and reduced sound-radius perk rows are no longer emitted.
Scope information is part of the existing cached perk list.
All original gameplay modifiers and other class files are unchanged.

Validation: ASM 9.8 BasicVerifier on all seven methods of the patched
Attachment class; ZIP CRC/duplicate checks; language JSON validation;
byte comparison of all unrelated entries against the supplied JAR.
No in-game Minecraft launch was performed in this environment.

Rebuild: compile/run Patch56.java with ASM core/tree/analysis 9.8,
passing extracted Attachment.class and Attachment-patched.class.
Place the patched class alongside package56.py, then run
python3 package56.py INPUT.jar OUTPUT.jar.
