"""Package a tooltip-only patch on the user's 0.3.55 JAR."""
from pathlib import Path
import hashlib
import json
import sys
import zipfile

source = Path(sys.argv[1])
destination = Path(sys.argv[2])
root = Path(__file__).parent
class_name = 'com/mrcrayfish/guns/item/attachment/impl/Attachment.class'
lang_names = ['assets/cgm/lang/en_us.json', 'assets/cgm/lang/tr_tr.json']
new_prefix = 'META-INF/cgm-port-0.3.56/'
destination.parent.mkdir(parents=True, exist_ok=True)

with zipfile.ZipFile(source) as original:
    assert original.testzip() is None
    assert len(original.namelist()) == len(set(original.namelist()))
    assert not any(n.upper().endswith(('.SF', '.RSA', '.DSA')) for n in original.namelist())
    changed = {class_name: (root / 'Attachment-patched.class').read_bytes()}
    for name in lang_names:
        data = json.loads(original.read(name))
        assert data.pop('perk.cgm.silenced.positive') == 'Susturuculu'
        assert data.pop('perk.cgm.sound_radius.positive') == 'Atış sesi daha yakından duyulur'
        data['perk.cgm.scope_zoom.positive'] = 'Uzağı görme'
        data['perk.cgm.scope_zoom.entry'] = '+%s'
        assert data['perk.cgm.scope_zoom.entry'] % data['perk.cgm.scope_zoom.positive'] == '+Uzağı görme'
        changed[name] = (json.dumps(data, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    for name in ('META-INF/MANIFEST.MF', 'META-INF/mods.toml'):
        contents = original.read(name)
        assert contents.count(b'1.3.7-26.3-port-0.3.55') == 1
        changed[name] = contents.replace(b'1.3.7-26.3-port-0.3.55', b'1.3.7-26.3-port-0.3.56')
    notes = (
        'CGM 26.3 / Forge 66.0.2 / port 0.3.56\n'
        'Base: user-supplied 0.3.55 R-RELOAD JAR.\n\n'
        'All IScope attachment tooltips now include exactly +Uzağı görme.\n'
        'This covers the registered short_scope, medium_scope, and long_scope.\n'
        'The silenced and reduced sound-radius perk rows are no longer emitted.\n'
        'Scope information is part of the existing cached perk list.\n'
        'All original gameplay modifiers and other class files are unchanged.\n\n'
        'Validation: ASM 9.8 BasicVerifier on all seven methods of the patched\n'
        'Attachment class; ZIP CRC/duplicate checks; language JSON validation;\n'
        'byte comparison of all unrelated entries against the supplied JAR.\n'
        'No in-game Minecraft launch was performed in this environment.\n\n'
        'Rebuild: compile/run Patch56.java with ASM core/tree/analysis 9.8,\n'
        'passing extracted Attachment.class and Attachment-patched.class.\n'
        'Place the patched class alongside package56.py, then run\n'
        'python3 package56.py INPUT.jar OUTPUT.jar.\n'
    )
    added = {
        new_prefix + 'Patch56.java': (root / 'Patch56.java').read_bytes(),
        new_prefix + 'package56.py': Path(__file__).read_bytes(),
        new_prefix + 'README.txt': notes.encode('utf-8'),
    }
    with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
        output.comment = original.comment
        for entry in original.infolist():
            output.writestr(entry, changed.get(entry.filename, original.read(entry)))
        for name, contents in added.items():
            output.writestr(name, contents)

with zipfile.ZipFile(source) as original, zipfile.ZipFile(destination) as output:
    assert output.testzip() is None
    assert len(output.namelist()) == len(set(output.namelist()))
    assert set(output.namelist()) - set(original.namelist()) == set(added)
    assert set(original.namelist()) - set(output.namelist()) == set()
    actual = {n for n in original.namelist() if original.read(n) != output.read(n)}
    assert actual == set(changed), actual
    for name in output.namelist():
        if name.endswith('.json'):
            json.loads(output.read(name))
    unchanged_classes = sum(n.endswith('.class') and n not in changed for n in original.namelist())
    print('Validated: 3 scope types covered; exact +Uzağı görme text; 2 silencer rows removed.')
    print('Changed existing entries:', '\n'.join(sorted(actual)), sep='\n')
    print('Other class files byte-identical:', unchanged_classes)
    print('Output:', destination.resolve())
    print('Size:', destination.stat().st_size)
    print('SHA256:', hashlib.sha256(destination.read_bytes()).hexdigest())
