import java.nio.file.*;
import java.util.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.tree.analysis.*;

/** Changes attachment tooltip presentation only; retains all gun modifiers. */
public final class Patch56 implements Opcodes {
    private static final String OWNER = "com/mrcrayfish/guns/item/attachment/impl/Attachment";
    private static final String ATTACHMENT = "com/mrcrayfish/guns/item/attachment/IAttachment";
    private static final String SCOPE = "com/mrcrayfish/guns/item/attachment/IScope";
    private static final String COMPONENT = "net/minecraft/network/chat/Component";
    private static final String MUTABLE = "net/minecraft/network/chat/MutableComponent";
    private static final String FORMAT = "net/minecraft/ChatFormatting";
    private static final String HELPER_DESC = "(Ljava/util/List;L" + ATTACHMENT + ";)V";

    private static void require(boolean ok, String message) {
        if (!ok) throw new IllegalStateException(message);
    }

    private static AbstractInsnNode prior(AbstractInsnNode node) {
        do { node = node.getPrevious(); } while (node != null && node.getOpcode() < 0);
        return node;
    }

    private static AbstractInsnNode next(AbstractInsnNode node) {
        do { node = node.getNext(); } while (node != null && node.getOpcode() < 0);
        return node;
    }

    public static void main(String[] args) throws Exception {
        ClassReader reader = new ClassReader(Files.readAllBytes(Path.of(args[0])));
        ClassNode clazz = new ClassNode();
        reader.accept(clazz, 0);
        require(clazz.name.equals(OWNER), "Unexpected target class");
        MethodNode event = clazz.methods.stream()
            .filter(m -> m.name.equals("addInformationEvent"))
            .findFirst().orElseThrow();
        require(clazz.methods.stream().noneMatch(m -> m.name.equals("cgm56$addScopePerk")),
            "Patch already applied");

        Set<String> hidden = Set.of("perk.cgm.silenced.positive", "perk.cgm.sound_radius.positive");
        int removed = 0;
        for (AbstractInsnNode node : event.instructions.toArray()) {
            if (!(node instanceof LdcInsnNode literal) || !hidden.contains(literal.cst)) continue;
            AbstractInsnNode bool = prior(node);
            AbstractInsnNode list = prior(bool);
            AbstractInsnNode count = next(node);
            AbstractInsnNode array = next(count);
            AbstractInsnNode call = next(array);
            require(list instanceof VarInsnNode v && v.getOpcode() == ALOAD && v.var == 5,
                "Unexpected positive-perk list");
            require(bool.getOpcode() == ICONST_1 && count.getOpcode() == ICONST_0,
                "Unexpected tooltip arguments");
            require(array instanceof TypeInsnNode t && t.getOpcode() == ANEWARRAY
                    && t.desc.equals("java/lang/Object"), "Unexpected argument array");
            require(call instanceof MethodInsnNode m && m.getOpcode() == INVOKESTATIC
                    && m.owner.equals(OWNER) && m.name.equals("addPerk")
                    && m.desc.equals("(Ljava/util/List;ZLjava/lang/String;[Ljava/lang/Object;)V"),
                "Unexpected perk call");
            for (AbstractInsnNode part : new AbstractInsnNode[]{list, bool, node, count, array, call})
                event.instructions.remove(part);
            removed++;
        }
        require(removed == 2, "Expected exactly two removed tooltip lines");

        List<AbstractInsnNode> positiveListStores = new ArrayList<>();
        for (AbstractInsnNode node : event.instructions.toArray()) {
            if (node instanceof VarInsnNode v && v.getOpcode() == ASTORE && v.var == 5)
                positiveListStores.add(node);
        }
        require(positiveListStores.size() == 1, "Ambiguous positive-perk list initialization");
        InsnList addScope = new InsnList();
        addScope.add(new VarInsnNode(ALOAD, 5));
        addScope.add(new VarInsnNode(ALOAD, 2));
        addScope.add(new MethodInsnNode(INVOKESTATIC, OWNER, "cgm56$addScopePerk", HELPER_DESC, false));
        event.instructions.insert(positiveListStores.get(0), addScope);

        // Populate the normal cached positive-perk list for every IScope, including
        // scopes without any stat modifiers. The compact prefix renders exactly '+Uzağı görme'.
        MethodNode helper = new MethodNode(ACC_PRIVATE | ACC_STATIC, "cgm56$addScopePerk",
            HELPER_DESC, null, null);
        Label done = new Label();
        helper.visitCode();
        helper.visitVarInsn(ALOAD, 1);
        helper.visitTypeInsn(INSTANCEOF, SCOPE);
        helper.visitJumpInsn(IFEQ, done);
        helper.visitVarInsn(ALOAD, 0);
        helper.visitLdcInsn("perk.cgm.scope_zoom.entry");
        helper.visitInsn(ICONST_1);
        helper.visitTypeInsn(ANEWARRAY, "java/lang/Object");
        helper.visitInsn(DUP);
        helper.visitInsn(ICONST_0);
        helper.visitLdcInsn("perk.cgm.scope_zoom.positive");
        helper.visitMethodInsn(INVOKESTATIC, COMPONENT, "translatable",
            "(Ljava/lang/String;)L" + MUTABLE + ";", true);
        helper.visitFieldInsn(GETSTATIC, FORMAT, "WHITE", "L" + FORMAT + ";");
        helper.visitMethodInsn(INVOKEVIRTUAL, MUTABLE, "withStyle", "(L" + FORMAT + ";)L" + MUTABLE + ";", false);
        helper.visitInsn(AASTORE);
        helper.visitMethodInsn(INVOKESTATIC, COMPONENT, "translatable",
            "(Ljava/lang/String;[Ljava/lang/Object;)L" + MUTABLE + ";", true);
        helper.visitFieldInsn(GETSTATIC, FORMAT, "DARK_AQUA", "L" + FORMAT + ";");
        helper.visitMethodInsn(INVOKEVIRTUAL, MUTABLE, "withStyle", "(L" + FORMAT + ";)L" + MUTABLE + ";", false);
        helper.visitMethodInsn(INVOKEINTERFACE, "java/util/List", "add", "(Ljava/lang/Object;)Z", true);
        helper.visitInsn(POP);
        helper.visitLabel(done);
        helper.visitFrame(F_SAME, 0, null, 0, null);
        helper.visitInsn(RETURN);
        helper.visitMaxs(7, 2);
        helper.visitEnd();
        clazz.methods.add(helper);

        ClassWriter writer = new ClassWriter(reader, ClassWriter.COMPUTE_MAXS);
        clazz.accept(writer);
        byte[] patched = writer.toByteArray();
        ClassNode check = new ClassNode();
        new ClassReader(patched).accept(check, 0);
        int verified = 0;
        for (MethodNode method : check.methods) {
            if ((method.access & (ACC_ABSTRACT | ACC_NATIVE)) == 0) {
                new Analyzer<>(new BasicVerifier()).analyze(check.name, method);
                verified++;
            }
        }
        Files.write(Path.of(args[1]), patched);
        System.out.println("Removed 2 tooltip entries; added cached scope perk; ASM verified " + verified + " methods.");
    }
}
