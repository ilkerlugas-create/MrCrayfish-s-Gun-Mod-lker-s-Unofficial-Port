"""Restore the verified loading metadata lost in the 0.3.51 input JAR.

Usage: python3 repair_manifest.py CURRENT_JAR WORKING_038_JAR OUTPUT_JAR
The packaged runtime classes and assets are never recompiled or replaced.
"""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED, ZipInfo
import hashlib
import json
import sys

BASE_SHA256 = "da36afd7aee239df1de07f353716a365f4857fdfdb0dee74a4cdbbaf83e1b20a"
CONFIGS = ["cgm.mixins.json", "framework.common.mixins.json", "framework.forge.mixins.json"]
ROOT = "META-INF/cgm-port-0.3.52/"


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def attributes(raw):
    # Main section only; continuation lines are part of their preceding value.
    lines = raw.decode("utf-8").replace("\r\n", "\n").split("\n")
    logical = []
    for line in lines:
        if not line:
            break
        if line.startswith(" "):
            assert logical
            logical[-1] += line[1:]
        else:
            logical.append(line)
    return dict(line.split(": ", 1) for line in logical)


def manifest_bytes(values):
    result = []
    for key, value in values.items():
        line = f"{key}: {value}"
        assert line.isascii()
        while len(line) > 70:
            result.append(line[:70])
            line = " " + line[70:]
        result.append(line)
    return ("\r\n".join(result) + "\r\n\r\n").encode("utf-8")


def main():
    base, reference, output = map(Path, sys.argv[1:])
    assert output.resolve() not in {base.resolve(), reference.resolve()}
    assert sha256(base.read_bytes()) == BASE_SHA256, "Unexpected input JAR"
    output.parent.mkdir(parents=True, exist_ok=True)

    with ZipFile(base) as old, ZipFile(reference) as known:
        assert old.testzip() is None and known.testzip() is None
        before = attributes(old.read("META-INF/MANIFEST.MF"))
        assert "MixinConfigs" not in before, "Input no longer has this regression"
        restored = attributes(known.read("META-INF/MANIFEST.MF"))
        assert restored["MixinConfigs"].split(",") == CONFIGS
        assert restored["Implementation-Version"] == "1.3.7-26.3-port-0.3.38+framework-0.13.27"
        restored["Implementation-Version"] = "1.3.7-26.3-port-0.3.52+framework-0.13.27"
        verified_mixins = []
        for name in CONFIGS:
            assert old.read(name) == known.read(name), name
            config = json.loads(old.read(name))
            classes = config.get("mixins", []) + config.get("client", []) + config.get("server", [])
            if config.get("plugin"):
                classes += [config["plugin"]]
            for cls in classes:
                qualified = cls if cls.startswith(config["package"] + ".") else config["package"] + "." + cls
                path = qualified.replace(".", "/") + ".class"
                assert old.read(path) == known.read(path), path
                verified_mixins.append(path)
        for cls in ["AttachmentPreview", "WorkbenchPreview", "InventoryAttachments"]:
            path = "com/mrcrayfish/guns/port/" + cls + ".class"
            assert old.read(path) == known.read(path), path

        metadata = old.read("META-INF/mods.toml")
        assert metadata.count(b'1.3.7-26.3-port-0.3.51') == 1
        updates = {
            "META-INF/MANIFEST.MF": manifest_bytes(restored),
            "META-INF/mods.toml": metadata.replace(b'1.3.7-26.3-port-0.3.51', b'1.3.7-26.3-port-0.3.52'),
        }
        assert attributes(updates["META-INF/MANIFEST.MF"]) == restored
        readme = """CGM 26.3 / Forge 66.0.2 — 0.3.52

Z MENUSU VE EKLENTILI ENVANTER GORUNUMU

0.3.51 paketindeki META-INF/MANIFEST.MF dosyasında MixinConfigs kaydı yoktu.
Bu yüzden mevcut 3D önizleme ölçekleme/döndürme kodu ve silah ile eklentileri
birlikte çizen envanter kodu yüklenmiyordu. Önceki 0.3.38 paketinden doğrulanan
yükleme kayıtları ve paket bilgileri geri getirildi.

Silah, eklenti, animasyon, reload ve optimizasyon sınıflarının tamamı
0.3.51 ile birebir aynıdır. Silah ve eklenti modelleri de değiştirilmemiştir.

Kurulum: Oyunu kapatın. mods klasöründeki önceki CGM JAR dosyasını çıkarın ve
bu JAR dosyasını koyun. Aynı modun iki sürümünü birlikte bırakmayın.

Doğrulama: JAR bütünlüğü, manifest kayıtları, yapılandırmalar, sınıf yolları
ve kaynakların korunması kontrol edildi. Bu ortamda Minecraft çalıştırılmadı.
"""
        report = {
            "base_sha256": sha256(base.read_bytes()),
            "reference_sha256": sha256(reference.read_bytes()),
            "cause": "Missing MixinConfigs in the current JAR main manifest",
            "restored_mixin_configs": CONFIGS,
            "mixins_and_plugins_identical_to_038": verified_mixins,
            "changed_existing_entries": sorted(updates),
            "runtime_classes_modified": 0,
            "assets_and_data_modified": 0,
            "game_launched": False,
        }
        additions = {
            ROOT + "repair_manifest.py": Path(__file__).read_bytes(),
            ROOT + "validation.json": (json.dumps(report, indent=2) + "\n").encode(),
            "CGM-0.3.52-OKU.txt": readme.encode("utf-8"),
        }
        assert not set(additions).intersection(old.namelist())
        with ZipFile(output, "w", ZIP_DEFLATED, compresslevel=9) as new:
            for info in old.infolist():
                new.writestr(info, updates.get(info.filename, old.read(info.filename)))
            for name, data in additions.items():
                info = ZipInfo(name, (2026, 10, 13, 0, 0, 0))
                info.compress_type = ZIP_DEFLATED
                new.writestr(info, data)

    with ZipFile(base) as old, ZipFile(output) as new:
        assert new.testzip() is None
        assert len(new.namelist()) == len(set(new.namelist()))
        assert set(old.namelist()).issubset(new.namelist())
        changes = [n for n in old.namelist() if old.read(n) != new.read(n)]
        assert set(changes) == set(updates), changes
        classes = [n for n in old.namelist() if n.endswith(".class")]
        resources = [n for n in old.namelist() if n.startswith(("assets/", "data/")) and not n.endswith("/")]
        assert all(old.read(n) == new.read(n) for n in classes + resources)
        print(json.dumps({
            "output": str(output.resolve()), "sha256": sha256(output.read_bytes()),
            "bytes": output.stat().st_size, "changed_entries": changes,
            "preserved_runtime_classes": len(classes), "preserved_resource_files": len(resources),
            "restored_mixin_configs": CONFIGS, "game_launched": False,
        }, indent=2))


if __name__ == "__main__":
    main()
