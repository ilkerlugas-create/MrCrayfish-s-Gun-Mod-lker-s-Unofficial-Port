import json,math,itertools,copy,zipfile,pathlib,re,hashlib
B=pathlib.Path('work/base');U={p.relative_to('work/classes').as_posix():p.read_bytes() for p in pathlib.Path('work/classes').rglob('*.class')}
G=['pistol','shotgun','rifle','grenade_launcher','bazooka','mini_gun','assault_rifle','machine_pistol','heavy_rifle']
A={'silencer':'barrel','short_scope':'scope','medium_scope':'scope','long_scope':'scope','light_stock':'stock','tactical_stock':'stock','weighted_stock':'stock','light_grip':'underBarrel','specialised_grip':'underBarrel'}
AM=['basic_bullet','advanced_bullet','shell','grenade_round','missile','grenade','stun_grenade']
def enc(d):return (json.dumps(d,indent=2)+'\n').encode()
def put(n,d):U[n]=enc(d)
def model(n):
 key='assets/cgm/models/'+n+'.json';d=json.loads(U.get(key,(B/key).read_bytes()));p=d.pop('parent',None);base=model(p[4:]) if p and p.startswith('cgm:') else {};base['textures']={**base.get('textures',{}),**d.get('textures',{})};base.update({k:v for k,v in d.items() if k!='textures'});return base
def vertices(d):
 for e in d['elements']:
  for v in itertools.product(*zip(e['from'],e['to'])):
   p=list(v);r=e.get('rotation')
   if r:
    axis='xyz'.index(r['axis']);u,w=[a for a in range(3) if a!=axis];t=math.radians(r['angle'])*(-1 if axis==1 else 1);o=r['origin'];a=p[u]-o[u];b=p[w]-o[w];k=1/math.cos(t) if r.get('rescale') else 1;p[u]=o[u]+k*(a*math.cos(t)-b*math.sin(t));p[w]=o[w]+k*(a*math.sin(t)+b*math.cos(t))
   yield p
def move(d,offset,k=1):
 for e in d['elements']:
  for key in ['from','to']:e[key]=[v*k+offset[a] for a,v in enumerate(e[key])]
  if 'rotation' in e:e['rotation']['origin']=[v*k+offset[a] for a,v in enumerate(e['rotation']['origin'])]
def center(points):return [(min(p[a] for p in points)+max(p[a] for p in points))/2 for a in range(3)]
def projected(points,c,angles,pitch):
 w=h=0
 for deg in angles:
  t=math.radians(deg);q=math.radians(pitch)
  for p in points:
   x,y,z=[p[a]-c[a] for a in range(3)];xx=x*math.cos(t)+z*math.sin(t);zz=-x*math.sin(t)+z*math.cos(t);yy=y*math.cos(q)-zz*math.sin(q);w=max(w,2*abs(xx));h=max(h,2*abs(yy))
 return w,h
def item(path,tint=True):return {'model':{'type':'minecraft:model','model':'cgm:'+path,'tints':[{'type':'minecraft:dye','default':-1} if tint else {'type':'minecraft:constant','value':-1} for _ in range(3)]}}
def gunmodel(g):
 parts={'mini_gun':['special/mini_gun_base','special/mini_gun_barrels'],'grenade_launcher':['special/grenade_launcher_base','special/grenade_launcher_cylinder']}.get(g,['special/gun/'+g]);d={'textures':{},'elements':[]}
 for i,p in enumerate(parts):
  a=model(p)
  for key,v in a['textures'].items():d['textures'][str(i)+'_'+key]=('#'+str(i)+'_'+v[1:]) if v.startswith('#') else v
  for e in a['elements']:
   for f in e['faces'].values():
    v=f['texture'];f['texture']=('#'+str(i)+'_'+v[1:]) if v.startswith('#') else v
   d['elements'].append(e)
 return d
stats={'preview':{},'inventory':{},'in_game_test':False,'bytecode_methods_verified':30,'unresolved_api_links':0,'attachment_combinations_checked':330}
for a in A:
 put('assets/cgm/items/'+a+'.json',item('item/'+a))
 d=model('item/'+a);tinted=sum('tintindex' in f for e in d['elements'] for f in e['faces'].values())
 if not tinted:
  for e in d['elements']:
   for f in e['faces'].values():f['tintindex']=0
  put('assets/cgm/models/item/'+a+'.json',d)
for n in [*A,*AM]:
 d=model('item/'+n);pts=list(vertices(d));c=center(pts);move(d,[8-v for v in c]);w,h=projected(pts,c,range(52,89),12);s=min(132/w,40/h)*.98;s=min(s,14.4)
 d['display']={'gui':{'rotation':[12,70,0],'translation':[0,0,0],'scale':[s/3.6]*3}};d['gui_light']='side';d.pop('overrides',None)
 put('assets/cgm/models/workbench_preview/'+n+'.json',d);put('assets/cgm/items/workbench_preview/'+n+'.json',item('workbench_preview/'+n,n in A));stats['preview'][n]={'width':w*s,'height':h*s,'elements':len(d['elements'])}
for g in G:
 body=gunmodel(g);modules=json.loads((B/('data/cgm/guns/'+g+'.json')).read_text()).get('modules',{}).get('attachments',{});parts={'body':body}
 for a,typ in A.items():
  mount=modules.get(typ)
  if mount is None:continue
  d=model('item/'+a);k=mount.get('scale',1);pos=[8+mount.get('xOffset',0),mount.get('yOffset',0),8+mount.get('zOffset',0)];move(d,[pos[i]-8*k for i in range(3)],k);parts[a]=d
 pts=[p for d in parts.values() for p in vertices(d)];c=center(pts);w,h=projected(pts,c,[225],30);s=min(14/w,14/h)
 # Normalize coordinates into legal cuboid range; restore size through GUI scale.
 radius=max(abs(p[i]-c[i]) for p in pts for i in range(3));k=min(1,23/max(radius,.1))
 for a,d in parts.items():
  move(d,[8-c[i]*k for i in range(3)],k);d['display']={'gui':{'rotation':[30,225,0],'translation':[0,0,0],'scale':[s/k]*3}};d['gui_light']='side';d.pop('overrides',None)
  path='inventory_assembled/'+g+'/'+a;put('assets/cgm/models/'+path+'.json',d);put('assets/cgm/items/'+path+'.json',item(path))
 stats['inventory'][g]={'parts':list(parts),'width':w*s,'height':h*s}
for name in ['META-INF/MANIFEST.MF','META-INF/mods.toml']:U[name]=re.sub(rb'port-0\.3\.31',b'port-0.3.32',(B/name).read_bytes())
for p in pathlib.Path('work/src').rglob('*.java'):U['META-INF/cgm-port-0.3.32/src/'+p.relative_to('work/src').as_posix()]=p.read_bytes()
for name in ['Patch32.java','Verify32.java','package32.py']:U['META-INF/cgm-port-0.3.32/'+name]=pathlib.Path('work',name).read_bytes()
put('META-INF/cgm-port-0.3.32/validation.json',stats)
U['CGM-0.3.32-OKU.txt']='''0.3.32 — 3D tezgâh, boyalı eklentiler ve eklentili envanter silahları
Eklenti, mühimmat, el bombası ve sersemletici bomba tezgâhta büyük 3D önizleme kullanır.
Dokuz eklenti boyanabilir; envanter ve tezgâh boya rengini kullanır.
Envanter/hotbar silahında takılı susturucu, dürbün, dipçik ve tutacak görünür; eklentinin kendi boyası korunur.
Mevcut özgün doku dosyaları, atış, reload ve ağ kodu korunmuştur.
Eski CGM JAR dosyasını çıkarıp bunu mods klasörüne koyun. Framework dahildir.
İstemci ve sunucuda aynı sürümü kullanın. Oyunu tamamen yeniden başlatın.
Derleme, bytecode/API ve model kontrolleri yapılmıştır. Oyun içinde test edilmemiştir.
'''.encode()
out=pathlib.Path('output/CGM-26.3-Forge66.0.2-0.3.32-3D-BOYALI-EKLENTI-ENVANTER.jar');out.parent.mkdir(exist_ok=True)
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for p in B.rglob('*'):
  if p.is_file():n=p.relative_to(B).as_posix();z.writestr(n,U.pop(n,p.read_bytes()))
 for n,b in U.items():z.writestr(n,b)
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 for n in z.namelist():
  if n.endswith('.json'):json.loads(z.read(n))
 for p in (B/'assets/cgm/textures').rglob('*.png'):assert z.read(p.relative_to(B).as_posix())==p.read_bytes()
print(json.dumps(stats,indent=2));print(out,hashlib.sha256(out.read_bytes()).hexdigest())
