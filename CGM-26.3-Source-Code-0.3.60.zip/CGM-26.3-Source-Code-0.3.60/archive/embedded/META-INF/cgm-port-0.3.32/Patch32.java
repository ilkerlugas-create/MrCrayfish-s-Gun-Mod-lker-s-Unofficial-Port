import java.nio.file.*;import java.util.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;
public class Patch32 implements Opcodes{
 public static void main(String[] args)throws Exception{
 int changes=0;
 for(String suffix:List.of("item/BarrelItem","item/ScopeItem","item/StockItem","item/UnderBarrelItem","mixin/client/WorkbenchPreviewMixin")){
 String name="com/mrcrayfish/guns/"+suffix;ClassNode c=new ClassNode();new ClassReader(Files.readAllBytes(Path.of("work/base/"+name+".class"))).accept(c,0);
 for(MethodNode m:c.methods){
 if(m.name.equals("canColor")){
 m.instructions.clear();m.tryCatchBlocks.clear();if(m.localVariables!=null)m.localVariables.clear();m.instructions.add(new InsnNode(ICONST_1));m.instructions.add(new InsnNode(IRETURN));changes++;
 }
 if(m.name.equals("cgmPreview"))for(var n:m.instructions.toArray())if(n instanceof MethodInsnNode a&&a.name.equals("animate")){
 InsnList l=new InsnList();l.add(new VarInsnNode(ALOAD,0));l.add(new TypeInsnNode(CHECKCAST,"net/minecraft/client/renderer/item/ItemModelResolver"));l.add(new VarInsnNode(ALOAD,1));l.add(new VarInsnNode(ALOAD,2));l.add(new VarInsnNode(ALOAD,4));l.add(new VarInsnNode(ALOAD,5));l.add(new VarInsnNode(ILOAD,6));l.add(new MethodInsnNode(INVOKESTATIC,"com/mrcrayfish/guns/port/InventoryAttachments","update","(Lnet/minecraft/client/renderer/item/ItemModelResolver;Lnet/minecraft/client/renderer/item/ItemStackRenderState;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/ItemOwner;I)V",false));m.instructions.insertBefore(n.getPrevious().getPrevious(),l);changes++;
 }
 }
 ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);Path out=Path.of("work/classes/"+name+".class");Files.createDirectories(out.getParent());Files.write(out,w.toByteArray());
 }
 if(changes!=5)throw new AssertionError(changes);System.out.println("PASS: 4 dye gates and GUI-only attachment hook");
 }
}
