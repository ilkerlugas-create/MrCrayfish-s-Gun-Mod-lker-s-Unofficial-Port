package com.mrcrayfish.guns.port;
import com.mrcrayfish.guns.common.Gun;
import com.mrcrayfish.guns.item.GunItem;
import com.mrcrayfish.guns.item.attachment.IAttachment;
import net.minecraft.client.renderer.item.ItemModelResolver;
import net.minecraft.client.renderer.item.ItemStackRenderState;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.ItemOwner;
import java.util.Set;
public final class InventoryAttachments {
 private static final Set<String> GUNS=Set.of("pistol","shotgun","rifle","grenade_launcher","bazooka","mini_gun","assault_rifle","machine_pistol","heavy_rifle");
 private static final Set<String> PARTS=Set.of("silencer","short_scope","medium_scope","long_scope","light_stock","tactical_stock","weighted_stock","light_grip","specialised_grip");
 public static void update(ItemModelResolver resolver,ItemStackRenderState state,ItemStack stack,Level world,ItemOwner owner,int seed){
  if(!(stack.getItem() instanceof GunItem gunItem))return;
  Identifier id=BuiltInRegistries.ITEM.getKey(stack.getItem());
  if(!id.getNamespace().equals("cgm")||!GUNS.contains(id.getPath()))return;
  Identifier chosen=stack.get(DataComponents.ITEM_MODEL);
  if(chosen!=null&&!chosen.equals(id))return;
  Gun gun=gunItem.getModifiedGun(stack);
  ItemStack body=stack.copy();DyeBridge.sync(body);
  body.set(DataComponents.ITEM_MODEL,Identifier.parse("cgm:inventory_assembled/"+id.getPath()+"/body"));
  resolver.updateForTopItem(state,body,ItemDisplayContext.GUI,world,owner,seed);
  for(IAttachment.Type type:IAttachment.Type.values()){
   if(!gun.canAttachType(type))continue;
   ItemStack part=Gun.getAttachment(type,stack);
   if(part.isEmpty())continue;
   Identifier pid=BuiltInRegistries.ITEM.getKey(part.getItem());
   if(!pid.getNamespace().equals("cgm")||!PARTS.contains(pid.getPath()))continue;
   part=part.copy();DyeBridge.sync(part);
   part.set(DataComponents.ITEM_MODEL,Identifier.parse("cgm:inventory_assembled/"+id.getPath()+"/"+pid.getPath()));
   resolver.appendItemLayers(state,part,ItemDisplayContext.GUI,world,owner,seed);
  }
 }
}
