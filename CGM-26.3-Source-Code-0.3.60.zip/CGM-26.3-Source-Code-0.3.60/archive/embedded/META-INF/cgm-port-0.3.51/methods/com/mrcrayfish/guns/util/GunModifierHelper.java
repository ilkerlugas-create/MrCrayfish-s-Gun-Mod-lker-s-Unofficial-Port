package com.mrcrayfish.guns.util;

import com.mrcrayfish.guns.interfaces.IGunModifier;
import com.mrcrayfish.guns.item.attachment.IAttachment;
import com.mrcrayfish.guns.port.StackReadCache;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/** Method donor only; Patch51 merges getModifiers into the original class. */
public class GunModifierHelper {
    private static final IGunModifier[] EMPTY = new IGunModifier[0];
    private static IGunModifier[] getModifiers(ItemStack weapon, IAttachment.Type type) {
        Item item = StackReadCache.attachmentItem(type, weapon);
        return item instanceof IAttachment<?> attachment ? attachment.getProperties().getModifiers() : EMPTY;
    }
}
