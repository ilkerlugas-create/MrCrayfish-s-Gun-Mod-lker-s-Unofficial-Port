package com.mrcrayfish.guns.common;

import com.mrcrayfish.guns.GunMod;
import com.mrcrayfish.guns.debug.Debug;
import com.mrcrayfish.guns.item.ScopeItem;
import com.mrcrayfish.guns.item.attachment.IAttachment;
import com.mrcrayfish.guns.item.attachment.impl.Scope;
import com.mrcrayfish.guns.port.StackReadCache;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/** Method donor only; the rest of the original Gun class is retained. */
public class Gun {
    public static Scope getScope(ItemStack weapon) {
        Item item = StackReadCache.attachmentItem(IAttachment.Type.SCOPE, weapon);
        if (item instanceof ScopeItem scope) {
            return GunMod.isDebugging() ? Debug.getScope(scope) : scope.getProperties();
        }
        return null;
    }
}
