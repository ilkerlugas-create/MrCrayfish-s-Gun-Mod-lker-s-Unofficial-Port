package com.mrcrayfish.guns.client.handler;

import com.mrcrayfish.guns.client.BulletTrail;
import java.util.Iterator;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraftforge.event.TickEvent;

/** Method donor only; rendering and event annotations are retained by the patcher. */
public class BulletTrailRenderingHandler {
    private Map<Integer, BulletTrail> bullets;
    public void onClientTick(TickEvent.ClientTickEvent.Post event) {
        if (Minecraft.getInstance().level != null) {
            Iterator<BulletTrail> iterator = bullets.values().iterator();
            while (iterator.hasNext()) {
                BulletTrail trail = iterator.next();
                trail.tick();
                if (trail.isDead()) iterator.remove();
            }
        } else if (!bullets.isEmpty()) {
            bullets.clear();
        }
    }
}
