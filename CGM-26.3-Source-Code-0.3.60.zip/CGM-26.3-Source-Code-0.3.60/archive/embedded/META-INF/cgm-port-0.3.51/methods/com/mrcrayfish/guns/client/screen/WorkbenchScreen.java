package com.mrcrayfish.guns.client.screen;

import java.util.List;
import net.minecraft.core.NonNullList;

/** Only getMaterials is merged. The real nested MaterialItem is not replaced. */
public class WorkbenchScreen {
    private List<MaterialItem> materials;
    private CheckBox checkBoxMaterials;
    private List<MaterialItem> getMaterials() {
        NonNullList<MaterialItem> result = NonNullList.withSize(6, MaterialItem.EMPTY);
        boolean remaining = checkBoxMaterials.isToggled();
        int index = 0;
        for (MaterialItem material : materials) {
            if (remaining ? !material.isEnabled() : material != MaterialItem.EMPTY) {
                result.set(index++, material);
                if (index == result.size()) break;
            }
        }
        return result;
    }

    public static class MaterialItem {
        public static MaterialItem EMPTY;
        public boolean isEnabled() { throw new AssertionError("compile-time signature only"); }
    }
}
