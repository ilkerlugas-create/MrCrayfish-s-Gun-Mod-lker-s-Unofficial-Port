import java.nio.file.*;
import java.util.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;

/** Narrow bytecode changes against the exact supplied 0.3.50 JAR. */
public class Patch51 implements Opcodes {
    static final Path BASE = Path.of("original"), COMPILED = Path.of("work51/classes"),
            DONORS = Path.of("work51/method-classes"), OUT = Path.of("work51/patched");
    static final String P = "com/mrcrayfish/guns/", CACHE = P + "port/StackReadCache",
            TYPE = P + "item/attachment/IAttachment$Type",
            STACK = "net/minecraft/world/item/ItemStack", ITEM = "net/minecraft/world/item/Item";
    static final List<String> CHANGES = new ArrayList<>();
    static final Map<String, ClassNode> EDITED = new LinkedHashMap<>();

    static ClassNode read(Path root, String name) throws Exception {
        ClassNode c = new ClassNode();
        new ClassReader(Files.readAllBytes(root.resolve(name + ".class"))).accept(c, 0);
        return c;
    }
    static ClassNode edit(String name) throws Exception {
        ClassNode c = EDITED.get(name);
        if (c == null) EDITED.put(name, c = read(BASE, name));
        return c;
    }
    static MethodNode method(ClassNode c, String name) {
        List<MethodNode> found = c.methods.stream().filter(m -> m.name.equals(name)).toList();
        if (found.size() != 1) throw new AssertionError(c.name + "." + name + " matches " + found.size());
        return found.getFirst();
    }
    static void changed(ClassNode c, MethodNode m) { CHANGES.add(c.name + " " + m.name + " " + m.desc); }
    static void merge(String owner, String name) throws Exception {
        ClassNode c = edit(owner);
        MethodNode old = method(c, name), replacement = method(read(DONORS, owner), name);
        if (!old.desc.equals(replacement.desc)) throw new AssertionError("descriptor " + name);
        // Keep Forge subscriptions, nullability and original access metadata.
        old.instructions = replacement.instructions;
        old.tryCatchBlocks = replacement.tryCatchBlocks;
        old.localVariables = replacement.localVariables;
        old.maxStack = replacement.maxStack;
        old.maxLocals = replacement.maxLocals;
        old.visibleLocalVariableAnnotations = replacement.visibleLocalVariableAnnotations;
        old.invisibleLocalVariableAnnotations = replacement.invisibleLocalVariableAnnotations;
        changed(c, old);
    }
    static AbstractInsnNode nextCode(AbstractInsnNode n) {
        do { n = n.getNext(); } while (n != null && n.getOpcode() < 0);
        return n;
    }
    static void check(boolean ok, String message) { if (!ok) throw new AssertionError(message); }

    public static void main(String[] args) throws Exception {
        merge(P + "util/GunModifierHelper", "getModifiers");
        merge(P + "common/Gun", "getScope");
        merge(P + "client/handler/BulletTrailRenderingHandler", "onClientTick");
        merge(P + "client/screen/WorkbenchScreen", "getMaterials");

        ClassNode modifiers = edit(P + "util/GunModifierHelper");
        modifiers.fields.add(new FieldNode(ACC_PRIVATE | ACC_STATIC | ACC_FINAL,
                "CGM_TYPES", "[L" + TYPE + ";", null, null));
        MethodNode clinit = method(modifiers, "<clinit>");
        InsnList init = new InsnList();
        init.add(new MethodInsnNode(INVOKESTATIC, TYPE, "values", "()[L" + TYPE + ";", false));
        init.add(new FieldInsnNode(PUTSTATIC, modifiers.name, "CGM_TYPES", "[L" + TYPE + ";"));
        clinit.instructions.insert(init);
        changed(modifiers, clinit);
        int enums = 0, itemOnly = 0;
        for (MethodNode m : modifiers.methods) {
            if (m.name.equals("<clinit>")) continue;
            boolean modified = false;
            for (AbstractInsnNode n : m.instructions.toArray()) {
                if (!(n instanceof MethodInsnNode call)) continue;
                if (call.owner.equals(TYPE) && call.name.equals("values")) {
                    m.instructions.set(call, new FieldInsnNode(GETSTATIC, modifiers.name, "CGM_TYPES", "[L" + TYPE + ";"));
                    enums++; modified = true;
                } else if (call.owner.equals(P + "common/Gun") && call.name.equals("getAttachment")) {
                    AbstractInsnNode following = nextCode(call);
                    check(following instanceof MethodInsnNode get && get.owner.equals(STACK) && get.name.equals("getItem"), "Expected item-only silencer path");
                    call.owner = CACHE; call.name = "attachmentItem";
                    call.desc = "(L" + TYPE + ";L" + STACK + ";)L" + ITEM + ";";
                    m.instructions.remove(following);
                    itemOnly++; modified = true;
                }
            }
            if (modified) changed(modifiers, m);
        }
        check(enums == 38, "Expected 38 enum clone sites; got " + enums);
        check(itemOnly == 3, "Expected 3 silencer item-only paths; got " + itemOnly);

        // Every selected copy result is consumed read-only. Mutation continues
        // through StackData.update/set; do not change their ownership semantics.
        Map<String, Set<String>> readonly = new LinkedHashMap<>();
        readonly.put("port/WeaponInstance", Set.of("selected"));
        readonly.put("port/ReloadRules", Set.of("canReload"));
        readonly.put("common/ReloadTracker", Set.of("isWeaponFull", "increaseAmmo"));
        readonly.put("client/handler/ReloadHandler", Set.of("onClientTick", "setReloading"));
        readonly.put("common/network/ServerPlayHandler", Set.of("handleShoot", "handleUnload"));
        int reads = 0;
        for (var target : readonly.entrySet()) {
            ClassNode c = edit(P + target.getKey());
            for (String name : target.getValue()) {
                MethodNode m = method(c, name);
                int count = 0;
                for (var n : m.instructions) if (n instanceof MethodInsnNode call
                        && call.owner.equals(P + "util/StackData") && call.name.equals("copy")) {
                    call.owner = CACHE; call.name = "read"; count++;
                }
                check(count > 0, "Missing audited read: " + c.name + "." + name);
                reads += count; changed(c, m);
            }
        }
        check(reads == 9, "Expected 9 read-only sites; got " + reads);

        // Own invisible tracer has no trail geometry and usually no item model.
        // Tick/particles still execute; bypass only its empty rendering work.
        ClassNode renderer = edit(P + "client/handler/BulletTrailRenderingHandler");
        MethodNode submit = method(renderer, "submitBulletTrail");
        LabelNode draw = new LabelNode();
        InsnList early = new InsnList();
        early.add(new VarInsnNode(ALOAD, 1));
        early.add(new MethodInsnNode(INVOKEVIRTUAL, P + "client/BulletTrail", "isTrailVisible", "()Z", false));
        early.add(new JumpInsnNode(IFNE, draw));
        early.add(new VarInsnNode(ALOAD, 1));
        early.add(new MethodInsnNode(INVOKEVIRTUAL, P + "client/BulletTrail", "getItem", "()L" + STACK + ";", false));
        early.add(new MethodInsnNode(INVOKEVIRTUAL, STACK, "isEmpty", "()Z", false));
        early.add(new JumpInsnNode(IFEQ, draw));
        early.add(new InsnNode(RETURN));
        early.add(draw);
        early.add(new FrameNode(F_SAME, 0, null, 0, null));
        submit.instructions.insert(early); changed(renderer, submit);

        ClassNode trail = edit(P + "client/BulletTrail");
        MethodNode tick = method(trail, "tick");
        int roots = 0, limits = 0;
        for (var n : tick.instructions.toArray()) {
            if (n instanceof MethodInsnNode call && call.owner.equals("java/lang/Math") && call.name.equals("sqrt")) {
                tick.instructions.remove(n); roots++;
            } else if (n instanceof LdcInsnNode ldc && Double.valueOf(256.0).equals(ldc.cst)) {
                ldc.cst = 256.0 * 256.0; limits++;
            }
        }
        check(roots == 1 && limits == 1, "Expected single distance sqrt and cutoff");
        changed(trail, tick);

        // Reuse the existing noncapturing factory from render() so Rotations is
        // constructed only when the entity is first added, not every tick.
        ClassNode mini = edit(P + "client/render/gun/model/MiniGunModel");
        InvokeDynamicInsnNode factory = null;
        for (var n : method(mini, "render").instructions) if (n instanceof InvokeDynamicInsnNode indy) {
            check(factory == null, "Ambiguous minigun factory"); factory = indy;
        }
        check(factory != null, "Missing minigun factory");
        tick = method(mini, "tick");
        int allocations = 0, puts = 0;
        for (var n : tick.instructions.toArray()) {
            if (n instanceof TypeInsnNode allocation && allocation.getOpcode() == NEW
                    && allocation.desc.equals(mini.name + "$Rotations")) {
                AbstractInsnNode dup = nextCode(n), ctor = nextCode(dup);
                check(dup.getOpcode() == DUP && ctor instanceof MethodInsnNode c && c.name.equals("<init>"), "Unexpected allocation");
                tick.instructions.set(n, new InvokeDynamicInsnNode(factory.name, factory.desc, factory.bsm, factory.bsmArgs));
                tick.instructions.remove(dup); tick.instructions.remove(ctor); allocations++;
            } else if (n instanceof MethodInsnNode call && call.owner.equals("java/util/WeakHashMap") && call.name.equals("putIfAbsent")) {
                call.name = "computeIfAbsent";
                call.desc = "(Ljava/lang/Object;Ljava/util/function/Function;)Ljava/lang/Object;"; puts++;
            }
        }
        check(allocations == 1 && puts == 1, "Minigun allocation pattern");
        changed(mini, tick);

        // Only these complete production helpers are installed. Donor skeletons
        // and test fixtures never enter the runtime class tree.
        for (String name : List.of(CACHE, CACHE + "$Cache")) {
            ClassNode c = read(COMPILED, name); EDITED.put(name, c);
            for (MethodNode m : c.methods) changed(c, m);
        }
        for (ClassNode c : EDITED.values()) {
            ClassWriter writer = new ClassWriter(ClassWriter.COMPUTE_MAXS);
            c.accept(writer);
            Path path = OUT.resolve(c.name + ".class"); Files.createDirectories(path.getParent());
            Files.write(path, writer.toByteArray());
        }
        Files.write(Path.of("work51/changed-methods.txt"), new TreeSet<>(CHANGES));
        System.out.println("Patched " + EDITED.size() + " classes; enum clone sites=" + enums
                + ", item-only silencer reads=" + itemOnly + ", read-only NBT sites=" + reads);
    }
}
