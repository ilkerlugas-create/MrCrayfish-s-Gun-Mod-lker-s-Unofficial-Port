from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED,ZipInfo
import sys,json,hashlib

ROOT=Path(__file__).resolve().parent.parent
base=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'upload/CGM-26.3-Forge66.0.2-0.3.50-MINIGUN-3S-TOTAL-FAST-LOOP.jar'
out=ROOT/'output';out.mkdir(exist_ok=True)
target=out/'CGM-26.3-Forge66.0.2-0.3.51-OPTIMIZED.jar'
patched={p.relative_to(ROOT/'work51/patched').as_posix():p.read_bytes() for p in (ROOT/'work51/patched').rglob('*.class')}
assert len(patched)==13
prefix='META-INF/cgm-port-0.3.51/'
meta={}
for name in ['src','methods','tests']:
    for p in (ROOT/'work51'/name).rglob('*'):
        if p.is_file() and p.suffix in ['.java','.py','.json','.txt']:
            meta[prefix+p.relative_to(ROOT/'work51').as_posix()]=p.read_bytes()
for name in ['Patch51.java','Verify51.java','build.py','package.py','changed-methods.txt','linkage.txt','README.md','OPTIMIZASYON-RAPORU-0.3.51.md']:
    p=ROOT/'work51'/name
    if p.is_file():meta[prefix+name]=p.read_bytes()
with ZipFile(base) as old,ZipFile(target,'w',ZIP_DEFLATED,compresslevel=9) as new:
    assert old.testzip() is None
    assert all(name in old.namelist() for name in patched)
    for info in old.infolist():
        data=patched.get(info.filename,old.read(info.filename))
        if info.filename=='META-INF/mods.toml':
            original=data
            data=data.replace(b'version="1.3.7-26.3-port-0.3.47"',b'version="1.3.7-26.3-port-0.3.51"')
            assert data!=original
        new.writestr(info,data)
    for name,data in sorted(meta.items()):
        info=ZipInfo(name,(2026,10,13,0,0,0));info.compress_type=ZIP_DEFLATED
        new.writestr(info,data)
with ZipFile(base) as a,ZipFile(target) as b:
    assert b.testzip() is None
    assert len(b.namelist())==len(set(b.namelist()))
    removed=set(a.namelist())-set(b.namelist());assert not removed
    changed=[n for n in a.namelist() if a.read(n)!=b.read(n)]
    assert set(changed)==set(patched)|{'META-INF/mods.toml'}
    resources=[n for n in a.namelist() if n.startswith(('assets/','data/')) and not n.endswith('/')]
    assert all(a.read(n)==b.read(n) for n in resources)
    guns={n:json.loads(b.read(n)) for n in b.namelist() if n.startswith('data/cgm/guns/') and n.endswith('.json')}
    assert guns['data/cgm/guns/mini_gun.json']['general']['maxAmmo']==124
    assert guns['data/cgm/guns/mini_gun.json']['general']['reloadAmount']==64
    assert guns['data/cgm/guns/grenade_launcher.json']['general']['maxAmmo']==6
report={'base_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),
        'changed_entries':changed,'removed_entries':list(removed),'preserved_resource_files':len(resources),
        'modified_runtime_classes':len(patched),'game_launched':False,'fps_measured':False}
(out/'validation-0.3.51.json').write_text(json.dumps(report,indent=2))
print(json.dumps({k:v for k,v in report.items() if k!='changed_entries'},indent=2))
print(target)
