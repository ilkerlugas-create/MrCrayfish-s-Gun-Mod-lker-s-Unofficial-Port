package com.mrcrayfish.guns.port;

import java.util.ArrayDeque;
import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.CustomData;
import com.mrcrayfish.guns.item.attachment.IAttachment;
import net.minecraftforge.server.ServerLifecycleHooks;

/** Bounded, thread-local snapshots for audited read-only paths. */
public final class StackReadCache {
    private static final int LIMIT = 256;
    private static final ThreadLocal<Cache> LOCAL = ThreadLocal.withInitial(Cache::new);

    private static final class Cache {
        final IdentityHashMap<CustomData, CompoundTag> tags = new IdentityHashMap<>();
        final ArrayDeque<CustomData> tagOrder = new ArrayDeque<>();
        final IdentityHashMap<CompoundTag, ItemStack> items = new IdentityHashMap<>();
        final ArrayDeque<CompoundTag> itemOrder = new ArrayDeque<>();
        // Identity remains the fast path. Content lookup is only needed for a
        // new snapshot (e.g. an AmmoCount change with identical attachments).
        final LinkedHashMap<CompoundTag, ItemStack> decodedItems = new LinkedHashMap<>(32, 0.75f, true);
        Object registryContext;
    }

    /** Borrowed snapshot: callers must not mutate it or its child tags. */
    public static CompoundTag read(ItemStack stack) {
        CustomData data = stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY);
        Cache cache = LOCAL.get();
        CompoundTag tag = cache.tags.get(data);
        if (tag == null) {
            tag = data.copyTag();
            if (cache.tags.size() >= LIMIT) cache.tags.remove(cache.tagOrder.removeFirst());
            cache.tags.put(data, tag);
            cache.tagOrder.addLast(data);
        }
        return tag;
    }

    /** Existing public API retains defensive ownership of the returned stack. */
    public static ItemStack readItem(CompoundTag tag) {
        return borrowedItem(tag).copy();
    }

    /** Properties belong to the Item; no temporary ItemStack is required. */
    public static Item readItemType(CompoundTag tag) {
        return borrowedItem(tag).getItem();
    }

    public static Item attachmentItem(IAttachment.Type type, ItemStack weapon) {
        CompoundTag root = read(weapon);
        if (!root.contains("Attachments")) return Items.AIR;
        CompoundTag attachments = root.getCompoundOrEmpty("Attachments");
        if (!attachments.contains(type.getTagKey())) return Items.AIR;
        return readItemType(attachments.getCompoundOrEmpty(type.getTagKey()));
    }

    /** Input is an immutable child of a read() snapshot. Never expose this value. */
    private static ItemStack borrowedItem(CompoundTag tag) {
        if (tag == null || tag.isEmpty()) return ItemStack.EMPTY;
        Cache cache = LOCAL.get();
        var server = ServerLifecycleHooks.getCurrentServer();
        Object context = server == null ? null : server.registryAccess();
        if (cache.registryContext != context) {
            cache.items.clear();
            cache.itemOrder.clear();
            cache.decodedItems.clear();
            cache.registryContext = context;
        }
        ItemStack item = cache.items.get(tag);
        if (item == null) {
            item = cache.decodedItems.get(tag);
            if (item == null) {
                item = AttachmentData.read(tag);
                // Registry initialization may make a failed decode succeed later.
                if (item.isEmpty()) return ItemStack.EMPTY;
                if (cache.decodedItems.size() >= LIMIT) cache.decodedItems.pollFirstEntry();
                cache.decodedItems.put(tag, item);
            }
            if (cache.items.size() >= LIMIT) cache.items.remove(cache.itemOrder.removeFirst());
            cache.items.put(tag, item);
            cache.itemOrder.addLast(tag);
        }
        return item;
    }
}
