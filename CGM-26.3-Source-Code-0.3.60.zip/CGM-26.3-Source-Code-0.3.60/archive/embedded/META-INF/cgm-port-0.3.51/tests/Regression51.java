import java.lang.reflect.*;
import java.util.*;
import net.minecraft.nbt.*;
import net.minecraft.world.item.*;
import net.minecraft.world.item.component.*;
import net.minecraft.core.component.*;
import net.minecraftforge.server.ServerLifecycleHooks;
import com.mrcrayfish.guns.port.*;
import com.mrcrayfish.guns.util.GunModifierHelper;
import com.mrcrayfish.guns.interfaces.IGunModifier;
import com.mrcrayfish.guns.item.attachment.*;
import com.mrcrayfish.guns.item.attachment.impl.Attachment;
import com.mrcrayfish.guns.init.ModItems;

public class Regression51 {
    static int checks;
    static final Item WEAPON=new Item("weapon");
    static void check(boolean b,String msg){checks++;if(!b)throw new AssertionError(msg);}
    static Object cache()throws Exception{Field f=StackReadCache.class.getDeclaredField("LOCAL");f.setAccessible(true);return ((ThreadLocal<?>)f.get(null)).get();}
    static void reset()throws Exception{Field f=StackReadCache.class.getDeclaredField("LOCAL");f.setAccessible(true);((ThreadLocal<?>)f.get(null)).remove();}
    static int size(String name)throws Exception{Object c=cache();Field f=c.getClass().getDeclaredField(name);f.setAccessible(true);return ((Map<?,?>)f.get(c)).size();}
    static ItemStack weapon(int ammo,CompoundTag parts){CompoundTag root=new CompoundTag();root.putInt("AmmoCount",ammo);root.put("Attachments",parts);ItemStack stack=new ItemStack(WEAPON,1);stack.set(DataComponents.CUSTOM_DATA,new CustomData(root));return stack;}
    static CompoundTag part(String id){CompoundTag t=new CompoundTag();t.putString("id",id);return t;}
    static class AttachmentItem extends Item implements IAttachment<Attachment> {
        final Attachment properties;
        AttachmentItem(String id,IGunModifier... mods){super(id);properties=new Attachment(mods);}
        public Attachment getProperties(){return properties;}
    }
    static IGunModifier modifier(int i){return new IGunModifier(){
        public int modifyProjectileLife(int v){return v*2+i;}
        public double modifyProjectileGravity(double v){return v*(1+i*.1);}
        public double additionalProjectileGravity(){return i*.003;}
        public float modifyProjectileSpread(float v){return v*.8f+i*.1f;}
        public double modifyProjectileSpeed(double v){return v*1.2+i;}
        public float modifyFireSoundVolume(float v){return v*.8f;}
        public double modifyMuzzleFlashSize(double v){return v*1.1+i;}
        public double modifyMuzzleFlashScale(double v){return v*.9+i;}
        public float kickModifier(){return .7f+i*.02f;}
        public float recoilModifier(){return .8f;}
        public double modifyFireSoundRadius(double v){return v/(i+1);}
        public float additionalDamage(){return i*.25f;}
        public float modifyProjectileDamage(float v){return v*1.1f+i;}
        public double modifyAimDownSightSpeed(double v){return v*1.1+i;}
        public int modifyFireRate(int v){return v+i;}
        public float criticalChance(){return .02f;}
    };}
    @SuppressWarnings("removal") static List<String> values(ItemStack s){return List.of(
        ""+GunModifierHelper.getModifiedProjectileLife(s,20),""+GunModifierHelper.getModifiedProjectileGravity(s,-.04),
        ""+GunModifierHelper.getModifiedSpread(s,5),""+GunModifierHelper.getModifiedProjectileSpeed(s,4),
        ""+GunModifierHelper.getFireSoundVolume(s),""+GunModifierHelper.getMuzzleFlashSize(s,1),
        ""+GunModifierHelper.getMuzzleFlashScale(s,1),""+GunModifierHelper.getKickReduction(s),
        ""+GunModifierHelper.getRecoilModifier(s),""+GunModifierHelper.isSilencedFire(s),
        ""+GunModifierHelper.getModifiedFireSoundRadius(s,80),""+GunModifierHelper.getAdditionalDamage(s),
        ""+GunModifierHelper.getModifiedProjectileDamage(s,7),""+GunModifierHelper.getModifiedDamage(s,null,7),
        ""+GunModifierHelper.getModifiedAimDownSightSpeed(s,1),""+GunModifierHelper.getModifiedRate(s,5),
        ""+GunModifierHelper.getCriticalChance(s));}
    public static void main(String[] args)throws Exception{
        boolean optimized=args[0].equals("optimized");
        for(int i=1;i<=4;i++)AttachmentData.REGISTRY.put("part"+i,new AttachmentItem("part"+i,modifier(i),modifier(i+1)));
        AttachmentData.REGISTRY.put("silencer",ModItems.SILENCER.get());
        CompoundTag parts=new CompoundTag();parts.put("Barrel",part("part1"));
        ItemStack s=weapon(124,parts);CustomData.copies=0;
        CompoundTag before=StackReadCache.read(s);
        for(int i=0;i<10000;i++)check(StackReadCache.read(s)==before,"stable snapshot");
        check(CustomData.copies==1,"one copy for stable data");
        s.set(DataComponents.CUSTOM_DATA,weapon(123,parts).get(DataComponents.CUSTOM_DATA));
        check(StackReadCache.read(s).getIntOr("AmmoCount",-1)==123,"ammo invalidation");
        check(before.getIntOr("AmmoCount",-1)==124,"previous snapshot immutable");
        s.remove(DataComponents.CUSTOM_DATA);check(StackReadCache.read(s).isEmpty(),"component removal");

        reset();AttachmentData.decodes=0;
        for(int ammo=124;ammo>0;ammo--){ItemStack w=weapon(ammo,parts);CompoundTag child=StackReadCache.read(w).getCompoundOrEmpty("Attachments").getCompoundOrEmpty("Barrel");
            ItemStack decoded=StackReadCache.readItem(child);check(decoded.getItem()==AttachmentData.REGISTRY.get("part1"),"attachment preserved across ammo updates");}
        int ammoDecodes=AttachmentData.decodes;
        check(ammoDecodes==(optimized?1:124),"expected decode reuse");
        CompoundTag a=part("part1");ItemStack first=StackReadCache.readItem(a);first.setCount(0);first.remove(DataComponents.CUSTOM_DATA);
        ItemStack second=StackReadCache.readItem(a);check(second.getCount()==1,"defensive count");check(second.get(DataComponents.CUSTOM_DATA)!=null,"defensive components");
        CompoundTag changed=part("part2");check(StackReadCache.readItem(changed).getItem()==AttachmentData.REGISTRY.get("part2"),"attachment replacement immediate");
        CompoundTag recolored=part("part1");recolored.putInt("Color",0x123456);
        check(StackReadCache.readItem(recolored).get(DataComponents.CUSTOM_DATA).copyTag().getIntOr("Color",0)==0x123456,"paint change immediate");
        if(optimized){ItemStack.copies=0;for(int i=0;i<1000;i++)check(StackReadCache.readItemType(a)==AttachmentData.REGISTRY.get("part1"),"item-only property");check(ItemStack.copies==0,"no ItemStack copies for item-only path");}

        int invalidations=0;
        ServerLifecycleHooks.server=new net.minecraft.server.MinecraftServer();int count=AttachmentData.decodes;StackReadCache.readItem(a);check(AttachmentData.decodes==count+1,"server context change");invalidations++;
        ServerLifecycleHooks.server.registries=new net.minecraft.core.RegistryAccess.Frozen(){};count=AttachmentData.decodes;StackReadCache.readItem(a);check(AttachmentData.decodes==count+1,"registry context change");invalidations++;
        ServerLifecycleHooks.server=null;count=AttachmentData.decodes;StackReadCache.readItem(a);check(AttachmentData.decodes==count+1,"disconnect context change");invalidations++;
        CompoundTag delayed=part("part4");delayed.putInt("unique",918);AttachmentData.ready=false;check(StackReadCache.readItem(delayed).isEmpty(),"codec unavailable");AttachmentData.ready=true;check(!StackReadCache.readItem(delayed).isEmpty(),"codec retry");
        Object parent=cache();Object[] child=new Object[1];Thread thread=new Thread(()->{try{child[0]=cache();}catch(Exception e){throw new RuntimeException(e);}});thread.start();thread.join();check(child[0]!=null&&child[0]!=parent,"thread isolation");
        for(int i=0;i<1000;i++){StackReadCache.read(weapon(i,parts));CompoundTag p=part("part1");p.putInt("Color",i);StackReadCache.readItem(p);}
        check(size("tags")<=256&&size("items")<=256,"bounded identity caches");if(optimized)check(size("decodedItems")<=256,"bounded content cache");
        check(StackReadCache.readItem(null).isEmpty()&&StackReadCache.readItem(new CompoundTag()).isEmpty(),"empty input");

        // Real original and patched GunModifierHelper methods, compared across
        // all 16 attachment combinations, both with and without silencer fallback.
        List<String> outputs=new ArrayList<>();reset();ItemStack.copies=0;
        for(int mask=0;mask<16;mask++)for(boolean silenced:new boolean[]{false,true}){
            CompoundTag p=new CompoundTag();IAttachment.Type[] types=IAttachment.Type.values();
            for(int i=0;i<4;i++)if((mask&(1<<i))!=0)p.put(types[i].getTagKey(),part("part"+(i+1)));
            if(silenced)p.put("Barrel",part("silencer"));
            outputs.addAll(values(weapon(15,p)));
        }
        int modifierCopies=ItemStack.copies;
        System.out.println("PASS "+args[0]+": "+checks+" cache checks; 544 modifier outputs; JVM -Xverify:all.");
        System.out.println("{\"mode\":\""+args[0]+"\",\"checks\":"+checks+",\"attachment_decodes\":"+ammoDecodes+",\"modifier_stack_copies\":"+modifierCopies+",\"invalidations\":"+invalidations+",\"modifier_outputs\":[\""+String.join("\",\"",outputs)+"\"]}");
    }
}
