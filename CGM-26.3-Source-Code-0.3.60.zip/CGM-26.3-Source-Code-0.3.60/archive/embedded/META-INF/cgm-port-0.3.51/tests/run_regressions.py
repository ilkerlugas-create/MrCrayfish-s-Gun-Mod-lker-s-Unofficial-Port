"""Runs the shipped bytecode in isolated engine fixtures, never bundled as runtime classes.
Not a Minecraft client/FPS test. Requires Java 25 and the work51 patched output.
"""
from pathlib import Path
import os, subprocess, json, shutil

JDK = Path(os.environ['CGM_JAVA_HOME']) if 'CGM_JAVA_HOME' in os.environ else Path(shutil.which('java')).resolve().parent.parent
ROOT = Path('work51/tests/fixtures')
OUT = Path('work51/tests/classes')
BASE = Path('original')
P = 'com/mrcrayfish/guns/'
fixtures = {
'net/minecraft/nbt/CompoundTag': '''import java.util.*;
public class CompoundTag {
 public final Map<String,Object> data=new HashMap<>();
 public boolean isEmpty(){return data.isEmpty();} public boolean contains(String k){return data.containsKey(k);}
 public void putInt(String k,int v){data.put(k,v);} public int getIntOr(String k,int v){return data.get(k) instanceof Integer n?n:v;}
 public void putString(String k,String v){data.put(k,v);} public String getStringOr(String k,String v){return data.get(k) instanceof String n?n:v;}
 public void put(String k,CompoundTag v){data.put(k,v);} public void remove(String k){data.remove(k);}
 public CompoundTag copy(){CompoundTag t=new CompoundTag();data.forEach((k,v)->t.data.put(k,v instanceof CompoundTag c?c.copy():v));return t;}
 public CompoundTag getCompoundOrEmpty(String k){return data.get(k) instanceof CompoundTag t?t:new CompoundTag();}
 public int hashCode(){return data.hashCode();}public boolean equals(Object v){return v instanceof CompoundTag t&&data.equals(t.data);}
}''',
'net/minecraft/core/component/DataComponentType': 'public class DataComponentType<T>{}',
'net/minecraft/core/component/DataComponents': '''import net.minecraft.world.item.component.CustomData;
public class DataComponents {public static final DataComponentType<CustomData> CUSTOM_DATA=new DataComponentType<>();}''',
'net/minecraft/world/item/component/CustomData': '''import net.minecraft.nbt.CompoundTag;
public class CustomData {public static final CustomData EMPTY=new CustomData(new CompoundTag());public static int copies;private final CompoundTag tag;
public CustomData(CompoundTag t){tag=t.copy();}public CompoundTag copyTag(){copies++;return tag.copy();}}''',
'net/minecraft/world/item/Item': 'public class Item {public final String id;public Item(String id){this.id=id;}}',
'net/minecraft/world/item/Items': 'public class Items {public static final Item AIR=new Item("air");}',
'net/minecraft/world/item/ItemStack': '''import java.util.*;import net.minecraft.core.component.*;
public class ItemStack {
 public static final ItemStack EMPTY=new ItemStack(Items.AIR,0);public static int copies;public final Map<DataComponentType<?>,Object> data=new HashMap<>();
 private int count;private final Item item;public ItemStack(Item i,int n){item=i;count=n;}public boolean isEmpty(){return count<=0||item==Items.AIR;}
 public Item getItem(){return isEmpty()?Items.AIR:item;}public int getCount(){return count;}public void setCount(int n){count=n;}
 public ItemStack copy(){if(isEmpty())return EMPTY;copies++;ItemStack s=new ItemStack(item,count);s.data.putAll(data);return s;}
 @SuppressWarnings("unchecked")public <T>T getOrDefault(DataComponentType<T> t,T d){return (T)data.getOrDefault(t,d);}
 @SuppressWarnings("unchecked")public <T>T get(DataComponentType<T> t){return (T)data.get(t);}
 @SuppressWarnings("unchecked")public <T>T set(DataComponentType<T> t,T v){return (T)data.put(t,v);}
 @SuppressWarnings("unchecked")public <T>T remove(DataComponentType<T> t){return (T)data.remove(t);}
}''',
'net/minecraft/core/RegistryAccess': 'public interface RegistryAccess {interface Frozen extends RegistryAccess {}}',
'net/minecraft/server/MinecraftServer': 'public class MinecraftServer {public net.minecraft.core.RegistryAccess.Frozen registries=new net.minecraft.core.RegistryAccess.Frozen(){};public net.minecraft.core.RegistryAccess.Frozen registryAccess(){return registries;}}',
'net/minecraftforge/server/ServerLifecycleHooks': 'public class ServerLifecycleHooks {public static net.minecraft.server.MinecraftServer server;public static net.minecraft.server.MinecraftServer getCurrentServer(){return server;}}',
'net/minecraft/util/Mth': '''public class Mth {public static int clamp(int v,int a,int b){return Math.max(a,Math.min(v,b));}public static float clamp(float v,float a,float b){return Math.max(a,Math.min(v,b));}public static double clamp(double v,double a,double b){return Math.max(a,Math.min(v,b));}}''',
'net/minecraftforge/registries/RegistryObject': 'public class RegistryObject<T>{private final T value;public RegistryObject(T t){value=t;}public T get(){return value;}}',
P+'item/attachment/impl/Attachment': '''import com.mrcrayfish.guns.interfaces.IGunModifier;public class Attachment {private final IGunModifier[] modifiers;public Attachment(IGunModifier... m){modifiers=m;}public IGunModifier[] getModifiers(){return modifiers;}}''',
P+'item/attachment/IAttachment': '''import com.mrcrayfish.guns.item.attachment.impl.Attachment;public interface IAttachment<T extends Attachment>{T getProperties();
enum Type {SCOPE("Scope"),BARREL("Barrel"),STOCK("Stock"),UNDER_BARREL("Under_Barrel");private final String key;Type(String k){key=k;}public String getTagKey(){return key;}}}''',
P+'init/ModItems': '''import net.minecraft.world.item.Item;import net.minecraftforge.registries.RegistryObject;public class ModItems {public static RegistryObject<Item> SILENCER=new RegistryObject<>(new Item("silencer"));}''',
P+'util/GunEnchantmentHelper': 'public class GunEnchantmentHelper {public static float getPuncturingChance(net.minecraft.world.item.ItemStack s){return 0.15f;}}',
P+'common/Gun': '''import com.mrcrayfish.guns.port.StackReadCache;import com.mrcrayfish.guns.item.attachment.IAttachment;import net.minecraft.world.item.*;import net.minecraft.nbt.*;
public class Gun {public static ItemStack getAttachment(IAttachment.Type t,ItemStack s){CompoundTag root=StackReadCache.read(s);if(!root.contains("Attachments"))return ItemStack.EMPTY;CompoundTag parts=root.getCompoundOrEmpty("Attachments");return parts.contains(t.getTagKey())?StackReadCache.readItem(parts.getCompoundOrEmpty(t.getTagKey())):ItemStack.EMPTY;}}''',
P+'port/AttachmentData': '''import java.util.*;import net.minecraft.nbt.*;import net.minecraft.world.item.*;import net.minecraft.world.item.component.*;import net.minecraft.core.component.*;
public class AttachmentData {public static int decodes;public static boolean ready=true;public static final Map<String,Item> REGISTRY=new HashMap<>();
public static ItemStack read(CompoundTag t){decodes++;if(!ready)return ItemStack.EMPTY;Item item=REGISTRY.get(t.getStringOr("id",""));if(item==null)return ItemStack.EMPTY;ItemStack s=new ItemStack(item,t.getIntOr("count",1));s.set(DataComponents.CUSTOM_DATA,new CustomData(t));return s;}}'''
}
for name, body in fixtures.items():
    path=ROOT/(name+'.java');path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text('package '+name.rsplit('/',1)[0].replace('/','.')+';\n'+body)
cp=os.pathsep.join(['work51/patched','original'])
test=Path('work51/tests/Regression51.java')
OUT.mkdir(parents=True,exist_ok=True)
subprocess.run([str(JDK/'bin/javac'),'-proc:none','--release','25','-cp',cp,'-d',str(OUT),*map(str,ROOT.rglob('*.java')),str(test)],check=True)
results=[]
for mode, production in [('baseline','original'),('optimized',os.pathsep.join(['work51/patched','original']))]:
    r=subprocess.run([str(JDK/'bin/java'),'-Xverify:all','-cp',str(OUT)+os.pathsep+production,'Regression51',mode],capture_output=True,text=True)
    print(r.stdout+r.stderr);r.check_returncode()
    Path(f'work51/tests/{mode}.txt').write_text(r.stdout)
    results.append(json.loads(r.stdout.strip().splitlines()[-1]))
assert results[0]['modifier_outputs']==results[1]['modifier_outputs'], 'Modifier behavior changed'
assert results[0]['attachment_decodes']==124 and results[1]['attachment_decodes']==1
assert results[0]['modifier_stack_copies']>0 and results[1]['modifier_stack_copies']==0
assert results[0]['invalidations']==results[1]['invalidations']
Path('work51/tests/results.json').write_text(json.dumps(results,indent=2))
print('PASS: baseline/optimized modifier outputs identical; ammo-update decodes 124 -> 1; modifier stack copies eliminated.')
