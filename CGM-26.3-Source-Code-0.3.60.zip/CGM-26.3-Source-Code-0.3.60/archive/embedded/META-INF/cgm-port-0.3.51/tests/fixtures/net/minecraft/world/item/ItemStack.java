package net.minecraft.world.item;
import java.util.*;import net.minecraft.core.component.*;
public class ItemStack {
 public static final ItemStack EMPTY=new ItemStack(Items.AIR,0);public static int copies;public final Map<DataComponentType<?>,Object> data=new HashMap<>();
 private int count;private final Item item;public ItemStack(Item i,int n){item=i;count=n;}public boolean isEmpty(){return count<=0||item==Items.AIR;}
 public Item getItem(){return isEmpty()?Items.AIR:item;}public int getCount(){return count;}public void setCount(int n){count=n;}
 public ItemStack copy(){if(isEmpty())return EMPTY;copies++;ItemStack s=new ItemStack(item,count);s.data.putAll(data);return s;}
 @SuppressWarnings("unchecked")public <T>T getOrDefault(DataComponentType<T> t,T d){return (T)data.getOrDefault(t,d);}
 @SuppressWarnings("unchecked")public <T>T get(DataComponentType<T> t){return (T)data.get(t);}
 @SuppressWarnings("unchecked")public <T>T set(DataComponentType<T> t,T v){return (T)data.put(t,v);}
 @SuppressWarnings("unchecked")public <T>T remove(DataComponentType<T> t){return (T)data.remove(t);}
}