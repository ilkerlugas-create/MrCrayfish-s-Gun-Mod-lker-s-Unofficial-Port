package com.mrcrayfish.guns.item.attachment;
import com.mrcrayfish.guns.item.attachment.impl.Attachment;public interface IAttachment<T extends Attachment>{T getProperties();
enum Type {SCOPE("Scope"),BARREL("Barrel"),STOCK("Stock"),UNDER_BARREL("Under_Barrel");private final String key;Type(String k){key=k;}public String getTagKey(){return key;}}}