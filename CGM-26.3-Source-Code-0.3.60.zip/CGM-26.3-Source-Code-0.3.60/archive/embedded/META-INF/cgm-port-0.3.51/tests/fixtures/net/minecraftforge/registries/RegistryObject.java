package net.minecraftforge.registries;
public class RegistryObject<T>{private final T value;public RegistryObject(T t){value=t;}public T get(){return value;}}