package com.mrcrayfish.guns.util;
public class GunEnchantmentHelper {public static float getPuncturingChance(net.minecraft.world.item.ItemStack s){return 0.15f;}}