package net.minecraft.world.item.component;
import net.minecraft.nbt.CompoundTag;
public class CustomData {public static final CustomData EMPTY=new CustomData(new CompoundTag());public static int copies;private final CompoundTag tag;
public CustomData(CompoundTag t){tag=t.copy();}public CompoundTag copyTag(){copies++;return tag.copy();}}