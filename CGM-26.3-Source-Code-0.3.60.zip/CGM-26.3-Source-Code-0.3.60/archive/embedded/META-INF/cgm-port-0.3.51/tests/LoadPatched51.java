import java.nio.file.*;
public class LoadPatched51 {
    public static void main(String[] args) throws Exception {
        int count=0;
        try(var paths=Files.walk(Path.of("work51/patched"))){
            for(Path p:paths.filter(p->p.toString().endsWith(".class")).sorted().toList()){
                String name=Path.of("work51/patched").relativize(p).toString().replace('/','.').replace('\\','.').replace(".class","");
                Class<?> c=Class.forName(name,false,LoadPatched51.class.getClassLoader());
                c.getDeclaredMethods();c.getDeclaredConstructors();
                count++;
                System.out.println("Verified class load: "+name);
            }
        }
        System.out.println("PASS: "+count+" classes load and verify against real Minecraft 26.3 / Forge 66.0.2 APIs (no game launch).");
    }
}
