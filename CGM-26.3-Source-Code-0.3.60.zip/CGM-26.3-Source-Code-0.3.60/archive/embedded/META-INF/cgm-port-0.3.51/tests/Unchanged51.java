import java.nio.file.*;
import java.util.*;
import java.io.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.util.*;
public class Unchanged51 {
    static ClassNode read(Path p)throws Exception{ClassNode c=new ClassNode();new ClassReader(Files.readAllBytes(p)).accept(c,0);return c;}
    static String code(MethodNode m){Textifier t=new Textifier();m.accept(new TraceMethodVisitor(t));StringWriter s=new StringWriter();t.print(new PrintWriter(s));return s.toString();}
    public static void main(String[] args)throws Exception{
        Set<String> allowed=new HashSet<>(Files.readAllLines(Path.of("work51/changed-methods.txt")));
        int same=0,different=0;
        try(var paths=Files.walk(Path.of("work51/patched"))){
            for(Path p:paths.filter(p->p.toString().endsWith(".class")).toList()){
                ClassNode a=read(Path.of("original").resolve(Path.of("work51/patched").relativize(p))),b=read(p);
                for(MethodNode old:a.methods){
                    MethodNode updated=b.methods.stream().filter(m->m.name.equals(old.name)&&m.desc.equals(old.desc)).findFirst().orElseThrow();
                    if(code(old).equals(code(updated))){same++;continue;}
                    if(!allowed.contains(b.name+" "+old.name+" "+old.desc))throw new AssertionError("Unintended change "+b.name+"."+old.name);
                    different++;
                }
            }
        }
        System.out.println("PASS: "+same+" untouched methods remain instruction-identical inside patched classes; "+different+" intentional existing method changes.");
    }
}
