# CGM 26.3 / Forge 66.0.2 — Optimization patch workspace 0.3.51

This workspace continues the supplied `0.3.50-MINIGUN-3S-TOTAL-FAST-LOOP.jar`.
It is a reproducible **binary patch workspace**, not a replacement for the full
upstream Gradle source tree. All original runtime classes/resources are kept;
13 classes receive narrow changes. Framework is unchanged.

`base/` contains the original input; `output/` contains the patched JAR and
verification manifest. `work51/src/` contains complete replacement cache helpers.
`work51/methods/` contains method donors: only named method bodies are merged into
the original classes. Donor skeletons and test fixtures are never installed in the
runtime class tree. `Patch51.java` asserts the exact input patterns before writing.

Read `OPTIMIZASYON-RAPORU-0.3.51.md` for findings, evidence, scope and limitations.

## Rebuild

Use Python 3.10+ and Java 25. Set `CGM_JAVA_HOME` to your JDK 25 directory.
Put the **matching** Minecraft 26.3 client JAR, Forge 26.3-66.0.2 universal JAR,
eventbus 7.0.1, ASM 9.9.1 (core/tree/analysis/util) and their normal compile/runtime
dependencies in `deps/`, or specify their paths in `CGM_DEPENDENCIES` separated
by your OS path separator. The dependencies are not redistributed in this archive.

From this workspace's root run:

```sh
python work51/build.py
```

The script extracts the included input JAR, compiles the helpers against the real
APIs, merges only selected methods, verifies links and JVM class loading, runs
the isolated baseline/optimized regression tests, then packages the result.
For Windows, use Java 25 on PATH and supply the dependencies via the environment
variable; the test harness also uses the platform classpath separator.

## Validation scope

- Compilation: actual Minecraft 26.3 and Forge 66.0.2 APIs, JDK 25.
- JVM `-Xverify:all`: all 13 modified classes loaded, without initializing a game.
- ASM method verification and member resolution: 41 methods, zero unresolved links.
- Exact instruction comparison: 116 other methods within edited classes unchanged.
- Isolated engine fixtures execute the original and new production bytecode:
  cache invalidation, defensive ownership, context changes, failure retry,
  cache bounds, thread isolation and 544 matching modifier outputs.
- ZIP integrity and byte comparison: all original asset/data resources preserved.

These checks do not constitute a Forge game launch, server/client integration test
or FPS measurement. Actual frame-time improvements depend on the scene and system.
