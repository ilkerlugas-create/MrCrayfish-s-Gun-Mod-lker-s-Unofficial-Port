# CGM 0.3.51 — Tespit edilen ve giderilen optimizasyon sorunları

Temel dosya: `CGM-26.3-Forge66.0.2-0.3.50-MINIGUN-3S-TOTAL-FAST-LOOP.jar`.
Hedef: Minecraft 26.3, Forge 66.0.2, Java 25.

**Altı alanda gereksiz işlem ve geçici nesne üretimi azaltıldı.** Değişiklikler
gönderilen JAR üzerinde yapıldı; yeni sürüm `0.3.51-OPTIMIZED`.

| Tespit | Yapılan düzeltme | Etkilenen durum |
|---|---|---|
| Mermi sayısı değişince silahın veri kopyası yenileniyor; değişmeyen eklentiler de tekrar çözümleniyordu. Önbellek yalnızca nesne kimliğine bakıyordu. | Hızlı kimlik önbelleği korundu; yeni veri kopyalarında aynı içerikteki eklentiyi bulabilen, en fazla 256 kayıt tutan ikinci bir önbellek eklendi. | Özellikle minigun ve diğer seri atış yapan silahlar. |
| Hasar, geri tepme, nişan ve susturucu hesapları yalnızca eklentinin türünü gerektirdiği hâlde geçici `ItemStack` kopyaları oluşturuyordu. Eklenti türleri dizisi de döngülerde tekrar kopyalanıyordu. | Salt tür/özellik okumaları için kopya gerektirmeyen yol eklendi. `GunModifierHelper` içindeki 38 `values()` çağrı noktası, tek sefer oluşturulan diziye yönlendirildi. Dürbün özellikleri de gereksiz eşya kopyası olmadan okunuyor. | Silah tutma, nişan, ateş ve susturucu hesapları. |
| Ateş/reload kontrollerinde ve seçili silahın envanterdeki kopyalarını kontrol ederken salt okuma için derin NBT kopyaları çıkarılıyordu. | Denetlenen 9 çağrı noktası mevcut, sınırlandırılmış salt okuma önbelleğine geçirildi. Yazma işlemleri ayrı ve güvenli kaldı. | Her ateşleme ve reload sırasında istemci/sunucu işlem yükü. |
| Oyuncunun kendi görünmeyen mermi izi, çizilecek eşya modeli de yokken matris ve mesafe hesaplarına giriyordu. İzler her tick iki kez dolaşılıyordu; menzil kontrolünde karekök alınıyordu. | Çizilecek içerik yoksa çizim hazırlığı atlanıyor. İzleri güncelleme ve ölü izleri kaldırma tek dolaşımda yapılıyor. 256 blok sınırı mesafenin karesiyle kontrol ediliyor. Parçacık üretimi ve görünür izler korunuyor. | Hızlı ve yoğun ateş sırasında istemci tarafı yük. |
| Minigun namlu dönüşü için `putIfAbsent(..., new Rotations())` her tick yeni nesne oluşturuyordu; kayıt zaten varsa nesne çöpe gidiyordu. | Dönüş durumu yalnızca oyuncu için ilk ihtiyaç olduğunda oluşturuluyor. | Minigun taşıyan oyuncuların her tick güncellenmesi. |
| Silah tezgâhı her karede malzemeleri filtrelemek için stream ve ara liste oluşturuyordu. | Doğrudan sonuç listesini dolduran, altı görünür satıra ulaşınca duran döngü kullanılıyor. | Tezgâh ekranı açıkken geçici nesne üretimi. |

**Kontrol sonuçları**

- Gerçek Minecraft 26.3 / Forge 66.0.2 API dosyalarına karşı Java 25 derlemesi tamamlandı.
- Değişen 13 sınıf JVM `-Xverify:all` ile yükleme/doğrulama kontrolünden geçti.
- Değişen/eklenen 41 yöntemin bytecode ve üye bağlantıları kontrol edildi; çözülemeyen bağlantı yok.
- Bu sınıflardaki diğer 116 yöntemin talimatları eski sürümle birebir aynı kaldı.
- Yalıtılmış testlerde 124 mermi güncellemesi için aynı eklentinin çözümlenmesi **124 → 1** oldu.
- 32 farklı eklenti/susturucu düzeninde 17 hesaplamanın, toplam **544 sonucun** eski ve yeni sürümde aynı olduğu doğrulandı. Bu testte geçici eklenti `ItemStack` kopyaları **1.440 → 0** oldu.
- Mermi ve eklenti değişiklikleri, boya değişimi, dönen eşya kopyasının bağımsızlığı, kayıt sistemi değişimi, başarısız çözümlemenin tekrar denenmesi, iş parçacığı ayrımı ve önbellek sınırları test edildi.
- Paketleme denetimi; orijinal kayıtların silinmediğini, yalnızca 13 çalışma zamanı sınıfı ve mod sürüm alanının değiştiğini, 592 `assets/` ve `data/` dosyasının birebir korunduğunu doğruladı.

**Korunan ayarlar:** Minigun 124 kapasite / 64'lük doldurma / toplam yaklaşık 3 saniye
ve hızlı doldurma animasyonu; bombaatar 6 kapasite; mevcut hasarlar, susturucu sesleri,
texture/model dosyaları, FPS/F5 tutuş kodu, Z tuşu ve Framework. Eski JAR'ın mod
bilgilerinde kalan `0.3.47` sürüm alanı da yeni paket için `0.3.51` olarak düzeltildi.

Bu testler oyunun açıldığı veya oyun içi performans ölçüldüğü anlamına gelmez.
Burada Forge istemcisiyle bir dünya açılmadı; FPS/kare süresi ölçümü yapılmadı.
Sayılar belirtilen yalıtılmış testlerin işlem/kopya sayılarıdır. Gerçek kazanım,
donanıma, dünyaya, oyuncu sayısına ve diğer modlara bağlıdır.

Kurulum: Eski CGM JAR'ını `mods` klasöründen çıkarıp `0.3.51-OPTIMIZED.jar` dosyasını
koy. Çok oyunculuda bu sürümü istemci ve sunucuda birlikte kullan.
Oyun içi son kontrol için minigunla sürekli ateş/reload, eklenti takıp çıkarma,
tezgâh ve FPS/F5 görünümünü dene.

Çalışma arşivi, giriş ve çıkış JAR'larını, değişiklik kaynaklarını, yeniden üretme
betiklerini ve doğrulama sonuçlarını içerir. Bu bir binary yama çalışma alanıdır;
tam upstream Gradle kaynak ağacı olarak sunulmamaktadır.
