"""Rebuild the 0.3.51 binary patch workspace; Python 3.10+, Java 25 required.
Run from the workspace root: python work51/build.py
Set CGM_JAVA_HOME to a JDK 25 and CGM_DEPENDENCIES to a path-separated list
of Minecraft 26.3, Forge 66.0.2, ASM 9.9.1 and matching dependency JARs.
Alternatively put the dependency JARs in deps/. No dependencies are downloaded.
"""
from pathlib import Path
import os, shutil, subprocess, zipfile, hashlib

ROOT=Path(__file__).resolve().parent.parent
os.chdir(ROOT)
jdk=Path(os.environ['CGM_JAVA_HOME']) if 'CGM_JAVA_HOME' in os.environ else Path(shutil.which('java')).resolve().parent.parent
java=str(jdk/'bin/java');javac=str(jdk/'bin/javac')
base=ROOT/'base/CGM-26.3-Forge66.0.2-0.3.50-MINIGUN-3S-TOTAL-FAST-LOOP.jar'
deps=[Path(x) for x in os.environ.get('CGM_DEPENDENCIES','').split(os.pathsep) if x] or list((ROOT/'deps').glob('*.jar'))
if not deps: raise SystemExit('Set CGM_DEPENDENCIES or add the matching Minecraft/Forge/ASM dependency JARs to deps/. See README.md.')
if not base.is_file(): raise SystemExit('Missing original 0.3.50 base JAR.')
if hashlib.sha256(base.read_bytes()).hexdigest()!='afcb61770faee0bdaf59fd689b2389cbcc057dd9e9a530e8cfa4adb1369c88d5':
    raise SystemExit('Input JAR differs from the audited 0.3.50 build; refusing to apply a patch to a different baseline.')
with zipfile.ZipFile(base) as z:z.extractall('original')
cp=os.pathsep.join(map(str,[base,*deps]));Path('work51/classpath.txt').write_text(cp)
def run(*args):subprocess.run(list(args),check=True)
for name in ['classes','method-classes','patched','tools']:
    p=Path('work51')/name
    if p.exists():shutil.rmtree(p)
    p.mkdir()
run(javac,'-proc:none','--release','25','-cp',cp,'-d','work51/classes',*map(str,Path('work51/src').rglob('*.java')))
# Compile donors separately: they deliberately define only the methods to merge.
for src in Path('work51/methods').rglob('*.java'):
    run(javac,'-proc:none','--release','25','-cp','work51/classes'+os.pathsep+cp,'-d','work51/method-classes',str(src))
run(javac,'-proc:none','--release','25','-cp',cp,'-d','work51/tools','work51/Patch51.java','work51/Verify51.java','work51/tests/LoadPatched51.java','work51/tests/Unchanged51.java')
run(java,'-cp','work51/tools'+os.pathsep+cp,'Patch51')
run(java,'-cp','work51/tools'+os.pathsep+cp,'Verify51',*map(str,[base,*deps]))
for name in ['LoadPatched51','Unchanged51']:
    run(java,'-Xverify:all','-cp',os.pathsep.join(['work51/tools','work51/patched',cp]),name)
run(__import__('sys').executable,'work51/tests/run_regressions.py')
run(__import__('sys').executable,'work51/package.py',str(base))
