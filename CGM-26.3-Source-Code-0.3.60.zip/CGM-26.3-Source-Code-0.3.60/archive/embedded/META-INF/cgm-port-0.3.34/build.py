from pathlib import Path
root=Path('work34/src')
files={
'com/mrcrayfish/guns/client/ClientHandler.java':'''package com.mrcrayfish.guns.client;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen;
import net.minecraftforge.client.event.InputEvent;
import com.mrcrayfish.guns.item.GunItem;
import com.mrcrayfish.guns.network.PacketHandler;
import com.mrcrayfish.guns.network.message.C2SMessageAttachments;
public class ClientHandler {
 public static void onKeyPressed(InputEvent.Key event) {
  Minecraft mc=Minecraft.getInstance();
  if(mc.player==null || event.getAction()!=1) return;
  Screen screen=mc.gui.screen();
  if(screen!=null && !(screen instanceof InventoryScreen)
    && !(screen instanceof CreativeModeInventoryScreen creative && creative.isInventoryOpen())) return;
  if(!(mc.player.getMainHandItem().getItem() instanceof GunItem)) return;
  if(KeyBinds.KEY_ATTACHMENTS.matches(event.getInfo()))
   PacketHandler.getPlayChannel().sendToServer(new C2SMessageAttachments());
 }
}''',
'net/minecraft/client/Minecraft.java':'''package net.minecraft.client; public class Minecraft {public static Minecraft INSTANCE=new Minecraft(); public net.minecraft.client.player.LocalPlayer player; public net.minecraft.client.gui.Gui gui=new net.minecraft.client.gui.Gui(); public static Minecraft getInstance(){return INSTANCE;}}''',
'net/minecraft/client/gui/Gui.java':'''package net.minecraft.client.gui; public class Gui { public net.minecraft.client.gui.screens.Screen value; public net.minecraft.client.gui.screens.Screen screen(){return value;} }''',
'net/minecraft/client/gui/screens/Screen.java':'package net.minecraft.client.gui.screens; public class Screen {}',
'net/minecraft/client/gui/screens/inventory/InventoryScreen.java':'package net.minecraft.client.gui.screens.inventory; public class InventoryScreen extends net.minecraft.client.gui.screens.Screen {}',
'net/minecraft/client/gui/screens/inventory/CreativeModeInventoryScreen.java':'package net.minecraft.client.gui.screens.inventory; public class CreativeModeInventoryScreen extends net.minecraft.client.gui.screens.Screen { public boolean inventory; public boolean isInventoryOpen(){return inventory;} }',
'net/minecraft/client/player/LocalPlayer.java':'package net.minecraft.client.player; public class LocalPlayer {public net.minecraft.world.item.ItemStack held=new net.minecraft.world.item.ItemStack(); public net.minecraft.world.item.ItemStack getMainHandItem(){return held;} }',
'net/minecraft/world/item/Item.java':'package net.minecraft.world.item; public class Item {}',
'net/minecraft/world/item/ItemStack.java':'package net.minecraft.world.item; public class ItemStack {public Item item=new Item(); public Item getItem(){return item;} }',
'com/mrcrayfish/guns/item/GunItem.java':'package com.mrcrayfish.guns.item; public class GunItem extends net.minecraft.world.item.Item {}',
'net/minecraft/client/input/KeyEvent.java':'package net.minecraft.client.input; public record KeyEvent(int key) {}',
'net/minecraftforge/client/event/InputEvent.java':'package net.minecraftforge.client.event; public interface InputEvent { public record Key(net.minecraft.client.input.KeyEvent getInfo,int getAction) {} }',
'net/minecraft/client/KeyMapping.java':'package net.minecraft.client; public class KeyMapping {public int key=90; public boolean matches(net.minecraft.client.input.KeyEvent info){return key==info.key();}}',
'com/mrcrayfish/guns/client/KeyBinds.java':'package com.mrcrayfish.guns.client; public class KeyBinds {public static net.minecraft.client.KeyMapping KEY_ATTACHMENTS=new net.minecraft.client.KeyMapping();}',
'com/mrcrayfish/framework/api/network/FrameworkNetwork.java':'package com.mrcrayfish.framework.api.network; public interface FrameworkNetwork { void sendToServer(Object message); }',
'com/mrcrayfish/guns/network/PacketHandler.java':'package com.mrcrayfish.guns.network; public class PacketHandler {public static int sent; public static com.mrcrayfish.framework.api.network.FrameworkNetwork getPlayChannel(){return m -> sent++;}}'.replace('com.mrcrayfish.framework.api.network.FrameworkNetwork','com.mrcrayfish.framework.api.network.FrameworkNetwork'),
'com/mrcrayfish/guns/network/message/C2SMessageAttachments.java':'package com.mrcrayfish.guns.network.message; public class C2SMessageAttachments {}',
}
for n,s in files.items():
 p=root/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
