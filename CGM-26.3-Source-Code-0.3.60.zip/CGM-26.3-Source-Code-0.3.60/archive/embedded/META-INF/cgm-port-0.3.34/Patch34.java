import java.nio.file.*;
import jdk.internal.org.objectweb.asm.*;
import jdk.internal.org.objectweb.asm.tree.*;
import jdk.internal.org.objectweb.asm.tree.analysis.*;
public class Patch34 implements Opcodes {
 static ClassNode read(Path path)throws Exception {byte[] b=Files.readAllBytes(path);b[6]=0;b[7]=61;ClassNode c=new ClassNode();new ClassReader(b).accept(c,0);return c;}
 static void save(ClassNode c)throws Exception {for(MethodNode m:c.methods)if((m.access&(ACC_ABSTRACT|ACC_NATIVE))==0)new Analyzer<>(new BasicVerifier()).analyze(c.name,m);ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);byte[] b=w.toByteArray();b[6]=0;b[7]=69;Path p=Path.of("work34/patched",c.name+".class");Files.createDirectories(p.getParent());Files.write(p,b);System.out.println("Verified "+c.name);}
 public static void main(String[] args)throws Exception {
  String root="com/mrcrayfish/guns/";
  ClassNode c=read(Path.of("inspect",root+"client/ClientHandler.class"));
  ClassNode donor=read(Path.of("work34/classes",c.name+".class"));
  MethodNode fresh=donor.methods.stream().filter(m->m.name.equals("onKeyPressed")).findFirst().orElseThrow();
  int replacements=0;
  for(int i=0;i<c.methods.size();i++)if(c.methods.get(i).name.equals("onKeyPressed")){c.methods.set(i,fresh);replacements++;}
  if(replacements!=1)throw new AssertionError(replacements);
  save(c);
  c=read(Path.of("inspect",root+"client/handler/ReloadHandler.class"));
  int hooks=0;
  for(MethodNode m:c.methods)if(m.name.equals("onKeyPressed")) {
   InsnList l=new InsnList();l.add(new VarInsnNode(ALOAD,1));l.add(new MethodInsnNode(INVOKESTATIC,root+"client/ClientHandler","onKeyPressed","(Lnet/minecraftforge/client/event/InputEvent$Key;)V",false));m.instructions.insert(l);hooks++;
  }
  if(hooks!=1)throw new AssertionError(hooks);
  save(c);
 }
}
