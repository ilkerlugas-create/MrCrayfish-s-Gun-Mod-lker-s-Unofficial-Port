package com.mrcrayfish.guns.client;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen;
import net.minecraftforge.client.event.InputEvent;
import com.mrcrayfish.guns.item.GunItem;
import com.mrcrayfish.guns.network.PacketHandler;
import com.mrcrayfish.guns.network.message.C2SMessageAttachments;
public class ClientHandler {
 public static void onKeyPressed(InputEvent.Key event) {
  Minecraft mc=Minecraft.getInstance();
  if(mc.player==null || event.getAction()!=1) return;
  Screen screen=mc.gui.screen();
  if(screen!=null && !(screen instanceof InventoryScreen)
    && !(screen instanceof CreativeModeInventoryScreen creative && creative.isInventoryOpen())) return;
  if(!(mc.player.getMainHandItem().getItem() instanceof GunItem)) return;
  if(KeyBinds.KEY_ATTACHMENTS.matches(event.getInfo()))
   PacketHandler.getPlayChannel().sendToServer(new C2SMessageAttachments());
 }
}