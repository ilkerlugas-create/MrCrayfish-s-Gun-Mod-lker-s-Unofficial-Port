from pathlib import Path
import zipfile,json,hashlib
base=next(Path('upload').glob('*.jar'))
out=Path('output/CGM-26.3-Forge66.0.2-0.3.34-Z-MENU-FIX.jar');out.parent.mkdir(exist_ok=True)
updates={p.relative_to('work34/patched').as_posix():p.read_bytes() for p in Path('work34/patched').rglob('*.class')}
report={'version':'0.3.34','base_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),'changes':['Attachment key routed through explicitly registered ReloadHandler input listener; former static key annotation removed to prevent duplicate sends','Allow game, survival inventory and creative inventory tab; reject chat, search and other screens','Only send while main hand holds a gun; honor rebound key; ignore release/repeat'],'validation':['ASM BasicVerifier passed both changed classes','13 isolated key path checks passed','Packaged handler bytecode matches tested method','One annotated key route'],'in_game_test':False,'limitation':'Without latest.log the reported no-open failure cannot be conclusively attributed to a single cause; this patch addresses the observed inventory guard and input routing.'}
updates['META-INF/cgm-port-0.3.34/validation.json']=json.dumps(report,indent=2).encode()
for p in [Path('work34/Patch34.java'),Path('work34/package.py'),Path('work34/build.py'),Path('work34/src/KeyPathTest.java'),Path('work34/src/com/mrcrayfish/guns/client/ClientHandler.java')]:updates['META-INF/cgm-port-0.3.34/'+p.name]=p.read_bytes()
updates['CGM-0.3.34-OKU.txt']='''0.3.34 - Z eklenti menüsü giriş düzeltmesi
Silah ana elindeyken Z ile mevcut 3D eklenti menüsünü aç.
Normal oyun, hayatta kalma envanteri ve yaratıcı modun oyuncu envanteri sekmesi desteklenir.
Sohbet, yaratıcı arama ve diğer menülerde tetiklenmez.
Tuş ataması Ayarlar > Kontroller içindeki CGM eklenti tuşunu izler; eski ayarında başka tuş varsa Z olarak değiştir.
Eski CGM JAR'ını mods klasöründen çıkar, tek CGM olarak bu sürümü kullan.
Sunucuda oynuyorsan istemci ve sunucuda aynı JAR'ı kullan.
3D menü, texture, silahlar ve reload davranışı korunmuştur.
13 izole giriş testi ve bytecode kontrolleri geçti. Minecraft içinde test yapılmadı.
Hâlâ açılmazsa Z'ye bastıktan sonraki logs/latest.log dosyasını gönder.
'''.encode()
with zipfile.ZipFile(base) as z:
 for n in ['META-INF/MANIFEST.MF','META-INF/mods.toml']:updates[n]=z.read(n).replace(b'port-0.3.33',b'port-0.3.34')
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as d:
  for n in z.namelist():d.writestr(n,updates.pop(n,z.read(n)))
  for n,v in updates.items():d.writestr(n,v)
with zipfile.ZipFile(base) as a,zipfile.ZipFile(out) as b:
 assert b.testzip() is None
 changed=[n for n in a.namelist() if a.read(n)!=b.read(n)]
 assert set(changed)=={'com/mrcrayfish/guns/client/ClientHandler.class','com/mrcrayfish/guns/client/handler/ReloadHandler.class','META-INF/MANIFEST.MF','META-INF/mods.toml'},changed
 for n in b.namelist():
  if n.endswith('.json'):json.loads(b.read(n))
 print('PASS: archive and JSON integrity; all model, texture, animation, menu and network entries preserved byte-for-byte')
print(out.resolve())
