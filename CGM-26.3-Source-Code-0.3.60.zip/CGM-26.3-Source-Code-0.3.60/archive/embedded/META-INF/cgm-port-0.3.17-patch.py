#!/usr/bin/env python3
"""Apply the CGM 0.3.16 -> 0.3.17 reflection hotfix without recompiling.

Only the two exact constant-pool UTF-8 entries below are changed in class files.
All method code, stack maps, resources and bundled Framework files are retained.
Usage: python patch_reflection.py input.jar output.jar
"""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import re
import struct
import zipfile

PATCHES = {
    'com/mrcrayfish/guns/client/handler/SoundHandler.class':
        ('f_120226_', 'instanceToChannel'),
    'com/mrcrayfish/guns/util/ReflectionUtil.class':
        ('m_57391_', 'updateRedstoneOutput'),
}
MANIFEST = 'META-INF/MANIFEST.MF'
OLD_VERSION = '1.3.7-26.3-port-0.3.16+framework-0.13.27'
NEW_VERSION = '1.3.7-26.3-port-0.3.17+framework-0.13.27'
SOURCE_SHA256 = '18c2a9d3e1622b7b1b1e62585f2834caf970576061ca36e37cf02e1cb3fa7634'


def constant_pool(data):
    assert data[:4] == b'\xca\xfe\xba\xbe', 'Not a Java class'
    count = struct.unpack_from('>H', data, 8)[0]
    position, index, entries = 10, 1, []
    sizes = {3: 4, 4: 4, 5: 8, 6: 8, 7: 2, 8: 2, 9: 4,
             10: 4, 11: 4, 12: 4, 15: 3, 16: 2, 17: 4, 18: 4,
             19: 2, 20: 2}
    while index < count:
        start = position
        tag = data[position]
        position += 1
        value = None
        if tag == 1:
            length = struct.unpack_from('>H', data, position)[0]
            position += 2
            value = data[position:position + length]
            position += length
        else:
            position += sizes[tag]
        assert position <= len(data), 'Truncated constant pool'
        entries.append((index, tag, value, data[start:position]))
        index += 2 if tag in (5, 6) else 1
    assert index == count
    return entries, position


def patch_class(data, old, new):
    entries, end = constant_pool(data)
    result, changes = [data[:10]], 0
    for _, tag, value, raw in entries:
        if tag == 1 and value == old.encode('ascii'):
            value = new.encode('ascii')
            raw = b'\x01' + struct.pack('>H', len(value)) + value
            changes += 1
        result.append(raw)
    assert changes == 1, f'Expected exactly one {old} constant, got {changes}'
    result.append(data[end:])
    changed = b''.join(result)
    checked, checked_end = constant_pool(changed)
    assert data[:10] == changed[:10]
    assert data[end:] == changed[checked_end:], 'Class body changed'
    assert len(entries) == len(checked)
    assert sum(a != b for a, b in zip(entries, checked)) == 1
    return changed


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    assert args.input.resolve() != args.output.resolve(), 'Use a separate output path'
    original_sha = hashlib.sha256(args.input.read_bytes()).hexdigest()
    assert original_sha == SOURCE_SHA256, 'Input is not the inspected 0.3.16 JAR'
    report = {'base_sha256': original_sha, 'version': NEW_VERSION,
              'class_changes': PATCHES, 'runtime_game_test': 'not performed',
              'validation': ['Exact Minecraft 26.3 Forge class members inspected',
                             'Class bodies and bytecode unchanged',
                             'All other original entries preserved byte-for-byte',
                             'No legacy f_N_ or m_N_ member names remain in class files',
                             'ZIP CRC validation passed']}
    notes = (
        'CGM 26.3 runtime hotfix 0.3.17\n'
        'Base: uploaded 0.3.16 REGISTRY-ID-HOTFIX-BUNDLED-FRAMEWORK.jar\n'
        'Minecraft 26.3 / Forge 66.0.2 / Java 25 / Framework 0.13.27\n\n'
        'SoundHandler: f_120226_ -> instanceToChannel. Fixes the startup\n'
        'NoSuchFieldException while preserving stun/deafening/ringing logic.\n'
        'ReflectionUtil: m_57391_ -> updateRedstoneOutput. Fixes the same\n'
        'legacy-name issue in target-block redstone updates when shooting.\n'
        'Both member names and types were checked in the Forge 26.3 client.\n'
        'No methods, mixins, models, textures, sounds or Framework code removed.\n'
        'This is a targeted binary patch, not a full source rebuild.\n'
        'Archive and bytecode preservation checked; game launch not tested.\n\n'
        'Kurulum: Eski CGM JAR dosyasini mods klasorunden disari tasiyin.\n'
        'Bu JAR dosyasini mods klasorune koyun. Framework icindedir; ayri\n'
        'bir Framework JAR dosyasi ile birlikte yuklemeyin.\n'
    ).encode('utf-8')
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(args.input) as source:
        names = source.namelist()
        assert len(names) == len(set(names)), 'Duplicate input entries'
        assert not any(re.match(r'META-INF/[^/]+\.(SF|RSA|DSA|EC)$', n) for n in names)
        assert source.testzip() is None
        with zipfile.ZipFile(args.output, 'w', compression=zipfile.ZIP_DEFLATED) as output:
            output.comment = source.comment
            for info in source.infolist():
                data = source.read(info.filename)
                if info.filename in PATCHES:
                    data = patch_class(data, *PATCHES[info.filename])
                elif info.filename == MANIFEST:
                    assert data.count(OLD_VERSION.encode()) == 1
                    data = data.replace(OLD_VERSION.encode(), NEW_VERSION.encode())
                output.writestr(copy.copy(info), data)
            output.writestr('CGM-26.3-RUNTIME-HOTFIX-0.3.17.txt', notes)
            output.writestr('META-INF/cgm-port-0.3.17-validation.json',
                            json.dumps(report, indent=2) + '\n')
            output.writestr('META-INF/cgm-port-0.3.17-patch.py', Path(__file__).read_bytes())
        with zipfile.ZipFile(args.output) as output:
            assert output.testzip() is None
            changed = [n for n in names if source.read(n) != output.read(n)]
            assert set(changed) == set(PATCHES) | {MANIFEST}
            assert set(names) <= set(output.namelist())
            assert len(output.namelist()) == len(set(output.namelist()))
            for name in output.namelist():
                if name.endswith('.class'):
                    entries, _ = constant_pool(output.read(name))
                    assert not any(tag == 1 and re.fullmatch(rb'[fm]_\d+_', value)
                                   for _, tag, value, _ in entries), name
    print(json.dumps({'output': str(args.output.resolve()),
                      'sha256': hashlib.sha256(args.output.read_bytes()).hexdigest(),
                      'changed_entries': changed,
                      'preserved_original_entries': len(names) - len(changed),
                      'runtime_game_test': 'not performed'}, indent=2))


if __name__ == '__main__':
    main()
