import java.nio.file.*;
import java.util.zip.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.tree.analysis.*;

/** Add one pre-ADS preparation hook; all other gameplay bytecode is retained. */
public final class PatchMotion implements Opcodes {
    public static void main(String[] args) throws Exception {
        String name = "com/mrcrayfish/guns/client/handler/GunRenderingHandler.class";
        byte[] original;
        try (ZipFile z = new ZipFile(args[0])) { original = z.getInputStream(z.getEntry(name)).readAllBytes(); }
        ClassNode c = new ClassNode(); new ClassReader(original).accept(c, 0);
        for (MethodNode m : c.methods) for (var ins : m.instructions) {
            if (ins instanceof MethodInsnNode n && n.owner.equals("com/mrcrayfish/guns/port/ViewSway") && n.name.equals("prepare"))
                throw new IllegalArgumentException("The input already contains the motion patch; use the original 0.3.56 JAR.");
        }
        int hooks = 0, swayCalls = 0;
        for (MethodNode method : c.methods) {
            for (AbstractInsnNode ins : method.instructions.toArray()) {
                if (!(ins instanceof MethodInsnNode call)) continue;
                if (call.owner.equals("com/mrcrayfish/guns/port/ViewSway") && call.name.equals("apply")) swayCalls++;
                if (method.name.equals("onRenderOverlay") && hooks == 0
                        && call.owner.equals("com/mojang/blaze3d/vertex/PoseStack") && call.name.equals("pushPose")) {
                    InsnList hook = new InsnList();
                    hook.add(new VarInsnNode(ALOAD, 1));
                    hook.add(new MethodInsnNode(INVOKEVIRTUAL, "net/minecraftforge/client/event/RenderHandEvent", "getPoseStack", "()Lcom/mojang/blaze3d/vertex/PoseStack;", false));
                    hook.add(new VarInsnNode(ALOAD, 1));
                    hook.add(new MethodInsnNode(INVOKEVIRTUAL, "net/minecraftforge/client/event/RenderHandEvent", "getPartialTick", "()F", false));
                    hook.add(new MethodInsnNode(INVOKESTATIC, "com/mrcrayfish/guns/port/ViewSway", "prepare", "(Lcom/mojang/blaze3d/vertex/PoseStack;F)V", false));
                    method.instructions.insert(ins, hook);
                    hooks++;
                }
            }
        }
        if (hooks != 1 || swayCalls != 1) throw new AssertionError("Unexpected hooks: " + hooks + "/" + swayCalls);
        ClassWriter writer = new ClassWriter(ClassWriter.COMPUTE_MAXS); c.accept(writer);
        byte[] bytes = writer.toByteArray();
        ClassNode checked = new ClassNode(); new ClassReader(bytes).accept(checked, 0);
        for (MethodNode m : checked.methods) if ((m.access & (ACC_ABSTRACT | ACC_NATIVE)) == 0)
            new Analyzer<>(new BasicVerifier()).analyze(checked.name, m);
        Path out = Path.of(args[1], name); Files.createDirectories(out.getParent()); Files.write(out, bytes);
        System.out.println("PASS: one pre-ADS prepare hook, one existing sway call, handler bytecode verified.");
    }
}
