import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.tree.analysis.*;
import org.objectweb.asm.util.*;

/** Resolve changed code against the target installation; compare retained code. */
public final class CheckMotion implements Opcodes {
    static final Map<String, ClassNode> cache = new HashMap<>();
    static final List<ZipFile> jars = new ArrayList<>();
    static Path classes;
    static int references;
    static ClassNode parse(byte[] data) {
        ClassNode c = new ClassNode(); new ClassReader(data).accept(c, 0); return c;
    }
    static ClassNode get(String name) throws Exception {
        if (cache.containsKey(name)) return cache.get(name);
        byte[] bytes = null;
        Path local = classes.resolve(name + ".class");
        if (Files.isRegularFile(local)) bytes = Files.readAllBytes(local);
        if (bytes == null) for (ZipFile z : jars) {
            var e = z.getEntry(name + ".class");
            if (e != null) { bytes = z.getInputStream(e).readAllBytes(); break; }
        }
        if (bytes == null) try (var in = ClassLoader.getSystemResourceAsStream(name + ".class")) {
            if (in != null) bytes = in.readAllBytes();
        }
        ClassNode c = bytes == null ? null : parse(bytes); cache.put(name, c); return c;
    }
    static Integer member(String owner, String name, String desc, boolean method, Set<String> seen) throws Exception {
        if (!seen.add(owner)) return null;
        ClassNode c = get(owner); if (c == null) return null;
        if (method) {
            for (MethodNode m : c.methods) if (m.name.equals(name) && m.desc.equals(desc)) return m.access;
            if (name.equals("<init>")) return null;
        } else for (FieldNode f : c.fields) if (f.name.equals(name) && f.desc.equals(desc)) return f.access;
        if (c.superName != null) {
            Integer a = member(c.superName, name, desc, method, seen); if (a != null) return a;
        }
        for (String i : c.interfaces) {
            Integer a = member(i, name, desc, method, seen); if (a != null) return a;
        }
        return null;
    }
    static void reference(String owner, String name, String desc, boolean method, boolean isStatic) throws Exception {
        Integer access = member(owner, name, desc, method, new HashSet<>());
        if (access == null) throw new AssertionError("Missing target member: " + owner + "." + name + desc);
        if (((access & ACC_STATIC) != 0) != isStatic)
            throw new AssertionError("Static/instance mismatch: " + owner + "." + name);
        references++;
    }
    static String trace(MethodNode method) {
        Textifier t = new Textifier(); method.accept(new TraceMethodVisitor(t));
        StringWriter out = new StringWriter(); t.print(new PrintWriter(out)); return out.toString();
    }
    static void compareHandler(Path original) throws Exception {
        String name = "com/mrcrayfish/guns/client/handler/GunRenderingHandler";
        ClassNode before;
        try (ZipFile z = new ZipFile(original.toFile())) {
            before = parse(z.getInputStream(z.getEntry(name + ".class")).readAllBytes());
        }
        ClassNode after = parse(Files.readAllBytes(classes.resolve(name + ".class")));
        int hooks = 0;
        for (MethodNode m : after.methods) for (var ins : m.instructions.toArray()) {
            if (ins instanceof MethodInsnNode n && n.owner.equals("com/mrcrayfish/guns/port/ViewSway") && n.name.equals("prepare")) {
                if (!m.name.equals("onRenderOverlay")) throw new AssertionError("Wrong hook location");
                reference(n.owner, n.name, n.desc, true, true);
                for (int i = 0; i < 4; i++) m.instructions.remove(ins.getPrevious());
                m.instructions.remove(ins); hooks++;
            }
        }
        if (hooks != 1 || before.methods.size() != after.methods.size()) throw new AssertionError("Unexpected method change");
        for (int i = 0; i < before.methods.size(); i++) {
            MethodNode a = before.methods.get(i), b = after.methods.get(i);
            if (!a.name.equals(b.name) || !a.desc.equals(b.desc) || !trace(a).equals(trace(b)))
                throw new AssertionError("Unintended handler change: " + a.name);
        }
        System.out.println("PASS: all " + before.methods.size() + " existing handler methods retained, except the one preparation hook.");
    }
    public static void main(String[] args) throws Exception {
        classes = Path.of(args[0]);
        for (String path : Files.readString(Path.of(args[2])).trim().split(java.util.regex.Pattern.quote(File.pathSeparator)))
            jars.add(new ZipFile(path));
        int methods = 0;
        for (String name : List.of("com/mrcrayfish/guns/port/ViewSway", "com/mrcrayfish/guns/port/ViewSway$State")) {
            ClassNode c = get(name);
            for (MethodNode m : c.methods) {
                if ((m.access & (ACC_ABSTRACT | ACC_NATIVE)) == 0) new Analyzer<>(new BasicVerifier()).analyze(name, m);
                for (var ins : m.instructions) {
                    if (ins instanceof MethodInsnNode n) reference(n.owner, n.name, n.desc, true, n.getOpcode() == INVOKESTATIC);
                    if (ins instanceof FieldInsnNode n) reference(n.owner, n.name, n.desc, false, n.getOpcode() == GETSTATIC || n.getOpcode() == PUTSTATIC);
                }
                methods++;
            }
        }
        compareHandler(Path.of(args[1]));
        System.out.println("PASS: " + methods + " motion methods and " + references + " exact member descriptors/static flags verified against Minecraft 26.3, Forge and bundled CGM.");
        for (ZipFile z : jars) z.close();
    }
}
