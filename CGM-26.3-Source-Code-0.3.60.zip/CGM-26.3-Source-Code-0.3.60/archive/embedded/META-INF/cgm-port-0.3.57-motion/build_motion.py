#!/usr/bin/env python3
"""Rebuild this patch from the original mod and an installed target toolchain.

python build_motion.py --input original.jar --output CGM-26.3-Forge-SMOOTH-SWAY.jar \
    --classpath-file classpath.txt --jdk /path/to/jdk-25

The classpath file is one platform-separated line containing the original mod,
Minecraft 26.3 client, Forge 66.0.2 and its dependencies, plus ASM 9.9 core/tree/
analysis/util. Use original JOML 1.10.9 (from the Minecraft version manifest).
All paths should be absolute. Extract this entire META-INF folder to rebuild.
"""
import argparse
import copy
import hashlib
import os
from pathlib import Path
import subprocess
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parent
VERSION = "0.3.57"
SOURCE_VERSION = "0.3.56"
META = "META-INF/cgm-port-" + VERSION + "-motion/"
CLASSES = (
    "com/mrcrayfish/guns/port/ViewSway.class",
    "com/mrcrayfish/guns/port/ViewSway$State.class",
    "com/mrcrayfish/guns/client/handler/GunRenderingHandler.class",
)

def build(args):
    original = args.input.resolve()
    output = args.output.resolve()
    if original == output:
        raise ValueError("Output must be a different file from the original")
    cp_file = args.classpath_file.resolve()
    cp = cp_file.read_text().strip()
    java = str(args.jdk.resolve() / "bin" / ("java.exe" if os.name == "nt" else "java"))
    javac = str(args.jdk.resolve() / "bin" / ("javac.exe" if os.name == "nt" else "javac"))
    results = []
    def run(command):
        r = subprocess.run(command, text=True, capture_output=True)
        print(r.stdout + r.stderr, end="", flush=True)
        if r.returncode:
            raise RuntimeError("Build or validation failed")
        results.append(r.stdout)
    with tempfile.TemporaryDirectory(prefix="cgm-motion-") as tmp:
        tmp = Path(tmp)
        classes, tools, tests = [tmp / p for p in ("classes", "tools", "tests")]
        for dest, sources, classpath in (
            (classes, sorted((ROOT / "src").rglob("*.java")), cp),
            (tools, sorted((ROOT / "tools").glob("*.java")), cp),
            (tests, sorted((ROOT / "tests").rglob("*.java")), str(classes) + os.pathsep + cp),
        ):
            dest.mkdir()
            run([javac, "--release", "25", "-proc:none", "-cp", classpath, "-d", str(dest), *map(str, sources)])
        tool_cp = str(tools) + os.pathsep + cp
        run([java, "-Xverify:all", "-cp", tool_cp, "PatchMotion", str(original), str(classes)])
        run([java, "-Xverify:all", "-cp", tool_cp, "CheckMotion", str(classes), str(original), str(cp_file)])
        run([java, "-Xverify:all", "-cp", os.pathsep.join((str(tests), str(classes), cp)),
             "com.mrcrayfish.guns.port.MotionRegression"])
        report = ("CGM 26.3 cosmetic motion patch " + VERSION + "\n"
                  + "Original SHA-256: " + hashlib.sha256(original.read_bytes()).hexdigest() + "\n\n"
                  + "\n".join(results)
                  + "\nNo in-game client session was launched. Automated checks do not prove final visual equivalence.\n")
        with zipfile.ZipFile(original) as zin:
            changed = {name: (classes / name).read_bytes() for name in CLASSES}
            for name in ("META-INF/mods.toml", "META-INF/MANIFEST.MF"):
                data = zin.read(name)
                old = ("1.3.7-26.3-port-" + SOURCE_VERSION).encode()
                new = ("1.3.7-26.3-port-" + VERSION).encode()
                if old not in data:
                    raise ValueError("Unexpected input version in " + name)
                changed[name] = data.replace(old, new)
            added = {META + "verification.txt": report.encode()}
            for prefix in ("src", "tools", "tests"):
                for p in sorted((ROOT / prefix).rglob("*.java")):
                    added[META + p.relative_to(ROOT).as_posix()] = p.read_bytes()
            for name in ("build_motion.py", "MOTION_README.txt"):
                added[META + name] = (ROOT / name).read_bytes()
            if set(added) & set(zin.namelist()):
                raise ValueError("The input already contains patch provenance")
            output.parent.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zout:
                for info in zin.infolist():
                    data = changed[info.filename] if info.filename in changed else zin.read(info.filename)
                    zout.writestr(copy.copy(info), data)
                for name, data in added.items():
                    zout.writestr(name, data)
            with zipfile.ZipFile(output) as zout:
                assert zout.testzip() is None, "CRC failure"
                assert len(zout.namelist()) == len(set(zout.namelist())), "Duplicate entries"
                assert set(zout.namelist()) == set(zin.namelist()) | set(added)
                for name in zin.namelist():
                    expected = changed[name] if name in changed else zin.read(name)
                    assert zout.read(name) == expected, name
                runtime_changes = {name for name in zin.namelist() if name.endswith(".class") and zin.read(name) != zout.read(name)}
                assert runtime_changes == set(CLASSES), runtime_changes
                assert not any(name.endswith(".class") for name in added)
        print("PASS: archive CRC, unique entries, exactly three replaced runtime classes; all other original payloads preserved except version metadata.")
        print("Saved:", output)
        print("SHA-256:", hashlib.sha256(output.read_bytes()).hexdigest())

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--classpath-file", required=True, type=Path)
    parser.add_argument("--jdk", required=True, type=Path)
    build(parser.parse_args())
