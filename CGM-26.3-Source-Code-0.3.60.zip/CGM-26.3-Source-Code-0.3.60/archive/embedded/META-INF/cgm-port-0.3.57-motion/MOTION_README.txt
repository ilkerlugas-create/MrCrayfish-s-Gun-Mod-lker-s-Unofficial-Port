CGM 26.3 / Forge - motion update 0.3.57

Changes
- First-person mouse movement drives continuous, frame-rate-independent weapon
  inertia. Fast pans produce visible yaw/pitch lag and a soft return to rest.
- Small strafe translation and roll ease into left/right changes.
- Native hand look tilt and walking bob are removed in their exact inverse
  order before applying a quieter, configurable weapon-only walking bob.
- The added motion fades to zero as aim-down-sights completes.
- Existing weaponSway, swaySensitivity, swayType and bobbingIntensity options
  remain supported. Default swaySensitivity is 0.3, swayType is DRAG.
- Existing gun assets, shot direction, recoil, reload, sprint and third-person
  code are retained. The motion handler only changes first-person rendering.

Install
Replace the previous CGM JAR in the Minecraft 26.3 Forge mods folder with this
JAR. Use one CGM JAR. The bundled Framework dependency remains in the file.

Validation
Compiled with JDK 25 for the actual Minecraft 26.3 target API.
Checks cover 20-240 FPS, wrapping yaw, direction reversal, return to rest,
duplicate renders, camera cuts, invalid input and ADS strength. Real Minecraft
PoseStack/JOML matrices verify the native-motion cancellation order.
All exact method/field descriptors and static flags used by the new code are
resolved against the target dependencies. Existing handler methods are checked
for unintended bytecode changes. The archive preserves unrelated payloads.
See verification.txt for the executed results and the original JAR hash.

The videos were used as visual references. This build has not been launched
inside a playable Minecraft client; final visual tuning needs an in-game check.

Source and rebuild
The modified source, patch tool, validation code and build_motion.py are in
this folder. Rebuild using the original 0.3.56 JAR, JDK 25, Python 3, Minecraft
26.3, Forge 66.0.2 and their normal dependencies, plus ASM 9.9 core/tree/
analysis/util. Use original dependencies, including JOML 1.10.9, rather than
compile-only jars with stripped stack-map frames. No dependency jars are
added to the mod by this patch. Run build_motion.py --help for arguments.
