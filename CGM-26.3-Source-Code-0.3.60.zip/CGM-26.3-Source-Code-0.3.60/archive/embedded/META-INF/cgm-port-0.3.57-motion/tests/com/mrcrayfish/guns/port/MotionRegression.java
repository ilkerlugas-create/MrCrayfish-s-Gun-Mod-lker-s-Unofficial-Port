package com.mrcrayfish.guns.port;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import java.util.Random;
import net.minecraft.util.Mth;
import org.joml.Matrix4f;

/** Executes the actual new classes against Minecraft 26.3 and JOML. */
public final class MotionRegression {
    static int checks;
    static void check(boolean ok, String message) {
        checks++;
        if (!ok) throw new AssertionError(message);
    }
    static void near(double actual, double expected, double error, String message) {
        check(Double.isFinite(actual) && Math.abs(actual - expected) <= error,
                message + ": " + actual + " != " + expected);
    }
    static float wrap(float angle) { return ViewSway.difference(angle, 0F); }
    static ViewSway.State turning(int fps, float speed, boolean seam) {
        ViewSway.State s = new ViewSway.State();
        s.sample(0, 0, 170, 0);
        for (int f = 1; f <= fps; f++) {
            float yaw = 170F + speed * f / fps;
            s.sample(20.0 * f / fps, 0F, seam ? wrap(yaw) : yaw, 1F);
        }
        return s;
    }
    static void matrixNear(Matrix4f actual, Matrix4f expected, float tolerance, String message) {
        float[] a = new float[16], b = new float[16];
        actual.get(a); expected.get(b);
        for (int i = 0; i < 16; i++) near(a[i], b[i], tolerance, message + " [" + i + "]");
    }
    public static void main(String[] args) {
        for (int fps : new int[]{20, 30, 60, 144, 240}) {
            for (float speed : new float[]{-720F, -300F, 60F, 300F, 720F}) {
                ViewSway.State s = turning(fps, speed, false);
                double expected = speed / 20.0 * 1.35 * (1.0 - Math.exp(-20 / 1.35));
                near(s.yawLag, expected, 0.00015, "frame-rate-independent angular lag " + fps);
                near(s.yawLag, turning(fps, speed, true).yawLag, 0.00015, "yaw wrap " + fps);
                float before = s.yawLag;
                s.sample(20, 45, 123, -1);
                near(s.yawLag, before, 0, "duplicate render pass does not advance");
                for (int f = 1; f <= fps; f++) s.sample(20 + 20.0 * f / fps, 0, 170 + speed, 0);
                near(s.yawLag, 0, 0.0001, "returns to rest " + fps);
                near(s.strafe, 0, 0.00001, "strafe returns to rest " + fps);
            }
        }
        ViewSway.State s = turning(60, 300, false);
        float visible = ViewSway.angle(s.yawLag, .3F, 24F);
        check(visible > 10F && visible < 15F, "noticeable reference-style mouse sway");
        System.out.printf("300 deg/s look: %.3f deg cosmetic yaw; old hard maximum: 1.750 deg%n", visible);
        float last = s.yawLag;
        s.sample(20 + 1.0 / 3.0, 0, 465, -1);
        check(s.yawLag < last && s.yawLag > 0, "direction reversal eases through neutral");
        s.sample(40, 0, 90, 1); near(s.yawLag, 0, 0, "render gap resets inertia");
        s.sample(2, 0, 0, 0); near(s.strafe, 0, 0, "world/time reset");
        s.sample(Double.NaN, 0, 0, 0); check(!s.ready, "invalid time reset");
        s.sample(0, Float.NaN, 0, 0); check(!s.ready, "invalid angle reset");
        s.sample(0, 0, 0, 0); s.sample(.1, 0, 150, 0);
        near(s.yawLag, 0, 0, "camera cut resets");
        s.sample(10000000, 0, 0, 0); s.sample(10000000 + 20.0/240, 0, 1, 0);
        check(s.yawLag > 0F, "long-session 240 FPS precision");
        near(ViewSway.strength(1), 0, 0, "full ADS is stable");
        near(ViewSway.strength(0), 1, 0, "hip fire is full strength");
        near(ViewSway.angle(100, 0, 24), 0, 0, "sensitivity zero");
        Random random = new Random(57);
        for (int i = 0; i < 1000; i++) {
            float value = (random.nextFloat() - .5F) * 20000F;
            check(Math.abs(ViewSway.angle(value, 1, 24)) <= 24, "bounded yaw");
            check(Math.abs(ViewSway.angle(value, 1, 18)) <= 18, "bounded pitch");
            near(ViewSway.angle(-value, .3F, 24), -ViewSway.angle(value, .3F, 24), 0, "left/right symmetry");
        }
        for (float bad : new float[]{Float.NaN, Float.POSITIVE_INFINITY, Float.NEGATIVE_INFINITY})
            near(ViewSway.angle(bad, 1, 24), 0, 0, "invalid input stays finite");
        // Compose the real vanilla order, then the new pre-ADS correction.
        // It must equal only the intended reduced bob, with no residual tilt.
        for (int i = 0; i < 200; i++) {
            float distance = random.nextFloat() * 100;
            float bob = i % 5 == 0 ? 0 : random.nextFloat() * .18F;
            float pitch = (random.nextFloat() - .5F) * 30;
            float yaw = (random.nextFloat() - .5F) * 75;
            float amount = i % 4 == 0 ? 0 : random.nextFloat() * 2;
            float phase = distance * (float)Math.PI;
            float x = Mth.sin(phase) * bob * .5F;
            float y = -Math.abs(Mth.cos(phase) * bob);
            float rz = Mth.sin(phase) * bob * 3;
            float rx = Math.abs(Mth.cos(phase - .2F) * bob) * 5;
            PoseStack pose = new PoseStack();
            pose.translate(x, y, 0F);
            pose.rotateDegrees(Axis.ZP, rz); pose.rotateDegrees(Axis.XP, rx);
            pose.rotateDegrees(Axis.XP, pitch); pose.rotateDegrees(Axis.YP, yaw);
            ViewSway.correctNative(pose, pitch, yaw, distance, bob, amount);
            PoseStack target = new PoseStack();
            target.translate(x * .28F * amount, y * .38F * amount, 0F);
            target.rotateDegrees(Axis.ZP, rz * .35F * amount);
            target.rotateDegrees(Axis.XP, rx * .35F * amount);
            matrixNear(pose.last().pose(), target.last().pose(), 3E-6F, "native motion cancellation");
        }
        System.out.println("PASS: " + checks + " checks: 20-240 FPS, yaw seam, reversals, stopping, resets, ADS, actual PoseStack matrices.");
    }
}
