package com.mrcrayfish.guns.port;

import java.util.Map;
import java.util.WeakHashMap;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.mrcrayfish.guns.Config;
import com.mrcrayfish.guns.client.SwayType;
import com.mrcrayfish.guns.client.handler.AimingHandler;
import com.mrcrayfish.guns.common.Gun;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;

/** First-person cosmetic inertia. No changes to camera rotation or shot direction. */
public final class ViewSway {
    private static final Map<LocalPlayer, State> STATES = new WeakHashMap<>();
    private static final double LOOK_RESPONSE_TICKS = 1.35;
    private static final double STRAFE_RESPONSE_TICKS = 1.60;
    private static final float MAX_YAW = 24F;
    private static final float MAX_PITCH = 18F;
    private ViewSway() {}

    static float finite(float value) { return Float.isFinite(value) ? value : 0F; }
    static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, finite(value)));
    }
    static float difference(float current, float previous) {
        double d = (double) current - previous;
        if (!Double.isFinite(d)) return 0F;
        d %= 360.0;
        if (d >= 180.0) d -= 360.0;
        if (d < -180.0) d += 360.0;
        return (float) d;
    }
    static float strength(float ads) {
        float hip = 1F - clamp(ads, 0F, 1F);
        return hip * hip;
    }
    static float angle(float lag, float sensitivity, float limit) {
        return (float) (limit * Math.tanh(finite(lag) * clamp(sensitivity, 0F, 1F) * 2.2 / limit));
    }

    static final class State {
        double time;
        float lastPitch, lastYaw, pitchLag, yawLag, strafe;
        boolean ready;

        void reset(double now, float pitch, float yaw) {
            time = now;
            lastPitch = finite(pitch);
            lastYaw = finite(yaw);
            pitchLag = yawLag = strafe = 0F;
            ready = Double.isFinite(now) && Float.isFinite(pitch) && Float.isFinite(yaw);
        }

        void sample(double now, float pitch, float yaw, float targetStrafe) {
            if (!Double.isFinite(now) || !Float.isFinite(pitch) || !Float.isFinite(yaw)
                    || !ready || now < time || now - time > 5.0) {
                reset(now, pitch, yaw);
                return;
            }
            double elapsed = now - time;
            // Render passes for the same game instant must not integrate twice.
            if (elapsed <= 1E-7) return;
            float dp = difference(pitch, lastPitch);
            float dy = difference(yaw, lastYaw);
            // A teleport/camera cut is not a mouse movement to drag behind.
            if (Math.abs(dp) > 120F || Math.abs(dy) > 120F) {
                reset(now, pitch, yaw);
                return;
            }
            double decay = Math.exp(-elapsed / LOOK_RESPONSE_TICKS);
            double inputWeight = -Math.expm1(-elapsed / LOOK_RESPONSE_TICKS)
                    * LOOK_RESPONSE_TICKS / elapsed;
            // Exact integration of d(lag)/dt = angularVelocity - lag/tau for
            // constant velocity within a frame. No 20 Hz xBob/yBob target.
            pitchLag = (float) (pitchLag * decay + dp * inputWeight);
            yawLag = (float) (yawLag * decay + dy * inputWeight);
            float moveAlpha = (float) -Math.expm1(-elapsed / STRAFE_RESPONSE_TICKS);
            strafe += (clamp(targetStrafe, -1F, 1F) - strafe) * moveAlpha;
            lastPitch = pitch;
            lastYaw = yaw;
            time = now;
        }
    }

    /**
     * Called immediately inside the gun's pushPose, BEFORE ADS/equip offsets.
     * Forge's hand event already inherits vanilla walk bob and look tilt.
     * Undo them in reverse order, then apply a quieter weapon-only walk bob.
     * The values below come from the SAME extracted render state as vanilla.
     */
    public static void prepare(PoseStack pose, float partial) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        var state = mc.gameRenderer.gameRenderState();
        var hands = state.levelRenderState.playerRenderState.firstPersonHandsAndItems;
        float lookPitch = hands == null ? 0F : finite((hands.viewXRot - hands.xBob) * .1F);
        float lookYaw = hands == null ? 0F : finite((hands.viewYRot - hands.yBob) * .1F);
        var camera = state.levelRenderState.cameraRenderState.entityRenderState;
        float bob = state.optionsRenderState.bobView && camera.isPlayer ? finite(camera.bob) : 0F;
        float distance = finite(camera.backwardsInterpolatedWalkDistance);
        float intensity = clamp(Config.CLIENT.display.bobbingIntensity.get().floatValue(), 0F, 2F);
        float ads = (float) AimingHandler.get().getNormalisedAdsProgress();
        correctNative(pose, lookPitch, lookYaw, distance, bob, intensity * strength(ads));
    }

    static void correctNative(PoseStack pose, float lookPitch, float lookYaw,
            float distance, float bob, float amount) {
        // Vanilla look order is Rx * Ry. Do not wrap angles here: the inverse
        // must cancel the EXACT vanilla transform, including a yaw seam.
        pose.rotateDegrees(Axis.YP, -lookYaw);
        pose.rotateDegrees(Axis.XP, -lookPitch);
        if (bob == 0F) return;
        float phase = distance * (float) Math.PI;
        float sine = Mth.sin(phase);
        float x = sine * bob * .5F;
        float y = -Math.abs(Mth.cos(phase) * bob);
        float roll = sine * bob * 3F;
        float pitch = Math.abs(Mth.cos(phase - .2F) * bob) * 5F;
        // Inverse of vanilla T * Rz * Rx, followed by the reduced replacement.
        pose.rotateDegrees(Axis.XP, -pitch);
        pose.rotateDegrees(Axis.ZP, -roll);
        pose.translate(-x, -y, 0F);
        pose.translate(x * .28F * amount, y * .38F * amount, 0F);
        pose.rotateDegrees(Axis.ZP, roll * .35F * amount);
        pose.rotateDegrees(Axis.XP, pitch * .35F * amount);
    }

    public static void apply(PoseStack pose, Gun gun, LocalPlayer player,
            float x, float y, float z, float partial, float previousFall, float fall) {
        if (player == null) return;
        if (!Config.CLIENT.display.weaponSway.get()) {
            STATES.remove(player);
            return;
        }
        partial = clamp(partial, 0F, 1F);
        Minecraft mc = Minecraft.getInstance();
        var hands = mc.gameRenderer.gameRenderState().levelRenderState.playerRenderState.firstPersonHandsAndItems;
        float viewPitch = hands == null ? player.getViewXRot(partial) : hands.viewXRot;
        float viewYaw = hands == null ? player.getViewYRot(partial) : hands.viewYRot;
        State state = STATES.get(player);
        if (state == null) { state = new State(); STATES.put(player, state); }
        float strafeTarget = 0F;
        if (mc.gui.screen() == null && !player.isPassenger() && !player.isSleeping()) {
            var keys = player.input.keyPresses;
            float input = (keys.left() ? 1F : 0F) - (keys.right() ? 1F : 0F);
            float speed = (float) player.getDeltaMovement().horizontalDistance();
            strafeTarget = input * clamp(speed / .10F, 0F, 1F);
            if (keys.forward() || keys.backward()) strafeTarget *= .70710677F;
        }
        state.sample(player.tickCount + (double) partial, viewPitch, viewYaw, strafeTarget);
        float sensitivity = clamp(Config.CLIENT.display.swaySensitivity.get().floatValue(), 0F, 1F);
        float weight = strength((float) AimingHandler.get().getNormalisedAdsProgress());
        float pitch = angle(state.pitchLag, sensitivity, MAX_PITCH) * weight;
        float yaw = angle(state.yawLag, sensitivity, MAX_YAW) * weight;
        float strafe = state.strafe * weight * clamp(sensitivity / .3F, 0F, 1F);
        float side = player.getMainArm() == HumanoidArm.LEFT ? -1F : 1F;
        x *= side;
        pose.translate(-strafe * .010F, 0F, 0F);
        pose.translate(x, y, z);
        double fallPivot = gun.getGeneral().getGripType().getHeldAnimation().getFallSwayZOffset();
        pose.translate(0.0, -.25, fallPivot);
        pose.rotateDegrees(Axis.XP, MotionLimits.sway(Mth.lerp(partial, previousFall, fall)) * weight);
        pose.translate(0.0, .25, -fallPivot);
        SwayType type = Config.CLIENT.display.swayType.get();
        float direction = type == SwayType.DRAG ? 1F : -1F;
        pose.rotateDegrees(type.getPitchRotation(), pitch);
        pose.rotateDegrees(type.getYawRotation(), yaw);
        pose.rotateDegrees(Axis.ZP, strafe * .8F - yaw * .08F * direction);
        pose.translate(-x, -y, -z);
    }
}
