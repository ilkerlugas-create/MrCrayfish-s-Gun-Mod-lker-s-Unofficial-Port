package com.mrcrayfish.guns.port;

import com.mojang.blaze3d.platform.InputConstants;
import com.mrcrayfish.guns.client.KeyBinds;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;

/** Repairs the old GLFW Z value (90), which is SDL keypad 2 in Minecraft 26.3. */
public final class AttachmentsKey {
    private static final int LEGACY_GLFW_Z = 90;
    private static boolean checked;

    private AttachmentsKey() {}

    public static void migrateLegacyBinding() {
        if (checked) return;
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft == null || minecraft.options == null) return;

        KeyMapping mapping = KeyBinds.KEY_ATTACHMENTS;
        checked = true;
        if (!mapping.matches(InputConstants.Type.KEYBOARD.getOrCreate(LEGACY_GLFW_Z))) return;

        mapping.setKey(InputConstants.Type.KEYBOARD.getOrCreate(InputConstants.KEY_Z));
        KeyMapping.resetMapping();
        minecraft.options.save();
    }
}
