"""Exact-input Z menu fix. Requires Python 3 and a JDK 17+ (no network downloads).
Focused JVM tests use API fixtures. This is not a full Forge build or an in-game test.
"""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,zipfile

P=Path(__file__).resolve().parent
ROOT=P.parent
BASE=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT/'base/CGM-0.3.59-PERFORMANCE.jar'
EXPECTED='c95607780fb3cfbd165f83c8073871fe19c63828b9ac9fcafc93d178a52d8809'
assert hashlib.sha256(BASE.read_bytes()).hexdigest()==EXPECTED,'Wrong base JAR; patch only the exact uploaded 0.3.59'
INPUT=ROOT/'input'
with zipfile.ZipFile(BASE) as z:
 for n in z.namelist():
  path=Path(n)
  if n.endswith('/') or path.is_absolute() or '..' in path.parts:continue
  target=INPUT/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(n))

for name in ['classes','tools-classes','patched','test-runtime','test-classes']:
 path=P/name
 if path.exists():shutil.rmtree(path)

LOG=[]
def run(args):
 result=subprocess.run(list(map(str,args)),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 print(result.stdout,end='');LOG.append(result.stdout)
 if result.returncode:
  (P/'verification.txt').write_text(''.join(LOG));raise SystemExit(result.returncode)

exports=[f'--add-exports=java.base/jdk.internal.org.objectweb.asm{s}=ALL-UNNAMED' for s in ('','.tree','.tree.analysis','.util')]
run(['java','com.sun.tools.javac.Main',*exports,'-d',P/'tools-classes',*sorted((P/'tools').glob('*.java'))])
run(['java',*exports,'-cp',P/'tools-classes','TestRuntime60',INPUT,P/'test-runtime/before'])
run(['python3',P/'tests/make_fixtures.py'])
run(['java','com.sun.tools.javac.Main','--release','17','-cp',P/'test-runtime/before','-d',P/'classes',
     *sorted((P/'fixtures').rglob('*.java')),*sorted((P/'src').rglob('*.java'))])
run(['java',*exports,'-cp',P/'tools-classes','Patch60',INPUT,P/'patched',P/'classes'])
run(['java',*exports,'-cp',P/'tools-classes','TestRuntime60',P/'patched',P/'test-runtime/after'])
cp=os.pathsep.join(map(str,[P/'test-runtime/after',P/'classes']))
run(['java','com.sun.tools.javac.Main','--release','17','-cp',cp,'-d',P/'test-classes',P/'tests/KeyRegression60.java'])
for side in ['before','after']:
 cp=os.pathsep.join(map(str,[P/f'test-runtime/{side}',P/'test-classes',P/'classes']))
 for scenario in ['fresh','legacy','custom','unbound','guards','deferred']:
  run(['java','-Xverify:all','-cp',cp,'KeyRegression60',str(side=='after').lower(),scenario])

run(['java',*exports,'-cp',P/'tools-classes','Verify60',INPUT,P/'patched'])
(P/'verification.txt').write_text(''.join(LOG))

updates={p.relative_to(P/'patched').as_posix():p.read_bytes() for p in (P/'patched').rglob('*.class')}
OUT=ROOT/'output';OUT.mkdir(exist_ok=True)
target=OUT/'CGM-26.3-Forge-Ilker-Unofficial-Port-EU-0.3.60-Z-MENU-FIX.jar'
with zipfile.ZipFile(BASE) as old:
 for name in ['META-INF/MANIFEST.MF','META-INF/mods.toml']:
  data=old.read(name);assert b'port-0.3.59' in data
  updates[name]=data.replace(b'port-0.3.59',b'port-0.3.60')
 for folder in ['src','tools','tests']:
  for p in (P/folder).rglob('*'):
   if p.is_file() and p.suffix in ['.java','.py']:
    updates['META-INF/cgm-port-0.3.60/'+p.relative_to(P).as_posix()]=p.read_bytes()
 for p in [P/'build.py',*P.glob('*.md'),P/'verification.txt']:
  updates['META-INF/cgm-port-0.3.60/'+p.name]=p.read_bytes()
 with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as new:
  for info in old.infolist():new.writestr(info,updates.pop(info.filename,old.read(info.filename)))
  for name,data in sorted(updates.items()):new.writestr(name,data)

with zipfile.ZipFile(BASE) as old,zipfile.ZipFile(target) as new:
 assert new.testzip() is None
 assert len(new.namelist())==len(set(new.namelist()))
 assert not set(old.namelist())-set(new.namelist())
 changed=sorted(n for n in old.namelist() if old.read(n)!=new.read(n))
 expected={'com/mrcrayfish/guns/'+n+'.class' for n in ['client/KeyBinds','client/ClientHandler','client/handler/ReloadHandler']}
 assert set(changed)==expected|{'META-INF/MANIFEST.MF','META-INF/mods.toml'},changed
 new_classes=sorted(n for n in set(new.namelist())-set(old.namelist()) if n.endswith('.class'))
 assert new_classes==['com/mrcrayfish/guns/port/AttachmentsKey.class'],new_classes
 assets=[n for n in old.namelist() if n.startswith(('assets/','data/')) and not n.endswith('/')]
 assert all(old.read(n)==new.read(n) for n in assets)
 for n in expected:set_version=int.from_bytes(new.read(n)[6:8],'big');assert set_version==69

report={'input_sha256':EXPECTED,'output_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),
 'changed_original_entries':changed,'added_runtime_classes':new_classes,
 'assets_and_data_preserved_byte_for_byte':len(assets),'full_forge_build':False,'in_game_test':False,
 'focused_before_after_jvm_tests':True,'runtime_class_version':69,
 'tests':'Actual key initializer and onKeyPressed bytecode executed with API fixtures; guarded menu packet dispatch and persisted-key migration verified.'}
(OUT/'validation-0.3.60.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS: archive CRC, unique entries, exact changed-entry whitelist, retained Java 25 versions, unchanged assets and data.')
print('OUTPUT',target)
