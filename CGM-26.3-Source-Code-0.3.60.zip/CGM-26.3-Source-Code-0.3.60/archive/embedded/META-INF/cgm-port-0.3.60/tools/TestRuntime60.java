import java.nio.file.*;
import java.util.*;
import jdk.internal.org.objectweb.asm.*;
import jdk.internal.org.objectweb.asm.tree.*;

/** Runs the actual changed initializer and key handler against small API fixtures, not a game. */
public final class TestRuntime60 implements Opcodes {
    static void write(ClassNode node, Path output) throws Exception {
        node.version = V17;
        ClassWriter writer = new ClassWriter(ClassWriter.COMPUTE_MAXS);
        node.accept(writer);
        Path path = output.resolve(node.name + ".class");
        Files.createDirectories(path.getParent());
        Files.write(path, writer.toByteArray());
    }

    public static void main(String[] args) throws Exception {
        Path source = Path.of(args[0]), output = Path.of(args[1]);
        ClassNode keys = Patch60.read(source, Patch60.G + "client/KeyBinds");
        keys.methods.removeIf(m -> !Set.of("<init>", "<clinit>", "registerKeyMappings").contains(m.name));
        write(keys, output);

        ClassNode handler = Patch60.read(source, Patch60.G + "client/ClientHandler");
        // Rendering method dependencies are intentionally absent from this focused test runtime.
        handler.methods.removeIf(m -> !Set.of("<init>", "onKeyPressed").contains(m.name));
        write(handler, output);

        Path helper = source.resolve(Patch60.HELPER + ".class");
        if (Files.exists(helper)) write(Patch60.read(source, Patch60.HELPER), output);
        System.out.println("Created focused test runtime: " + output);
    }
}
