import java.nio.file.*;
import java.util.*;
import jdk.internal.org.objectweb.asm.*;
import jdk.internal.org.objectweb.asm.tree.*;

/** Remove only the intended edits, then require identical normalized class structures. */
public final class Verify60 implements Opcodes {
 static byte[] bytes(ClassNode node){ClassWriter writer=new ClassWriter(0);node.accept(writer);return writer.toByteArray();}
 public static void main(String[] args)throws Exception{
  Path before=Path.of(args[0]),after=Path.of(args[1]);
  for(String name:List.of("client/KeyBinds","client/ClientHandler","client/handler/ReloadHandler")){
   ClassNode old=Patch60.read(before,Patch60.G+name),now=Patch60.read(after,Patch60.G+name);
   int undo=0;
   for(MethodNode m:now.methods)for(var i:m.instructions.toArray()){
    if(name.equals("client/KeyBinds")&&m.name.equals("<clinit>")&&i instanceof FieldInsnNode field
      &&field.owner.equals("com/mojang/blaze3d/platform/InputConstants")&&field.name.equals("KEY_Z")){
      m.instructions.set(i,new IntInsnNode(BIPUSH,90));undo++;
    }else if(i instanceof MethodInsnNode call&&call.owner.equals(Patch60.HELPER)){
      m.instructions.remove(i);undo++;
    }
   }
   Patch60.check(undo==1,"Expected exactly one changed instruction: "+name);
   Patch60.check(Arrays.equals(bytes(old),bytes(now)),"Unrelated bytecode/metadata changed: "+name);
   System.out.println("PASS exact class structure after reversing the one intended edit: "+name);
  }
 }
}
