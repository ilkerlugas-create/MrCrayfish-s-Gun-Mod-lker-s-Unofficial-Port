import java.nio.file.*;
import java.util.*;
import jdk.internal.org.objectweb.asm.*;
import jdk.internal.org.objectweb.asm.tree.*;
import jdk.internal.org.objectweb.asm.tree.analysis.*;

/** Exact-input patch: preserve existing methods, stack maps, annotations and Java 25 versions. */
public final class Patch60 implements Opcodes {
    static final String G = "com/mrcrayfish/guns/";
    static final String HELPER = G + "port/AttachmentsKey";
    static Path input, output;

    static void check(boolean value, String message) {
        if (!value) throw new AssertionError(message);
    }

    static ClassNode read(Path root, String name) throws Exception {
        byte[] bytes = Files.readAllBytes(root.resolve(name + ".class"));
        int version = (bytes[6] & 255) << 8 | (bytes[7] & 255);
        // JDK 17's ASM can read these unchanged instructions after normalizing its reader header.
        // The original Java 25 version is restored in every delivered original class.
        bytes[6] = 0; bytes[7] = 61;
        ClassNode node = new ClassNode();
        new ClassReader(bytes).accept(node, 0);
        node.version = version;
        return node;
    }

    static MethodNode method(ClassNode node, String name, String descriptor) {
        var found = node.methods.stream().filter(m -> m.name.equals(name)
                && m.desc.equals(descriptor)).toList();
        check(found.size() == 1, "Expected one " + node.name + "." + name + descriptor);
        return found.get(0);
    }

    static void save(ClassNode node) throws Exception {
        for (MethodNode m : node.methods) {
            if ((m.access & (ACC_ABSTRACT | ACC_NATIVE)) == 0)
                new Analyzer<>(new BasicVerifier()).analyze(node.name, m);
        }
        ClassWriter writer = new ClassWriter(ClassWriter.COMPUTE_MAXS);
        node.accept(writer);
        Path path = output.resolve(node.name + ".class");
        Files.createDirectories(path.getParent());
        Files.write(path, writer.toByteArray());
        System.out.println("VERIFIED " + node.name + " class version " + node.version);
    }

    static void migrateAtEntry(ClassNode node, String name, String descriptor) {
        MethodNode m = method(node, name, descriptor);
        for (var i : m.instructions)
            check(!(i instanceof MethodInsnNode call && call.owner.equals(HELPER)),
                    "Already patched: " + node.name);
        m.instructions.insert(new MethodInsnNode(INVOKESTATIC, HELPER,
                "migrateLegacyBinding", "()V", false));
    }

    public static void main(String[] args) throws Exception {
        input = Path.of(args[0]); output = Path.of(args[1]);
        ClassNode keys = read(input, G + "client/KeyBinds");
        MethodNode init = method(keys, "<clinit>", "()V");
        int changes = 0;
        for (var i : init.instructions.toArray()) {
            if (!(i instanceof LdcInsnNode text) || !"key.cgm.attachments".equals(text.cst)) continue;
            var next = i.getNext();
            while (next != null && next.getOpcode() < 0) next = next.getNext();
            check(next instanceof IntInsnNode old && old.operand == 90, "Expected old GLFW Z value");
            // Resolve Minecraft's named constant at runtime instead of embedding another GLFW value.
            init.instructions.set(next, new FieldInsnNode(GETSTATIC,
                    "com/mojang/blaze3d/platform/InputConstants", "KEY_Z", "I"));
            changes++;
        }
        check(changes == 1, "Exactly one attachment default must change");
        save(keys);

        ClassNode handler = read(input, G + "client/ClientHandler");
        migrateAtEntry(handler, "onKeyPressed", "(Lnet/minecraftforge/client/event/InputEvent$Key;)V");
        save(handler);

        ClassNode reload = read(input, G + "client/handler/ReloadHandler");
        // This registered client tick also runs in menus, after Options has loaded.
        migrateAtEntry(reload, "onClientTick", "(Lnet/minecraftforge/event/TickEvent$ClientTickEvent$Post;)V");
        save(reload);

        ClassNode helper = read(Path.of(args[2]), HELPER);
        helper.version = keys.version;
        save(helper);
    }
}
