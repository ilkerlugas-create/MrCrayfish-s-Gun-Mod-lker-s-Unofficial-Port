import com.mojang.blaze3d.platform.InputConstants;
import com.mrcrayfish.guns.client.ClientHandler;
import com.mrcrayfish.guns.client.KeyBinds;
import com.mrcrayfish.guns.item.GunItem;
import com.mrcrayfish.guns.network.PacketHandler;
import com.mrcrayfish.guns.network.message.C2SMessageAttachments;
import com.mrcrayfish.guns.port.AttachmentsKey;
import net.minecraft.client.*;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.*;
import net.minecraft.world.item.*;
import net.minecraftforge.client.event.*;

public final class KeyRegression60 {
 static int assertions;
 static void check(boolean value,String message){assertions++;if(!value)throw new AssertionError(message);}
 static void bind(int code){KeyBinds.KEY_ATTACHMENTS.setKey(InputConstants.Type.KEYBOARD.getOrCreate(code));}
 static void send(int code,int action,int count,String label){
  PacketHandler.sent.clear();ClientHandler.onKeyPressed(new InputEvent.Key(code,action));
  check(PacketHandler.sent.size()==count,label);
  for(Object packet:PacketHandler.sent)check(packet instanceof C2SMessageAttachments,"Correct menu packet");
 }
 public static void main(String[] args){
  boolean patched=Boolean.parseBoolean(args[0]);String scenario=args[1];
  Minecraft mc=Minecraft.getInstance();
  mc.player=new LocalPlayer();mc.player.held=new ItemStack(new GunItem());
  check(KeyBinds.KEY_ATTACHMENTS.defaultCode==(patched?29:90),"Actual static initializer default");
  check(KeyBinds.KEY_RELOAD.defaultCode==21,"Existing R reload unchanged");
  RegisterKeyMappingsEvent register=new RegisterKeyMappingsEvent();KeyBinds.registerKeyMappings(register);
  check(register.mappings.size()==3&&register.mappings.contains(KeyBinds.KEY_ATTACHMENTS),"Control registered");

  switch(scenario){
   case "fresh" -> {
    send(29,1,patched?1:0,"Z press with gun");
    send(90,1,patched?0:1,"Old keypad code");
    check(mc.options.saves==0,"No unnecessary save for fresh settings");
   }
   case "legacy" -> {
    bind(90);send(29,1,patched?1:0,"Z repairs saved old keypad binding before matching");
    check(KeyBinds.KEY_ATTACHMENTS.key.value()==(patched?29:90),"Saved binding migrated");
    check(mc.options.saves==(patched?1:0),"Legacy migration saved once");
    if(patched){
     check(mc.options.savedCode==29&&KeyMapping.resetCalls==1,"Persisted Z and rebuilt key lookup");
     for(int i=0;i<1000;i++)AttachmentsKey.migrateLegacyBinding();
     check(mc.options.saves==1&&KeyMapping.resetCalls==1,"No per-tick disk writes");
    }
   }
   case "custom" -> {
    bind(25);send(25,1,1,"Custom V still opens menu");send(29,1,0,"Default does not override custom V");
    check(mc.options.saves==0&&KeyBinds.KEY_ATTACHMENTS.key.value()==25,"Custom preserved");
   }
   case "unbound" -> {
    bind(0);send(29,1,0,"Unbound action remains unbound");check(mc.options.saves==0,"Unbound not overwritten");
   }
   case "guards" -> {
    // Use an explicit correct binding so guards can be compared in both binaries.
    bind(29);send(29,0,0,"Release does not open menu");send(29,2,0,"Repeat does not send duplicate requests");
    send(21,1,0,"Reload key does not open attachments");
    mc.player.held=new ItemStack(new Item());send(29,1,0,"Non-gun cannot open menu");
    mc.player.held=new ItemStack(new GunItem());mc.gui.current=new Screen();send(29,1,0,"Chat/other screen blocked");
    mc.gui.current=new InventoryScreen();send(29,1,1,"Survival inventory allowed");
    mc.gui.current=new CreativeModeInventoryScreen(true);send(29,1,1,"Creative player inventory allowed");
    mc.gui.current=new CreativeModeInventoryScreen(false);send(29,1,0,"Creative search/category screen blocked");
    mc.gui.current=null;mc.player=null;send(29,1,0,"No player blocked");
   }
   case "deferred" -> {
    if(!patched)break;
    bind(90);Options saved=mc.options;mc.options=null;
    AttachmentsKey.migrateLegacyBinding();check(KeyBinds.KEY_ATTACHMENTS.key.value()==90,"Wait for options");
    mc.options=saved;AttachmentsKey.migrateLegacyBinding();
    check(KeyBinds.KEY_ATTACHMENTS.key.value()==29&&saved.saves==1,"Deferred migration works");
    bind(90);AttachmentsKey.migrateLegacyBinding();
    check(KeyBinds.KEY_ATTACHMENTS.key.value()==90&&saved.saves==1,"No binding rewrite after initial check");
   }
   default -> throw new AssertionError("Unknown scenario");
  }
  System.out.println("PASS "+(patched?"after":"before")+" "+scenario+" ("+assertions+" checks)");
 }
}
