from pathlib import Path
P = Path(__file__).resolve().parent.parent
sources = {
'com/mojang/blaze3d/platform/InputConstants.java': '''package com.mojang.blaze3d.platform;
public final class InputConstants {
 public static final int KEY_Z=29;
 public enum Type { KEYBOARD, MOUSE;
  public Key getOrCreate(int value){return new Key(this,value);}
 }
 public record Key(Type type,int value){}
}''',
'net/minecraft/resources/Identifier.java': '''package net.minecraft.resources;
public record Identifier(String namespace,String path){
 public static Identifier fromNamespaceAndPath(String namespace,String path){return new Identifier(namespace,path);}
}''',
'net/minecraft/client/input/KeyEvent.java': '''package net.minecraft.client.input;
public record KeyEvent(int key){}''',
'net/minecraft/client/KeyMapping.java': '''package net.minecraft.client;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.resources.Identifier;
public class KeyMapping {
 public final String name; public final int defaultCode; public InputConstants.Key key;
 public static int resetCalls;
 public KeyMapping(String name,int code,Category category){this.name=name;defaultCode=code;key=InputConstants.Type.KEYBOARD.getOrCreate(code);}
 public boolean matches(KeyEvent event){return key.type()==InputConstants.Type.KEYBOARD && key.value()==event.key();}
 public boolean matches(InputConstants.Key other){return key.equals(other);}
 public void setKey(InputConstants.Key key){this.key=key;}
 public static void resetMapping(){resetCalls++;}
 public record Category(Identifier id){public static Category register(Identifier id){return new Category(id);}}
}''',
'net/minecraft/client/Options.java': '''package net.minecraft.client;
public class Options {public int saves;public int savedCode=-999;
 public void save(){saves++;savedCode=com.mrcrayfish.guns.client.KeyBinds.KEY_ATTACHMENTS.key.value();}
}''',
'net/minecraft/client/Minecraft.java': '''package net.minecraft.client;
public class Minecraft {
 public static Minecraft instance=new Minecraft();
 public Options options=new Options();
 public net.minecraft.client.player.LocalPlayer player;
 public net.minecraft.client.gui.Gui gui=new net.minecraft.client.gui.Gui();
 public static Minecraft getInstance(){return instance;}
}''',
'net/minecraft/client/gui/Gui.java': '''package net.minecraft.client.gui;
public class Gui {public net.minecraft.client.gui.screens.Screen current;
 public net.minecraft.client.gui.screens.Screen screen(){return current;}
}''',
'net/minecraft/client/gui/screens/Screen.java': '''package net.minecraft.client.gui.screens;
public class Screen {}''',
'net/minecraft/client/gui/screens/inventory/InventoryScreen.java': '''package net.minecraft.client.gui.screens.inventory;
public class InventoryScreen extends net.minecraft.client.gui.screens.Screen {}''',
'net/minecraft/client/gui/screens/inventory/CreativeModeInventoryScreen.java': '''package net.minecraft.client.gui.screens.inventory;
public class CreativeModeInventoryScreen extends net.minecraft.client.gui.screens.Screen {
 public boolean inventory; public CreativeModeInventoryScreen(boolean inventory){this.inventory=inventory;}
 public boolean isInventoryOpen(){return inventory;}
}''',
'net/minecraft/world/item/Item.java': '''package net.minecraft.world.item;public class Item {}''',
'net/minecraft/world/item/ItemStack.java': '''package net.minecraft.world.item;
public class ItemStack {private final Item item;public ItemStack(Item item){this.item=item;}public Item getItem(){return item;}}''',
'net/minecraft/client/player/LocalPlayer.java': '''package net.minecraft.client.player;
public class LocalPlayer {public net.minecraft.world.item.ItemStack held;
 public net.minecraft.world.item.ItemStack getMainHandItem(){return held;}
}''',
'com/mrcrayfish/guns/item/GunItem.java': '''package com.mrcrayfish.guns.item;
public class GunItem extends net.minecraft.world.item.Item {}''',
'net/minecraftforge/client/event/InputEvent.java': '''package net.minecraftforge.client.event;
public class InputEvent {public static class Key {
 private final int action;private final net.minecraft.client.input.KeyEvent info;
 public Key(int code,int action){this.action=action;info=new net.minecraft.client.input.KeyEvent(code);}
 public int getAction(){return action;}public net.minecraft.client.input.KeyEvent getInfo(){return info;}
}}''',
'net/minecraftforge/client/event/RegisterKeyMappingsEvent.java': '''package net.minecraftforge.client.event;
public class RegisterKeyMappingsEvent {
 public java.util.List<net.minecraft.client.KeyMapping> mappings=new java.util.ArrayList<>();
 public void register(net.minecraft.client.KeyMapping mapping){mappings.add(mapping);}
}''',
'com/mrcrayfish/framework/api/network/FrameworkNetwork.java': '''package com.mrcrayfish.framework.api.network;
public interface FrameworkNetwork {void sendToServer(Object message);}''',
'com/mrcrayfish/guns/network/PacketHandler.java': '''package com.mrcrayfish.guns.network;
public class PacketHandler {public static final java.util.List<Object> sent=new java.util.ArrayList<>();
 private static final com.mrcrayfish.framework.api.network.FrameworkNetwork channel=sent::add;
 public static com.mrcrayfish.framework.api.network.FrameworkNetwork getPlayChannel(){return channel;}
}''',
'com/mrcrayfish/guns/network/message/C2SMessageAttachments.java': '''package com.mrcrayfish.guns.network.message;
public class C2SMessageAttachments {}''',
}
for name, source in sources.items():
 p=P/'fixtures'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(source+'\n')
print('Generated',len(sources),'API fixtures; none are shipped as runtime classes.')
