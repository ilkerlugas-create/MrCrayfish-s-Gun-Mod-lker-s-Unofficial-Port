# CGM 26.3 Z attachments menu repair — 0.3.60

Continue the full existing mod from the user's exact uploaded performance JAR.
Input SHA-256: `c95607780fb3cfbd165f83c8073871fe19c63828b9ac9fcafc93d178a52d8809`.
No full Forge workspace or live Minecraft client is available in this run.

## Diagnosis and changes

The shipped `KeyBinds` initializer supplied 90 for `key.cgm.attachments`, inherited
from GLFW Z. Minecraft 26.3 uses SDL scancodes: 90 is keypad 2 and Z is 29.
The existing `ClientHandler.onKeyPressed` matched that incorrect binding, so a
real Z press did not send `C2SMessageAttachments`. The server packet and menu
implementation already existed and were retained.

- `KeyBinds`: replace only the attachments default with a runtime reference to
  `InputConstants.KEY_Z`, including the default shown by Controls / Reset.
- New `AttachmentsKey`: once options are available, convert an existing saved
  keyboard code 90 to Z, rebuild the key lookup and save options once.
- `ReloadHandler.onClientTick`: call the migration before existing tick logic,
  so it also runs from the main menu.
- `ClientHandler.onKeyPressed`: call the same idempotent migration before matching,
  covering early key input. The existing screen, player, held-gun and press guards
  and the existing server request remain untouched.
- Other custom bindings and unbound controls are preserved. A deliberately saved
  keypad-2 attachment binding is indistinguishable from the broken old default and
  will also migrate on the next launch.
- Runtime classes stay at Java 25 class version 69. All existing assets, data,
  rendering/animation code, server networking and performance helpers are retained.

## Reproduce and validate

Run with Python 3 and a JDK 17+ from the patch folder:

`python3 build.py ../base/CGM-0.3.59-PERFORMANCE.jar`

The JDK internal ASM reader uses a temporary version-61 header only while reading
classes. Production output restores version 69. Focused test runtime copies use 61
to execute actual initializers/handler instructions against explicit API fixtures.
Fixtures are not production game code and are never shipped as runtime classes.

Verification covers: before/after Z dispatch, legacy option migration, one-time
save and lookup reset, custom and unbound controls, press/release/repeat behavior,
no-gun/no-player guards, inventory/chat/creative screen guards, deferred options,
and exact structural preservation after reversing each intended instruction edit.
Archive checks verify no removed entries, duplicate entries, CRC failures, or
unexpected changed classes/assets. These checks are not an in-game or full Forge test.

## Manual smoke check on the user's PC

Close Minecraft, replace the older CGM JAR in `mods` with the 0.3.60 JAR, and restart.
Controls should show Z for Modify Attachments. Hold a CGM gun in the selected
hotbar slot and press Z. Confirm the original attachments screen and 3D preview,
attach/remove a part, close the screen, and confirm changes persist.
R reload and existing animations should retain their prior behavior.

## Technical references

- https://www.minecraft.net/en-us/article/minecraft-java-edition-26-3
- https://docs.neoforged.net/primer/docs/26.3/
- https://wiki.libsdl.org/SDL3/SDL_Scancode

Those sources document the SDL migration and key-code definitions; the bug itself
was confirmed from the uploaded binary, not inferred solely from documentation.
