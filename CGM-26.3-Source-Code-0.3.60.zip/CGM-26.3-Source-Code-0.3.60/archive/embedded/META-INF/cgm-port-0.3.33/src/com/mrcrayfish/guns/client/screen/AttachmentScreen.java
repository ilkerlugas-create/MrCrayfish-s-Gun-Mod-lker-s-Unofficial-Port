package com.mrcrayfish.guns.client.screen;

import com.mrcrayfish.guns.Config;
import com.mrcrayfish.guns.Reference;
import com.mrcrayfish.guns.client.screen.widget.MiniButton;
import com.mrcrayfish.guns.client.util.RenderUtil;
import com.mrcrayfish.guns.common.container.AttachmentContainer;
import com.mrcrayfish.guns.common.container.slot.AttachmentSlot;
import com.mrcrayfish.guns.item.GunItem;
import com.mrcrayfish.guns.item.attachment.IAttachment;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.Identifier;
import net.minecraft.world.Container;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.client.ConfigScreenHandler;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Author: MrCrayfish
 */
public class AttachmentScreen extends AbstractContainerScreen<AttachmentContainer>
{
    private static final Identifier GUI_TEXTURES = Identifier.parse("cgm:textures/gui/attachments.png");
    private static final Component CONFIG_TOOLTIP = Component.translatable("cgm.button.config.tooltip");

    private final Inventory playerInventory;
    private final Container weaponInventory;

    private boolean showHelp = true;
    private int windowZoom = 10;
    private int windowX, windowY;
    private float windowRotationX, windowRotationY;
    private boolean mouseGrabbed;
    private int mouseGrabbedButton;
    private int mouseClickedX, mouseClickedY;

    public AttachmentScreen(AttachmentContainer screenContainer, Inventory playerInventory, Component titleIn)
    {
        super(screenContainer, playerInventory, titleIn, 176, 184);
        this.playerInventory = playerInventory;
        this.weaponInventory = screenContainer.getWeaponInventory();
    }

    @Override
    protected void init()
    {
        super.init();

        List<MiniButton> buttons = this.gatherButtons();
        for(int i = 0; i < buttons.size(); i++)
        {
            MiniButton button = buttons.get(i);
            switch(Config.CLIENT.buttonAlignment.get())
            {
                case LEFT ->
                {
                    int titleWidth = this.minecraft.font.width(this.title);
                    button.setX(this.leftPos + titleWidth + 8 + 3 + i * 13);
                }
                case RIGHT ->
                {
                    button.setX(this.leftPos + this.imageWidth - 7 - 10 - (buttons.size() - 1 - i) * 13);
                }
            }
            button.setY(this.topPos + 5);
            this.addRenderableWidget(button);
        }
    }

    private List<MiniButton> gatherButtons()
    {
        List<MiniButton> buttons = new ArrayList<>();
        if(!Config.CLIENT.hideConfigButton.get())
        {
            MiniButton configButton = new MiniButton(0, 0, 192, 0, GUI_TEXTURES, onPress -> this.openConfigScreen());
            configButton.setTooltip(Tooltip.create(CONFIG_TOOLTIP));
            buttons.add(configButton);
        }
        return buttons;
    }

    @Override
    public void containerTick()
    {
        super.containerTick();
        if(this.minecraft != null && this.minecraft.player != null)
        {
            if(!(this.minecraft.player.getMainHandItem().getItem() instanceof GunItem))
            {
                Minecraft.getInstance().gui.setScreen(null);
            }
        }
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTicks)
    {
        super.extractRenderState(graphics, mouseX, mouseY, partialTicks);

        int startX = this.leftPos;
        int startY = this.topPos;
        for(int i = 0; i < IAttachment.Type.values().length; i++)
        {
            if(RenderUtil.isMouseWithin(mouseX, mouseY, startX + 7, startY + 16 + i * 18, 18, 18))
            {
                IAttachment.Type type = IAttachment.Type.values()[i];
                if(!this.menu.getSlot(i).isActive())
                {
                    graphics.setComponentTooltipForNextFrame(this.font, Arrays.asList(
                            Component.translatable("slot.cgm.attachment." + type.getTranslationKey()),
                            Component.translatable("slot.cgm.attachment.not_applicable")), mouseX, mouseY);
                }
                else if(this.menu.getSlot(i) instanceof AttachmentSlot slot && slot.getItem().isEmpty() && !this.isCompatible(this.menu.getCarried(), slot))
                {
                    graphics.setComponentTooltipForNextFrame(this.font, Arrays.asList(
                            Component.translatable("slot.cgm.attachment.incompatible").withStyle(ChatFormatting.YELLOW)), mouseX, mouseY);
                }
                else if(this.weaponInventory.getItem(i).isEmpty())
                {
                    graphics.setComponentTooltipForNextFrame(this.font, Collections.singletonList(
                            Component.translatable("slot.cgm.attachment." + type.getTranslationKey())), mouseX, mouseY);
                }
            }
        }
    }

    @Override
    protected void extractLabels(GuiGraphicsExtractor graphics, int mouseX, int mouseY)
    {
        graphics.text(this.font, this.title, this.titleLabelX, this.titleLabelY, 4210752, false);
        graphics.text(this.font, this.playerInventory.getDisplayName(), this.inventoryLabelX, this.inventoryLabelY + 19, 4210752, false);
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTicks)
    {
        int left = this.leftPos;
        int top = this.topPos;
        graphics.blit(RenderPipelines.GUI_TEXTURED, GUI_TEXTURES, left, top, 0.0F, 0.0F, this.imageWidth, this.imageHeight, 256, 256);

        for(int i = 0; i < IAttachment.Type.values().length; i++)
        {
            if(!this.canPlaceAttachmentInSlot(this.menu.getCarried(), this.menu.getSlot(i)))
            {
                graphics.blit(RenderPipelines.GUI_TEXTURED, GUI_TEXTURES, left + 8, top + 17 + i * 18, 176.0F, 0.0F, 16, 16, 256, 256);
            }
            else if(this.weaponInventory.getItem(i).isEmpty())
            {
                graphics.blit(RenderPipelines.GUI_TEXTURED, GUI_TEXTURES, left + 8, top + 17 + i * 18, 176.0F, 16.0F + i * 16.0F, 16, 16, 256, 256);
            }
        }

        ItemStack weapon = this.menu.previewStack();
        if(!weapon.isEmpty())
        {
            graphics.enableScissor(left + 26, top + 17, left + 168, top + 87);
            var pose = graphics.pose();
            pose.pushMatrix();
            float dragX = this.windowX + (this.mouseGrabbed && this.mouseGrabbedButton == 0 ? mouseX - this.mouseClickedX : 0);
            float dragY = this.windowY + (this.mouseGrabbed && this.mouseGrabbedButton == 0 ? mouseY - this.mouseClickedY : 0);
            float yaw = this.windowRotationX + (this.mouseGrabbed && this.mouseGrabbedButton == 1 ? mouseX - this.mouseClickedX : 0);
            float pitch = this.windowRotationY - (this.mouseGrabbed && this.mouseGrabbedButton == 1 ? mouseY - this.mouseClickedY : 0);
            pose.translate(left + 97 + dragX, top + 52 + dragY);
            graphics.item(com.mrcrayfish.guns.port.AttachmentPreview.create(weapon,yaw,pitch,this.windowZoom/10F),-8,-8);
            pose.popMatrix();
            graphics.disableScissor();
        }

        if(this.showHelp)
        {
            graphics.text(this.font, Component.translatable("container.cgm.attachments.window_help"), left + 28, top + 19, 0xFFFFFF, false);
        }
    }

    private boolean canPlaceAttachmentInSlot(ItemStack stack, Slot slot)
    {
        if(!slot.isActive()) return false;

        if(!slot.equals(this.hoveredSlot)) return true;

        if(!slot.getItem().isEmpty()) return true;

        if(!(slot instanceof AttachmentSlot s)) return true;

        if(!(stack.getItem() instanceof IAttachment<?> a)) return true;

        if(!s.getType().equals(a.getType())) return true;

        return s.mayPlace(stack);
    }

    private boolean isCompatible(ItemStack stack, AttachmentSlot slot)
    {
        if(stack.isEmpty()) return true;

        if(!(stack.getItem() instanceof IAttachment<?> attachment)) return false;

        if(!attachment.getType().equals(slot.getType())) return true;

        return slot.mayPlace(stack);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY)
    {
        int startX = (this.width - this.imageWidth) / 2;
        int startY = (this.height - this.imageHeight) / 2;
        if(RenderUtil.isMouseWithin((int) mouseX, (int) mouseY, startX + 26, startY + 17, 142, 70))
        {
            if(scrollY < 0 && this.windowZoom > 3)
            {
                this.showHelp = false;
                this.windowZoom--;
            }
            else if(scrollY > 0 && this.windowZoom < 25)
            {
                this.showHelp = false;
                this.windowZoom++;
            }
        }
        return false;
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick)
    {
        double mouseX = event.x();
        double mouseY = event.y();
        int button = event.button();
        int startX = this.leftPos;
        int startY = this.topPos;

        if(RenderUtil.isMouseWithin((int) mouseX, (int) mouseY, startX + 26, startY + 17, 142, 70))
        {
            if(!this.mouseGrabbed && (button == 0 || button == 1))
            {
                this.mouseGrabbed = true;
                this.mouseGrabbedButton = button == 1 ? 1 : 0;
                this.mouseClickedX = (int) mouseX;
                this.mouseClickedY = (int) mouseY;
                this.showHelp = false;
                return true;
            }
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event)
    {
        double mouseX = event.x();
        double mouseY = event.y();
        int button = event.button();
        if(this.mouseGrabbed)
        {
            if(this.mouseGrabbedButton == 0 && button == 0)
            {
                this.mouseGrabbed = false;
                this.windowX += (int) (mouseX - this.mouseClickedX);
                this.windowY += (int) (mouseY - this.mouseClickedY);
            }
            else if(this.mouseGrabbedButton == 1 && button == 1)
            {
                this.mouseGrabbed = false;
                this.windowRotationX += (float) (mouseX - this.mouseClickedX);
                this.windowRotationY -= (float) (mouseY - this.mouseClickedY);
            }
        }
        return super.mouseReleased(event);
    }

    // Original config-screen implementation is preserved by Patch33.
    private void openConfigScreen() {}
}
