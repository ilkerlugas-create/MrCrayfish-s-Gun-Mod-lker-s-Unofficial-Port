package com.mrcrayfish.guns.port;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import com.mrcrayfish.guns.util.StackData;
public final class AttachmentPreview {
 public static ItemStack create(ItemStack source,float yaw,float pitch,float zoom){
  ItemStack stack=source.copy();
  var id=BuiltInRegistries.ITEM.getKey(stack.getItem());
  stack.set(DataComponents.ITEM_MODEL,Identifier.parse("cgm:attachment_preview/"+id.getPath()));
  StackData.update(stack,t->{t.putFloat("PreviewYaw",yaw);t.putFloat("PreviewPitch",pitch);t.putFloat("PreviewZoom",zoom);});
  DyeBridge.sync(stack);return stack;
 }
 public static boolean animate(net.minecraft.client.renderer.item.ItemStackRenderState state,ItemStack stack){
  Identifier model=stack.get(DataComponents.ITEM_MODEL);
  if(model==null||!model.getNamespace().equals("cgm")||!model.getPath().startsWith("attachment_preview/"))return false;
  var tag=StackData.copy(stack);
  var matrix=new org.joml.Matrix4f().translate(.5F,.5F,.5F)
   .rotateX((float)Math.toRadians(tag.getFloatOr("PreviewPitch",0)))
   .rotateY((float)Math.toRadians(tag.getFloatOr("PreviewYaw",0)))
   .scale(4.5F*Math.max(.3F,Math.min(2.5F,tag.getFloatOr("PreviewZoom",1))))
   .translate(-.5F,-.5F,-.5F);
  var access=(com.mrcrayfish.guns.mixin.client.PreviewLayersAccessor)(Object)state;
  for(int i=0;i<access.cgmPreviewLayerCount();i++)access.cgmPreviewLayers()[i].setLocalTransform(matrix);
  state.setOversizedInGui(true);state.setAnimated();return true;
 }
}
