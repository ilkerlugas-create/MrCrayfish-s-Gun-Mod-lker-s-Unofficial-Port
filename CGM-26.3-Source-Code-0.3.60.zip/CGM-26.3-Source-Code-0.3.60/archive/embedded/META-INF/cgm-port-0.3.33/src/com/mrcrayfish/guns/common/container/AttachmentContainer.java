package com.mrcrayfish.guns.common.container;

import com.mrcrayfish.guns.common.Gun;
import com.mrcrayfish.guns.common.container.slot.AttachmentSlot;
import com.mrcrayfish.guns.init.ModContainers;
import com.mrcrayfish.guns.item.attachment.IAttachment;
import com.mrcrayfish.guns.util.StackData;
import net.minecraft.nbt.NbtOps;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.RegistryOps;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

/**
 * Author: MrCrayfish
 */
public class AttachmentContainer extends AbstractContainerMenu
{
    private ItemStack weapon;
    private Inventory playerInventory;
    private Container weaponInventory = new SimpleContainer(IAttachment.Type.values().length)
    {
        @Override
        public void setChanged()
        {
            super.setChanged();
            AttachmentContainer.this.slotsChanged(this);
        }
    };
    private boolean loaded = false;
    private int lockedSlot;

    public AttachmentContainer(int windowId, Inventory playerInventory, ItemStack stack) {
        this(windowId, playerInventory);
    }

    public AttachmentContainer(int windowId, Inventory playerInventory)
    {
        super(ModContainers.ATTACHMENTS.get(), windowId);
        this.weapon = playerInventory.getSelectedItem();
        this.playerInventory = playerInventory;
        this.lockedSlot = playerInventory.getSelectedSlot();

        for(int i = 0; i < IAttachment.Type.values().length; i++)
        {
            this.addSlot(new AttachmentSlot(this, this.weaponInventory, this.weapon, IAttachment.Type.values()[i], playerInventory.player, i, 8, 17 + i * 18));
        }

        for(int i = 0; i < 3; i++)
        {
            for(int j = 0; j < 9; j++)
            {
                this.addSlot(new Slot(playerInventory, j + i * 9 + 9, 8 + j * 18, 102 + i * 18));
            }
        }

        for(int i = 0; i < 9; i++)
        {
            if(i == playerInventory.getSelectedSlot())
            {
                this.addSlot(new Slot(playerInventory, i, 8 + i * 18, 160)
                {
                    @Override
                    public boolean mayPickup(Player playerIn)
                    {
                        return false;
                    }
                });
            }
            else
            {
                this.addSlot(new Slot(playerInventory, i, 8 + i * 18, 160));
            }
        }
        var saved = StackData.copy(this.weapon).getCompoundOrEmpty("Attachments");
        for(int i=0;i<IAttachment.Type.values().length;i++) {
            var part=com.mrcrayfish.guns.port.AttachmentData.read(saved.getCompoundOrEmpty(IAttachment.Type.values()[i].getTagKey()),playerInventory.player.registryAccess());
            this.weaponInventory.setItem(i,part);
        }
        this.loaded=true;
    }

    public boolean isLoaded()
    {
        return this.loaded;
    }

    @Override
    public boolean stillValid(Player playerIn)
    {
        return playerIn.isAlive() && playerInventory.getSelectedSlot()==lockedSlot
            && playerInventory.getItem(lockedSlot)==weapon && weapon.getItem() instanceof com.mrcrayfish.guns.item.GunItem;
    }

    @Override
    public void slotsChanged(Container inventoryIn)
    {
        if(!loaded || playerInventory.player.level().isClientSide())return;
        CompoundTag attachments = new CompoundTag();

        for(int i = 0; i < this.getWeaponInventory().getContainerSize(); i++)
        {
            ItemStack attachment = this.getSlot(i).getItem();
            if(attachment.getItem() instanceof IAttachment)
            {
                attachments.put(((IAttachment) attachment.getItem()).getType().getTagKey(),com.mrcrayfish.guns.port.AttachmentData.write(attachment,playerInventory.player.registryAccess()));
            }
        }

        StackData.update(this.weapon, tag -> tag.put("Attachments", attachments));
        playerInventory.setChanged();
        super.broadcastChanges();
    }

    @Override
    public ItemStack quickMoveStack(Player playerIn, int index)
    {
        if(index==31+lockedSlot || index<0 || index>=this.slots.size())return ItemStack.EMPTY;
        ItemStack copyStack = ItemStack.EMPTY;
        Slot slot = this.slots.get(index);
        if(slot != null && slot.hasItem())
        {
            ItemStack slotStack = slot.getItem();
            copyStack = slotStack.copy();
            if(index < this.weaponInventory.getContainerSize())
            {
                if(!this.moveItemStackTo(slotStack, this.weaponInventory.getContainerSize(), this.slots.size(), true))
                {
                    return ItemStack.EMPTY;
                }
            }
            else if(!this.moveItemStackTo(slotStack, 0, this.weaponInventory.getContainerSize(), false))
            {
                return ItemStack.EMPTY;
            }

            if(slotStack.isEmpty())
            {
                slot.set(ItemStack.EMPTY);
            }
            else
            {
                slot.setChanged();
            }
        }

        return copyStack;
    }

    @Override
    public void clicked(int slot,int button,net.minecraft.world.inventory.ContainerInput action,Player player) {
        if(slot==31+lockedSlot || (action==net.minecraft.world.inventory.ContainerInput.SWAP && button==lockedSlot))return;
        super.clicked(slot,button,action,player);
    }
    public ItemStack previewStack() {
        ItemStack preview=weapon.copy();
        CompoundTag data=new CompoundTag();
        for(int i=0;i<weaponInventory.getContainerSize();i++) {
            ItemStack part=weaponInventory.getItem(i);
            if(!part.isEmpty() && part.getItem() instanceof IAttachment a)
                data.put(a.getType().getTagKey(),com.mrcrayfish.guns.port.AttachmentData.write(part,playerInventory.player.registryAccess()));
        }
        StackData.update(preview,t->t.put("Attachments",data));
        return preview;
    }
    public Container getPlayerInventory()
    {
        return this.playerInventory;
    }

    public Container getWeaponInventory()
    {
        return this.weaponInventory;
    }
}
