package com.mrcrayfish.guns.port;
import net.minecraft.world.item.ItemStack;
import net.minecraft.nbt.*;
import net.minecraft.resources.RegistryOps;
import net.minecraft.core.*;
import net.minecraft.core.registries.BuiltInRegistries;
import com.mrcrayfish.guns.util.StackData;
public final class AttachmentData {
 public static ItemStack read(CompoundTag tag){
  if(tag==null||tag.isEmpty())return ItemStack.EMPTY;
  var plain=ItemStack.CODEC.parse(NbtOps.INSTANCE,tag).result();
  if(plain.isPresent())return plain.get();
  var server=net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
  HolderLookup.Provider registries=server!=null?server.registryAccess():RegistryAccess.fromRegistryOfRegistries(BuiltInRegistries.REGISTRY);
  return read(tag,registries);
 }
 public static ItemStack read(CompoundTag tag,HolderLookup.Provider registries){
  if(tag==null||tag.isEmpty())return ItemStack.EMPTY;
  return ItemStack.CODEC.parse(RegistryOps.create(NbtOps.INSTANCE,registries),tag).result().orElse(ItemStack.EMPTY);
 }
 public static CompoundTag write(ItemStack stack,HolderLookup.Provider registries){
  // The full codec preserves dye, name, enchantments and other components.
  return (CompoundTag)ItemStack.CODEC.encodeStart(RegistryOps.create(NbtOps.INSTANCE,registries),stack.copyWithCount(1)).getOrThrow();
 }
}
