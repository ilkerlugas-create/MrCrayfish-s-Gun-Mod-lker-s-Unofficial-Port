package com.mrcrayfish.guns.port;
import net.minecraft.server.level.ServerPlayer;
import com.mrcrayfish.guns.item.GunItem;
import com.mrcrayfish.guns.common.container.AttachmentContainer;
import com.mrcrayfish.guns.common.ReloadTracker;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.network.chat.Component;
public final class AttachmentMenu {
 public static void open(ServerPlayer player){
  if(!player.isAlive()||player.isSpectator()||player.containerMenu instanceof AttachmentContainer)return;
  var weapon=player.getMainHandItem();
  if(!(weapon.getItem() instanceof GunItem))return;
  ReloadTracker.cancel(player);
  player.openMenu(new SimpleMenuProvider((id,inventory,p)->new AttachmentContainer(id,inventory,weapon),Component.translatable("container.cgm.attachments")));
 }
}
