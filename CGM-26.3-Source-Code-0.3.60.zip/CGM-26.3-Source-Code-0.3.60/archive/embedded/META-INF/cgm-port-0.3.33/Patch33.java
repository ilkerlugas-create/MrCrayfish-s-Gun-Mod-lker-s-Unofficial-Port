import java.nio.file.*;import java.util.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;
public class Patch33 implements Opcodes {
 static ClassNode read(String root,String n)throws Exception{ClassNode c=new ClassNode();new ClassReader(Files.readAllBytes(Path.of(root,n+".class"))).accept(c,0);return c;}
 static void save(ClassNode c)throws Exception{ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);Path p=Path.of("work33/classes",c.name+".class");Files.createDirectories(p.getParent());Files.write(p,w.toByteArray());}
 static void clear(MethodNode m){m.instructions.clear();m.tryCatchBlocks.clear();if(m.localVariables!=null)m.localVariables.clear();}
 public static void main(String[] args)throws Exception{
 int changes=0;String root="work33/base",p="com/mrcrayfish/guns/";
 ClassNode c=read(root,p+"item/GunItem");int old=c.methods.size();c.methods.removeIf(m->m.name.equals("overrideOtherStackedOnMe"));if(old-c.methods.size()!=1)throw new AssertionError("click hook");save(c);changes++;
 c=read(root,p+"client/ClientHandler");
 for(MethodNode m:c.methods)if(m.name.equals("onKeyPressed"))for(var ins:m.instructions.toArray())if(ins instanceof MethodInsnNode a && a.owner.equals("net/minecraft/client/KeyMapping")&&a.name.equals("isDown")){
  InsnList l=new InsnList();l.add(new VarInsnNode(ALOAD,0));l.add(new MethodInsnNode(INVOKEVIRTUAL,"net/minecraftforge/client/event/InputEvent$Key","getInfo","()Lnet/minecraft/client/input/KeyEvent;",false));m.instructions.insertBefore(a,l);a.name="matches";a.desc="(Lnet/minecraft/client/input/KeyEvent;)Z";changes++;
 }save(c);
 c=read(root,p+"util/StackData");for(MethodNode m:c.methods)if(m.name.equals("readItem")){
  clear(m);m.instructions.add(new VarInsnNode(ALOAD,0));m.instructions.add(new MethodInsnNode(INVOKESTATIC,p+"port/AttachmentData","read",m.desc,false));m.instructions.add(new InsnNode(ARETURN));changes++;
 }save(c);
 c=read(root,p+"common/network/ServerPlayHandler");for(MethodNode m:c.methods)if(m.name.equals("handleAttachments")){
  clear(m);m.instructions.add(new VarInsnNode(ALOAD,0));m.instructions.add(new MethodInsnNode(INVOKESTATIC,p+"port/AttachmentMenu","open",m.desc,false));m.instructions.add(new InsnNode(RETURN));changes++;
 }save(c);
 c=read(root,p+"client/screen/AttachmentScreen");ClassNode compiled=read("work33/classes",c.name);
 Set<String> methods=Set.of("extractBackground","isCompatible","mouseScrolled","mouseReleased");
 for(int i=0;i<c.methods.size();i++){MethodNode m=c.methods.get(i);if(methods.contains(m.name)){c.methods.set(i,compiled.methods.stream().filter(x->x.name.equals(m.name)&&x.desc.equals(m.desc)).findFirst().orElseThrow());changes++;}}
 save(c);if(changes!=8)throw new AssertionError(changes);System.out.println("PASS 8 patches: removed inventory click; Z key match; registry decode; authoritative menu; native 3D preview");
 }
}
