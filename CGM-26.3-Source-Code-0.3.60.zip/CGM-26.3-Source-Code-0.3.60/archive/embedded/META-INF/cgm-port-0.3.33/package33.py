from pathlib import Path
import zipfile,json,math,itertools,re,hashlib
base=Path('output/CGM-26.3-Forge66.0.2-0.3.32-3D-BOYALI-EKLENTI-ENVANTER.jar');out=Path('output/CGM-26.3-Forge66.0.2-0.3.33-Z-3D-EKLENTI-MENUSU.jar')
updates={p.relative_to('work33/classes').as_posix():p.read_bytes() for p in Path('work33/classes').rglob('*.class')}
def put(n,d):updates[n]=(json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode()
# Actual vertices include Blockbench element rotations.
def points(d):
 for e in d['elements']:
  for corner in itertools.product(*zip(e['from'],e['to'])):
   p=list(corner);r=e.get('rotation')
   if r:
    axis='xyz'.index(r['axis']);u,v=[i for i in range(3) if i!=axis];t=math.radians(r['angle'])*(-1 if axis==1 else 1);o=r['origin'];x,y=p[u]-o[u],p[v]-o[v];k=1/math.cos(t) if r.get('rescale') else 1;p[u]=o[u]+k*(x*math.cos(t)-y*math.sin(t));p[v]=o[v]+k*(x*math.sin(t)+y*math.cos(t))
   yield p
fits={}
with zipfile.ZipFile(base) as z:
 guns=['pistol','shotgun','rifle','grenade_launcher','bazooka','mini_gun','assault_rifle','machine_pistol','heavy_rifle']
 for g in guns:
  prefix='assets/cgm/models/inventory_assembled/'+g+'/'
  models={n:json.loads(z.read(n)) for n in z.namelist() if n.startswith(prefix)}
  pts=[p for d in models.values() for p in points(d)];t=math.radians(70);q=math.radians(12);w=h=0
  for p in pts:
   x,y,v=[p[i]-8 for i in range(3)];xx=x*math.cos(t)+v*math.sin(t);zz=-x*math.sin(t)+v*math.cos(t);yy=y*math.cos(q)-zz*math.sin(q);w=max(w,2*abs(xx));h=max(h,2*abs(yy))
  s=min(132/w,62/h)*.96
  for n,d in models.items():
   d['display']={'gui':{'rotation':[12,70,0],'translation':[0,0,0],'scale':[s/4.5]*3}}
   new=n.replace('inventory_assembled/','attachment_preview/');put(new,d)
   item=new.replace('/models/','/items/');definition={'model':{'type':'minecraft:model','model':'cgm:'+new.split('/models/')[1][:-5],'tints':[{'type':'minecraft:dye','default':-1} for _ in range(3)]}};put(item,definition)
   if n.endswith('/body.json'):put('assets/cgm/items/attachment_preview/'+g+'.json',definition)
  fits[g]={'width':w*s,'height':h*s,'parts':len(models)}
 for lang in ['tr_tr','en_us']:
  n='assets/cgm/lang/'+lang+'.json';d=json.loads(z.read(n))
  d['info.cgm.attachment_help']='Eklenti takmak / sökmek için silah elindeyken %s.' if lang=='tr_tr' else 'Hold the weapon and press %s to modify attachments.'
  d['container.cgm.attachments.window_help']='Sağ sürükle / Tekerlek' if lang=='tr_tr' else 'Right drag: rotate | Scroll: zoom'
  put(n,d)
 for n in ['META-INF/MANIFEST.MF','META-INF/mods.toml']:updates[n]=z.read(n).replace(b'port-0.3.32',b'port-0.3.33')
 for p in Path('work33/src').rglob('*.java'):updates['META-INF/cgm-port-0.3.33/src/'+p.relative_to('work33/src').as_posix()]=p.read_bytes()
 for n in ['Patch33.java','package33.py','Verify33.java','linkage.txt','regression.txt','test_menu.py']:
  p=Path('work33',n)
  if p.exists():updates['META-INF/cgm-port-0.3.33/'+n]=p.read_bytes()
 put('META-INF/cgm-port-0.3.33/validation.json',{'preview_bounds':fits,'in_game_test':False,'isolated_menu_checks':21,'bytecode_verified_methods':54,'unresolved_links':0})
 updates['CGM-0.3.33-OKU.txt']='''0.3.33 — Z ile 3D eklenti menüsü
Silah ana elindeyken Z: eklenti menüsünü açar. Eski envanterde silaha sağ tıklayarak eklenti takma kaldırıldı.
Soldaki uyumlu yuvalara eklentiyi koyarak tak; çıkararak sök. Shift+tık desteklenir.
Menüdeki silah ve takılan parçalar gerçek 3D modellerdir. Renkler korunur.
Önizleme: sağ tuşla sürükleyerek 3D döndür, sol tuşla taşı, tekerlekle yakınlaştır.
Boyalı eklentiler registry-aware ItemStack codec ile kaydedilir/okunur.
Menü açılırken reload durur. Menüde kullanılan silahın slotu kilitlidir.
Eski CGM dosyasını mods klasöründen çıkarıp bunu koy. Framework dahildir.
İstemci ve sunucuda aynı sürümü kullan. Oyun içi test yapılmadı.
'''.encode()
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as dest:
  for n in z.namelist():dest.writestr(n,updates.pop(n,z.read(n)))
  for n,b in updates.items():dest.writestr(n,b)
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 for n in z.namelist():
  if n.endswith('.json'):json.loads(z.read(n))
print('PASS: 9 assembled native 3D menu previews; archive/JSON integrity');print(out);print(hashlib.sha256(out.read_bytes()).hexdigest())
