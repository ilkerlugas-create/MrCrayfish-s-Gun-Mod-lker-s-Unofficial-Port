from pathlib import Path
import zipfile,hashlib,json
ROOT=Path(__file__).resolve().parent
base=ROOT.parent/'output/CGM-26.3-Forge66.0.2-0.3.39-F5-ESKI-SWAY-FIX.jar'
out=ROOT.parent/'output/CGM-26.3-Forge66.0.2-0.3.40-SUSTURUCU-POMPALI.jar'
updates={}
for folder in ['classes','patched']:
 for p in (ROOT/folder).rglob('*.class'):updates[p.relative_to(ROOT/folder).as_posix()]=p.read_bytes()
expected={'com/mrcrayfish/guns/common/GunModifiers$1.class','com/mrcrayfish/guns/entity/ProjectileEntity.class','com/mrcrayfish/guns/port/ShotgunBalance.class'}
assert set(updates)==expected,set(updates)
with zipfile.ZipFile(base) as z:
 # Same armor, exhaustion, death message and difficulty behavior as CGM bullets.
 updates['data/cgm/damage_type/shotgun_pellet.json']=z.read('data/cgm/damage_type/bullet.json')
 for tag in ['bypasses_cooldown','is_projectile']:
  name='data/minecraft/tags/damage_type/'+tag+'.json'
  content=json.loads(z.read(name)) if name in z.namelist() else {'replace':False,'values':[]}
  assert content.get('replace',False)==False
  if 'cgm:shotgun_pellet' not in content['values']:content['values'].append('cgm:shotgun_pellet')
  updates[name]=json.dumps(content,indent=2).encode()
 gun=json.loads(z.read('data/cgm/guns/shotgun.json'))
 assert gun['projectile']['damage']==18 and gun['general']['projectileAmount']==5
 sounds=json.loads(z.read('assets/cgm/sounds.json'))
 for kind in ['pistol','shotgun','rifle','assault_rifle','machine_pistol','heavy_rifle']:
  data=json.loads(z.read('data/cgm/guns/'+kind+'.json'))
  key=data['sounds']['silencedFire'].removeprefix('cgm:')
  resource=sounds[key]['sounds'][0]['name'].removeprefix('cgm:')
  suppressed=z.read('assets/cgm/sounds/'+resource+'.ogg')
  assert suppressed!=z.read('assets/cgm/sounds/item/'+kind+'/fire.ogg')
for folder in ['src','tests']:
 for p in (ROOT/folder).rglob('*.java'):updates['META-INF/cgm-port-0.3.40/'+p.relative_to(ROOT).as_posix()]=p.read_bytes()
for name in ['Patch40.java','build.py','verify.py','package.py']:
 updates['META-INF/cgm-port-0.3.40/'+name]=(ROOT/name).read_bytes()
updates['META-INF/cgm-port-0.3.40/validation.json']=json.dumps({
 'base_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),
 'silencer':{'volume_multiplier':.28,'gain_change_db':-11.056839,
             'range_multiplier_preserved':.25,'six_distinct_existing_suppressed_samples_verified':True},
 'shotgun':{'close_range_blocks':5,'standard_body_shell_hp':18,'standard_head_shell_hp':20,
            'pellets':5,'body_pellet_hp':3.6,'head_pellet_hp':4,
            'cooldown_bypass':'new cgm:shotgun_pellet damage type only',
            'limits':'Full hit with standard unmodified shotgun, no armor/resistance. Misses, mixed head/body hits, attachments and enchantments continue to affect damage.'},
 'checks':['Java 25 compile against real Minecraft 26.3 / Forge 66.0.2','39 damage/sound modifier checks','Shotgun damage type parsed with Minecraft 26.3 DamageType.DIRECT_CODEC after Bootstrap.bootStrap','ASM verification for modified classes','Existing F5, sway, pistol, models, network codecs and other classes preserved'],
 'in_game_test':False},ensure_ascii=False,indent=2).encode()
updates['CGM-0.3.40-OKU.txt']='''0.3.40 — Susturucu sesi ve pompalı hasarı
Minecraft 26.3 / Forge 66.0.2 / Java 25
Taban: 0.3.39 F5-ESKI-SWAY-FIX.

SUSTURUCU
Susturucu artık yalnızca duyulma mesafesini değil, atış sesinin seviyesini de azaltır.
Ayrı susturuculu ses örnekleri korunur; ses çarpanı 0.28 olur (öncekinden yaklaşık 11 dB düşük).
Değişiklik hem atış yapan oyuncuya hem diğer oyunculara gönderilen ses verisine uygulanır.

POMPALI
5 blok ve daha yakın mesafede, standart pompalıyla zırhsız/dirençsiz hedefe tam isabet:
- Gövde: 9 kalp = 18 HP toplam; 5 saçma x 3.6 HP.
- Kafa: 10 kalp = 20 HP toplam; 5 saçma x 4 HP.
Karışık kafa/gövde isabetinde toplam orantılıdır; ıskalayan saçma hasar vermez.
Zırh, direnç, kalkan, büyü ve eklentilerin mevcut etkileri korunur.
Susturucunun mevcut hasar azaltma etkisi de korunur; belirtilen değerler eklentisiz standart pompalı içindir.
Saçmaların birbirini hasar bekleme süresinde engellememesi için yalnızca pompalıya özel bir hasar türü eklendi.
Diğer silahların hasar ve bekleme süresi davranışı korunur.

KURULUM
Oyunu kapatıp önceki CGM JAR'ını bu dosyayla değiştir. Aynı anda iki CGM JAR'ı bırakma.
Çok oyunculuda istemci ve sunucuya aynı sürümü kur.

DOĞRULAMA
Gerçek hedef API'leriyle derleme, hasar/ses hesapları ve JAR kontrolleri geçti.
Oyun içi ses/hasar testi bu ortamda yapılmadı.
'''.encode()
with zipfile.ZipFile(base) as z:
 for name in ['META-INF/MANIFEST.MF','META-INF/mods.toml']:
  updates[name]=z.read(name).replace(b'port-0.3.39',b'port-0.3.40')
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as d:
  for info in z.infolist():d.writestr(info,updates.pop(info.filename,z.read(info.filename)))
  for name,data in updates.items():d.writestr(name,data)
with zipfile.ZipFile(base) as a,zipfile.ZipFile(out) as b:
 assert b.testzip() is None
 assert len(b.namelist())==len(set(b.namelist()))
 changed={n for n in a.namelist() if a.read(n)!=b.read(n)}
 assert changed=={'com/mrcrayfish/guns/common/GunModifiers$1.class','com/mrcrayfish/guns/entity/ProjectileEntity.class','META-INF/MANIFEST.MF','META-INF/mods.toml'},changed
 for n in b.namelist():
  if n.endswith('.json'):json.loads(b.read(n))
 assert json.loads(b.read('data/minecraft/tags/damage_type/bypasses_cooldown.json'))=={'replace':False,'values':['cgm:shotgun_pellet']}
 assert not any(n.startswith(('net/minecraft/','org/joml/')) for n in b.namelist())
 print('PASS: default 18 HP/5 pellets verified, six suppressed audio routes valid, shotgun-only cooldown tag, archive integrity; all unrelated entries unchanged')
print(out)
print('SHA256',hashlib.sha256(out.read_bytes()).hexdigest())
