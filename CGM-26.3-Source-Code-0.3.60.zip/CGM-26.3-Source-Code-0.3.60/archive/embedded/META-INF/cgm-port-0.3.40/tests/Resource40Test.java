import java.util.zip.ZipFile;
import java.nio.charset.StandardCharsets;
import com.google.gson.JsonParser;
import com.mojang.serialization.JsonOps;
import net.minecraft.world.damagesource.DamageType;
public class Resource40Test {
 public static void main(String[] args)throws Exception {
  net.minecraft.SharedConstants.tryDetectVersion();
  net.minecraft.server.Bootstrap.bootStrap();
  try(ZipFile jar=new ZipFile(args[0])) {
   var e=jar.getEntry("data/cgm/damage_type/shotgun_pellet.json");
   String json=new String(jar.getInputStream(e).readAllBytes(),StandardCharsets.UTF_8);
   DamageType type=DamageType.DIRECT_CODEC.parse(JsonOps.INSTANCE,JsonParser.parseString(json)).getOrThrow();
   if(!type.msgId().equals("cgm.bullet"))throw new AssertionError("death message changed");
   if(type.exhaustion()!=.05F)throw new AssertionError("exhaustion changed");
   net.minecraft.server.Bootstrap.realStdoutPrintln("PASS: new shotgun damage type accepted by Minecraft 26.3's actual codec");
  }
 }
}
