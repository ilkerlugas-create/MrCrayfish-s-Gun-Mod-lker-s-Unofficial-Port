package com.mrcrayfish.guns.port;

import com.mrcrayfish.guns.interfaces.IGunModifier;

public final class Balance40Test {
    static int checks;
    static void near(double a,double b,double tolerance,String text) {
        if(!Double.isFinite(a)||Math.abs(a-b)>tolerance)throw new AssertionError(text+": "+a+" vs "+b);
        checks++;
    }
    public static void main(String[] args)throws Exception {
        int pellets=5;float shellDamage=18F,perPellet=shellDamage/pellets;
        for(double distance:new double[]{0,1,3,4.99,5}) {
            float headPellet=(float)(perPellet*ShotgunBalance.multiplier(true,distance*distance,1.25));
            near(perPellet*pellets,18,1E-6,"body total at "+distance+" blocks");
            near(headPellet*pellets,20,1E-6,"head total at "+distance+" blocks");
        }
        near(ShotgunBalance.multiplier(true,25.0001,1.25),1.25,0,"outside close range preserved");
        near(ShotgunBalance.multiplier(false,1,1.75),1.75,0,"other guns preserved");
        near(ShotgunBalance.multiplier(true,Double.NaN,1.25),1.25,0,"invalid distance safe");
        // Mixed hits stay proportional to pellets; no single pellet gets the
        // entire shell's 18/20 HP, and misses do not create damage.
        for(int body=0;body<=5;body++)for(int head=0;head<=5-body;head++) {
            float total=body*perPellet+head*(float)(perPellet*ShotgunBalance.multiplier(true,4,1.25));
            near(total,body*3.6+head*4,2E-6,"mixed hit total");
            if(total>20.00001F)throw new AssertionError("overpowered pellet total");
        }
        Class<?> type=Class.forName("com.mrcrayfish.guns.common.GunModifiers$1");
        var constructor=type.getDeclaredConstructor();constructor.setAccessible(true);
        IGunModifier silencer=(IGunModifier)constructor.newInstance();
        if(!silencer.silencedFire())throw new AssertionError("suppressed sample selection lost");
        near(silencer.modifyFireSoundVolume(1F),.28,1E-7,"suppressed gain");
        near(silencer.modifyFireSoundVolume(.5F),.14,1E-7,"gain composes with other modifiers");
        near(silencer.modifyFireSoundRadius(80),20,0,"existing range preserved");
        near(new IGunModifier(){}.modifyFireSoundVolume(1F),1,0,"unsuppressed default unchanged");
        near(silencer.modifyProjectileDamage(4),4,0,"volume change does not alter damage modifier");
        System.out.println("PASS: "+checks+" checks; 18/20 HP shell totals, mixed/missed pellets, close-range boundary, other guns and real patched silencer modifier");
    }
}
