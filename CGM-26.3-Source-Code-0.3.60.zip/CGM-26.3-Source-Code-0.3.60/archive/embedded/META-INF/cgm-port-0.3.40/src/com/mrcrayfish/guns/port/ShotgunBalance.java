package com.mrcrayfish.guns.port;

import com.mrcrayfish.guns.entity.ProjectileEntity;
import com.mrcrayfish.guns.init.ModDamageTypes;
import com.mrcrayfish.guns.init.ModItems;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/** Shotgun-only balance. Uses normal armor/shield/enchantment damage handling. */
public final class ShotgunBalance {
    private static final double CLOSE_RANGE_SQUARED = 25.0;
    private static final ResourceKey<DamageType> PELLET = ResourceKey.create(
            Registries.DAMAGE_TYPE, Identifier.fromNamespaceAndPath("cgm", "shotgun_pellet"));
    private ShotgunBalance() {}

    private static boolean isShotgun(ProjectileEntity projectile) {
        return projectile.getWeapon().getItem() == ModItems.SHOTGUN.get();
    }

    static double multiplier(boolean shotgun, double distanceSquared, double normal) {
        // Default shell = 18 HP / 5 pellets. At <= 5 blocks a head pellet is
        // 4 HP, so five body pellets total 18 HP and five head pellets 20 HP.
        return shotgun && distanceSquared >= 0.0 && distanceSquared <= CLOSE_RANGE_SQUARED
                ? 20.0 / 18.0 : normal;
    }

    public static double headMultiplier(double normal, ProjectileEntity projectile, Vec3 hit) {
        LivingEntity shooter = projectile.getShooter();
        if (shooter == null || hit == null) return normal;
        return multiplier(isShotgun(projectile), shooter.getEyePosition().distanceToSqr(hit), normal);
    }

    public static DamageSource source(RegistryAccess registries, ProjectileEntity projectile, LivingEntity shooter) {
        if (!isShotgun(projectile)) return ModDamageTypes.Sources.projectile(registries, projectile, shooter);
        // Only this new damage type bypasses hurt cooldown. Five pellets must
        // all count; do not globally bypass cooldown for CGM's other weapons.
        return new DamageSource(registries.lookupOrThrow(Registries.DAMAGE_TYPE).getOrThrow(PELLET), projectile, shooter);
    }
}
