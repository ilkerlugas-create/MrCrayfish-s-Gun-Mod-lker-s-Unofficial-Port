import java.nio.file.*;
import java.util.zip.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.tree.analysis.*;

public final class Patch40 implements Opcodes {
    static ClassNode read(ZipFile z,String name)throws Exception {
        ClassNode c=new ClassNode();new ClassReader(z.getInputStream(z.getEntry(name+".class"))).accept(c,0);return c;
    }
    static void write(ClassNode c,Path root)throws Exception {
        ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);
        byte[] bytes=w.toByteArray();ClassNode checked=new ClassNode();new ClassReader(bytes).accept(checked,0);
        for(MethodNode m:checked.methods)if((m.access&(ACC_ABSTRACT|ACC_NATIVE))==0)new Analyzer<>(new BasicVerifier()).analyze(checked.name,m);
        Path p=root.resolve(c.name+".class");Files.createDirectories(p.getParent());Files.write(p,bytes);
    }
    public static void main(String[] args)throws Exception {
        try(ZipFile z=new ZipFile(args[0])) {
            ClassNode silencer=read(z,"com/mrcrayfish/guns/common/GunModifiers$1");
            if(silencer.methods.stream().anyMatch(m->m.name.equals("modifyFireSoundVolume")))throw new AssertionError("already has volume override");
            MethodNode volume=new MethodNode(ACC_PUBLIC,"modifyFireSoundVolume","(F)F",null,null);
            volume.instructions.add(new VarInsnNode(FLOAD,1));
            volume.instructions.add(new LdcInsnNode(.28F));
            volume.instructions.add(new InsnNode(FMUL));
            volume.instructions.add(new InsnNode(FRETURN));
            silencer.methods.add(volume);
            write(silencer,Path.of(args[1]));

            ClassNode projectile=read(z,"com/mrcrayfish/guns/entity/ProjectileEntity");
            int headHooks=0,sourceHooks=0;
            for(MethodNode m:projectile.methods)if(m.name.equals("onHitEntity")) {
                for(var ins:m.instructions.toArray())if(ins instanceof MethodInsnNode call) {
                    if(call.owner.equals("java/lang/Double")&&call.name.equals("doubleValue")) {
                        InsnList hook=new InsnList();hook.add(new VarInsnNode(ALOAD,0));hook.add(new VarInsnNode(ALOAD,2));
                        hook.add(new MethodInsnNode(INVOKESTATIC,"com/mrcrayfish/guns/port/ShotgunBalance","headMultiplier",
                            "(DLcom/mrcrayfish/guns/entity/ProjectileEntity;Lnet/minecraft/world/phys/Vec3;)D",false));
                        m.instructions.insert(call,hook);headHooks++;
                    }
                    if(call.owner.equals("com/mrcrayfish/guns/init/ModDamageTypes$Sources")&&call.name.equals("projectile")) {
                        call.owner="com/mrcrayfish/guns/port/ShotgunBalance";call.name="source";sourceHooks++;
                    }
                }
            }
            if(headHooks!=1||sourceHooks!=1)throw new AssertionError(headHooks+"/"+sourceHooks);
            write(projectile,Path.of(args[1]));
            System.out.println("PASS: silencer volume override + single shotgun head/source hooks; modified bytecode verified");
        }
    }
}
