from pathlib import Path
import zipfile,json,hashlib
base=Path('output/CGM-26.3-Forge66.0.2-0.3.35-Z-PISTOL-HOLD.jar')
out=Path('output/CGM-26.3-Forge66.0.2-0.3.36-FPS-F5-MOTION.jar')
updates={p.relative_to('work36/classes').as_posix():p.read_bytes() for p in Path('work36/classes/com/mrcrayfish/guns/port').glob('RunAnimation*.class')}
assert len(updates)==2
for p in Path('work36/src').rglob('*.java'):updates['META-INF/cgm-port-0.3.36/src/'+p.relative_to('work36/src').as_posix()]=p.read_bytes()
for p in Path('work36/stubs').rglob('*.java'):updates['META-INF/cgm-port-0.3.36/test-fixtures/'+p.relative_to('work36/stubs').as_posix()]=p.read_bytes()
updates['META-INF/cgm-port-0.3.36/package.py']=Path('work36/package.py').read_bytes()
updates['META-INF/cgm-port-0.3.36/validation.json']=json.dumps({'base_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),'changes':['Shared per-player sprint timeline for FPS and F5','Identical sprint offsets and angles mapped to player-model coordinates','Both arms transformed as a rigid pair for two-handed grips; gun inherits primary arm','Removed independent F5 gait bob because first-person bobbing is disabled in base','Left handed and weapon grip scaling; aim/shoot/reload/config suppression shared'],'isolated_checks':77,'external_api_refs':'Every non-JDK external reference already exists in input JAR','in_game_test':False,'visual_limits':'Camera perspective and base first/third-person rigs differ; movement deltas and timing matched, not pixel-identical rendering'},indent=2).encode()
updates['CGM-0.3.36-OKU.txt']='''0.3.36 — FPS / F5 hareket eşleştirmesi
Koşu durumu ve geçişi oyuncu başına ortaktır; F5 geçişinde animasyon yeniden başlamaz.
FPS koşu hareketinin açıları ve kaymaları F5 kol koordinatlarına dönüştürülür.
İki elle tutuşta kollar birlikte hareket eder; silah tutan koldan dönüşümü devralır.
FPS'te bağımsız yürüme sallantısı kapalı olduğundan F5'e sonradan eklenen farklı sallantı kaldırıldı.
Nişan/ateş/reload ve koşu animasyonu ayarı her iki görünümde aynı koşu geçişini kullanır.
Z menüsü ve önceki tabanca tutuşu korunur.
Eski CGM JAR'ını çıkar, bu dosyayı koy ve oyunu yeniden başlat. Çok oyunculuda aynı sürümü kullan.
77 izole hareket kontrolü geçti. Oyun içi görsel test yapılmadı.
Kamera açısı ve temel karakter rig'i farklıdır; eşleşen kısım hareket zamanlaması ve hareket dönüşümüdür.
'''.encode()
with zipfile.ZipFile(base) as z:
 for n in ['META-INF/MANIFEST.MF','META-INF/mods.toml']:updates[n]=z.read(n).replace(b'port-0.3.35',b'port-0.3.36')
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as d:
  for n in z.namelist():d.writestr(n,updates.pop(n,z.read(n)))
  for n,b in updates.items():d.writestr(n,b)
with zipfile.ZipFile(base) as a,zipfile.ZipFile(out) as b:
 assert b.testzip() is None
 assert {n for n in a.namelist() if a.read(n)!=b.read(n)}=={'com/mrcrayfish/guns/port/RunAnimation.class','META-INF/MANIFEST.MF','META-INF/mods.toml'}
 assert not any(n.startswith('net/minecraft/') for n in b.namelist())
 for n in b.namelist():
  if n.endswith('.json'):json.loads(b.read(n))
print('PASS: archive integrity; existing resources, key fixes, pistol pose, reload and weapon systems unchanged')
print(out.resolve())
