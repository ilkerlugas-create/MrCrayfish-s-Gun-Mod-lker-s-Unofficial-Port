package com.mrcrayfish.guns.port;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mrcrayfish.guns.client.render.IHeldAnimation;
import com.mrcrayfish.guns.client.handler.AimingHandler;
import com.mrcrayfish.guns.common.*;
import com.mrcrayfish.guns.item.GunItem;
import com.mrcrayfish.guns.Config;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.player.Player;
public class MotionTest {
 static int checks;
 static void eq(double a,double b){if(Math.abs(a-b)>1e-5)throw new AssertionError(a+" != "+b);checks++;}
 static ModelPart part(float x){ModelPart p=new ModelPart();p.x=x;p.y=2;p.xRot=-1.3F;p.yRot=.2F;p.zRot=.05F;return p;}
 static double[] hand(ModelPart p){double[] m=RunAnimation.matrix(p.xRot,p.yRot,p.zRot);return new double[]{p.x+m[1]*10,p.y+m[4]*10,p.z+m[7]*10};}
 static IHeldAnimation animation=new IHeldAnimation(){public void applyPlayerModelRotation(Player p,ModelPart r,ModelPart l,ModelPart h,InteractionHand hand,float a){}public void applyHeldItemTransforms(Player p,InteractionHand h,float a,PoseStack pose,SubmitNodeCollector c){}};
 static void third(Player p,ModelPart r,ModelPart l){RunAnimation.thirdPerson(animation,p,r,l,new ModelPart(),InteractionHand.MAIN_HAND,0);}
 public static void main(String[] args){
  Minecraft mc=Minecraft.getInstance();Player p=mc.player;Gun gun=((GunItem)p.stack.item).gun;
  ModelPart r=part(-5),l=part(5);third(p,r,l);eq(r.y,2);eq(l.y,2); // no independent F5 walking bob
  p.sprint=true;
  for(int tick=1;tick<=5;tick++){
   p.tickCount=tick;PoseStack fp=new PoseStack();RunAnimation.firstPerson(gun,HumanoidArm.RIGHT,fp,0);
   r=part(-5);l=part(5);double[] before=hand(r),other=hand(l);third(p,r,l);double[] after=hand(r),otherAfter=hand(l);
   eq(after[0]-before[0],-fp.x*16);eq(after[1]-before[1],-fp.y*16);eq(after[2]-before[2],0);
   double d1=0,d2=0;for(int k=0;k<3;k++){d1+=Math.pow(other[k]-before[k],2);d2+=Math.pow(otherAfter[k]-after[k],2);}eq(d1,d2);
   double[] rb=RunAnimation.matrix(-1.3F,.2F,.05F),ra=RunAnimation.matrix(r.xRot,r.yRot,r.zRot);
   double[] move=RunAnimation.matrix(Math.toRadians(-fp.pitch),Math.toRadians(-fp.yaw),0);
   for(int i=0;i<3;i++)for(int j=0;j<3;j++){double expected=0;for(int k=0;k<3;k++)expected+=move[i*3+k]*rb[k*3+j];eq(ra[i*3+j],expected);}
   PoseStack again=new PoseStack();RunAnimation.firstPerson(gun,HumanoidArm.RIGHT,again,0);eq(fp.yaw,again.yaw); // F5 does not advance timer twice
  }
  AimingHandler.get().aiming=true;for(int i=6;i<=10;i++){p.tickCount=i;third(p,part(-5),part(5));}
  PoseStack stopped=new PoseStack();RunAnimation.firstPerson(gun,HumanoidArm.RIGHT,stopped,0);eq(stopped.yaw,0);
  AimingHandler.get().aiming=false;gun.general.grip=GripType.ONE_HANDED;p.arm=HumanoidArm.LEFT;
  for(int i=11;i<=15;i++){p.tickCount=i;third(p,part(-5),part(5));}
  r=part(-5);l=part(5);third(p,r,l);eq(r.x,-5);eq(r.y,2);PoseStack left=new PoseStack();RunAnimation.firstPerson(gun,HumanoidArm.LEFT,left,0);eq(left.yaw,-10.5);
  Config.CLIENT.display.sprintAnimation.value=false;for(int i=16;i<=20;i++){p.tickCount=i;third(p,part(-5),part(5));}
  PoseStack disabled=new PoseStack();RunAnimation.firstPerson(gun,HumanoidArm.LEFT,disabled,0);eq(disabled.yaw,0);
  System.out.println("PASS: "+checks+" checks: FPS/F5 rigid motion, shared timeline, grip distance, left hand, walking identity, aim/config transitions. Isolated fixtures, not in-game.");
 }
}
