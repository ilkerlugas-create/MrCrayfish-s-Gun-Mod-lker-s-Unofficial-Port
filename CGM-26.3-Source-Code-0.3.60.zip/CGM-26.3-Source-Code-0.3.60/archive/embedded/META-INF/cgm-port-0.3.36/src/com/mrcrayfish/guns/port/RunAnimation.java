package com.mrcrayfish.guns.port;
import java.util.Map;
import java.util.WeakHashMap;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.mrcrayfish.guns.client.KeyBinds;
import com.mrcrayfish.guns.Config;
import com.mrcrayfish.guns.client.handler.AimingHandler;
import com.mrcrayfish.guns.client.render.IHeldAnimation;
import com.mrcrayfish.guns.common.Gun;
import com.mrcrayfish.guns.common.GripType;
import com.mrcrayfish.guns.init.ModSyncedDataKeys;
import com.mrcrayfish.guns.item.GunItem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.player.Player;
public final class RunAnimation {
 private static final Map<Player,State> STATES=new WeakHashMap<>();
 private static final class State {float time,progress;State(float time){this.time=time;}}
 public static float approach(float value,boolean running,float elapsed) {
  float step=Math.max(0F,Math.min(elapsed,1F))/5F;
  return running?Math.min(1F,value+step):Math.max(0F,value-step);
 }
 private static float sample(Player player,float partial) {
  float time=player.tickCount+partial;
  State state=STATES.computeIfAbsent(player,p->new State(time));
  if(time<state.time){state.time=time;state.progress=0;}
  boolean aiming=player.isLocalPlayer()?AimingHandler.get().isAiming():ModSyncedDataKeys.AIMING.getValue(player);
  boolean shooting=player.isLocalPlayer()?KeyBinds.getShootMapping().isDown():ModSyncedDataKeys.SHOOTING.getValue(player);
  boolean running=Config.CLIENT.display.sprintAnimation.get()&&player.isSprinting()&&!aiming&&!shooting&&!ModSyncedDataKeys.RELOADING.getValue(player);
  state.progress=approach(state.progress,running,time-state.time);state.time=time;
  return state.progress*state.progress*(3F-2F*state.progress);
 }
 private static float amount(GripType grip){return grip==GripType.BAZOOKA||grip==GripType.MINI_GUN?.4F:grip==GripType.ONE_HANDED?.7F:1F;}
 public static void firstPerson(Gun gun,HumanoidArm arm,PoseStack pose,float partial) {
  Player player=Minecraft.getInstance().player;if(player==null)return;
  float eased=sample(player,partial),side=arm==HumanoidArm.LEFT?-1F:1F,a=amount(gun.getGeneral().getGripType());
  pose.translate(-.08F*side*eased*a,-.12F*eased,0);
  pose.rotateDegrees(Axis.YP,15F*side*eased*a);
  pose.rotateDegrees(Axis.XP,-8F*eased*a);
 }
 public static void thirdPerson(IHeldAnimation animation,Player player,ModelPart right,ModelPart left,ModelPart head,InteractionHand hand,float aim) {
  aim=F5Aim.progress(player,aim);
  animation.applyPlayerModelRotation(player,right,left,head,hand,aim);
  var stack=player.getMainHandItem();if(!(stack.getItem() instanceof GunItem item))return;
  float partial=Minecraft.getInstance().getDeltaTracker().getGameTimeDeltaPartialTick(true);
  float eased=sample(player,partial);if(eased==0)return;
  if(player.isPassenger()||player.isSleeping()||player.isFallFlying()||player.isVisuallySwimming())return;
  GripType grip=item.getModifiedGun(stack).getGeneral().getGripType();
  boolean isRight=(player.getMainArm()==HumanoidArm.RIGHT)==(hand==InteractionHand.MAIN_HAND);
  float side=isRight?1F:-1F,a=amount(grip);
  ModelPart primary=isRight?right:left;
  // Convert camera space into the mirrored, Y-down player model coordinates.
  double[] rotation=matrix(Math.toRadians(8F*eased*a),Math.toRadians(-15F*side*eased*a),0);
  double[] gripRotation=matrix(primary.xRot,primary.yRot,primary.zRot);
  double px=primary.x+gripRotation[1]*10,py=primary.y+gripRotation[4]*10,pz=primary.z+gripRotation[7]*10;
  float dx=.08F*side*eased*a*16F,dy=.12F*eased*16F;
  transform(primary,rotation,px,py,pz,dx,dy);
  if(grip!=GripType.ONE_HANDED)transform(isRight?left:right,rotation,px,py,pz,dx,dy);
 }
 // Rz * Ry * Rx, matching ModelPart's rotationZYX convention.
 static double[] matrix(double x,double y,double z){
  double cx=Math.cos(x),sx=Math.sin(x),cy=Math.cos(y),sy=Math.sin(y),cz=Math.cos(z),sz=Math.sin(z);
  return new double[]{cz*cy,cz*sy*sx-sz*cx,cz*sy*cx+sz*sx,sz*cy,sz*sy*sx+cz*cx,sz*sy*cx-cz*sx,-sy,cy*sx,cy*cx};
 }
 static void transform(ModelPart part,double[] r,double px,double py,double pz,float dx,float dy){
  double x=part.x-px,y=part.y-py,z=part.z-pz;
  part.x=(float)(px+r[0]*x+r[1]*y+r[2]*z+dx);
  part.y=(float)(py+r[3]*x+r[4]*y+r[5]*z+dy);
  part.z=(float)(pz+r[6]*x+r[7]*y+r[8]*z);
  double[] b=matrix(part.xRot,part.yRot,part.zRot),c=new double[9];
  for(int i=0;i<3;i++)for(int j=0;j<3;j++)for(int k=0;k<3;k++)c[3*i+j]+=r[3*i+k]*b[3*k+j];
  double ry=Math.asin(Math.max(-1D,Math.min(1D,-c[6])));
  part.yRot=(float)ry;
  if(Math.abs(Math.cos(ry))>1e-6){part.xRot=(float)Math.atan2(c[7],c[8]);part.zRot=(float)Math.atan2(c[3],c[0]);}
  else {part.xRot=0;part.zRot=(float)Math.atan2(-c[1],c[4]);}
 }
 public static void heldItem(IHeldAnimation animation,Player player,InteractionHand hand,float aim,PoseStack pose,SubmitNodeCollector collector){
  // ItemInHandLayer already inherits the transformed primary arm: no second motion.
  animation.applyHeldItemTransforms(player,hand,F5Aim.progress(player,aim),pose,collector);
 }
}
