import com.mrcrayfish.guns.port.MotionLimits;
import java.nio.file.*;
import org.objectweb.asm.*;import org.objectweb.asm.tree.*;
public class MotionRegression {
 public static void main(String[] args)throws Exception {
  // Crossing the yaw seam must remain a small movement, not a full turn.
  for(float[] pair:new float[][]{{359,-1},{-359,1},{360,0},{-360,0},{3,3},{-3,-3},{90,6},{-90,-6}})
   if(Math.abs(MotionLimits.sway(pair[0])-pair[1])>1e-5)throw new AssertionError("seam/clamp "+pair[0]);
  for(float angle=-1440;angle<=1440;angle+=.25F)if(Math.abs(MotionLimits.sway(angle))>6)throw new AssertionError("sway bound");
  for(float angle:new float[]{Float.NaN,Float.POSITIVE_INFINITY,Float.NEGATIVE_INFINITY})if(MotionLimits.sway(angle)!=0)throw new AssertionError("nonfinite");
  ClassNode c=new ClassNode();new ClassReader(Files.readAllBytes(Path.of(args[0]))).accept(c,0);
  MethodNode bob=c.methods.stream().filter(m->m.name.equals("applyBobbingTransforms")).findFirst().orElseThrow();
  if(bob.instructions.size()!=1||bob.instructions.getFirst().getOpcode()!=Opcodes.RETURN)throw new AssertionError("legacy limb-driven bob still active");
  MethodNode sway=c.methods.stream().filter(m->m.name.equals("applySwayTransforms")).findFirst().orElseThrow();
  int count=0;for(var i:sway.instructions)if(i instanceof MethodInsnNode m&&m.name.equals("rotateDegrees")) {
   if(!(i.getPrevious() instanceof MethodInsnNode limit)||!limit.owner.equals("com/mrcrayfish/guns/port/MotionLimits"))throw new AssertionError("unbounded sway");count++;
  }
  if(count!=3)throw new AssertionError("rotations");
  System.out.println("PASS: yaw seam, finite bounds, invalid inputs, native bob, and all three sway call sites.");
 }
}
