import java.nio.file.*;import java.util.*;import java.util.jar.*;
import org.objectweb.asm.*;import org.objectweb.asm.tree.*;import org.objectweb.asm.tree.analysis.*;
public class Patch23 implements Opcodes {
 public static void main(String[] args)throws Exception {
  int bob=0,sway=0,help=0;
  try(JarFile jar=new JarFile(args[0])) {
   for(String name:List.of("com/mrcrayfish/guns/client/handler/GunRenderingHandler","com/mrcrayfish/guns/item/GunItem","com/mrcrayfish/guns/item/AmmoItem")) {
    ClassNode c=new ClassNode();new ClassReader(jar.getInputStream(jar.getJarEntry(name+".class"))).accept(c,0);
    for(MethodNode m:c.methods) {
     if(name.endsWith("GunRenderingHandler")&&m.name.equals("applyBobbingTransforms")) {
      // Vanilla's camera bob uses CameraEntityRenderState.bob/walk distance.
      // Limb walkAnimation is NOT its inverse: preserve native bob unchanged.
      m.instructions.clear();m.tryCatchBlocks.clear();if(m.localVariables!=null)m.localVariables.clear();
      m.instructions.add(new InsnNode(RETURN));bob++;
     }
     if(name.endsWith("GunRenderingHandler")&&m.name.equals("applySwayTransforms")) {
      for(var n:m.instructions.toArray())if(n instanceof MethodInsnNode call&&call.name.equals("rotateDegrees")) {
       m.instructions.insertBefore(n,new MethodInsnNode(INVOKESTATIC,"com/mrcrayfish/guns/port/MotionLimits","sway","(F)F",false));sway++;
      }
     }
     if(name.endsWith("/GunItem")&&m.name.equals("appendHoverText")) {
      for(var n:m.instructions.toArray())if(n.getOpcode()==RETURN){InsnList add=new InsnList();add.add(new VarInsnNode(ALOAD,4));add.add(new MethodInsnNode(INVOKESTATIC,"com/mrcrayfish/guns/port/AmmoHelp","reload","(Ljava/util/function/Consumer;)V",false));m.instructions.insertBefore(n,add);help++;}
     }
    }
    if(name.endsWith("/AmmoItem")) {
     if(c.methods.stream().anyMatch(m->m.name.equals("appendHoverText")))throw new IllegalStateException("existing ammo tooltip");
     MethodNode m=new MethodNode(ACC_PUBLIC,"appendHoverText","(Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/Item$TooltipContext;Lnet/minecraft/world/item/component/TooltipDisplay;Ljava/util/function/Consumer;Lnet/minecraft/world/item/TooltipFlag;)V",null,null);
     m.instructions.add(new VarInsnNode(ALOAD,1));m.instructions.add(new VarInsnNode(ALOAD,4));m.instructions.add(new MethodInsnNode(INVOKESTATIC,"com/mrcrayfish/guns/port/AmmoHelp","ammo","(Lnet/minecraft/world/item/ItemStack;Ljava/util/function/Consumer;)V",false));m.instructions.add(new InsnNode(RETURN));c.methods.add(m);help++;
    }
    ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);byte[] b=w.toByteArray();ClassNode check=new ClassNode();new ClassReader(b).accept(check,0);
    for(MethodNode m:check.methods)if((m.access&(ACC_NATIVE|ACC_ABSTRACT))==0)new Analyzer<>(new BasicVerifier()).analyze(check.name,m);
    Path p=Path.of(args[1],name+".class");Files.createDirectories(p.getParent());Files.write(p,b);
   }
  }
  if(bob!=1||sway!=3||help!=2)throw new IllegalStateException("patch counts "+bob+","+sway+","+help);
  System.out.println("PASS: native bob preserved, 3 sway rotations bounded, 2 tooltip hooks; bytecode verified.");
 }
}
