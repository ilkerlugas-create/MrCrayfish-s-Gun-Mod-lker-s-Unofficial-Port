import json,zipfile,pathlib,hashlib
base=pathlib.Path('output/CGM-26.3-Forge66.0.2-0.3.22-TURKCE-ANIMASYON-MUHIMMAT.jar')
out=pathlib.Path('output/CGM-26.3-Forge66.0.2-0.3.23-HAREKET-BAZOOKA-FIX.jar')
with zipfile.ZipFile(base) as z:data={n:z.read(n) for n in z.namelist()}
def put(n,d):data[n]=(json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode()
n='assets/cgm/models/special/gun/bazooka.json'
d=json.loads(data[n]);d['textures']['2']='cgm:item/bazooka_reticle';d['textures']['particle']='cgm:item/bazooka';put(n,d)
data['assets/cgm/textures/item/bazooka_reticle.png']=data['assets/cgm/textures/effect/red_dot_reticle.png']
for lang in ['tr_tr','en_us']:
 n=f'assets/cgm/lang/{lang}.json';d=json.loads(data[n]);d.update({'info.cgm.reload_help':'Mühimmat envanterdeyken %s ile doldur.','info.cgm.ammo_for':'Kullanan silah: %s'});put(n,d)
for p in pathlib.Path('work/fix23/classes').rglob('*.class'):
 if p.relative_to('work/fix23/classes').as_posix().startswith('com/mrcrayfish/'):
  data[p.relative_to('work/fix23/classes').as_posix()]=p.read_bytes()
for n in ['META-INF/mods.toml','META-INF/MANIFEST.MF']:data[n]=data[n].replace(b'port-0.3.22',b'port-0.3.23')
for p in pathlib.Path('work/fix23').rglob('*'):
 if p.suffix in ['.java','.py']:data['META-INF/cgm-port-0.3.23/'+p.relative_to('work/fix23').as_posix()]=p.read_bytes()

# Resolve every registered item's inherited textures, not just files on disk.
def model(n,seen=None):
 seen=set() if seen is None else seen
 assert n not in seen,('cycle',n)
 seen.add(n);ns,path=n.split(':');d=json.loads(data[f'assets/{ns}/models/{path}.json'])
 parent=d.get('parent','');merged={}
 if parent.startswith('cgm:'):merged=model(parent,seen)
 merged.update(d.get('textures',{}));return merged
checked=0
for n in data:
 if n.startswith('assets/cgm/items/') and n.endswith('.json'):
  definition=json.loads(data[n])['model'];textures=model(definition['model'])
  for k,t in textures.items():
   seen=set()
   while t.startswith('#'):
    assert t not in seen,(n,t);seen.add(t);t=textures[t[1:]]
   if t.startswith('cgm:'):
    assert t.startswith(('cgm:item/','cgm:block/')),(n,t,'wrong atlas')
    assert f'assets/cgm/textures/{t.split(":",1)[1]}.png' in data,(n,t)
  checked+=1
assert checked==25,checked
for n,b in data.items():
 if n.endswith('.json'):json.loads(b)
put('META-INF/cgm-port-0.3.23-validation.json',{'version':'0.3.23','base_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),'changes':['Preserve native camera walk bob; remove incorrect inverse using limb animation and 4x/8x amplification','Bound all cosmetic sway rotations and wrap yaw seam','Reduce sprint rotation and maintain two-handed F5 grip with shared gait translation','Repair bazooka reticle item-atlas mapping','Dynamic ammo compatibility and remappable reload-key tooltips in Turkish'],'item_model_texture_chains_checked':checked,'validation':{'motion_regression':'passed: yaw seam, bounds, invalid input, native bob and all sway sites','ammo_regression':'passed: 8 combinations and sprint transitions','muzzle_flash_regression':'passed: original failure reproduced; all 4 patched vertices complete','api_links':'passed: 11 helper methods against exact Minecraft and Forge APIs','bytecode_verifier':'passed'},'runtime_gameplay_test':'not run'})
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 for n,b in data.items():z.writestr(n,b)
with zipfile.ZipFile(out) as z:assert z.testzip() is None
print(out);print('PASS: all 25 item texture chains use item-atlas sprites; all JSON and ZIP entries valid.')
