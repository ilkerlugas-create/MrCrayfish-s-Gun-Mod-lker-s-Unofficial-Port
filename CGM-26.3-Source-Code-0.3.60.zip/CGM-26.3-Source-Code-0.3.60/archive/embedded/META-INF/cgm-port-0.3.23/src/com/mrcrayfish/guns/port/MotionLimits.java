package com.mrcrayfish.guns.port;

/** Limits apply only to cosmetic sway, never to the player's aim. */
public final class MotionLimits {
 public static float sway(float angle) {
  if(!Float.isFinite(angle))return 0F;
  angle=angle%360F;
  if(angle>=180F)angle-=360F;
  if(angle< -180F)angle+=360F;
  return Math.max(-6F,Math.min(6F,angle));
 }
}
