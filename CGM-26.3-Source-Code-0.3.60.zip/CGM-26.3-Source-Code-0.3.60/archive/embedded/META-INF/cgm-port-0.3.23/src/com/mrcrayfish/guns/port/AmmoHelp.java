package com.mrcrayfish.guns.port;

import java.util.function.Consumer;
import com.mrcrayfish.guns.client.KeyBinds;
import com.mrcrayfish.guns.init.ModItems;
import com.mrcrayfish.guns.item.GunItem;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;

public final class AmmoHelp {
 public static void reload(Consumer<Component> tooltip) {
  tooltip.accept(Component.translatable("info.cgm.reload_help",
    KeyBinds.KEY_RELOAD.getTranslatedKeyMessage()).withStyle(ChatFormatting.GREEN));
 }
 public static void ammo(ItemStack stack,Consumer<Component> tooltip) {
  var id=ForgeRegistries.ITEMS.getKey(stack.getItem());
  boolean found=false;
  for(var entry:ModItems.REGISTER.getEntries()) {
   if(entry.get() instanceof GunItem gun && gun.getModifiedGun(gun.getDefaultInstance()).getProjectile().getItem().equals(id)) {
    tooltip.accept(Component.translatable("info.cgm.ammo_for",
      Component.translatable(gun.getDescriptionId())).withStyle(ChatFormatting.GRAY));
    found=true;
   }
  }
  if(found)reload(tooltip);
 }
}
