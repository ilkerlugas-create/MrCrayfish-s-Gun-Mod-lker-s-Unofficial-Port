from pathlib import Path
import subprocess
s={
'net/minecraft/core/NonNullList':'public class NonNullList<T> extends java.util.ArrayList<T>{ public static <T> NonNullList<T> create(){return new NonNullList<>();}}',
'net/minecraft/core/BlockPos':'public record BlockPos(int x){}',
'net/minecraft/core/RegistryAccess':'public interface RegistryAccess{}',
'net/minecraft/resources/Identifier':'public record Identifier(String name){}',
'io/netty/buffer/ByteBuf':'public class ByteBuf {public java.util.List<Object> values=new java.util.ArrayList<>(); public int index; public boolean isReadable(){return index<values.size();} public int readableBytes(){return isReadable()?100:0;}}',
'net/minecraft/network/FriendlyByteBuf':'''public class FriendlyByteBuf extends io.netty.buffer.ByteBuf {
 public FriendlyByteBuf writeBlockPos(net.minecraft.core.BlockPos p){values.add(p);return this;} public net.minecraft.core.BlockPos readBlockPos(){return (net.minecraft.core.BlockPos)values.get(index++);}
 public FriendlyByteBuf writeVarInt(int i){values.add(i);return this;} public int readVarInt(){return (int)values.get(index++);}
 public FriendlyByteBuf writeIdentifier(net.minecraft.resources.Identifier i){values.add(i);return this;} public net.minecraft.resources.Identifier readIdentifier(){return (net.minecraft.resources.Identifier)values.get(index++);}
}''',
'net/minecraft/network/RegistryFriendlyByteBuf':'public class RegistryFriendlyByteBuf extends FriendlyByteBuf {public RegistryFriendlyByteBuf(io.netty.buffer.ByteBuf b,net.minecraft.core.RegistryAccess r){values=b.values;index=b.index;}}',
'net/minecraft/network/codec/StreamCodec':'public interface StreamCodec<B,T>{void encode(B b,T t);T decode(B b);}',
'net/minecraft/world/level/block/entity/BlockEntity':'public class BlockEntity{}',
'com/mrcrayfish/guns/blockentity/WorkbenchBlockEntity':'public class WorkbenchBlockEntity extends net.minecraft.world.level.block.entity.BlockEntity{}',
'net/minecraft/world/level/Level':'''public class Level {public net.minecraft.core.NonNullList<com.mrcrayfish.guns.crafting.WorkbenchRecipe> recipes=net.minecraft.core.NonNullList.create(); public net.minecraft.core.RegistryAccess registryAccess(){return null;} public net.minecraft.world.level.block.entity.BlockEntity getBlockEntity(net.minecraft.core.BlockPos p){return new com.mrcrayfish.guns.blockentity.WorkbenchBlockEntity();}}''',
'net/minecraft/world/entity/player/Player':'public class Player{ public net.minecraft.world.level.Level level(){return new net.minecraft.world.level.Level();}}',
'net/minecraft/world/Container':'public interface Container{}',
'net/minecraft/world/entity/player/Inventory':'public class Inventory implements net.minecraft.world.Container{public Player player=new Player();}',
'com/mrcrayfish/guns/common/container/WorkbenchContainer':'public class WorkbenchContainer{public WorkbenchContainer(int i,net.minecraft.world.Container inv,com.mrcrayfish.guns.blockentity.WorkbenchBlockEntity b){}}',
'com/mrcrayfish/guns/crafting/WorkbenchRecipes':'public class WorkbenchRecipes{public static net.minecraft.core.NonNullList<WorkbenchRecipe> getAll(net.minecraft.world.level.Level l){return l.recipes;}}',
'com/mrcrayfish/guns/crafting/WorkbenchRecipe':'''public class WorkbenchRecipe {private net.minecraft.resources.Identifier id;public int value;public WorkbenchRecipe(int v){value=v;}public net.minecraft.resources.Identifier getId(){return id;}public WorkbenchRecipe withId(net.minecraft.resources.Identifier i){id=i;return this;}public static final net.minecraft.network.codec.StreamCodec<net.minecraft.network.RegistryFriendlyByteBuf,WorkbenchRecipe> STREAM_CODEC=new net.minecraft.network.codec.StreamCodec<>(){public void encode(net.minecraft.network.RegistryFriendlyByteBuf b,WorkbenchRecipe r){b.writeVarInt(r.value);} public WorkbenchRecipe decode(net.minecraft.network.RegistryFriendlyByteBuf b){return new WorkbenchRecipe(b.readVarInt());}};}'''
}
for name,body in s.items():
 p=Path('work/testsrc/'+name+'.java');p.parent.mkdir(parents=True,exist_ok=True);p.write_text('package '+name.rsplit('/',1)[0].replace('/','.')+';\n'+body)
p=Path('work/testsrc/SyncTest.java');p.write_text('''import com.mrcrayfish.guns.port.MenuRecipes;
import com.mrcrayfish.guns.crafting.*;
import net.minecraft.network.*;
import net.minecraft.core.*;
import net.minecraft.world.entity.player.*;
public class SyncTest {
 public static void main(String[] args){
 var level=new net.minecraft.world.level.Level();
 var inv=new Inventory(); var pos=new BlockPos(5);
 var empty=new FriendlyByteBuf(); MenuRecipes.writer(pos,level).accept(empty);
 var menu0=MenuRecipes.create(1,inv,empty); if(!MenuRecipes.get(menu0).isEmpty())throw new AssertionError();
 for(int i=0;i<40;i++)level.recipes.add(new WorkbenchRecipe(i).withId(new net.minecraft.resources.Identifier("cgm:test"+i)));
 var buf=new FriendlyByteBuf();MenuRecipes.writer(pos,level).accept(buf);
 var menu=MenuRecipes.create(2,inv,buf); var recipes=MenuRecipes.get(menu);
 if(recipes.size()!=40)throw new AssertionError();
 for(int i=0;i<40;i++) if(recipes.get(i).value!=i || !recipes.get(i).getId().name().equals("cgm:test"+i))throw new AssertionError();
 if(!MenuRecipes.get(menu0).isEmpty())throw new AssertionError("menu leaked");
 var legacy=new FriendlyByteBuf();legacy.writeBlockPos(pos);if(!MenuRecipes.get(MenuRecipes.create(3,inv,legacy)).isEmpty())throw new AssertionError();
 var bad=new FriendlyByteBuf();bad.writeBlockPos(pos);bad.writeVarInt(-1);try{MenuRecipes.create(4,inv,bad);throw new AssertionError();}catch(IllegalArgumentException expected){}
 System.out.println("PASS: empty, 40 recipes + IDs, menu isolation, legacy data, invalid count (helper runtime with API stubs)");
 }}''')
subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-cp','work/classes','-d','work/testclasses',*map(str,Path('work/testsrc').rglob('*.java'))],check=True)
subprocess.run(['java','-cp','work/testclasses:work/classes','SyncTest'],check=True)
