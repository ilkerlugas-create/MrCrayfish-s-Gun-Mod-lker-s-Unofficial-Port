import java.nio.file.*;
import java.util.jar.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.tree.analysis.*;
public class Patch26 implements Opcodes {
 public static void main(String[] args)throws Exception {
  String helper="com/mrcrayfish/guns/port/MenuRecipes";
  try(JarFile jar=new JarFile(args[0])) {
   for(String name:new String[]{"com/mrcrayfish/guns/block/WorkbenchBlock","com/mrcrayfish/guns/init/ModContainers"}) {
    ClassNode c=new ClassNode();new ClassReader(jar.getInputStream(jar.getJarEntry(name+".class")).readAllBytes()).accept(c,0);
    int edits=0;
    for(MethodNode m:c.methods) {
     if(name.endsWith("WorkbenchBlock")&&m.name.equals("useWithoutItem")) for(var n:m.instructions.toArray()) if(n instanceof InvokeDynamicInsnNode d&&d.desc.equals("(Lnet/minecraft/core/BlockPos;)Ljava/util/function/Consumer;")) {
      m.instructions.insertBefore(n,new VarInsnNode(ALOAD,2));
      m.instructions.set(n,new MethodInsnNode(INVOKESTATIC,helper,"writer","(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/Level;)Ljava/util/function/Consumer;",false));edits++;
     }
     if(name.endsWith("ModContainers")&&m.name.startsWith("lambda$")&&m.desc.equals("(ILnet/minecraft/world/entity/player/Inventory;Lnet/minecraft/network/FriendlyByteBuf;)Lcom/mrcrayfish/guns/common/container/WorkbenchContainer;")) {
      m.instructions.clear();m.tryCatchBlocks.clear();if(m.localVariables!=null)m.localVariables.clear();
      m.instructions.add(new VarInsnNode(ILOAD,0));m.instructions.add(new VarInsnNode(ALOAD,1));m.instructions.add(new VarInsnNode(ALOAD,2));
      m.instructions.add(new MethodInsnNode(INVOKESTATIC,helper,"create",m.desc,false));m.instructions.add(new InsnNode(ARETURN));edits++;
     }
    }
    if(edits!=1)throw new IllegalStateException(name+": "+edits);
    ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);
    Path p=Path.of("work/classes/"+name+".class");Files.createDirectories(p.getParent());Files.write(p,w.toByteArray());
   }
  }
  int count=0;
  try(var files=Files.walk(Path.of("work/classes"))) {
   for(Path p:files.filter(x->x.toString().endsWith(".class")).toList()) {
    ClassNode c=new ClassNode();new ClassReader(Files.readAllBytes(p)).accept(c,0);
    for(MethodNode m:c.methods) {new Analyzer<BasicValue>(new BasicVerifier()).analyze(c.name,m);count++;}
   }
  }
  System.out.println("ASM BasicVerifier passed: "+count+" methods");
 }
}
