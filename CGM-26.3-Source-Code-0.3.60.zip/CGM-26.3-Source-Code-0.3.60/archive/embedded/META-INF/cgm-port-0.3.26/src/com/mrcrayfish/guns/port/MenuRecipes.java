package com.mrcrayfish.guns.port;
import java.util.*;
import java.util.function.Consumer;
import com.mrcrayfish.guns.crafting.*;
import com.mrcrayfish.guns.blockentity.WorkbenchBlockEntity;
import com.mrcrayfish.guns.common.container.WorkbenchContainer;
import net.minecraft.core.*;
import net.minecraft.network.*;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Inventory;
public final class MenuRecipes {
 private static final Map<WorkbenchContainer,NonNullList<WorkbenchRecipe>> MENUS = new WeakHashMap<>();
 public static NonNullList<WorkbenchRecipe> get(WorkbenchContainer menu) {
  return MENUS.getOrDefault(menu,NonNullList.create());
 }
 public static Consumer<FriendlyByteBuf> writer(BlockPos pos, Level level) {
  // Snapshot server recipes on the server thread; do not read client recipe access.
  var recipes=WorkbenchRecipes.getAll(level);
  return data -> {
   data.writeBlockPos(pos);
   var buf=new RegistryFriendlyByteBuf(data,level.registryAccess());
   buf.writeVarInt(recipes.size());
   for(var recipe:recipes) {
    buf.writeIdentifier(recipe.getId());
    WorkbenchRecipe.STREAM_CODEC.encode(buf,recipe);
   }
  };
 }
 public static WorkbenchContainer create(int id, Inventory inventory, FriendlyByteBuf data) {
  if(data==null || data.readableBytes()<8) throw new IllegalArgumentException("Missing workbench opening data");
  var pos=data.readBlockPos();
  var level=inventory.player.level();
  var recipes=NonNullList.<WorkbenchRecipe>create();
  if(data.isReadable()) {
   var buf=new RegistryFriendlyByteBuf(data,level.registryAccess());
   int count=buf.readVarInt();
   if(count<0 || count>4096) throw new IllegalArgumentException("Invalid workbench recipe count: "+count);
   for(int i=0;i<count;i++) {
    var key=buf.readIdentifier();
    recipes.add(WorkbenchRecipe.STREAM_CODEC.decode(buf).withId(key));
   }
  }
  if(!(level.getBlockEntity(pos) instanceof WorkbenchBlockEntity bench)) throw new IllegalStateException("Missing workbench at "+pos);
  var menu=new WorkbenchContainer(id,inventory,bench);
  MENUS.put(menu,recipes);
  return menu;
 }
}
