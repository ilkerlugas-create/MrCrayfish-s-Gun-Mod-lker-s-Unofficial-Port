package com.mrcrayfish.guns.port;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.world.item.ItemStack;
import com.mrcrayfish.guns.client.handler.AimingHandler;
public final class PistolHold {
 public static void apply(PoseStack pose,ItemStack stack,int side) {
  if(!"pistol".equals(ReloadTiming.kind(stack)))return;
  float ads=(float)Math.max(0D,Math.min(1D,AimingHandler.get().getNormalisedAdsProgress()));
  float weight=1F-ads*ads*(3F-2F*ads);
  float partial=net.minecraft.client.Minecraft.getInstance().getDeltaTracker().getGameTimeDeltaPartialTick(true);
  float reload=Math.max(0F,Math.min(1F,com.mrcrayfish.guns.client.handler.ReloadHandler.get().getReloadProgress(partial)));
  weight*=1F-reload*reload*(3F-2F*reload);
  if(weight<=0F)return;
  // Shared parent transform: the gripping hand, gun and attachments stay aligned.
  // Fully fade out at ADS so the existing sight alignment remains exact.
  pose.translate(-.08F*side*weight,.04F*weight,.025F*weight);
  pose.rotateDegrees(Axis.YP,10F*side*weight);
  pose.rotateDegrees(Axis.XP,4F*weight);
 }
}
