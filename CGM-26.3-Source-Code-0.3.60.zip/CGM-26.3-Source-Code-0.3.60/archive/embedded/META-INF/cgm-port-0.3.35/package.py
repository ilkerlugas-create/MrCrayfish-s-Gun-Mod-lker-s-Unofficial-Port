from pathlib import Path
import zipfile,json,hashlib,io
from jawa.cf import ClassFile
base=Path('output/CGM-26.3-Forge66.0.2-0.3.34-Z-MENU-FIX.jar')
out=Path('output/CGM-26.3-Forge66.0.2-0.3.35-Z-PISTOL-HOLD.jar')
updates={p.relative_to('work35/patched').as_posix():p.read_bytes() for p in Path('work35/patched').rglob('*.class')}
updates['com/mrcrayfish/guns/port/PistolHold.class']=Path('work35/classes/com/mrcrayfish/guns/port/PistolHold.class').read_bytes()
for p in [Path('work35/src/com/mrcrayfish/guns/port/PistolHold.java'),Path('work35/Patch35.java'),Path('work35/PoseTest.java'),Path('work35/package.py')]:updates['META-INF/cgm-port-0.3.35/'+p.name]=p.read_bytes()
updates['META-INF/cgm-port-0.3.35/validation.json']=json.dumps({'base_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),'default_attachment_key':'Z (GLFW 90), unchanged and verified','pose':'Pistol only; shared hand/gun parent transform; mirrored left hand; smooth fade to zero at ADS and reload','checks':['ASM BasicVerifier all modified renderer methods','isolated pose tests','archive integrity and unchanged resources'],'in_game_test':False,'visual_match':'Approximation from supplied screenshot; requires in-game visual confirmation'},indent=2).encode()
updates['CGM-0.3.35-OKU.txt']='''0.3.35 — Z ve tabanca tutuşu
Eklenti menüsünün varsayılan tuşu Z'dir.
Daha önce J gibi başka bir tuş atadıysan Kontroller'de yalnızca CGM eklenti tuşunun Sıfırla düğmesine bas; kayıtlı ayarlar korunur.
Tabanca sağ alttan merkeze doğru 10 derece çevrildi, 4 derece yukarı yöneltildi; el ve silah birlikte taşınır.
Sol elde dönüşüm aynalanır. Nişan ve reload sırasında ek tutuş yumuşakça kaldırılır.
Mevcut modeller, boyama, diğer silahlar ve çalışan Z menüsü korunmuştur.
Eski CGM JAR'ını mods klasöründen çıkarıp bunu koy ve oyunu yeniden başlat.
Kod kontrolleri geçti. Oyun içi görsel test yapılmadı; referans eşleşmesi yaklaşık ayarlanmıştır.
'''.encode()
with zipfile.ZipFile(base) as z:
 c=ClassFile(io.BytesIO(z.read('com/mrcrayfish/guns/client/KeyBinds.class')))
 m=next(m for m in c.methods if m.name.value=='<clinit>');ins=list(m.code.disassemble())
 matches=[i for i,x in enumerate(ins) if x.mnemonic=='putstatic' and c.constants.get(x.operands[0].value).name_and_type.name.value=='KEY_ATTACHMENTS']
 assert len(matches)==1
 assert any(x.mnemonic=='bipush' and x.operands[0].value==90 for x in ins[matches[0]-4:matches[0]])
 for n in ['META-INF/MANIFEST.MF','META-INF/mods.toml']:updates[n]=z.read(n).replace(b'port-0.3.34',b'port-0.3.35')
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as d:
  for n in z.namelist():d.writestr(n,updates.pop(n,z.read(n)))
  for n,b in updates.items():d.writestr(n,b)
with zipfile.ZipFile(base) as a,zipfile.ZipFile(out) as b:
 assert b.testzip() is None
 changed=[n for n in a.namelist() if a.read(n)!=b.read(n)]
 assert set(changed)=={'com/mrcrayfish/guns/client/handler/GunRenderingHandler.class','META-INF/MANIFEST.MF','META-INF/mods.toml'},changed
 assert 'net/minecraft/world/item/ItemStack.class' not in b.namelist()
 for n in b.namelist():
  if n.endswith('.json'):json.loads(b.read(n))
print('PASS: default key Z; archive/JSON; no test fixtures packaged; all existing assets and 0.3.34 input fix preserved')
print(out.resolve())
