import java.nio.file.*;import java.util.zip.*;
import jdk.internal.org.objectweb.asm.*;import jdk.internal.org.objectweb.asm.tree.*;import jdk.internal.org.objectweb.asm.tree.analysis.*;
public class Patch35 implements Opcodes {
 public static void main(String[] args)throws Exception {
  String name="com/mrcrayfish/guns/client/handler/GunRenderingHandler.class";
  byte[] bytes;try(ZipFile z=new ZipFile(args[0])){bytes=z.getInputStream(z.getEntry(name)).readAllBytes();}
  int major=((bytes[6]&255)<<8)|(bytes[7]&255);bytes[6]=0;bytes[7]=61;
  ClassNode c=new ClassNode();new ClassReader(bytes).accept(c,0);int count=0;
  for(MethodNode m:c.methods)if(m.name.equals("applyAimingTransforms")){
   InsnList l=new InsnList();l.add(new VarInsnNode(ALOAD,1));l.add(new VarInsnNode(ALOAD,2));l.add(new VarInsnNode(ILOAD,7));
   l.add(new MethodInsnNode(INVOKESTATIC,"com/mrcrayfish/guns/port/PistolHold","apply","(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/world/item/ItemStack;I)V",false));m.instructions.insert(l);count++;
  }
  if(count!=1)throw new AssertionError(count);
  ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);bytes=w.toByteArray();
  ClassNode check=new ClassNode();new ClassReader(bytes).accept(check,0);for(MethodNode m:check.methods)if((m.access&(ACC_ABSTRACT|ACC_NATIVE))==0)new Analyzer<>(new BasicVerifier()).analyze(check.name,m);
  bytes[6]=(byte)(major>>8);bytes[7]=(byte)major;Path p=Path.of("work35/patched",name);Files.createDirectories(p.getParent());Files.write(p,bytes);
  System.out.println("PASS: single shared pistol-pose hook; all GunRenderingHandler methods pass ASM BasicVerifier");
 }
}
