import com.mrcrayfish.guns.port.PistolHold;
import com.mrcrayfish.guns.client.handler.*;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.world.item.ItemStack;
public class PoseTest {
 public static void main(String[] args){
  ItemStack pistol=new ItemStack();PoseStack r=new PoseStack(),l=new PoseStack();
  PistolHold.apply(r,pistol,1);PistolHold.apply(l,pistol,-1);
  if(r.calls!=3||r.x!=-l.x||r.yaw!=-l.yaw||r.y!=l.y||r.pitch!=l.pitch)throw new AssertionError("mirror");
  AimingHandler.get().ads=1;PoseStack ads=new PoseStack();PistolHold.apply(ads,pistol,1);if(ads.calls!=0)throw new AssertionError("ADS");
  AimingHandler.get().ads=0;ReloadHandler.get().progress=1;PoseStack reload=new PoseStack();PistolHold.apply(reload,pistol,1);if(reload.calls!=0)throw new AssertionError("reload");
  ReloadHandler.get().progress=0;pistol.kind="rifle";PoseStack other=new PoseStack();PistolHold.apply(other,pistol,1);if(other.calls!=0)throw new AssertionError("other gun");
  System.out.println("PASS: left/right mirroring; ADS and full reload identity; other weapons untouched (isolated API fixtures)");
 }
}
