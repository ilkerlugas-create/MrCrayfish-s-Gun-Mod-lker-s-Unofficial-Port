from pathlib import Path
import subprocess
cp=':'.join(str(p) for p in Path('/workspace/scratch/efe9d3d72167/work/deps').glob('asm*.jar'))
subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-cp',cp,'-d','work37/tools','work37/Verify37.java'],check=True)
args=[*map(str,Path('/workspace/scratch/efe9d3d72167/work/test-libs').glob('*.jar')),'/workspace/scratch/3d6a260178a7/work/deps/forge.jar','/workspace/scratch/3d6a260178a7/work/deps/eventbus.jar','/workspace/scratch/941f87ec3186/work34/events.jar','/workspace/scratch/efe9d3d72167/work/deps/minecraft-26.3-client.jar','upload/CGM-26.3-Forge66.0.2-0.3.36-FPS-F5-MOTION.jar']
r=subprocess.run(['java','-cp','work37/tools:'+cp,'Verify37',*args],capture_output=True,text=True);print(r.stdout+r.stderr);Path('work37/linkage.txt').write_text(r.stdout+r.stderr);r.check_returncode()
