from pathlib import Path
import subprocess
cp=[Path('work37/compiledeps/base.jar')]+list(Path('/workspace/scratch/941f87ec3186/work/deps').glob('*.jar'))+[Path('/workspace/scratch/36c0e134ba8f/work27/dep-0.jar'),Path('/workspace/scratch/941f87ec3186/work34/events.jar')]
cp=':'.join(str(p.resolve()) for p in cp)
Path('work37/classpath.txt').write_text(cp)
subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','--release','17','-cp',cp,'-d','work37/classes']+[str(p) for p in Path('work37/src').rglob('*.java')],check=True)
