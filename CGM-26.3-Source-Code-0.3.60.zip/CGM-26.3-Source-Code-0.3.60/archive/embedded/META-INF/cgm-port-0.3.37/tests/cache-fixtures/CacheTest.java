import net.minecraft.nbt.*;import net.minecraft.world.item.*;import net.minecraft.world.item.component.*;import net.minecraft.core.component.*;import com.mrcrayfish.guns.port.*;import java.lang.reflect.*;import java.util.*;
public class CacheTest {
 static int checks;static void check(boolean b,String s){if(!b)throw new AssertionError(s);checks++;}
 static ItemStack stack(int ammo,int color){CompoundTag t=new CompoundTag();t.putInt("AmmoCount",ammo);t.putInt("Color",color);ItemStack s=new ItemStack(1);s.set(DataComponents.CUSTOM_DATA,new CustomData(t));return s;}
 static Object local()throws Exception{Field f=StackReadCache.class.getDeclaredField("LOCAL");f.setAccessible(true);return ((ThreadLocal<?>)f.get(null)).get();}
 static int size(String name)throws Exception{Object c=local();Field f=c.getClass().getDeclaredField(name);f.setAccessible(true);return ((Map<?,?>)f.get(c)).size();}
 public static void main(String[] a)throws Exception{
  ItemStack s=stack(12,0x3399cc);int start=CustomData.copies;CompoundTag first=StackReadCache.read(s);
  for(int i=0;i<10000;i++)StackReadCache.read(s);
  check(CustomData.copies-start==1,"stable reads must copy NBT once");
  ItemStack other=stack(7,0xaa3300);check(StackReadCache.read(other).getIntOr("AmmoCount",0)==7,"same item must have independent data");
  CompoundTag changed=s.get(DataComponents.CUSTOM_DATA).copyTag();changed.putInt("AmmoCount",11);s.set(DataComponents.CUSTOM_DATA,new CustomData(changed));
  check(StackReadCache.read(s).getIntOr("AmmoCount",0)==11,"ammo updates immediately");check(first.getIntOr("AmmoCount",0)==12,"older snapshot remains independent");
  s.remove(DataComponents.CUSTOM_DATA);check(StackReadCache.read(s).isEmpty(),"component removal invalidates");
  s=stack(5,0x224466);DyeBridge.sync(s);check(s.get(DataComponents.DYED_COLOR).rgb()==0x224466,"paint rendered");int sets=s.sets;for(int i=0;i<100;i++)DyeBridge.sync(s);check(s.sets==sets,"stable color does not rewrite component");
  changed=s.get(DataComponents.CUSTOM_DATA).copyTag();changed.putInt("Color",0x112233);s.set(DataComponents.CUSTOM_DATA,new CustomData(changed));DyeBridge.sync(s);check(s.get(DataComponents.DYED_COLOR).rgb()==0x112233,"new paint immediate");s.remove(DataComponents.CUSTOM_DATA);DyeBridge.sync(s);check(s.get(DataComponents.DYED_COLOR)==null,"paint removal immediate");
  CompoundTag part=new CompoundTag();part.putInt("Color",0x987654);int before=AttachmentData.decodes;
  ItemStack returned=StackReadCache.readItem(part);returned.setCount(0);returned.remove(DataComponents.CUSTOM_DATA);
  for(int i=0;i<10000;i++)StackReadCache.readItem(part);
  check(AttachmentData.decodes-before==1,"stable attachment decoded once");
  returned=StackReadCache.readItem(part);check(returned.getCount()==1,"returned stacks own count");check(returned.get(DataComponents.CUSTOM_DATA).copyTag().getIntOr("Color",0)==0x987654,"returned stacks preserve components");
  net.minecraftforge.server.ServerLifecycleHooks.server=new net.minecraft.server.MinecraftServer();before=AttachmentData.decodes;StackReadCache.readItem(part);check(AttachmentData.decodes==before+1,"server context invalidates");
  net.minecraftforge.server.ServerLifecycleHooks.server.registries=new net.minecraft.core.RegistryAccess.Frozen(){};before=AttachmentData.decodes;StackReadCache.readItem(part);check(AttachmentData.decodes==before+1,"registry reload invalidates");
  net.minecraftforge.server.ServerLifecycleHooks.server=null;before=AttachmentData.decodes;StackReadCache.readItem(part);check(AttachmentData.decodes==before+1,"disconnect invalidates");
  CompoundTag delayed=new CompoundTag();delayed.putInt("id",3);AttachmentData.ready=false;check(StackReadCache.readItem(delayed).isEmpty(),"failed codec empty");AttachmentData.ready=true;check(!StackReadCache.readItem(delayed).isEmpty(),"failed codec retried");
  Object main=local();Object[] worker=new Object[1];Thread t=new Thread(()->{try{worker[0]=local();StackReadCache.read(stack(10,1));}catch(Exception e){throw new RuntimeException(e);}});t.start();t.join();check(worker[0]!=null&&worker[0]!=main,"client and server thread isolation");
  for(int i=0;i<700;i++){StackReadCache.read(stack(i,i));CompoundTag x=new CompoundTag();x.putInt("n",i);StackReadCache.readItem(x);}
  check(size("tags")<=256&&size("items")<=256,"both caches bounded");
  check(StackReadCache.readItem(null).isEmpty()&&StackReadCache.readItem(new CompoundTag()).isEmpty(),"empty inputs");
  System.out.println("PASS: "+checks+" production-bytecode checks for cache invalidation, defensive ownership, color updates, registry changes, failure retry, bounds and thread isolation.");
  System.out.println("Operation count: 10,001 stable NBT reads -> 1 deep copy; 10,001 stable attachment reads -> 1 decode (isolated fixtures, not FPS).");
 }
}