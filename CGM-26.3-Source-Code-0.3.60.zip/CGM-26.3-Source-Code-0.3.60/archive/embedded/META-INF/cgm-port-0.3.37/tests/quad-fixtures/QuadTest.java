import java.util.*;import com.mojang.blaze3d.vertex.*;import com.mrcrayfish.framework.api.client.model.renderer.StandaloneModelRenderer;import net.minecraft.client.renderer.*;import net.minecraft.client.renderer.block.dispatch.*;import net.minecraft.client.resources.model.geometry.*;import net.minecraft.core.*;
public class QuadTest {
 public static void main(String[] args){List<SubmitNodeCollector.CustomGeometryRenderer> jobs=new ArrayList<>();List<String> sheets=new ArrayList<>();SubmitNodeCollector c=(p,t,r)->{jobs.add(r);sheets.add(t.name());};
 BlockStateModelPart part=new BlockStateModelPart(){public int materialFlags(){return 1;}public List<BakedQuad> getQuads(Direction d){if(d!=null&&d!=Direction.NORTH)return List.of();return List.of(new BakedQuad(d==null?10:0,new BakedQuad.MaterialInfo(true)),new BakedQuad(d==null?11:1,new BakedQuad.MaterialInfo(false)));}};
 StandaloneModelRenderer.submitDraw(c,part,new PoseStack(),.25F,.5F,1F,123,456);StandaloneModelRenderer.submitDraw(c,part,new PoseStack(),1.5F,-.2F,.5F,789,321);
 if(QuadInstance.instances!=0)throw new AssertionError("must allocate inside deferred callback");
 int count=0;for(int i=1;i>=0;i--){final int index=i;List<String> got=new ArrayList<>();jobs.get(i).render(new PoseStack.Pose(),(p,q,v)->{int expected=q.materialInfo().isTinted()?(index==0?0xff4080ff:0xffff0080):-1;if(v.color!=expected||v.light!=(index==0?123:789)||v.overlay!=(index==0?456:321))throw new AssertionError("tint/light/overlay changed");got.add(q.id()+":"+v.color+":"+v.light+":"+v.overlay);});if(got.size()!=4)throw new AssertionError("geometry lost");count+=got.size();}
 if(!sheets.equals(List.of("translucent","translucent")))throw new AssertionError("sheet changed");
 System.out.println("PASS: "+count+" mixed tinted/untinted quads, all faces, deferred submission, clamped RGB, light/overlay and translucent sheet.");System.out.println("QuadInstance allocations for two model submissions: "+QuadInstance.instances);
 }
}