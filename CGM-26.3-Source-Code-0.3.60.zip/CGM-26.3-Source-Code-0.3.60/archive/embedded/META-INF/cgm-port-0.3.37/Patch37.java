import java.nio.file.*;import java.util.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;
public class Patch37 implements Opcodes {
 static Path base=Path.of("work37/base"),compiled=Path.of("work37/classes"),out=Path.of("work37/patched");
 static List<String> changed=new ArrayList<>();
 static ClassNode read(Path root,String name)throws Exception{ClassNode c=new ClassNode();new ClassReader(Files.readAllBytes(root.resolve(name+".class"))).accept(c,0);return c;}
 static void save(ClassNode c)throws Exception{ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);Path p=out.resolve(c.name+".class");Files.createDirectories(p.getParent());Files.write(p,w.toByteArray());}
 public static void main(String[] args)throws Exception{
  Map<String,Set<String>> targets=new LinkedHashMap<>();String p="com/mrcrayfish/guns/";
  targets.put(p+"common/Gun",Set.of("getScopeStack","getScope","getAttachment","hasAttachmentEquipped","getAdditionalDamage","hasAmmo"));
  targets.put(p+"item/GunItem",Set.of("getModifiedGun","isBarVisible","getBarWidth","appendHoverText"));
  targets.put(p+"item/IColored",Set.of("hasColor","getColor"));
  targets.put(p+"client/handler/GunRenderingHandler",Set.of("applyWeaponScale","renderWeapon","renderAttachments"));
  targets.put(p+"client/util/PropertyHelper",Set.of("getReticleColor"));
  int reads=0,decodes=0;
  for(var target:targets.entrySet()){
   ClassNode c=read(base,target.getKey());Set<String> found=new HashSet<>();
   for(var m:c.methods)if(target.getValue().contains(m.name)){
    int changes=0;
    for(var ins:m.instructions)if(ins instanceof MethodInsnNode a && a.owner.equals(p+"util/StackData")){
     if(a.name.equals("copy")){a.owner=p+"port/StackReadCache";a.name="read";reads++;changes++;}
     else if(a.name.equals("readItem") && c.name.equals(p+"common/Gun")){a.owner=p+"port/StackReadCache";decodes++;changes++;}
    }
    if(changes==0)throw new AssertionError("Missing expected read in "+c.name+"."+m.name);
    found.add(m.name);changed.add(c.name+" "+m.name+" "+m.desc);
   }
   if(!found.equals(target.getValue()))throw new AssertionError("Targets missing: "+target);
   save(c);
  }
  if(reads!=16||decodes!=3)throw new AssertionError("Read/decode counts "+reads+"/"+decodes);
  String container=p+"common/container/AttachmentContainer";
  ClassNode original=read(base,container),replacement=read(compiled,container);
  for(var f:replacement.fields)if(f.name.startsWith("cgmPreview"))original.fields.add(f);
  MethodNode method=replacement.methods.stream().filter(m->m.name.equals("previewStack")).findFirst().orElseThrow();
  original.methods.removeIf(m->m.name.equals("previewStack"));original.methods.add(method);save(original);changed.add(container+" "+method.name+" "+method.desc);
  for(String name:List.of("StackReadCache","StackReadCache$Cache","RunAnimation","RunAnimation$State","InventoryAttachments","AttachmentPreview","WorkbenchPreview","DyeBridge")){
   ClassNode c=read(compiled,p+"port/"+name);save(c);for(var m:c.methods)changed.add(c.name+" "+m.name+" "+m.desc);
  }
  ClassNode c=read(compiled,"com/mrcrayfish/framework/api/client/model/renderer/StandaloneModelRenderer");save(c);for(var m:c.methods)changed.add(c.name+" "+m.name+" "+m.desc);
  Files.write(Path.of("work37/changed-methods.txt"),changed);
  System.out.println("PASS: 16 audited read-only callsites, 3 defensive decode caches, cached menu preview, 9 optimized/helper classes; unrelated bytecode retained.");
 }
}
