from pathlib import Path
import shutil,subprocess
root=Path('work37/menu-fixtures');shutil.copytree('/workspace/scratch/941f87ec3186/work33/testsrc',root,dirs_exist_ok=True)
p=root/'net/minecraft/nbt/CompoundTag.java';s=p.read_text();s=s[:-1]+'''public boolean equals(Object o){return o instanceof CompoundTag t && m.equals(t.m);} public int hashCode(){return m.hashCode();}}''';p.write_text(s)
p=root/'net/minecraft/world/item/ItemStack.java';s=p.read_text();s=s[:-1]+'''public int getCount(){return count;}public static boolean isSameItemSameComponents(ItemStack a,ItemStack b){return a.item==b.item && a.data.equals(b.data);}}''';p.write_text(s)
p=root/'com/mrcrayfish/guns/util/StackData.java';s=p.read_text();s=s[:-1]+'''public static void set(ItemStack s,CompoundTag t){s.data=t.copy();}}''';p.write_text(s)
s=Path('work37/src/com/mrcrayfish/guns/common/container/AttachmentContainer.java').read_text().replace('import net.minecraft.nbt.NbtOps;','').replace('import net.minecraft.resources.RegistryOps;','')
(root/'com/mrcrayfish/guns/common/container/AttachmentContainer.java').write_text(s)
(root/'PreviewCacheTest.java').write_text('''import net.minecraft.world.item.*;import net.minecraft.world.entity.player.*;import net.minecraft.world.inventory.*;import com.mrcrayfish.guns.common.container.*;import com.mrcrayfish.guns.item.*;import com.mrcrayfish.guns.item.attachment.*;import com.mrcrayfish.guns.port.*;import net.minecraft.nbt.*;
public class PreviewCacheTest {static int checks;static void check(boolean b,String s){if(!b)throw new AssertionError(s);checks++;}record Part(IAttachment.Type getType)implements IAttachment{}
static ItemStack part(ItemStack preview){return AttachmentData.read(preview.data.getCompoundOrEmpty("Attachments").getCompoundOrEmpty("BARREL"),null);}
public static void main(String[] args){Player p=new Player();p.client=true;Inventory inv=new Inventory(p);ItemStack gun=new ItemStack(new GunItem(),1);gun.data.put("AmmoCount",12);inv.setItem(0,gun);AttachmentContainer menu=new AttachmentContainer(1,inv);ItemStack silencer=new ItemStack(new Part(IAttachment.Type.BARREL),1);silencer.data.put("Color",0x445566);silencer.data.put("Name","custom");menu.getSlot(1).set(silencer);
int start=AttachmentData.writes;ItemStack a=menu.previewStack();for(int n=0;n<1000;n++)menu.previewStack();check(AttachmentData.writes-start==1,"unchanged previews must encode once");check(part(a).data.m.get("Color").equals(0x445566),"initial dye");check(part(a).data.m.get("Name").equals("custom"),"initial name");
a.data.put("AmmoCount",999);check(menu.previewStack().data.m.get("AmmoCount").equals(12),"caller cannot change cached preview");
gun.data.put("AmmoCount",11);check(menu.previewStack().data.m.get("AmmoCount").equals(11),"ammo invalidation");
silencer.data.put("Color",0xaa2255);check(part(menu.previewStack()).data.m.get("Color").equals(0xaa2255),"same slot in-place dye invalidation");
silencer.data.put("Name","renamed");check(part(menu.previewStack()).data.m.get("Name").equals("renamed"),"name invalidation");
silencer.data.put("Enchant",3);check(part(menu.previewStack()).data.m.get("Enchant").equals(3),"enchantment invalidation");
menu.getSlot(1).set(ItemStack.EMPTY);check(menu.previewStack().data.getCompoundOrEmpty("Attachments").m.isEmpty(),"removal invalidation");
menu.getSlot(1).set(silencer);check(!part(menu.previewStack()).isEmpty(),"install invalidation");
Player p2=new Player();p2.client=true;Inventory i2=new Inventory(p2);ItemStack g2=new ItemStack(new GunItem(),1);i2.setItem(0,g2);AttachmentContainer m2=new AttachmentContainer(2,i2);check(m2.previewStack().data.getCompoundOrEmpty("Attachments").m.isEmpty(),"second menu independent");check(!part(menu.previewStack()).isEmpty(),"first menu unaffected");
check(gun.data.getCompoundOrEmpty("Attachments").m.isEmpty(),"client preview does not modify weapon");
System.out.println("PASS: "+checks+" preview cache tests for equipment/dye/name/enchantment/ammo updates, independent menus, and copy ownership.");System.out.println("Operation count: 1,001 unchanged one-attachment previews -> 1 codec encode; baseline encoded on every preview (isolated fixtures, not FPS).");}}
''')
subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','-d','work37/menu-tests',*map(str,root.rglob('*.java'))],check=True)
out=[]
for n in ['MenuTest','PreviewCacheTest']:
 r=subprocess.run(['java','-cp','work37/menu-tests',n],capture_output=True,text=True);print(r.stdout+r.stderr,end='');r.check_returncode();out.append(r.stdout)
Path('work37/menu-results.txt').write_text(''.join(out))
