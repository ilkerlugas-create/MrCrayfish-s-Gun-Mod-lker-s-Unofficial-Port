from pathlib import Path
import zipfile,json,hashlib
root=Path('work37');base=Path('upload/CGM-26.3-Forge66.0.2-0.3.36-FPS-F5-MOTION.jar');out=Path('output/CGM-26.3-Forge66.0.2-0.3.37-OPTIMIZE.jar')
updates={p.relative_to(root/'patched').as_posix():p.read_bytes() for p in (root/'patched').rglob('*.class')}
patched=set(updates)
meta='META-INF/cgm-port-0.3.37/'
for p in (root/'src').rglob('*.java'):updates[meta+'src/'+p.relative_to(root/'src').as_posix()]=p.read_bytes()
for directory in ['motion-fixtures','cache-fixtures','menu-fixtures','quad-fixtures']:
 for p in (root/directory).rglob('*.java'):updates[meta+'tests/'+directory+'/'+p.relative_to(root/directory).as_posix()]=p.read_bytes()
for name in ['compile.py','Patch37.java','Verify37.java','package37.py','run_cache_tests.py','run_motion_tests.py','run_menu_tests.py','run_quad_tests.py','verify_links.py','changed-methods.txt','cache-results.txt','motion-results.txt','menu-results.txt','quad-results.txt','linkage.txt']:
 updates[meta+name]=(root/name).read_bytes()
validation={
 'base_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),
 'version':'1.3.7-26.3-port-0.3.37',
 'changes':[
  'Bounded thread-local CustomData snapshots at 16 audited read-only callsites; component identity immediately invalidates ammo/color/attachment updates',
  'Three Gun attachment/scope decode paths cache successful decoding and return independent ItemStack copies; registry context changes invalidate',
  'Attachment menu encodes preview only on weapon, attachment components/count, or registry changes',
  'Prepared drag/zoom preview reused while source/angles/zoom are unchanged',
  'Reusable model identifiers, supported-item set and attachment type array; removed redundant attachment copy',
  'Dye sync avoids rewriting unchanged components',
  'F5 matrices preserve original math while removing steady-state temporary double arrays',
  'Standalone renderer allocates one QuadInstance per submitted model, with tint computed once'
 ],
 'verification':{'modified_methods_bytecode_verified':58,'unresolved_api_links':0,'cache_production_bytecode_checks':20,'menu_source_checks':34,'prior_motion_checks':77,'seeded_matrix_equivalence_poses':10000,'quad_baseline_vs_optimized':'Same color/light/overlay/geometry; 14 vs 2 QuadInstance allocations across two submissions','jar_integrity':True,'existing_assets_unchanged':True,'existing_network_and_reload_code_unchanged':True},
 'operation_counts_isolated_fixtures':{'stable_NBT_reads':10001,'NBT_deep_copies':1,'stable_attachment_reads':10001,'attachment_decodes':1,'stable_single_attachment_previews':1001,'preview_encodes':1},
 'limits':{'in_game_test':False,'in_game_fps_benchmark':False,'dedicated_server_launch_test':False,'note':'Compile and bytecode/API checks use the available Minecraft 26.3 and Forge 66.0.2 artifacts. Runtime behavior checks use isolated fixtures; they do not establish a specific FPS improvement.'},
 'runtime_class_entries':sorted(patched)
}
updates[meta+'validation.json']=(json.dumps(validation,indent=2)+'\n').encode()
updates['CGM-0.3.37-OKU.txt']='''CGM 26.3 / Forge 66.0.2 — 0.3.37 OPTİMİZASYON

Kurulum:
Oyunu kapat. mods klasöründeki önceki CGM JAR'ını çıkarıp bu dosyayı koy.
Aynı anda iki CGM sürümü bulundurma. Framework bu JAR'ın içindedir.
Çok oyunculuda istemci ve sunucuda aynı CGM sürümünü kullan.

Değişiklikler:
- Silah çiziminde tekrar edilen NBT kopyaları ve eklenti çözümlemeleri azaltıldı.
- Z menüsünde silah/eklenti değişmedikçe önizleme yeniden kodlanmıyor.
- Boya, eklenti, mermi veya kayıt verisi değişince önbellek yenileniyor.
- F5 animasyonunun geçici matris dizileri kaldırıldı; hareket hesabı korundu.
- Model çizimindeki geçici nesneler ve yinelenen renk işlemleri azaltıldı.
- Tezgah ve envanterin model kimlikleri tekrar kullanılabiliyor.

Doğrulama:
58 değişen metot için bytecode kontrolü, 0 çözülemeyen API bağlantısı.
Önbellek, eklenti menüsü, boya ve FPS/F5 hareket regresyonları geçti.
10.000 farklı pozda yeni matris hesabı öncekiyle eşleşti.
Modeller, dokular, tuşlar, ağ paketleri, reload ve silah başına mermi kodu değiştirilmedi.
Kaynaklar ve kontrol sonuçları META-INF/cgm-port-0.3.37/ içindedir.

Bu ortamda oyun başlatılarak test veya FPS ölçümü yapılmadı.
Belirli bir FPS artışı garanti edilmez. Devam eden takılma varsa F3 ekranı,
latest.log ve sorunun görüldüğü sahne üzerinden ayrıca incelenebilir.
'''.encode()
with zipfile.ZipFile(base) as z:
 for n in ['META-INF/MANIFEST.MF','META-INF/mods.toml']:
  updates[n]=z.read(n).replace(b'port-0.3.36',b'port-0.3.37')
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as d:
  for n in z.namelist():d.writestr(n,updates.pop(n,z.read(n)))
  for n,b in updates.items():d.writestr(n,b)
with zipfile.ZipFile(base) as a,zipfile.ZipFile(out) as b:
 assert b.testzip() is None
 assert len(b.namelist())==len(set(b.namelist()))
 actual_changes={n for n in a.namelist() if a.read(n)!=b.read(n)}
 expected=(patched&set(a.namelist()))|{'META-INF/MANIFEST.MF','META-INF/mods.toml'}
 assert actual_changes==expected,(actual_changes^expected)
 for n in a.namelist():
  if n.startswith(('assets/','data/','com/mrcrayfish/guns/network/')) or n.endswith(('ReloadTracker.class','ReloadHandler.class','WeaponInstance.class','ClientHandler.class','KeyBinds.class','cgm.mixins.json')):assert a.read(n)==b.read(n),n
 for n in b.namelist():
  assert not n.startswith(('net/minecraft/','net/minecraftforge/'))
  if n.endswith('.json'):json.loads(b.read(n))
 # All built-in inventory/preview model identifiers still resolve.
 guns=['pistol','shotgun','rifle','grenade_launcher','bazooka','mini_gun','assault_rifle','machine_pistol','heavy_rifle']
 for g in guns:
  for prefix in ['inventory_assembled','attachment_preview']:
   assert f'assets/cgm/items/{prefix}/{g}/body.json' in b.namelist()
 print('PASS: ZIP/JSON integrity, exact class change allowlist, all existing assets/network/reload/input code retained; 9 built-in gun preview models present.')
print(out.resolve())
print('bytes',out.stat().st_size,'SHA256',hashlib.sha256(out.read_bytes()).hexdigest())
(root/'validation.json').write_text(json.dumps(validation,indent=2))
