from pathlib import Path
import shutil,subprocess
root=Path('work37/motion-fixtures');shutil.copytree('work37/base/META-INF/cgm-port-0.3.36/test-fixtures',root,dirs_exist_ok=True)
p=root/'com/mrcrayfish/guns/port/MotionTest.java';p.write_bytes(Path('work37/base/META-INF/cgm-port-0.3.36/src/com/mrcrayfish/guns/port/MotionTest.java').read_bytes())
(root/'com/mrcrayfish/guns/port/MatrixTest.java').write_text('''package com.mrcrayfish.guns.port;
import net.minecraft.client.model.geom.ModelPart;import java.util.Random;
public class MatrixTest {
 static void reference(ModelPart p,double[] r,double px,double py,double pz,float dx,float dy){
  double x=p.x-px,y=p.y-py,z=p.z-pz;
  p.x=(float)(px+r[0]*x+r[1]*y+r[2]*z+dx);p.y=(float)(py+r[3]*x+r[4]*y+r[5]*z+dy);p.z=(float)(pz+r[6]*x+r[7]*y+r[8]*z);
  double[] b=RunAnimation.matrix(p.xRot,p.yRot,p.zRot),c=new double[9];
  for(int i=0;i<3;i++)for(int j=0;j<3;j++)for(int k=0;k<3;k++)c[3*i+j]+=r[3*i+k]*b[3*k+j];
  double ry=Math.asin(Math.max(-1D,Math.min(1D,-c[6])));p.yRot=(float)ry;
  if(Math.abs(Math.cos(ry))>1e-6){p.xRot=(float)Math.atan2(c[7],c[8]);p.zRot=(float)Math.atan2(c[3],c[0]);}else{p.xRot=0;p.zRot=(float)Math.atan2(-c[1],c[4]);}
 }
 static void eq(float a,float b){if(!Float.isFinite(a)||Math.abs(a-b)>1e-6)throw new AssertionError(a+" vs "+b);}
 public static void main(String[] args){Random rnd=new Random(37);for(int i=0;i<10000;i++){
  ModelPart a=new ModelPart(),b=new ModelPart();a.x=b.x=rnd.nextFloat()*20-10;a.y=b.y=rnd.nextFloat()*20-10;a.z=b.z=rnd.nextFloat()*20-10;
  a.xRot=b.xRot=(float)(rnd.nextDouble()*6-3);a.yRot=b.yRot=i<10?(float)(Math.PI/2):(float)(rnd.nextDouble()*6-3);a.zRot=b.zRot=(float)(rnd.nextDouble()*6-3);
  double[] r=RunAnimation.matrix(rnd.nextDouble(),rnd.nextDouble(),rnd.nextDouble());double x=rnd.nextDouble()*8,y=rnd.nextDouble()*8,z=rnd.nextDouble()*8;float dx=rnd.nextFloat(),dy=rnd.nextFloat();
  reference(a,r,x,y,z,dx,dy);RunAnimation.transform(b,r,x,y,z,dx,dy);eq(a.x,b.x);eq(a.y,b.y);eq(a.z,b.z);eq(a.xRot,b.xRot);eq(a.yRot,b.yRot);eq(a.zRot,b.zRot);
 }System.out.println("PASS: optimized transform matches original matrix multiplication across 10,000 seeded poses.");}
}''')
# Compile fixtures, but execute the shipped production RunAnimation bytecode first.
subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','-cp','work37/patched','-d','work37/motion-tests',*map(str,root.rglob('*.java'))],check=True)
out=[]
for n in ['MotionTest','MatrixTest']:
 r=subprocess.run(['java','-cp','work37/motion-tests:work37/patched','com.mrcrayfish.guns.port.'+n],capture_output=True,text=True,check=True);print(r.stdout,end='');out.append(r.stdout)
Path('work37/motion-results.txt').write_text(''.join(out))
