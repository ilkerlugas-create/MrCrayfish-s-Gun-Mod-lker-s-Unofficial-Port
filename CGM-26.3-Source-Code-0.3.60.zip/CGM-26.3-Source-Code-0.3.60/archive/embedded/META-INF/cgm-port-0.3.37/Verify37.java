import java.nio.file.*;import java.util.*;import java.util.jar.*;
import org.objectweb.asm.*;import org.objectweb.asm.tree.*;import org.objectweb.asm.tree.analysis.*;
public class Verify37 {
 static Map<String,ClassNode> all=new HashMap<>();
 static ClassNode load(String owner){
  ClassNode c=all.get(owner);if(c==null&&owner.startsWith("java/"))try(var in=ClassLoader.getSystemResourceAsStream(owner+".class")){if(in!=null){c=new ClassNode();new ClassReader(in).accept(c,ClassReader.SKIP_CODE);all.put(owner,c);}}catch(Exception ex){throw new RuntimeException(ex);}return c;
 }
 static boolean member(String owner,String name,String desc,boolean field,Set<String> seen){
  if(owner.startsWith("["))return true;
  if(!seen.add(owner))return false;ClassNode c=load(owner);if(c==null)return false;
  if(field){for(var f:c.fields)if(f.name.equals(name)&&f.desc.equals(desc))return true;}
  else for(var m:c.methods)if(m.name.equals(name)&&m.desc.equals(desc))return true;
  if(c.superName!=null&&member(c.superName,name,desc,field,seen))return true;
  for(String i:c.interfaces)if(member(i,name,desc,field,seen))return true;return false;
 }
 public static void main(String[] args)throws Exception {
  for(String arg:args)try(JarFile j=new JarFile(arg)){for(var e:Collections.list(j.entries()))if(e.getName().endsWith(".class")){ClassNode c=new ClassNode();new ClassReader(j.getInputStream(e)).accept(c,ClassReader.SKIP_CODE);all.put(c.name,c);}}
  Set<String> names=new TreeSet<>();
  try(var paths=Files.walk(Path.of("work37/patched"))){for(Path p:paths.filter(p->p.toString().endsWith(".class")).toList()){ClassNode c=new ClassNode();new ClassReader(Files.readAllBytes(p)).accept(c,0);all.put(c.name,c);names.add(c.name);}}
  Set<String> selected=new HashSet<>(Files.readAllLines(Path.of("work37/changed-methods.txt")));
  int verified=0;Set<String> missing=new TreeSet<>();
  for(String n:names)for(MethodNode m:all.get(n).methods){
   if(!selected.contains(n+" "+m.name+" "+m.desc))continue;

   if((m.access&(Opcodes.ACC_ABSTRACT|Opcodes.ACC_NATIVE))==0)new Analyzer<>(new BasicVerifier()).analyze(n,m);verified++;
   for(var ins:m.instructions){
    if(ins instanceof MethodInsnNode a&&!member(a.owner,a.name,a.desc,false,new HashSet<>()))missing.add(n+"."+m.name+" -> "+a.owner+"."+a.name+a.desc);
    if(ins instanceof FieldInsnNode a&&!member(a.owner,a.name,a.desc,true,new HashSet<>()))missing.add(n+"."+m.name+" -> FIELD "+a.owner+"."+a.name+a.desc);
    if(ins instanceof InvokeDynamicInsnNode a)for(Object b:a.bsmArgs)if(b instanceof Handle h&&!member(h.getOwner(),h.getName(),h.getDesc(),h.getTag()<=4,new HashSet<>()))missing.add(n+"."+m.name+" -> HANDLE "+h);
   }
  }
  System.out.println("Bytecode verified methods: "+verified);for(String s:missing)System.out.println(s);System.out.println("Unresolved links: "+missing.size());if(!missing.isEmpty())throw new AssertionError(missing);
 }
}
