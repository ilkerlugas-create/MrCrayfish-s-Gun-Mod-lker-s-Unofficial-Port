from pathlib import Path
import subprocess
root=Path('work37/cache-fixtures')
stubs={
'net/minecraft/core/component/DataComponentType': 'public class DataComponentType<T> {}',
'net/minecraft/core/component/DataComponents': '''import net.minecraft.world.item.component.*;public class DataComponents {public static final DataComponentType<CustomData> CUSTOM_DATA=new DataComponentType<>();public static final DataComponentType<DyedItemColor> DYED_COLOR=new DataComponentType<>();}''',
'net/minecraft/nbt/CompoundTag': '''import java.util.*;public class CompoundTag {public final Map<String,Object> data=new HashMap<>();public boolean isEmpty(){return data.isEmpty();}public boolean contains(String k){return data.containsKey(k);}public void putInt(String k,int v){data.put(k,v);}public int getIntOr(String k,int v){return data.get(k) instanceof Integer n?n:v;}public CompoundTag copy(){CompoundTag t=new CompoundTag();data.forEach((k,v)->t.data.put(k,v instanceof CompoundTag c?c.copy():v));return t;}public CompoundTag getCompoundOrEmpty(String k){return data.get(k) instanceof CompoundTag t?t:new CompoundTag();}}''',
'net/minecraft/world/item/component/CustomData': '''import net.minecraft.nbt.*;public class CustomData {public static final CustomData EMPTY=new CustomData(new CompoundTag());public static int copies;private final CompoundTag tag;public CustomData(CompoundTag t){tag=t.copy();}public CompoundTag copyTag(){copies++;return tag.copy();}}''',
'net/minecraft/world/item/component/DyedItemColor':'public record DyedItemColor(int rgb){}',
'net/minecraft/world/item/Item':'public class Item {}',
'net/minecraft/world/item/ItemStack':'''import java.util.*;import net.minecraft.core.component.*;public class ItemStack {public static final ItemStack EMPTY=new ItemStack(0);public final Map<DataComponentType<?>,Object> data=new HashMap<>();private int count;public int sets,removes;public ItemStack(int n){count=n;}public boolean isEmpty(){return count<=0;}public int getCount(){return count;}public void setCount(int n){count=n;}public void shrink(int n){count-=n;}public ItemStack copy(){ItemStack s=new ItemStack(count);s.data.putAll(data);return s;}@SuppressWarnings("unchecked")public <T>T getOrDefault(DataComponentType<T> t,T d){return (T)data.getOrDefault(t,d);}@SuppressWarnings("unchecked")public <T>T get(DataComponentType<T> t){return (T)data.get(t);}@SuppressWarnings("unchecked")public <T>T set(DataComponentType<T> t,T v){sets++;return (T)data.put(t,v);}@SuppressWarnings("unchecked")public <T>T remove(DataComponentType<T> t){removes++;return (T)data.remove(t);}}''',
'net/minecraft/core/NonNullList':'public class NonNullList<T> extends java.util.ArrayList<T>{}',
'net/minecraft/core/RegistryAccess':'public interface RegistryAccess {interface Frozen extends RegistryAccess {}}',
'net/minecraft/server/MinecraftServer':'public class MinecraftServer {public net.minecraft.core.RegistryAccess.Frozen registries=new net.minecraft.core.RegistryAccess.Frozen(){};public net.minecraft.core.RegistryAccess.Frozen registryAccess(){return registries;}}',
'net/minecraftforge/server/ServerLifecycleHooks':'public class ServerLifecycleHooks {public static net.minecraft.server.MinecraftServer server;public static net.minecraft.server.MinecraftServer getCurrentServer(){return server;}}',
'com/mrcrayfish/guns/port/AttachmentData':'''import net.minecraft.nbt.*;import net.minecraft.world.item.*;import net.minecraft.world.item.component.*;import net.minecraft.core.component.*;public class AttachmentData {public static int decodes;public static boolean ready=true;public static ItemStack read(CompoundTag t){decodes++;if(!ready)return ItemStack.EMPTY;ItemStack s=new ItemStack(t.getIntOr("count",1));s.set(DataComponents.CUSTOM_DATA,new CustomData(t));return s;}}'''
}
for name,body in stubs.items():
 p=root/(name+'.java');p.parent.mkdir(parents=True,exist_ok=True);p.write_text('package '+name.rsplit('/',1)[0].replace('/','.')+';'+body)
(root/'CacheTest.java').write_text('''import net.minecraft.nbt.*;import net.minecraft.world.item.*;import net.minecraft.world.item.component.*;import net.minecraft.core.component.*;import com.mrcrayfish.guns.port.*;import java.lang.reflect.*;import java.util.*;
public class CacheTest {
 static int checks;static void check(boolean b,String s){if(!b)throw new AssertionError(s);checks++;}
 static ItemStack stack(int ammo,int color){CompoundTag t=new CompoundTag();t.putInt("AmmoCount",ammo);t.putInt("Color",color);ItemStack s=new ItemStack(1);s.set(DataComponents.CUSTOM_DATA,new CustomData(t));return s;}
 static Object local()throws Exception{Field f=StackReadCache.class.getDeclaredField("LOCAL");f.setAccessible(true);return ((ThreadLocal<?>)f.get(null)).get();}
 static int size(String name)throws Exception{Object c=local();Field f=c.getClass().getDeclaredField(name);f.setAccessible(true);return ((Map<?,?>)f.get(c)).size();}
 public static void main(String[] a)throws Exception{
  ItemStack s=stack(12,0x3399cc);int start=CustomData.copies;CompoundTag first=StackReadCache.read(s);
  for(int i=0;i<10000;i++)StackReadCache.read(s);
  check(CustomData.copies-start==1,"stable reads must copy NBT once");
  ItemStack other=stack(7,0xaa3300);check(StackReadCache.read(other).getIntOr("AmmoCount",0)==7,"same item must have independent data");
  CompoundTag changed=s.get(DataComponents.CUSTOM_DATA).copyTag();changed.putInt("AmmoCount",11);s.set(DataComponents.CUSTOM_DATA,new CustomData(changed));
  check(StackReadCache.read(s).getIntOr("AmmoCount",0)==11,"ammo updates immediately");check(first.getIntOr("AmmoCount",0)==12,"older snapshot remains independent");
  s.remove(DataComponents.CUSTOM_DATA);check(StackReadCache.read(s).isEmpty(),"component removal invalidates");
  s=stack(5,0x224466);DyeBridge.sync(s);check(s.get(DataComponents.DYED_COLOR).rgb()==0x224466,"paint rendered");int sets=s.sets;for(int i=0;i<100;i++)DyeBridge.sync(s);check(s.sets==sets,"stable color does not rewrite component");
  changed=s.get(DataComponents.CUSTOM_DATA).copyTag();changed.putInt("Color",0x112233);s.set(DataComponents.CUSTOM_DATA,new CustomData(changed));DyeBridge.sync(s);check(s.get(DataComponents.DYED_COLOR).rgb()==0x112233,"new paint immediate");s.remove(DataComponents.CUSTOM_DATA);DyeBridge.sync(s);check(s.get(DataComponents.DYED_COLOR)==null,"paint removal immediate");
  CompoundTag part=new CompoundTag();part.putInt("Color",0x987654);int before=AttachmentData.decodes;
  ItemStack returned=StackReadCache.readItem(part);returned.setCount(0);returned.remove(DataComponents.CUSTOM_DATA);
  for(int i=0;i<10000;i++)StackReadCache.readItem(part);
  check(AttachmentData.decodes-before==1,"stable attachment decoded once");
  returned=StackReadCache.readItem(part);check(returned.getCount()==1,"returned stacks own count");check(returned.get(DataComponents.CUSTOM_DATA).copyTag().getIntOr("Color",0)==0x987654,"returned stacks preserve components");
  net.minecraftforge.server.ServerLifecycleHooks.server=new net.minecraft.server.MinecraftServer();before=AttachmentData.decodes;StackReadCache.readItem(part);check(AttachmentData.decodes==before+1,"server context invalidates");
  net.minecraftforge.server.ServerLifecycleHooks.server.registries=new net.minecraft.core.RegistryAccess.Frozen(){};before=AttachmentData.decodes;StackReadCache.readItem(part);check(AttachmentData.decodes==before+1,"registry reload invalidates");
  net.minecraftforge.server.ServerLifecycleHooks.server=null;before=AttachmentData.decodes;StackReadCache.readItem(part);check(AttachmentData.decodes==before+1,"disconnect invalidates");
  CompoundTag delayed=new CompoundTag();delayed.putInt("id",3);AttachmentData.ready=false;check(StackReadCache.readItem(delayed).isEmpty(),"failed codec empty");AttachmentData.ready=true;check(!StackReadCache.readItem(delayed).isEmpty(),"failed codec retried");
  Object main=local();Object[] worker=new Object[1];Thread t=new Thread(()->{try{worker[0]=local();StackReadCache.read(stack(10,1));}catch(Exception e){throw new RuntimeException(e);}});t.start();t.join();check(worker[0]!=null&&worker[0]!=main,"client and server thread isolation");
  for(int i=0;i<700;i++){StackReadCache.read(stack(i,i));CompoundTag x=new CompoundTag();x.putInt("n",i);StackReadCache.readItem(x);}
  check(size("tags")<=256&&size("items")<=256,"both caches bounded");
  check(StackReadCache.readItem(null).isEmpty()&&StackReadCache.readItem(new CompoundTag()).isEmpty(),"empty inputs");
  System.out.println("PASS: "+checks+" production-bytecode checks for cache invalidation, defensive ownership, color updates, registry changes, failure retry, bounds and thread isolation.");
  System.out.println("Operation count: 10,001 stable NBT reads -> 1 deep copy; 10,001 stable attachment reads -> 1 decode (isolated fixtures, not FPS).");
 }
}''')
cp='work37/patched'
subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','-cp',cp,'-d','work37/cache-tests',*map(str,root.rglob('*.java'))],check=True)
r=subprocess.run(['java','-cp','work37/cache-tests:'+cp,'CacheTest'],capture_output=True,text=True);print(r.stdout+r.stderr);r.check_returncode();Path('work37/cache-results.txt').write_text(r.stdout)
