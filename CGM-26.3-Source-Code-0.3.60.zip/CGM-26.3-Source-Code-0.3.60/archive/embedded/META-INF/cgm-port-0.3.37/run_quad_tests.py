from pathlib import Path
import subprocess
root=Path('work37/quad-fixtures')
stubs={
'com/mojang/blaze3d/vertex/PoseStack':'public class PoseStack {public static class Pose {}}',
'com/mojang/blaze3d/vertex/QuadInstance':'public class QuadInstance {public static int instances;public int color,light,overlay;public QuadInstance(){instances++;}public void setColor(int c){color=c;}public void setLightCoords(int n){light=n;}public void setOverlayCoords(int n){overlay=n;}}',
'com/mojang/blaze3d/vertex/VertexConsumer':'public interface VertexConsumer {void putBakedQuad(PoseStack.Pose p,net.minecraft.client.resources.model.geometry.BakedQuad q,QuadInstance i);}',
'net/minecraft/core/Direction':'public enum Direction {DOWN,UP,NORTH,SOUTH,WEST,EAST}',
'net/minecraft/client/renderer/rendertype/RenderType':'public record RenderType(String name){}',
'net/minecraft/client/renderer/chunk/ChunkSectionLayer':'public enum ChunkSectionLayer {SOLID}',
'net/minecraft/client/renderer/Sheets':'import net.minecraft.client.renderer.rendertype.*;public class Sheets {public static RenderType translucentBlockItemSheet(){return new RenderType("translucent");}public static RenderType cutoutBlockItemSheet(){return new RenderType("cutout");}}',
'net/minecraft/client/resources/model/geometry/BakedQuad':'public record BakedQuad(int id,MaterialInfo materialInfo){public record MaterialInfo(boolean isTinted){}}',
'net/minecraft/client/renderer/block/dispatch/BlockStateModelPart':'import net.minecraft.core.*;import java.util.*;import net.minecraft.client.resources.model.geometry.*;public interface BlockStateModelPart {List<BakedQuad> getQuads(Direction d);int materialFlags();}',
'net/minecraft/client/renderer/SubmitNodeCollector':'import com.mojang.blaze3d.vertex.*;import net.minecraft.client.renderer.rendertype.*;public interface SubmitNodeCollector {interface CustomGeometryRenderer {void render(PoseStack.Pose p,VertexConsumer v);}void submitCustomGeometry(PoseStack p,RenderType t,CustomGeometryRenderer r);}'
}
for n,b in stubs.items():
 p=root/(n+'.java');p.parent.mkdir(parents=True,exist_ok=True);p.write_text('package '+n.rsplit('/',1)[0].replace('/','.')+';'+b)
(root/'QuadTest.java').write_text('''import java.util.*;import com.mojang.blaze3d.vertex.*;import com.mrcrayfish.framework.api.client.model.renderer.StandaloneModelRenderer;import net.minecraft.client.renderer.*;import net.minecraft.client.renderer.block.dispatch.*;import net.minecraft.client.resources.model.geometry.*;import net.minecraft.core.*;
public class QuadTest {
 public static void main(String[] args){List<SubmitNodeCollector.CustomGeometryRenderer> jobs=new ArrayList<>();List<String> sheets=new ArrayList<>();SubmitNodeCollector c=(p,t,r)->{jobs.add(r);sheets.add(t.name());};
 BlockStateModelPart part=new BlockStateModelPart(){public int materialFlags(){return 1;}public List<BakedQuad> getQuads(Direction d){if(d!=null&&d!=Direction.NORTH)return List.of();return List.of(new BakedQuad(d==null?10:0,new BakedQuad.MaterialInfo(true)),new BakedQuad(d==null?11:1,new BakedQuad.MaterialInfo(false)));}};
 StandaloneModelRenderer.submitDraw(c,part,new PoseStack(),.25F,.5F,1F,123,456);StandaloneModelRenderer.submitDraw(c,part,new PoseStack(),1.5F,-.2F,.5F,789,321);
 if(QuadInstance.instances!=0)throw new AssertionError("must allocate inside deferred callback");
 int count=0;for(int i=1;i>=0;i--){final int index=i;List<String> got=new ArrayList<>();jobs.get(i).render(new PoseStack.Pose(),(p,q,v)->{int expected=q.materialInfo().isTinted()?(index==0?0xff4080ff:0xffff0080):-1;if(v.color!=expected||v.light!=(index==0?123:789)||v.overlay!=(index==0?456:321))throw new AssertionError("tint/light/overlay changed");got.add(q.id()+":"+v.color+":"+v.light+":"+v.overlay);});if(got.size()!=4)throw new AssertionError("geometry lost");count+=got.size();}
 if(!sheets.equals(List.of("translucent","translucent")))throw new AssertionError("sheet changed");
 System.out.println("PASS: "+count+" mixed tinted/untinted quads, all faces, deferred submission, clamped RGB, light/overlay and translucent sheet.");System.out.println("QuadInstance allocations for two model submissions: "+QuadInstance.instances);
 }
}''')
subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-proc:none','-cp','work37/patched','-d','work37/quad-tests',*map(str,root.rglob('*.java'))],check=True)
out=[]
for mode in ['baseline','optimized']:
 if mode=='baseline':
  p=Path('work37/quad-baseline/com/mrcrayfish/framework/api/client/model/renderer/StandaloneModelRenderer.class');p.parent.mkdir(parents=True,exist_ok=True);b=Path('work37/base/com/mrcrayfish/framework/api/client/model/renderer/StandaloneModelRenderer.class').read_bytes();p.write_bytes(b[:6]+b'\x00\x3d'+b[8:]);cp='work37/quad-baseline'
 else:cp='work37/patched'
 r=subprocess.run(['java','-cp','work37/quad-tests:'+cp,'QuadTest'],capture_output=True,text=True);print(mode+': '+r.stdout+r.stderr);r.check_returncode();out.append(mode+': '+r.stdout)
Path('work37/quad-results.txt').write_text(''.join(out))
