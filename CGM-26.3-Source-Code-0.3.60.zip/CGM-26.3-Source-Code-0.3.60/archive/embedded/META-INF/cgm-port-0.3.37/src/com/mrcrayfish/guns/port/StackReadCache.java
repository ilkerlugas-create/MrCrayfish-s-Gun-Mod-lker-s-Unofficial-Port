package com.mrcrayfish.guns.port;

import java.util.ArrayDeque;
import java.util.IdentityHashMap;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.minecraftforge.server.ServerLifecycleHooks;

/** Bounded, thread-local snapshots for explicitly audited read-only CGM paths.
 * Never substitute this for StackData.copy on a path that mutates the tag.
 * CustomData is immutable; replacement by sync/update/set invalidates by identity.
 */
public final class StackReadCache {
    private static final int LIMIT = 256;
    private static final ThreadLocal<Cache> LOCAL = ThreadLocal.withInitial(Cache::new);

    private static final class Cache {
        final IdentityHashMap<CustomData, CompoundTag> tags = new IdentityHashMap<>();
        final ArrayDeque<CustomData> tagOrder = new ArrayDeque<>();
        final IdentityHashMap<CompoundTag, ItemStack> items = new IdentityHashMap<>();
        final ArrayDeque<CompoundTag> itemOrder = new ArrayDeque<>();
        Object registryContext;
    }

    /** Borrowed snapshot: callers must not mutate it or its child tags. */
    public static CompoundTag read(ItemStack stack) {
        CustomData data = stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY);
        Cache cache = LOCAL.get();
        CompoundTag tag = cache.tags.get(data);
        if (tag == null) {
            tag = data.copyTag();
            if (cache.tags.size() >= LIMIT) cache.tags.remove(cache.tagOrder.removeFirst());
            cache.tags.put(data, tag);
            cache.tagOrder.addLast(data);
        }
        return tag;
    }

    /** Only called with an immutable child of a snapshot returned by read(). */
    public static ItemStack readItem(CompoundTag tag) {
        if (tag == null || tag.isEmpty()) return ItemStack.EMPTY;
        Cache cache = LOCAL.get();
        var server = ServerLifecycleHooks.getCurrentServer();
        Object context = server == null ? null : server.registryAccess();
        if (cache.registryContext != context) {
            cache.items.clear();
            cache.itemOrder.clear();
            cache.registryContext = context;
        }
        ItemStack item = cache.items.get(tag);
        if (item == null) {
            item = AttachmentData.read(tag);
            // Failed decoding can recover after registry initialization; do not cache it.
            if (item.isEmpty()) return ItemStack.EMPTY;
            if (cache.items.size() >= LIMIT) cache.items.remove(cache.itemOrder.removeFirst());
            cache.items.put(tag, item);
            cache.itemOrder.addLast(tag);
        }
        // Preserve the old API's ownership: modifying a returned attachment is safe.
        return item.copy();
    }
}
