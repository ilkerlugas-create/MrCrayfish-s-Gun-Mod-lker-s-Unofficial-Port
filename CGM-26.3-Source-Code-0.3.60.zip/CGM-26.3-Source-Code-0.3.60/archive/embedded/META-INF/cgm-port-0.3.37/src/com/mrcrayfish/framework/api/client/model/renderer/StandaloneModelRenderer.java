/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.vertex.PoseStack
 *  com.mojang.blaze3d.vertex.PoseStack$Pose
 *  com.mojang.blaze3d.vertex.QuadInstance
 *  com.mojang.blaze3d.vertex.VertexConsumer
 *  net.minecraft.client.renderer.Sheets
 *  net.minecraft.client.renderer.SubmitNodeCollector
 *  net.minecraft.client.renderer.block.dispatch.BlockStateModelPart
 *  net.minecraft.client.renderer.chunk.ChunkSectionLayer
 *  net.minecraft.client.renderer.rendertype.RenderType
 *  net.minecraft.client.resources.model.geometry.BakedQuad
 *  net.minecraft.core.Direction
 *  net.minecraft.util.ARGB
 */
package com.mrcrayfish.framework.api.client.model.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.QuadInstance;
import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.List;
import net.minecraft.client.renderer.Sheets;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.block.dispatch.BlockStateModelPart;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.resources.model.geometry.BakedQuad;
import net.minecraft.core.Direction;
import net.minecraft.util.ARGB;

public class StandaloneModelRenderer {
    private static final Direction[] DIRECTIONS = Direction.values();


    public static void submitDraw(SubmitNodeCollector collector, BlockStateModelPart model, PoseStack pose, float red, float green, float blue, int light, int overlay) {
        StandaloneModelRenderer.submitDraw(collector, model, ChunkSectionLayer.SOLID, pose, red, green, blue, light, overlay);
    }

    public static void submitDraw(SubmitNodeCollector collector, BlockStateModelPart model, ChunkSectionLayer layer, PoseStack pose, float red, float green, float blue, int light, int overlay) {
        int tint = 0xFF000000 | (Math.max(0, Math.min(255, Math.round(red * 255F))) << 16) | (Math.max(0, Math.min(255, Math.round(green * 255F))) << 8) | Math.max(0, Math.min(255, Math.round(blue * 255F)));
        collector.submitCustomGeometry(pose, StandaloneModelRenderer.getSheet(model), (pose1, consumer) -> {
            QuadInstance quadInstance = new QuadInstance();
            quadInstance.setLightCoords(light);
            quadInstance.setOverlayCoords(overlay);
            for (Direction direction : DIRECTIONS) {
                StandaloneModelRenderer.putQuads(pose1, consumer, tint, model.getQuads(direction), quadInstance);
            }
            StandaloneModelRenderer.putQuads(pose1, consumer, tint, model.getQuads(null), quadInstance);
        });
    }

    private static void putQuads(PoseStack.Pose pose, VertexConsumer consumer, int tint, List<BakedQuad> quads, QuadInstance instance) {
        for (BakedQuad quad : quads) {
            instance.setColor(quad.materialInfo().isTinted() ? tint : -1);
            consumer.putBakedQuad(pose, quad, instance);
        }
    }

    private static RenderType getSheet(BlockStateModelPart part) {
        return (part.materialFlags() & 1) != 0 ? Sheets.translucentBlockItemSheet() : Sheets.cutoutBlockItemSheet();
    }
}

