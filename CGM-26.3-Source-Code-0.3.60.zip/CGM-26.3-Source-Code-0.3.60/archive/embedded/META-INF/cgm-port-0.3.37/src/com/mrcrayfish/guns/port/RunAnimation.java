package com.mrcrayfish.guns.port;
import java.util.Map;
import java.util.WeakHashMap;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import com.mrcrayfish.guns.client.KeyBinds;
import com.mrcrayfish.guns.Config;
import com.mrcrayfish.guns.client.handler.AimingHandler;
import com.mrcrayfish.guns.client.render.IHeldAnimation;
import com.mrcrayfish.guns.common.Gun;
import com.mrcrayfish.guns.common.GripType;
import com.mrcrayfish.guns.init.ModSyncedDataKeys;
import com.mrcrayfish.guns.item.GunItem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.player.Player;
public final class RunAnimation {
 private static final Map<Player,State> STATES=new WeakHashMap<>();
 private static final class State {float time,progress;final double[] rotation=new double[9];State(float time){this.time=time;}}
 public static float approach(float value,boolean running,float elapsed) {
  float step=Math.max(0F,Math.min(elapsed,1F))/5F;
  return running?Math.min(1F,value+step):Math.max(0F,value-step);
 }
 private static float sample(Player player,float partial) {
  float time=player.tickCount+partial;
  State state=STATES.get(player);
  if(state==null){state=new State(time);STATES.put(player,state);}
  if(time<state.time){state.time=time;state.progress=0;}
  boolean aiming=player.isLocalPlayer()?AimingHandler.get().isAiming():ModSyncedDataKeys.AIMING.getValue(player);
  boolean shooting=player.isLocalPlayer()?KeyBinds.getShootMapping().isDown():ModSyncedDataKeys.SHOOTING.getValue(player);
  boolean running=Config.CLIENT.display.sprintAnimation.get()&&player.isSprinting()&&!aiming&&!shooting&&!ModSyncedDataKeys.RELOADING.getValue(player);
  state.progress=approach(state.progress,running,time-state.time);state.time=time;
  return state.progress*state.progress*(3F-2F*state.progress);
 }
 private static float amount(GripType grip){return grip==GripType.BAZOOKA||grip==GripType.MINI_GUN?.4F:grip==GripType.ONE_HANDED?.7F:1F;}
 public static void firstPerson(Gun gun,HumanoidArm arm,PoseStack pose,float partial) {
  Player player=Minecraft.getInstance().player;if(player==null)return;
  float eased=sample(player,partial),side=arm==HumanoidArm.LEFT?-1F:1F,a=amount(gun.getGeneral().getGripType());
  pose.translate(-.08F*side*eased*a,-.12F*eased,0);
  pose.rotateDegrees(Axis.YP,15F*side*eased*a);
  pose.rotateDegrees(Axis.XP,-8F*eased*a);
 }
 public static void thirdPerson(IHeldAnimation animation,Player player,ModelPart right,ModelPart left,ModelPart head,InteractionHand hand,float aim) {
  aim=F5Aim.progress(player,aim);
  animation.applyPlayerModelRotation(player,right,left,head,hand,aim);
  var stack=player.getMainHandItem();if(!(stack.getItem() instanceof GunItem item))return;
  float partial=Minecraft.getInstance().getDeltaTracker().getGameTimeDeltaPartialTick(true);
  float eased=sample(player,partial);if(eased==0)return;
  if(player.isPassenger()||player.isSleeping()||player.isFallFlying()||player.isVisuallySwimming())return;
  GripType grip=item.getModifiedGun(stack).getGeneral().getGripType();
  boolean isRight=(player.getMainArm()==HumanoidArm.RIGHT)==(hand==InteractionHand.MAIN_HAND);
  float side=isRight?1F:-1F,a=amount(grip);
  ModelPart primary=isRight?right:left;
  // Convert camera space into the mirrored, Y-down player model coordinates.
  double[] rotation=STATES.get(player).rotation;
  fillMatrix(rotation,Math.toRadians(8F*eased*a),Math.toRadians(-15F*side*eased*a),0);
  double sx=Math.sin(primary.xRot),cx=Math.cos(primary.xRot),sy=Math.sin(primary.yRot),cy=Math.cos(primary.yRot),sz=Math.sin(primary.zRot),cz=Math.cos(primary.zRot);
  double px=primary.x+(cz*sy*sx-sz*cx)*10,py=primary.y+(sz*sy*sx+cz*cx)*10,pz=primary.z+cy*sx*10;
  float dx=.08F*side*eased*a*16F,dy=.12F*eased*16F;
  transform(primary,rotation,px,py,pz,dx,dy);
  if(grip!=GripType.ONE_HANDED)transform(isRight?left:right,rotation,px,py,pz,dx,dy);
 }
 // Rz * Ry * Rx, matching ModelPart's rotationZYX convention.
 static double[] matrix(double x,double y,double z){
  double[] r=new double[9];fillMatrix(r,x,y,z);return r;
 }
 private static void fillMatrix(double[] r,double x,double y,double z){
  double cx=Math.cos(x),sx=Math.sin(x),cy=Math.cos(y),sy=Math.sin(y),cz=Math.cos(z),sz=Math.sin(z);
  r[0]=cz*cy;r[1]=cz*sy*sx-sz*cx;r[2]=cz*sy*cx+sz*sx;
  r[3]=sz*cy;r[4]=sz*sy*sx+cz*cx;r[5]=sz*sy*cx-cz*sx;
  r[6]=-sy;r[7]=cy*sx;r[8]=cy*cx;
 }
 static void transform(ModelPart part,double[] r,double px,double py,double pz,float dx,float dy){
  double x=part.x-px,y=part.y-py,z=part.z-pz;
  part.x=(float)(px+r[0]*x+r[1]*y+r[2]*z+dx);
  part.y=(float)(py+r[3]*x+r[4]*y+r[5]*z+dy);
  part.z=(float)(pz+r[6]*x+r[7]*y+r[8]*z);
  double cx=Math.cos(part.xRot),sx=Math.sin(part.xRot),cy=Math.cos(part.yRot),sy=Math.sin(part.yRot),cz=Math.cos(part.zRot),sz=Math.sin(part.zRot);
  double b0=cz*cy,b1=cz*sy*sx-sz*cx,b2=cz*sy*cx+sz*sx;
  double b3=sz*cy,b4=sz*sy*sx+cz*cx,b5=sz*sy*cx-cz*sx,b6=-sy,b7=cy*sx,b8=cy*cx;
  double c6=r[6]*b0+r[7]*b3+r[8]*b6,c7=r[6]*b1+r[7]*b4+r[8]*b7,c8=r[6]*b2+r[7]*b5+r[8]*b8;
  double ry=Math.asin(Math.max(-1D,Math.min(1D,-c6)));
  part.yRot=(float)ry;
  if(Math.abs(Math.cos(ry))>1e-6){
   part.xRot=(float)Math.atan2(c7,c8);
   part.zRot=(float)Math.atan2(r[3]*b0+r[4]*b3+r[5]*b6,r[0]*b0+r[1]*b3+r[2]*b6);
  } else {part.xRot=0;part.zRot=(float)Math.atan2(-(r[0]*b1+r[1]*b4+r[2]*b7),r[3]*b1+r[4]*b4+r[5]*b7);}
 }
 public static void heldItem(IHeldAnimation animation,Player player,InteractionHand hand,float aim,PoseStack pose,SubmitNodeCollector collector){
  // ItemInHandLayer already inherits the transformed primary arm: no second motion.
  animation.applyHeldItemTransforms(player,hand,F5Aim.progress(player,aim),pose,collector);
 }
}
