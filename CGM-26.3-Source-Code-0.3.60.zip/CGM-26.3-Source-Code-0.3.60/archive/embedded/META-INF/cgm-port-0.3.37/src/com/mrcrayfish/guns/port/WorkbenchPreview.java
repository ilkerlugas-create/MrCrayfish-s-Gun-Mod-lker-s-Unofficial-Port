package com.mrcrayfish.guns.port;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
public final class WorkbenchPreview {
 private static final java.util.Set<String> SUPPORTED=java.util.Set.of("pistol","shotgun","rifle","grenade_launcher","bazooka","mini_gun","assault_rifle","machine_pistol","heavy_rifle","silencer","short_scope","medium_scope","long_scope","light_stock","tactical_stock","weighted_stock","light_grip","specialised_grip","basic_bullet","advanced_bullet","shell","grenade_round","missile","grenade","stun_grenade");
 private static final java.util.Map<String,Identifier> MODELS=new java.util.HashMap<>();
 static { for(String path:SUPPORTED) MODELS.put(path,Identifier.parse("cgm:workbench_preview/"+path)); }
 public static void animate(net.minecraft.client.renderer.item.ItemStackRenderState state,ItemStack stack) {
  if(AttachmentPreview.animate(state,stack))return;
  Identifier model=stack.get(DataComponents.ITEM_MODEL);
  if(model==null || !model.getNamespace().equals("cgm") || !model.getPath().startsWith("workbench_preview/"))return;
  var mc=net.minecraft.client.Minecraft.getInstance();
  if(mc.level==null)return;
  float partial=mc.getDeltaTracker().getGameTimeDeltaPartialTick(true);
  float angle=(float)Math.toRadians(18.0*Math.sin(((mc.level.getGameTime()%240)+partial)*Math.PI/120.0));
  var transform=new org.joml.Matrix4f().translate(.5F,.5F,.5F).rotateY(angle).scale(3.6F).translate(-.5F,-.5F,-.5F);
  var access=(com.mrcrayfish.guns.mixin.client.PreviewLayersAccessor)(Object)state;
  var layers=access.cgmPreviewLayers();
  for(int i=0;i<access.cgmPreviewLayerCount();i++)layers[i].setLocalTransform(transform);
  state.setOversizedInGui(true);
  state.setAnimated();
 }
 public static org.joml.Matrix3x2f scale(org.joml.Matrix3x2fStack pose,float x,float y,ItemStack stack) {
  if(stack!=null && supported(stack))return pose;
  return pose.scale(x,y);
 }
 public static boolean supported(ItemStack stack) {
  var id=BuiltInRegistries.ITEM.getKey(stack.getItem());
  return id.getNamespace().equals("cgm") && SUPPORTED.contains(id.getPath());
 }
 public static ItemStack create(ItemStack original) {
  ItemStack result=original.copy();
  var id=BuiltInRegistries.ITEM.getKey(original.getItem());
  if(supported(original))
   result.set(DataComponents.ITEM_MODEL,MODELS.get(id.getPath()));
  DyeBridge.sync(result);
  return result;
 }
}
