package com.mrcrayfish.guns.port;
import com.mrcrayfish.guns.common.Gun;
import com.mrcrayfish.guns.item.GunItem;
import com.mrcrayfish.guns.item.attachment.IAttachment;
import net.minecraft.client.renderer.item.ItemModelResolver;
import net.minecraft.client.renderer.item.ItemStackRenderState;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.ItemOwner;
import java.util.Set;
public final class InventoryAttachments {
 private static final Set<String> GUNS=Set.of("pistol","shotgun","rifle","grenade_launcher","bazooka","mini_gun","assault_rifle","machine_pistol","heavy_rifle");
 private static final Set<String> PARTS=Set.of("silencer","short_scope","medium_scope","long_scope","light_stock","tactical_stock","weighted_stock","light_grip","specialised_grip");
 private static final IAttachment.Type[] TYPES=IAttachment.Type.values();
 private static final java.util.Map<String,Identifier> MODELS=new java.util.HashMap<>();
 static {
  for(String gun:GUNS) {
   MODELS.put("preview/"+gun,Identifier.parse("cgm:attachment_preview/"+gun));
   for(String prefix:new String[]{"cgm:attachment_preview/","cgm:inventory_assembled/"}) {
    MODELS.put(prefix+gun+"/body",Identifier.parse(prefix+gun+"/body"));
    for(String part:PARTS) MODELS.put(prefix+gun+"/"+part,Identifier.parse(prefix+gun+"/"+part));
   }
  }
 }
 public static void update(ItemModelResolver resolver,ItemStackRenderState state,ItemStack stack,Level world,ItemOwner owner,int seed){
  if(!(stack.getItem() instanceof GunItem gunItem))return;
  Identifier id=BuiltInRegistries.ITEM.getKey(stack.getItem());
  if(!id.getNamespace().equals("cgm")||!GUNS.contains(id.getPath()))return;
  Identifier chosen=stack.get(DataComponents.ITEM_MODEL);
  boolean preview=chosen!=null && chosen.equals(MODELS.get("preview/"+id.getPath()));
  if(!preview && chosen!=null&&!chosen.equals(id))return;
  String prefix=preview?"cgm:attachment_preview/":"cgm:inventory_assembled/";
  Gun gun=gunItem.getModifiedGun(stack);
  ItemStack body=stack.copy();DyeBridge.sync(body);
  body.set(DataComponents.ITEM_MODEL,MODELS.get(prefix+id.getPath()+"/body"));
  resolver.updateForTopItem(state,body,ItemDisplayContext.GUI,world,owner,seed);
  for(IAttachment.Type type:TYPES){
   if(!gun.canAttachType(type))continue;
   ItemStack part=Gun.getAttachment(type,stack);
   if(part.isEmpty())continue;
   Identifier pid=BuiltInRegistries.ITEM.getKey(part.getItem());
   if(!pid.getNamespace().equals("cgm")||!PARTS.contains(pid.getPath()))continue;
   DyeBridge.sync(part);
   part.set(DataComponents.ITEM_MODEL,MODELS.get(prefix+id.getPath()+"/"+pid.getPath()));
   resolver.appendItemLayers(state,part,ItemDisplayContext.GUI,world,owner,seed);
  }
 }
}
