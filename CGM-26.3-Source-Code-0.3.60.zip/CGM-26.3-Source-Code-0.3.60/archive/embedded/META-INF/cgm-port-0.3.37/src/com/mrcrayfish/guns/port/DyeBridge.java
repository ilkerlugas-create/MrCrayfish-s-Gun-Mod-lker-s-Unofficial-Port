package com.mrcrayfish.guns.port;
import com.mrcrayfish.guns.util.StackData;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.DyedItemColor;
public final class DyeBridge {
 public static void sync(ItemStack stack) {
  var tag=StackReadCache.read(stack);
  DyedItemColor current=stack.get(DataComponents.DYED_COLOR);
  if(tag.contains("Color")) {
   int rgb=tag.getIntOr("Color",0)&0xFFFFFF;
   if(current==null || current.rgb()!=rgb)stack.set(DataComponents.DYED_COLOR,new DyedItemColor(rgb));
  } else if(current!=null) stack.remove(DataComponents.DYED_COLOR);
 }
 public static int color(ItemStack stack,int index) {
  var tag=StackReadCache.read(stack);
  return tag.contains("Color") ? 0xFF000000 | (tag.getIntOr("Color",0)&0xFFFFFF) : 0xFFFFFFFF;
 }
 public static Object consume(net.minecraft.core.NonNullList<ItemStack> items,int slot,Object ignored) {
  ItemStack dye=items.get(slot);dye.shrink(1);
  if(dye.isEmpty())items.set(slot,ItemStack.EMPTY);
  return dye;
 }
}
