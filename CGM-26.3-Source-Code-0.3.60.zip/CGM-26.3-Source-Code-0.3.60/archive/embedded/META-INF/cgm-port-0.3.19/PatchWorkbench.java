import java.nio.file.*;
import java.util.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.tree.analysis.*;

/** Keep recipe results as immutable templates until item components are bound. */
public class PatchWorkbench implements Opcodes {
    static final String SELF = "com/mrcrayfish/guns/crafting/WorkbenchRecipe";
    static final String STACK = "net/minecraft/world/item/ItemStack";
    static final String TEMPLATE = "net/minecraft/world/item/ItemStackTemplate";
    static final String SD = "L" + STACK + ";", TD = "L" + TEMPLATE + ";";
    static String templateDesc(String value) {
        return value == null ? null : value.replace(SD, TD);
    }
    static void updateFrame(List<Object> values) {
        if (values != null) for (int i = 0; i < values.size(); i++)
            if (STACK.equals(values.get(i))) values.set(i, TEMPLATE);
    }
    public static void main(String[] args) throws Exception {
        ClassNode cls = new ClassNode();
        new ClassReader(Files.readAllBytes(Path.of(args[0]))).accept(cls, 0);
        if (!cls.name.equals(SELF)) throw new IllegalArgumentException(cls.name);
        int fields = 0, codecs = 0, constructors = 0, getters = 0;
        for (FieldNode f : cls.fields) {
            if (f.name.equals("item")) {
                if (!f.desc.equals(SD)) throw new IllegalStateException("Already patched");
                f.desc = TD;
                f.signature = templateDesc(f.signature);
                fields++;
            }
        }
        for (MethodNode m : cls.methods) {
            boolean parameterChanged = m.name.equals("<init>") || m.name.equals("lambda$static$2");
            if (parameterChanged) {
                m.desc = templateDesc(m.desc);
                m.signature = templateDesc(m.signature);
                if (m.name.equals("<init>")) constructors++;
            }
            if (parameterChanged || m.name.equals("lambda$static$4")) {
                if (m.localVariables != null) for (LocalVariableNode l : m.localVariables) {
                    l.desc = templateDesc(l.desc);
                    l.signature = templateDesc(l.signature);
                }
                for (AbstractInsnNode n : m.instructions) if (n instanceof FrameNode f) {
                    updateFrame(f.local); updateFrame(f.stack);
                }
            }
            for (AbstractInsnNode n : m.instructions) {
                if (n instanceof FieldInsnNode f) {
                    if (f.owner.equals(SELF) && f.name.equals("item")) f.desc = TD;
                    if (f.owner.equals(STACK) && (f.name.equals("CODEC") || f.name.equals("STREAM_CODEC"))) {
                        f.owner = TEMPLATE;
                        codecs++;
                    }
                } else if (n instanceof MethodInsnNode call) {
                    if (call.owner.equals(SELF) && call.name.equals("<init>"))
                        call.desc = templateDesc(call.desc);
                    if (m.name.equals("getItem") && call.owner.equals(STACK) && call.name.equals("copy")) {
                        call.owner = TEMPLATE;
                        call.name = "create";
                        getters++;
                    }
                } else if (n instanceof TypeInsnNode t && m.name.equals("lambda$static$4") && t.desc.equals(STACK)) {
                    t.desc = TEMPLATE;
                } else if (n instanceof InvokeDynamicInsnNode dynamic) {
                    for (int i = 0; i < dynamic.bsmArgs.length; i++) {
                        Object arg = dynamic.bsmArgs[i];
                        if (arg instanceof Handle h && h.getOwner().equals(SELF)) {
                            String name = h.getName().equals("getItem") ? "getItemTemplate" : h.getName();
                            dynamic.bsmArgs[i] = new Handle(h.getTag(), h.getOwner(), name,
                                templateDesc(h.getDesc()), h.isInterface());
                        } else if (arg instanceof Type t) {
                            dynamic.bsmArgs[i] = Type.getType(templateDesc(t.getDescriptor()));
                        }
                    }
                }
            }
        }
        if (fields != 1 || codecs != 3 || constructors != 1 || getters != 1)
            throw new IllegalStateException("Unexpected original class layout");

        MethodNode getter = new MethodNode(ACC_PUBLIC, "getItemTemplate", "()" + TD, null, null);
        getter.instructions.add(new VarInsnNode(ALOAD, 0));
        getter.instructions.add(new FieldInsnNode(GETFIELD, SELF, "item", TD));
        getter.instructions.add(new InsnNode(ARETURN));
        getter.maxLocals = 1; getter.maxStack = 1;
        cls.methods.add(getter);

        // Preserve the existing public constructor for callers with a live stack.
        String ctorStart = "(Lnet/minecraft/resources/Identifier;";
        String ctorEnd = "Lcom/google/common/collect/ImmutableList;)V";
        MethodNode bridge = new MethodNode(ACC_PUBLIC, "<init>", ctorStart + SD + ctorEnd, null, null);
        bridge.instructions.add(new VarInsnNode(ALOAD, 0));
        bridge.instructions.add(new VarInsnNode(ALOAD, 1));
        bridge.instructions.add(new VarInsnNode(ALOAD, 2));
        bridge.instructions.add(new MethodInsnNode(INVOKESTATIC, TEMPLATE, "fromNonEmptyStack", "(" + SD + ")" + TD, false));
        bridge.instructions.add(new VarInsnNode(ALOAD, 3));
        bridge.instructions.add(new MethodInsnNode(INVOKESPECIAL, SELF, "<init>", ctorStart + TD + ctorEnd, false));
        bridge.instructions.add(new InsnNode(RETURN));
        bridge.maxLocals = 4; bridge.maxStack = 4;
        cls.methods.add(bridge);
        ClassWriter writer = new ClassWriter(ClassWriter.COMPUTE_MAXS);
        cls.accept(writer);
        byte[] bytes = writer.toByteArray();
        ClassNode verified = new ClassNode();
        new ClassReader(bytes).accept(verified, 0);
        for (MethodNode method : verified.methods) {
            new Analyzer<BasicValue>(new BasicVerifier()).analyze(verified.name, method);
        }
        Files.createDirectories(Path.of(args[1]).getParent());
        Files.write(Path.of(args[1]), bytes);
        System.out.println("Patched WorkbenchRecipe; verified " + verified.methods.size() + " methods with ASM BasicVerifier");
    }
}
