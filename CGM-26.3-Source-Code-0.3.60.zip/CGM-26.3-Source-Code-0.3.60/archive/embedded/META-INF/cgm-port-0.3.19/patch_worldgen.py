#!/usr/bin/env python3
"""CGM 0.3.18 -> 0.3.19: migrate world-load data and lazy recipe results.

Usage: python patch_worldgen.py INPUT_JAR PATCHED_RECIPE_CLASS OUTPUT_JAR
Compile and run the adjacent PatchWorkbench.java first (ASM 9.8).
"""
import copy
import hashlib
import json
from pathlib import Path
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
CLASS = 'com/mrcrayfish/guns/crafting/WorkbenchRecipe.class'
OLD_VERSION = b'1.3.7-26.3-port-0.3.18+framework-0.13.27'
NEW_VERSION = b'1.3.7-26.3-port-0.3.19+framework-0.13.27'
TAGS = {
    'forge:ingots/iron': 'c:ingots/iron',
    'forge:nuggets/iron': 'c:nuggets/iron',
    'forge:nuggets/gold': 'c:nuggets/gold',
    'forge:gunpowder': 'c:gunpowders',
    'forge:gems/amethyst': 'c:gems/amethyst',
    'forge:dyes/black': 'c:dyes/black',
    'forge:dyes/red': 'c:dyes/red',
    'forge:dusts/redstone': 'c:dusts/redstone',
    'forge:dusts/glowstone': 'c:dusts/glowstone',
    'forge:glass': 'c:glass_blocks',
    'forge:glass_panes': 'c:glass_panes',
}


def tag_id(value):
    if value.startswith('forge:'):
        assert value in TAGS, value
    return TAGS.get(value, value)


def ingredient(value):
    if isinstance(value, str):
        return '#' + tag_id(value[1:]) if value.startswith('#') else value
    assert isinstance(value, dict) and len(value) == 1, value
    if 'item' in value:
        return value['item']
    assert 'tag' in value, value
    return '#' + tag_id(value['tag'])


def migrate(name, value):
    if name.startswith('data/cgm/recipe/'):
        if value['type'] == 'cgm:workbench':
            for material in value['materials']:
                material['ingredient'] = ingredient(material['ingredient'])
        elif value['type'] == 'minecraft:crafting_shaped':
            value['key'] = {k: ingredient(v) for k, v in value['key'].items()}
            if 'item' in value['result']:
                value['result']['id'] = value['result'].pop('item')
    elif name.startswith('data/cgm/advancement/'):
        for criterion in value['criteria'].values():
            conditions = criterion.get('conditions', {})
            if criterion['trigger'] == 'minecraft:recipe_unlocked':
                conditions['recipes'] = conditions.pop('recipe')
            elif criterion['trigger'] == 'minecraft:inventory_changed':
                for predicate in conditions.get('items', []):
                    if 'tag' in predicate:
                        predicate['items'] = '#' + tag_id(predicate.pop('tag'))
    elif name == 'data/cgm/loot_table/blocks/workbench.json':
        for pool in value['pools']:
            condition = pool['condition']
            condition['type'] = condition.pop('condition')
            assert pool['rolls'] == 1.0
            pool['rolls'] = 1
    elif name == 'data/cgm/tags/block/fragile.json':
        value['values'] = ['#' + tag_id(v[1:]) if v.startswith('#') else v
                           for v in value['values']]
    return value


def main():
    source, patched_class, target = map(Path, sys.argv[1:])
    assert source.resolve() != target.resolve()
    with zipfile.ZipFile(source) as original:
        assert original.testzip() is None
        names = original.namelist()
        assert len(set(names)) == len(names)
        files = {n: original.read(n) for n in names}
        assert OLD_VERSION in files['META-INF/MANIFEST.MF']
        for n, data in list(files.items()):
            if n.startswith('data/cgm/') and n.endswith('.json'):
                before = json.loads(data)
                after = migrate(n, copy.deepcopy(before))
                if before != after:
                    files[n] = (json.dumps(after, indent=2, ensure_ascii=False) + '\n').encode()
        files[CLASS] = patched_class.read_bytes()
        assert files[CLASS] != original.read(CLASS)
        files['META-INF/MANIFEST.MF'] = files['META-INF/MANIFEST.MF'].replace(OLD_VERSION, NEW_VERSION)
        changes = [n for n in names if files[n] != original.read(n)]
        assert len([n for n in changes if '/recipe/' in n]) == 25
        assert len([n for n in changes if '/advancement/' in n]) == 25
        assert len([n for n in changes if n.endswith('.class')]) == 1
        report = {
            'version': NEW_VERSION.decode(),
            'base_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
            'changed_existing_entries': changes,
            'preserved_original_entries': len(names) - len(changes),
            'class_files_changed': [CLASS],
            'tag_migrations': TAGS,
            'validation': {
                'archive_crc': 'passed',
                'all_json_parse': 'passed',
                'bytecode_basic_verifier': '25 methods passed',
                'target_api_linkage': '5 ItemStackTemplate references verified against the official 26.3 client',
                'lambda_bootstrap_descriptors': '6 exact type checks passed',
                'target_api': 'Minecraft 26.3 official client e877b6a07acd633fb3bb475002175cec036e7b87',
                'full_forge_client_world_creation': 'not performed',
            },
        }
        notes = '''CGM 26.3 / Forge 66.0.2 - world-load hotfix 0.3.19

Fixes the registry-loading failures in the supplied 0.3.18 launcher log:
- Migrate ingredients to modern string/tag syntax, workbench result item to id.
- Use current c: common tags (including c:gunpowders and c:glass_blocks).
- Migrate recipe_unlocked conditions from recipe to recipes in 25 advancements.
- Preserve inventory advancement criteria using modern items predicates.
- Migrate the workbench survives_explosion predicate from condition to type.
- Store workbench recipe results as ItemStackTemplate, not live ItemStack.
  JSON and network codecs both use templates. A live stack is created only
  by getItem(), after item components are available. Preserve the public
  ItemStack constructor as a compatibility bridge.

Earlier reflection and texture-atlas fixes are retained. No recipes,
advancements, guns, models, textures or sounds are removed. The bundled
Framework code is unchanged. Sources for this patch and its validation
report are included under META-INF. Older reports are historical.

Kurulum: Oyunu kapatin. Eski CGM JAR dosyalarini mods klasorunden disari
tasiyin ve bu dosyayi mods klasorune koyun. Framework bu dosyanin icindedir;
ayrica etkin bir Framework JAR'i bulundurmayin. Minecraft 26.3 / Forge 66.0.2
ile once yeni bir deneme dunyasi olusturun.

Full Forge client world-creation/gameplay testing was not performed here.
See META-INF/cgm-port-0.3.19-validation.json for completed checks.
'''
        target.parent.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED) as out:
            out.comment = original.comment
            for info in original.infolist():
                out.writestr(copy.copy(info), files[info.filename])
            out.writestr('META-INF/cgm-port-0.3.19/patch_worldgen.py', Path(__file__).read_bytes())
            out.writestr('META-INF/cgm-port-0.3.19/PatchWorkbench.java', (ROOT/'PatchWorkbench.java').read_bytes())
            out.writestr('META-INF/cgm-port-0.3.19/CheckPatch.java', (ROOT/'CheckPatch.java').read_bytes())
            out.writestr('META-INF/cgm-port-0.3.19-validation.json', json.dumps(report, indent=2)+'\n')
            out.writestr('CGM-26.3-WORLD-LOAD-HOTFIX-0.3.19.txt', notes)
        with zipfile.ZipFile(target) as out:
            assert out.testzip() is None
            assert len(out.namelist()) == len(set(out.namelist()))
            assert set(names) <= set(out.namelist())
            assert [n for n in names if original.read(n) != out.read(n)] == changes
            for n in out.namelist():
                if n.endswith('.json'):
                    json.loads(out.read(n))
            for n in names:
                if n.startswith('com/mrcrayfish/framework/') or n.startswith('assets/'):
                    assert out.read(n) == original.read(n), n
        print(json.dumps({'output': str(target.resolve()), 'sha256': hashlib.sha256(target.read_bytes()).hexdigest(),
                          'changed_entries': len(changes), 'preserved_entries': len(names)-len(changes)}, indent=2))


if __name__ == '__main__':
    main()
