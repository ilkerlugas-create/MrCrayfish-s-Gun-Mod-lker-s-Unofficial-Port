import java.nio.file.*;
import java.util.*;
import java.util.zip.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;

/** Validate every newly referenced target method/field and lambda descriptor. */
public class CheckPatch {
    static ClassNode read(byte[] b) {
        ClassNode c = new ClassNode(); new ClassReader(b).accept(c, 0); return c;
    }
    public static void main(String[] args) throws Exception {
        ClassNode patched = read(Files.readAllBytes(Path.of(args[0])));
        String templateName = "net/minecraft/world/item/ItemStackTemplate";
        ClassNode template;
        try (ZipFile zip = new ZipFile(args[1])) {
            template = read(zip.getInputStream(zip.getEntry(templateName + ".class")).readAllBytes());
        }
        int references = 0, lambdas = 0;
        for (MethodNode m : patched.methods) for (AbstractInsnNode n : m.instructions) {
            if (n instanceof MethodInsnNode c && c.owner.equals(templateName)) {
                if (template.methods.stream().noneMatch(t -> t.name.equals(c.name) && t.desc.equals(c.desc)))
                    throw new AssertionError(c.name + c.desc);
                references++;
            }
            if (n instanceof FieldInsnNode f && f.owner.equals(templateName)) {
                if (template.fields.stream().noneMatch(t -> t.name.equals(f.name) && t.desc.equals(f.desc)))
                    throw new AssertionError(f.name + f.desc);
                references++;
            }
            if (n instanceof InvokeDynamicInsnNode d) {
                Handle h = (Handle)d.bsmArgs[1];
                Type instantiated = (Type)d.bsmArgs[2];
                if (!h.getOwner().equals(patched.name)) throw new AssertionError(h);
                if (patched.methods.stream().noneMatch(t -> t.name.equals(h.getName()) && t.desc.equals(h.getDesc())))
                    throw new AssertionError(h);
                Type target = Type.getMethodType(h.getDesc());
                List<Type> inputs = new ArrayList<>();
                if (h.getTag() != Opcodes.H_INVOKESTATIC) inputs.add(Type.getObjectType(h.getOwner()));
                inputs.addAll(Arrays.asList(target.getArgumentTypes()));
                if (!inputs.equals(Arrays.asList(instantiated.getArgumentTypes())) ||
                        !target.getReturnType().equals(instantiated.getReturnType()))
                    throw new AssertionError("Lambda descriptor mismatch: " + h);
                lambdas++;
            }
        }
        if (references != 5 || lambdas != 6) throw new AssertionError(references + "/" + lambdas);
        System.out.println("PASS: " + references + " new Minecraft 26.3 API references; " + lambdas + " exact lambda descriptors");
    }
}
