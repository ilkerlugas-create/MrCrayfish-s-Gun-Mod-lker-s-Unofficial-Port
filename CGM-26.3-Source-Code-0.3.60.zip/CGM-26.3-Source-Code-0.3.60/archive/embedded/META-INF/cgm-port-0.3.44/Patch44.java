import java.nio.file.*;
import jdk.internal.org.objectweb.asm.*;
import jdk.internal.org.objectweb.asm.tree.*;

public final class Patch44 implements Opcodes {
    static ClassNode read(Path p) throws Exception {
        byte[] original = Files.readAllBytes(p);
        int major = ((original[6] & 255) << 8) | (original[7] & 255);
        byte[] masked = original.clone();
        masked[6] = 0; masked[7] = 65;
        ClassNode c = new ClassNode();
        new ClassReader(masked).accept(c, 0);
        c.version = major;
        return c;
    }
    static void write(ClassNode c, Path p) throws Exception {
        ClassWriter w = new ClassWriter(ClassWriter.COMPUTE_MAXS);
        c.accept(w);
        Files.write(p, w.toByteArray());
    }
    static MethodNode method(ClassNode c, String name, String desc) {
        return c.methods.stream().filter(m -> m.name.equals(name) && m.desc.equals(desc)).findFirst()
            .orElseThrow(() -> new IllegalStateException("Missing method " + c.name + "." + name + desc));
    }
    static void addMiniGunCheck(InsnList x, int stackLocal) {
        x.add(new VarInsnNode(ALOAD, stackLocal));
        x.add(new MethodInsnNode(INVOKEVIRTUAL, "net/minecraft/world/item/ItemStack", "getItem", "()Lnet/minecraft/world/item/Item;", false));
        x.add(new FieldInsnNode(GETSTATIC, "com/mrcrayfish/guns/init/ModItems", "MINI_GUN", "Lnet/minecraftforge/registries/RegistryObject;"));
        x.add(new MethodInsnNode(INVOKEVIRTUAL, "net/minecraftforge/registries/RegistryObject", "get", "()Ljava/lang/Object;", false));
        x.add(new MethodInsnNode(INVOKESTATIC, "java/util/Objects", "equals", "(Ljava/lang/Object;Ljava/lang/Object;)Z", false));
    }
    public static void main(String[] args) throws Exception {
        Path root = Path.of(args[0]);

        // Runtime floor: mini gun must expose at least 124-round capacity.
        Path gehPath = root.resolve("com/mrcrayfish/guns/util/GunEnchantmentHelper.class");
        ClassNode geh = read(gehPath);
        MethodNode capacity = method(geh, "getAmmoCapacity", "(Lnet/minecraft/world/item/ItemStack;Lcom/mrcrayfish/guns/common/Gun;)I");
        AbstractInsnNode capReturn = null;
        for (AbstractInsnNode n = capacity.instructions.getFirst(); n != null; n = n.getNext()) if (n.getOpcode() == IRETURN) capReturn = n;
        if (capReturn == null) throw new IllegalStateException("Missing getAmmoCapacity return");
        InsnList floor = new InsnList();
        addMiniGunCheck(floor, 0);
        floor.add(new IntInsnNode(BIPUSH, 124));
        floor.add(new InsnNode(IMUL));
        floor.add(new MethodInsnNode(INVOKESTATIC, "java/lang/Math", "max", "(II)I", false));
        capacity.instructions.insertBefore(capReturn, floor);
        write(geh, gehPath);

        // Reload in one vanilla stack-sized chunk. Capacity clamp means the second 64 stack adds only 60.
        Path rtPath = root.resolve("com/mrcrayfish/guns/common/ReloadTracker.class");
        ClassNode rt = read(rtPath);
        MethodNode increase = method(rt, "increaseAmmo", "(Lnet/minecraft/world/entity/player/Player;)V");
        MethodInsnNode firstMax = null;
        for (AbstractInsnNode n = increase.instructions.getFirst(); n != null; n = n.getNext()) {
            if (n instanceof MethodInsnNode m && m.getOpcode() == INVOKESTATIC && m.owner.equals("java/lang/Math") && m.name.equals("max") && m.desc.equals("(II)I")) { firstMax = m; break; }
        }
        if (firstMax == null) throw new IllegalStateException("Missing reload Math.max");
        InsnList reloadFloor = new InsnList();
        reloadFloor.add(new VarInsnNode(ALOAD, 0));
        reloadFloor.add(new FieldInsnNode(GETFIELD, "com/mrcrayfish/guns/common/ReloadTracker", "stack", "Lnet/minecraft/world/item/ItemStack;"));
        addMiniGunCheckFromItemStackAlreadyOnStack(reloadFloor);
        reloadFloor.add(new IntInsnNode(BIPUSH, 64));
        reloadFloor.add(new InsnNode(IMUL));
        reloadFloor.add(new MethodInsnNode(INVOKESTATIC, "java/lang/Math", "max", "(II)I", false));
        increase.instructions.insert(firstMax, reloadFloor);
        write(rt, rtPath);

        System.out.println("PASS: mini gun 124-round capacity floor and 64-round reload chunk");
    }
    static void addMiniGunCheckFromItemStackAlreadyOnStack(InsnList x) {
        x.add(new MethodInsnNode(INVOKEVIRTUAL, "net/minecraft/world/item/ItemStack", "getItem", "()Lnet/minecraft/world/item/Item;", false));
        x.add(new FieldInsnNode(GETSTATIC, "com/mrcrayfish/guns/init/ModItems", "MINI_GUN", "Lnet/minecraftforge/registries/RegistryObject;"));
        x.add(new MethodInsnNode(INVOKEVIRTUAL, "net/minecraftforge/registries/RegistryObject", "get", "()Ljava/lang/Object;", false));
        x.add(new MethodInsnNode(INVOKESTATIC, "java/util/Objects", "equals", "(Ljava/lang/Object;Ljava/lang/Object;)Z", false));
    }
}
