from pathlib import Path
import zipfile, hashlib, json

BASE=Path('/mnt/data/CGM-26.3-Forge66.0.2-0.3.41-BOMBAATAR-6.jar')
OUT=Path('/mnt/data/CGM-26.3-Forge66.0.2-0.3.42-SUSTURUCU-BOMBAATAR-FIX.jar')
PATCH=Path('/mnt/data/cgm_patch/patched42')
SRC=Path('/mnt/data/cgm_patch/Patch42.java')

updates={
 'com/mrcrayfish/guns/util/GunModifierHelper.class': (PATCH/'com/mrcrayfish/guns/util/GunModifierHelper.class').read_bytes(),
 'com/mrcrayfish/guns/util/GunEnchantmentHelper.class': (PATCH/'com/mrcrayfish/guns/util/GunEnchantmentHelper.class').read_bytes(),
 'com/mrcrayfish/guns/common/ReloadTracker.class': (PATCH/'com/mrcrayfish/guns/common/ReloadTracker.class').read_bytes(),
}
with zipfile.ZipFile(BASE,'r') as z:
    manifest=z.read('META-INF/MANIFEST.MF').replace(b'port-0.3.41', b'port-0.3.42')
    mods=z.read('META-INF/mods.toml').replace(b'port-0.3.41', b'port-0.3.42')
    assert manifest != z.read('META-INF/MANIFEST.MF')
    assert mods != z.read('META-INF/mods.toml')
    gun=json.loads(z.read('data/cgm/guns/grenade_launcher.json'))
    assert gun['general']['maxAmmo']==6 and gun['general']['reloadAmount']==6
    sounds=json.loads(z.read('assets/cgm/sounds.json'))
    for kind in ['pistol','shotgun','rifle','assault_rifle','machine_pistol','heavy_rifle']:
        data=json.loads(z.read(f'data/cgm/guns/{kind}.json'))
        assert 'silencedFire' in data['sounds'], kind
        key=data['sounds']['silencedFire'].removeprefix('cgm:')
        assert key in sounds, (kind,key)
        res=sounds[key]['sounds'][0]['name'].removeprefix('cgm:')
        assert f'assets/cgm/sounds/{res}.ogg' in z.namelist(), res
    updates['META-INF/MANIFEST.MF']=manifest
    updates['META-INF/mods.toml']=mods

readme='''0.3.42 — Susturucu ses rotası + bombaatar 6 atış garantisi
Minecraft 26.3 / Forge 66.0.2
Taban: 0.3.41 BOMBAATAR-6.

SUSTURUCU
- Susturucu takılı silah artık normal ateş sesine düşmez.
- Mevcut modifier algısı korunur; ayrıca BARREL slotunda cgm:silencer doğrudan tanınır.
- Pistol, shotgun, rifle, assault rifle, machine pistol ve heavy rifle için mevcut ayrı silenced_fire sesleri kullanılır.
- Susturucu ses seviyesi en fazla 0.28'e çekilir; aynı azaltma iki kez uygulanmaz.
- Ses yayılma/duyulma mesafesi de normalin en fazla %25'i olacak şekilde güvenceye alınır.

BOMBAATAR
- data/cgm/guns/grenade_launcher.json içindeki maxAmmo=6 ve reloadAmount=6 korunur.
- Buna ek olarak çalışma kodunda bombaatar kapasitesi en az 6'ya sabitlenir.
- Eski/custom silah NBT verisinde kapasite veya reloadAmount 1 kalmış olsa bile bombaatar en az 6 bomba alabilir.
- R ile doldurma işlemi, mevcut cephane ve boş kapasite izin verdiği ölçüde tek geçişte 6'ya kadar bomba yükler.
- Normal atış tüketimi bir bomba/atış olarak kaldığı için tam dolu bombaatar 6 kez ateş edebilir.

KURULUM
Önceki CGM JAR'ını kaldırıp bu JAR'ı tek başına mods klasörüne koy.
Çok oyunculuda istemci ve sunucu aynı sürümü kullanmalı.

DOĞRULAMA
- Değiştirilen bytecode yöntemleri ASM BasicVerifier ile kontrol edildi.
- Susturulmuş ses kayıtları ve gun JSON rotaları arşiv içinde doğrulandı.
- Bombaatar JSON kapasitesi 6/6 olarak doğrulandı.
- JAR CRC ve benzersiz-entry kontrolleri yapıldı.
- Oyun içi gerçek runtime testi bu ortamda yapılamadı.
'''.encode('utf-8')
updates['CGM-0.3.42-OKU.txt']=readme
updates['META-INF/cgm-port-0.3.42/Patch42.java']=SRC.read_bytes()
validation={
 'base_sha256':hashlib.sha256(BASE.read_bytes()).hexdigest(),
 'version':'1.3.7-26.3-port-0.3.42',
 'silencer':{
   'fallback_detection':'BARREL attachment equals ModItems.SILENCER',
   'sound_selection':'ServerPlayHandler existing getFireSound path now receives true even if generic modifier decode falls through',
   'volume_cap':0.28,
   'radius_cap_multiplier':0.25,
   'existing_silenced_samples_verified':['pistol','shotgun','rifle','assault_rifle','machine_pistol','heavy_rifle']
 },
 'grenade_launcher':{
   'json_maxAmmo':6,'json_reloadAmount':6,
   'runtime_capacity_floor':6,
   'runtime_reload_request_floor':6,
   'normal_shot_consumption':'existing one round per shot preserved'
 },
 'modified_runtime_classes':[
   'com/mrcrayfish/guns/util/GunModifierHelper.class',
   'com/mrcrayfish/guns/util/GunEnchantmentHelper.class',
   'com/mrcrayfish/guns/common/ReloadTracker.class'
 ],
 'verification':['ASM BasicVerifier on all methods of the three modified classes','javap inspection of inserted bytecode','archive CRC','unique zip entries','resource route assertions'],
 'in_game_test':False
}
updates['META-INF/cgm-port-0.3.42/validation.json']=json.dumps(validation,ensure_ascii=False,indent=2).encode('utf-8')
updates['META-INF/cgm-port-0.3.42/package42.py']=Path(__file__).read_bytes()

with zipfile.ZipFile(BASE,'r') as src, zipfile.ZipFile(OUT,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as dst:
    seen=set()
    for info in src.infolist():
        name=info.filename
        if name in seen: raise RuntimeError('duplicate base entry '+name)
        seen.add(name)
        data=updates.pop(name, src.read(name))
        # Preserve basic entry metadata where practical.
        new=zipfile.ZipInfo(name, date_time=info.date_time)
        new.compress_type=zipfile.ZIP_DEFLATED
        new.comment=info.comment
        new.extra=info.extra
        new.internal_attr=info.internal_attr
        new.external_attr=info.external_attr
        new.create_system=info.create_system
        dst.writestr(new,data)
    for name,data in updates.items():
        if name in seen: raise RuntimeError('duplicate update '+name)
        dst.writestr(name,data)

with zipfile.ZipFile(BASE,'r') as b, zipfile.ZipFile(OUT,'r') as o:
    assert o.testzip() is None
    assert len(o.namelist())==len(set(o.namelist()))
    old=set(b.namelist()); new=set(o.namelist())
    added=new-old
    assert {'CGM-0.3.42-OKU.txt','META-INF/cgm-port-0.3.42/Patch42.java','META-INF/cgm-port-0.3.42/validation.json','META-INF/cgm-port-0.3.42/package42.py'} <= added
    changed={n for n in old if b.read(n)!=o.read(n)}
    expected={
      'META-INF/MANIFEST.MF','META-INF/mods.toml',
      'com/mrcrayfish/guns/util/GunModifierHelper.class',
      'com/mrcrayfish/guns/util/GunEnchantmentHelper.class',
      'com/mrcrayfish/guns/common/ReloadTracker.class'
    }
    assert changed==expected,(changed,expected)
    gun=json.loads(o.read('data/cgm/guns/grenade_launcher.json'))
    assert gun['general']['maxAmmo']==6 and gun['general']['reloadAmount']==6
    assert b'port-0.3.42' in o.read('META-INF/MANIFEST.MF')
    assert b'port-0.3.42' in o.read('META-INF/mods.toml')
print('PASS',OUT)
print('SHA256',hashlib.sha256(OUT.read_bytes()).hexdigest())
print('SIZE',OUT.stat().st_size)
