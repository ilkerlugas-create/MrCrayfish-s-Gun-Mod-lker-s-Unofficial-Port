import java.nio.file.*;
import java.util.*;
import jdk.internal.org.objectweb.asm.*;
import jdk.internal.org.objectweb.asm.tree.*;

public final class Patch42 implements Opcodes {
    static ClassNode read(Path p) throws Exception {
        byte[] original = Files.readAllBytes(p);
        int major = ((original[6] & 255) << 8) | (original[7] & 255);
        byte[] masked = original.clone();
        masked[6] = 0; masked[7] = 65; // JDK 21's bundled ASM parser ceiling
        ClassNode c = new ClassNode();
        new ClassReader(masked).accept(c, 0);
        c.version = major;
        return c;
    }
    static void write(ClassNode c, Path p) throws Exception {
        ClassWriter w = new ClassWriter(ClassWriter.COMPUTE_MAXS);
        c.accept(w);
        byte[] out = w.toByteArray();
        Files.createDirectories(p.getParent());
        Files.write(p, out);
    }
    static AbstractInsnNode prevOpcode(AbstractInsnNode n) {
        for (AbstractInsnNode p=n.getPrevious(); p!=null; p=p.getPrevious()) if (p.getOpcode() >= 0) return p;
        return null;
    }
    static MethodNode method(ClassNode c, String name, String desc) {
        return c.methods.stream().filter(m -> m.name.equals(name) && m.desc.equals(desc)).findFirst()
                .orElseThrow(() -> new IllegalStateException("Missing method " + c.name + "." + name + desc));
    }
    static void addExactSilencerCheck(InsnList x, int stackLocal) {
        x.add(new FieldInsnNode(GETSTATIC, "com/mrcrayfish/guns/item/attachment/IAttachment$Type", "BARREL", "Lcom/mrcrayfish/guns/item/attachment/IAttachment$Type;"));
        x.add(new VarInsnNode(ALOAD, stackLocal));
        x.add(new MethodInsnNode(INVOKESTATIC, "com/mrcrayfish/guns/common/Gun", "getAttachment", "(Lcom/mrcrayfish/guns/item/attachment/IAttachment$Type;Lnet/minecraft/world/item/ItemStack;)Lnet/minecraft/world/item/ItemStack;", false));
        x.add(new MethodInsnNode(INVOKEVIRTUAL, "net/minecraft/world/item/ItemStack", "getItem", "()Lnet/minecraft/world/item/Item;", false));
        x.add(new FieldInsnNode(GETSTATIC, "com/mrcrayfish/guns/init/ModItems", "SILENCER", "Lnet/minecraftforge/registries/RegistryObject;"));
        x.add(new MethodInsnNode(INVOKEVIRTUAL, "net/minecraftforge/registries/RegistryObject", "get", "()Ljava/lang/Object;", false));
        x.add(new MethodInsnNode(INVOKESTATIC, "java/util/Objects", "equals", "(Ljava/lang/Object;Ljava/lang/Object;)Z", false));
    }
    static void addGrenadeLauncherCheck(InsnList x, int stackLocal) {
        x.add(new VarInsnNode(ALOAD, stackLocal));
        x.add(new MethodInsnNode(INVOKEVIRTUAL, "net/minecraft/world/item/ItemStack", "getItem", "()Lnet/minecraft/world/item/Item;", false));
        x.add(new FieldInsnNode(GETSTATIC, "com/mrcrayfish/guns/init/ModItems", "GRENADE_LAUNCHER", "Lnet/minecraftforge/registries/RegistryObject;"));
        x.add(new MethodInsnNode(INVOKEVIRTUAL, "net/minecraftforge/registries/RegistryObject", "get", "()Ljava/lang/Object;", false));
        x.add(new MethodInsnNode(INVOKESTATIC, "java/util/Objects", "equals", "(Ljava/lang/Object;Ljava/lang/Object;)Z", false));
    }
    public static void main(String[] args) throws Exception {
        Path root = Path.of(args[0]);

        // 1) Robust silencer detection: keep generic modifier path, but if it falls through,
        // explicitly recognize CGM's registered silencer in the BARREL slot.
        Path gmhPath = root.resolve("com/mrcrayfish/guns/util/GunModifierHelper.class");
        ClassNode gmh = read(gmhPath);
        MethodNode silenced = method(gmh, "isSilencedFire", "(Lnet/minecraft/world/item/ItemStack;)Z");
        AbstractInsnNode lastIReturn = null;
        for (AbstractInsnNode n=silenced.instructions.getFirst(); n!=null; n=n.getNext()) if (n.getOpcode()==IRETURN) lastIReturn=n;
        if (lastIReturn == null || prevOpcode(lastIReturn)==null || prevOpcode(lastIReturn).getOpcode()!=ICONST_0)
            throw new IllegalStateException("Unexpected isSilencedFire tail");
        AbstractInsnNode oldFalse = prevOpcode(lastIReturn);
        InsnList exact = new InsnList(); addExactSilencerCheck(exact, 0);
        silenced.instructions.insertBefore(oldFalse, exact);
        silenced.instructions.remove(oldFalse);

        // 2) Robust silencer volume: preserve any existing modifier reduction, but cap exact
        // silencer shots at 0.28 volume. If the generic modifier already worked, no double reduction.
        MethodNode volume = method(gmh, "getFireSoundVolume", "(Lnet/minecraft/world/item/ItemStack;)F");
        AbstractInsnNode freturn = null;
        for (AbstractInsnNode n=volume.instructions.getFirst(); n!=null; n=n.getNext()) if (n.getOpcode()==FRETURN) freturn=n;
        if (freturn == null) throw new IllegalStateException("Missing getFireSoundVolume return");
        InsnList cap = new InsnList();
        cap.add(new LdcInsnNode(16.0f));
        addExactSilencerCheck(cap, 0);
        cap.add(new InsnNode(I2F));
        cap.add(new LdcInsnNode(15.72f));
        cap.add(new InsnNode(FMUL));
        cap.add(new InsnNode(FSUB)); // 16.0 - silencerFlag * 15.72 => 0.28 or 16.0
        cap.add(new MethodInsnNode(INVOKESTATIC, "java/lang/Math", "min", "(FF)F", false));
        volume.instructions.insertBefore(freturn, cap);

        // Keep the suppressor's reduced network / mob-hearing radius even if generic modifier decoding fails.
        MethodNode radius = method(gmh, "getModifiedFireSoundRadius", "(Lnet/minecraft/world/item/ItemStack;D)D");
        AbstractInsnNode dreturn = null;
        for (AbstractInsnNode n=radius.instructions.getFirst(); n!=null; n=n.getNext()) if (n.getOpcode()==DRETURN) dreturn=n;
        if (dreturn == null) throw new IllegalStateException("Missing getModifiedFireSoundRadius return");
        InsnList radiusCap = new InsnList();
        radiusCap.add(new VarInsnNode(DSTORE, 13)); // clamped current result
        radiusCap.add(new VarInsnNode(DLOAD, 13)); // Math.min arg 1
        radiusCap.add(new VarInsnNode(DLOAD, 13)); // candidate starts at current result
        addExactSilencerCheck(radiusCap, 0);
        radiusCap.add(new InsnNode(I2D));
        radiusCap.add(new VarInsnNode(DLOAD, 1));
        radiusCap.add(new LdcInsnNode(0.25d));
        radiusCap.add(new InsnNode(DMUL));
        radiusCap.add(new VarInsnNode(DLOAD, 13));
        radiusCap.add(new InsnNode(DSUB)); // base*0.25 - current
        radiusCap.add(new InsnNode(DMUL));
        radiusCap.add(new InsnNode(DADD)); // current + flag*(quarterBase-current)
        radiusCap.add(new MethodInsnNode(INVOKESTATIC, "java/lang/Math", "min", "(DD)D", false));
        radius.instructions.insertBefore(dreturn, radiusCap);
        write(gmh, gmhPath);

        // 3) Grenade launcher capacity floor: existing/current/custom gun data can never reduce it below 6.
        Path gehPath = root.resolve("com/mrcrayfish/guns/util/GunEnchantmentHelper.class");
        ClassNode geh = read(gehPath);
        MethodNode capacity = method(geh, "getAmmoCapacity", "(Lnet/minecraft/world/item/ItemStack;Lcom/mrcrayfish/guns/common/Gun;)I");
        AbstractInsnNode capReturn = null;
        for (AbstractInsnNode n=capacity.instructions.getFirst(); n!=null; n=n.getNext()) if (n.getOpcode()==IRETURN) capReturn=n;
        if (capReturn == null) throw new IllegalStateException("Missing getAmmoCapacity return");
        InsnList floor = new InsnList();
        addGrenadeLauncherCheck(floor, 0);
        floor.add(new IntInsnNode(BIPUSH, 6));
        floor.add(new InsnNode(IMUL));
        floor.add(new MethodInsnNode(INVOKESTATIC, "java/lang/Math", "max", "(II)I", false));
        capacity.instructions.insertBefore(capReturn, floor);
        write(geh, gehPath);

        // 4) Grenade launcher reload floor: a reload pass requests up to 6 rounds even if an old/custom
        // gun NBT copy still says reloadAmount=1. Remaining capacity and available ammo still clamp it.
        Path rtPath = root.resolve("com/mrcrayfish/guns/common/ReloadTracker.class");
        ClassNode rt = read(rtPath);
        MethodNode increase = method(rt, "increaseAmmo", "(Lnet/minecraft/world/entity/player/Player;)V");
        MethodInsnNode firstMax = null;
        for (AbstractInsnNode n=increase.instructions.getFirst(); n!=null; n=n.getNext()) {
            if (n instanceof MethodInsnNode m && m.getOpcode()==INVOKESTATIC && m.owner.equals("java/lang/Math") && m.name.equals("max") && m.desc.equals("(II)I")) { firstMax=m; break; }
        }
        if (firstMax == null) throw new IllegalStateException("Missing reload Math.max");
        InsnList reloadFloor = new InsnList();
        reloadFloor.add(new VarInsnNode(ALOAD, 0));
        reloadFloor.add(new FieldInsnNode(GETFIELD, "com/mrcrayfish/guns/common/ReloadTracker", "stack", "Lnet/minecraft/world/item/ItemStack;"));
        reloadFloor.add(new MethodInsnNode(INVOKEVIRTUAL, "net/minecraft/world/item/ItemStack", "getItem", "()Lnet/minecraft/world/item/Item;", false));
        reloadFloor.add(new FieldInsnNode(GETSTATIC, "com/mrcrayfish/guns/init/ModItems", "GRENADE_LAUNCHER", "Lnet/minecraftforge/registries/RegistryObject;"));
        reloadFloor.add(new MethodInsnNode(INVOKEVIRTUAL, "net/minecraftforge/registries/RegistryObject", "get", "()Ljava/lang/Object;", false));
        reloadFloor.add(new MethodInsnNode(INVOKESTATIC, "java/util/Objects", "equals", "(Ljava/lang/Object;Ljava/lang/Object;)Z", false));
        reloadFloor.add(new IntInsnNode(BIPUSH, 6));
        reloadFloor.add(new InsnNode(IMUL));
        reloadFloor.add(new MethodInsnNode(INVOKESTATIC, "java/lang/Math", "max", "(II)I", false));
        increase.instructions.insert(firstMax, reloadFloor);
        write(rt, rtPath);

        System.out.println("PASS: patched silencer sound selection/volume and grenade launcher capacity/reload floors");
    }
}
