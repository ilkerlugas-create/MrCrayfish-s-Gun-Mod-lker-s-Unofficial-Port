package com.mrcrayfish.guns.port;

import com.mojang.blaze3d.platform.InputConstants;
import com.mrcrayfish.guns.client.KeyBinds;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.input.KeyEvent;

/** Restores R reload for installations with the legacy Up Arrow binding. */
public final class ReloadKey {
    private ReloadKey() {}

    public static void migrateLegacyBinding() {
        KeyMapping reload = KeyBinds.KEY_RELOAD;
        if (!reload.matches(InputConstants.Type.KEYBOARD.getOrCreate(InputConstants.KEY_UP))) {
            return;
        }
        reload.setKey(InputConstants.Type.KEYBOARD.getOrCreate(InputConstants.KEY_R));
        KeyMapping.resetMapping();
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.options != null) {
            minecraft.options.save();
        }
    }

    public static boolean matches(KeyMapping mapping, KeyEvent event) {
        migrateLegacyBinding();
        // R works even if options.txt still contains a different saved binding.
        // Up Arrow must never enter the reload path.
        return event.key() != InputConstants.KEY_UP
            && (event.key() == InputConstants.KEY_R || mapping.matches(event));
    }
}
