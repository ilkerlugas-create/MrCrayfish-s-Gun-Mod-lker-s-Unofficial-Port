from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib
import subprocess

root = Path(__file__).resolve().parents[2]
patch = root / 'work/patch55'
source = root / 'upload/CGM-26.3-Forge66.0.2-0.3.54-FRAMEWORK-SYNC-FIX (1).jar'
output = root / 'CGM-26.3-Forge66.0.2-0.3.55-R-RELOAD.jar'
jdk = Path('/workspace/scratch/d2bb45d8b68f/work/deps/jdk-25/bin')
deps = Path('/workspace/scratch/d2bb45d8b68f/work/deps')
cp = (root / 'work/classpath.txt').read_text().strip()
asm = ':'.join(str(deps / name) for name in ['asm.jar', 'asm-tree.jar', 'asm-analysis.jar', 'asm-util.jar'])
classes = patch / 'classes'
tools = patch / 'tools'
classes.mkdir(parents=True, exist_ok=True)
tools.mkdir(parents=True, exist_ok=True)
subprocess.run([str(jdk / 'javac'), '-proc:none', '--release', '25', '-cp', cp,
                '-d', str(classes), str(patch / 'src/com/mrcrayfish/guns/port/ReloadKey.java')], check=True)
subprocess.run([str(jdk / 'javac'), '-proc:none', '-cp', asm + ':' + cp, '-d', str(tools), str(patch / 'Patch55.java')], check=True)
subprocess.run([str(jdk / 'java'), '-cp', str(tools) + ':' + asm, 'Patch55', str(source), str(classes)], check=True)

patched_handler = 'com/mrcrayfish/guns/client/handler/ReloadHandler.class'
patched_keys = 'com/mrcrayfish/guns/client/KeyBinds.class'
with ZipFile(source) as original, ZipFile(output, 'w', ZIP_DEFLATED) as result:
    assert len(original.namelist()) == len(set(original.namelist()))
    for entry in original.infolist():
        content = original.read(entry)
        if entry.filename in [patched_handler, patched_keys]:
            content = (classes / entry.filename).read_bytes()
        elif entry.filename in ['META-INF/MANIFEST.MF', 'META-INF/mods.toml']:
            assert b'0.3.54' in content
            content = content.replace(b'0.3.54', b'0.3.55')
        result.writestr(entry, content)
    helper_name = 'com/mrcrayfish/guns/port/ReloadKey.class'
    assert helper_name not in original.namelist()
    result.write(classes / helper_name, helper_name)
    for relative in ['src/com/mrcrayfish/guns/port/ReloadKey.java', 'Patch55.java', 'build.py']:
        result.write(patch / relative, 'META-INF/cgm-port-0.3.55/' + relative)

with ZipFile(source) as original, ZipFile(output) as result:
    assert result.testzip() is None
    assert len(result.namelist()) == len(set(result.namelist()))
    assert set(original.namelist()) <= set(result.namelist())
    changed = [n for n in original.namelist() if original.read(n) != result.read(n)]
    assert set(changed) == {patched_handler, patched_keys, 'META-INF/MANIFEST.MF', 'META-INF/mods.toml'}, changed
    print('Changed original entries:', changed)
    print('Added entries:', sorted(set(result.namelist()) - set(original.namelist())))
print('Output:', output)
print('SHA256:', hashlib.sha256(output.read_bytes()).hexdigest())
