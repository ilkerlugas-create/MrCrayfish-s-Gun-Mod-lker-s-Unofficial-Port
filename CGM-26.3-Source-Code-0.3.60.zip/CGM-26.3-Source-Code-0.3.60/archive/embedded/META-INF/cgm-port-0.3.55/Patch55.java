import java.nio.file.Files;
import java.nio.file.Path;
import java.util.zip.ZipFile;
import com.mojang.blaze3d.platform.InputConstants;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.tree.analysis.*;
import org.objectweb.asm.util.CheckClassAdapter;

public final class Patch55 implements Opcodes {
    private static final String HELPER = "com/mrcrayfish/guns/port/ReloadKey";
    private static final String HANDLER = "com/mrcrayfish/guns/client/handler/ReloadHandler";

    public static void main(String[] args) throws Exception {
        ClassNode cls = new ClassNode();
        try (ZipFile zip = new ZipFile(args[0])) {
            new ClassReader(zip.getInputStream(zip.getEntry(HANDLER + ".class"))).accept(cls, 0);
        }
        int tickChanges = 0;
        int keyChanges = 0;
        for (MethodNode method : cls.methods) {
            if (method.name.equals("onClientTick") && method.desc.equals("(Lnet/minecraftforge/event/TickEvent$ClientTickEvent$Post;)V")) {
                method.instructions.insert(new MethodInsnNode(INVOKESTATIC, HELPER,
                    "migrateLegacyBinding", "()V", false));
                tickChanges++;
            }
            if (!method.name.equals("onKeyPressed")) continue;
            boolean reloadMapping = false;
            for (AbstractInsnNode instruction : method.instructions.toArray()) {
                if (instruction instanceof FieldInsnNode field && field.getOpcode() == GETSTATIC
                        && field.owner.equals("com/mrcrayfish/guns/client/KeyBinds")) {
                    reloadMapping = field.name.equals("KEY_RELOAD");
                }
                if (reloadMapping && instruction instanceof MethodInsnNode call
                        && call.owner.equals("net/minecraft/client/KeyMapping")
                        && call.name.equals("matches")
                        && call.desc.equals("(Lnet/minecraft/client/input/KeyEvent;)Z")) {
                    method.instructions.set(call, new MethodInsnNode(INVOKESTATIC, HELPER, "matches",
                        "(Lnet/minecraft/client/KeyMapping;Lnet/minecraft/client/input/KeyEvent;)Z", false));
                    reloadMapping = false;
                    keyChanges++;
                }
            }
        }
        if (tickChanges != 1 || keyChanges != 1) {
            throw new IllegalStateException("Unexpected patch counts: tick=" + tickChanges + ", key=" + keyChanges);
        }
        // Both edits preserve the original operand stack and existing frames.
        ClassWriter writer = new ClassWriter(0);
        cls.accept(writer);
        byte[] bytes = writer.toByteArray();
        verify(bytes);
        Path output = Path.of(args[1], HANDLER + ".class");
        Files.createDirectories(output.getParent());
        Files.write(output, bytes);
        verify(Files.readAllBytes(Path.of(args[1], HELPER + ".class")));
        patchDefaultKey(args[0], args[1]);
        System.out.println("Patched reload key routing and legacy binding migration; class verification passed.");
    }

    private static void patchDefaultKey(String input, String outputDirectory) throws Exception {
        String name = "com/mrcrayfish/guns/client/KeyBinds";
        ClassNode cls = new ClassNode();
        try (ZipFile zip = new ZipFile(input)) {
            new ClassReader(zip.getInputStream(zip.getEntry(name + ".class"))).accept(cls, 0);
        }
        int changes = 0;
        for (MethodNode method : cls.methods) {
            if (!method.name.equals("<clinit>")) continue;
            for (AbstractInsnNode instruction : method.instructions.toArray()) {
                if (instruction instanceof LdcInsnNode text && "key.cgm.reload".equals(text.cst)) {
                    AbstractInsnNode key = instruction.getNext();
                    if (!(key instanceof IntInsnNode code) || code.operand != 82) {
                        throw new IllegalStateException("Unexpected existing reload key code");
                    }
                    // Minecraft 26.3 uses keyboard scancodes: R=21, Up=82.
                    method.instructions.set(key, new IntInsnNode(BIPUSH, InputConstants.KEY_R));
                    changes++;
                }
            }
        }
        if (changes != 1) throw new IllegalStateException("Expected one reload default key, found " + changes);
        ClassWriter writer = new ClassWriter(0);
        cls.accept(writer);
        byte[] bytes = writer.toByteArray();
        verify(bytes);
        Path output = Path.of(outputDirectory, name + ".class");
        Files.createDirectories(output.getParent());
        Files.write(output, bytes);
        System.out.println("Reload default corrected from legacy 82 (Up) to " + InputConstants.KEY_R + " (R).");
    }

    private static void verify(byte[] bytes) throws Exception {
        ClassReader reader = new ClassReader(bytes);
        reader.accept(new CheckClassAdapter(new ClassWriter(0), true), 0);
        ClassNode cls = new ClassNode();
        reader.accept(cls, 0);
        for (MethodNode method : cls.methods) {
            if ((method.access & (ACC_ABSTRACT | ACC_NATIVE)) == 0) {
                new Analyzer<BasicValue>(new BasicVerifier()).analyze(cls.name, method);
            }
        }
    }
}
