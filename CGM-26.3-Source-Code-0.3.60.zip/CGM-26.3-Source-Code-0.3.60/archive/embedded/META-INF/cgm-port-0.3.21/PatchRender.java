import java.nio.file.*;
import java.util.*;
import java.util.jar.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.tree.analysis.*;
public class PatchRender implements Opcodes {
 public static void main(String[] args)throws Exception {
  int vertices=0,wrap=0,sleeves=0,hands=0;
  try(JarFile jar=new JarFile(args[0])) {
   var entries=jar.entries();while(entries.hasMoreElements()) {
    var e=entries.nextElement();String name=e.getName();
    if(!name.endsWith(".class") || !(name.endsWith("GunRenderingHandler.class") || name.endsWith("PlayerModelMixin.class") || name.startsWith("com/mrcrayfish/guns/client/render/pose/")))continue;
    ClassNode c=new ClassNode();new ClassReader(jar.getInputStream(e)).accept(c,0);boolean changed=false;
    for(MethodNode m:c.methods) {
     if(c.name.endsWith("/GunRenderingHandler") && m.name.startsWith("lambda$drawMuzzleFlash$")) {
      for(var n:m.instructions.toArray()) if(n instanceof MethodInsnNode call && call.name.equals("setLight")) {
       InsnList add=new InsnList();
       add.add(new FieldInsnNode(GETSTATIC,"net/minecraft/client/renderer/texture/OverlayTexture","NO_OVERLAY","I"));
       add.add(new MethodInsnNode(INVOKEINTERFACE,"com/mojang/blaze3d/vertex/VertexConsumer","setOverlay","(I)Lcom/mojang/blaze3d/vertex/VertexConsumer;",true));
       add.add(new VarInsnNode(ALOAD,2));add.add(new InsnNode(FCONST_0));add.add(new InsnNode(FCONST_0));add.add(new InsnNode(FCONST_1));
       add.add(new MethodInsnNode(INVOKEINTERFACE,"com/mojang/blaze3d/vertex/VertexConsumer","setNormal","(Lcom/mojang/blaze3d/vertex/PoseStack$Pose;FFF)Lcom/mojang/blaze3d/vertex/VertexConsumer;",true));
       m.instructions.insert(n,add);vertices++;changed=true;
      }
     }
     if(c.name.endsWith("/GunRenderingHandler") && m.name.equals("renderWeapon")) {
      for(var n:m.instructions.toArray()) if(n instanceof MethodInsnNode call && call.owner.equals(c.name)) {
       if(call.name.equals("renderGun")) {
        InsnList a=new InsnList();a.add(new VarInsnNode(ALOAD,4));a.add(new MethodInsnNode(INVOKEVIRTUAL,"com/mojang/blaze3d/vertex/PoseStack","pushPose","()V",false));
        a.add(new VarInsnNode(ALOAD,2));a.add(new VarInsnNode(ALOAD,3));a.add(new VarInsnNode(ALOAD,4));
        a.add(new MethodInsnNode(INVOKESTATIC,"com/mrcrayfish/guns/port/EffectTransforms","apply","(Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemDisplayContext;Lcom/mojang/blaze3d/vertex/PoseStack;)V",false));
        m.instructions.insert(n,a);wrap++;changed=true;
       }
       if(call.name.equals("renderMuzzleFlash")) {
        InsnList a=new InsnList();a.add(new VarInsnNode(ALOAD,4));a.add(new MethodInsnNode(INVOKEVIRTUAL,"com/mojang/blaze3d/vertex/PoseStack","popPose","()V",false));m.instructions.insert(n,a);wrap++;
       }
      }
     }
     if(c.name.endsWith("/PlayerModelMixin") && m.name.equals("copyModelAngles")) {
      // Since 26.3, sleeves and hat are child parts. They already inherit
      // parent transforms; copying rotation again bends them a second time.
      m.instructions.clear();m.tryCatchBlocks.clear();if(m.localVariables!=null)m.localVariables.clear();m.instructions.add(new InsnNode(RETURN));m.maxStack=0;sleeves++;changed=true;
     }
     if(c.name.contains("/render/pose/") && m.desc.startsWith("(Lnet/minecraft/world/entity/player/Player;")) {
      for(var n:m.instructions.toArray()) {
       if(!(n instanceof MethodInsnNode call) || !call.owner.equals("net/minecraft/client/Minecraft") || !call.name.equals("getInstance"))continue;
       var p=n.getNext();List<AbstractInsnNode> seq=new ArrayList<>();seq.add(n);
       // Match exactly getInstance().options.mainHand().get(), then cast.
       if(!(p instanceof FieldInsnNode f) || !f.name.equals("options"))continue;seq.add(p);p=p.getNext();
       if(!(p instanceof MethodInsnNode a) || !a.name.equals("mainHand"))continue;seq.add(p);p=p.getNext();
       if(!(p instanceof MethodInsnNode b) || !b.name.equals("get"))continue;seq.add(p);p=p.getNext();
       if(p instanceof TypeInsnNode t && t.desc.equals("net/minecraft/world/entity/HumanoidArm"))seq.add(p);
       InsnList replacement=new InsnList();replacement.add(new VarInsnNode(ALOAD,1));replacement.add(new MethodInsnNode(INVOKEVIRTUAL,"net/minecraft/world/entity/player/Player","getMainArm","()Lnet/minecraft/world/entity/HumanoidArm;",false));
       m.instructions.insertBefore(n,replacement);for(var old:seq)m.instructions.remove(old);hands++;changed=true;
      }
     }
    }
    if(changed) {
     ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);byte[] bytes=w.toByteArray();
     ClassNode v=new ClassNode();new ClassReader(bytes).accept(v,0);for(MethodNode m:v.methods)if((m.access&(ACC_ABSTRACT|ACC_NATIVE))==0)new Analyzer<>(new BasicVerifier()).analyze(v.name,m);
     Path target=Path.of(args[1],name);Files.createDirectories(target.getParent());Files.write(target,bytes);System.out.println("Verified "+name);
    }
   }
  }
  if(vertices!=4 || wrap!=2 || sleeves!=1 || hands<1)throw new IllegalStateException("Unexpected counts "+vertices+","+wrap+","+sleeves+","+hands);
  System.out.println("Patched 4 complete ENTITY vertices, paired effect transforms, child-part rotation fix, "+hands+" player-specific handedness sites.");
 }
}
