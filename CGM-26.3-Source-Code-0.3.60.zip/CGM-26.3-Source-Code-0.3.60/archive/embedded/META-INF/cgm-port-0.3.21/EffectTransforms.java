package com.mrcrayfish.guns.port;
import java.util.*;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.resources.model.cuboid.ItemTransform;
import net.minecraft.world.item.*;
import net.minecraftforge.registries.ForgeRegistries;
import org.joml.Vector3f;
public final class EffectTransforms {
 private static final Map<String,Map<String,ItemTransform>> TRANSFORMS=new HashMap<>();
 static {
  {Map<String,ItemTransform> m=new HashMap<>();
   m.put("thirdperson_righthand",new ItemTransform(new Vector3f(0.0F,0.0F,0.0F),new Vector3f(0.0F,0.40625F,-0.421875F),new Vector3f(1.1F,1.1F,1.1F)));
   m.put("firstperson_righthand",new ItemTransform(new Vector3f(0.0F,0.0F,0.0F),new Vector3f(-0.3125F,0.53125F,0.0F),new Vector3f(0.8F,0.8F,0.8F)));
   m.put("ground",new ItemTransform(new Vector3f(0.0F,0.0F,0.0F),new Vector3f(0.0F,0.3125F,-0.0625F),new Vector3f(1.0F,1.0F,1.0F)));
   m.put("gui",new ItemTransform(new Vector3f(30.0F,225.0F,0.0F),new Vector3f(0.078125F,0.28125F,0.0F),new Vector3f(1.2F,1.2F,1.2F)));
   m.put("fixed",new ItemTransform(new Vector3f(0.0F,90.0F,0.0F),new Vector3f(-0.203125F,0.703125F,-0.125F),new Vector3f(2.0F,2.0F,2.0F)));
   TRANSFORMS.put("assault_rifle",m);}
  {Map<String,ItemTransform> m=new HashMap<>();
   m.put("thirdperson_righthand",new ItemTransform(new Vector3f(0.0F,0.0F,0.0F),new Vector3f(0.0F,0.40625F,0.109375F),new Vector3f(1.1F,1.1F,1.1F)));
   m.put("firstperson_righthand",new ItemTransform(new Vector3f(0.0F,0.0F,0.0F),new Vector3f(-0.21875F,0.53125F,0.359375F),new Vector3f(0.8F,0.8F,0.8F)));
   m.put("ground",new ItemTransform(new Vector3f(0.0F,0.0F,0.0F),new Vector3f(0.0F,0.3125F,-0.015625F),new Vector3f(1.0F,1.0F,1.0F)));
   m.put("gui",new ItemTransform(new Vector3f(30.0F,225.0F,0.0F),new Vector3f(-0.015625F,0.15625F,0.0F),new Vector3f(0.9F,0.9F,0.9F)));
   m.put("fixed",new ItemTransform(new Vector3f(0.0F,90.0F,0.0F),new Vector3f(-0.03125F,0.578125F,-0.125F),new Vector3f(2.0F,2.0F,2.0F)));
   TRANSFORMS.put("bazooka",m);}
  {Map<String,ItemTransform> m=new HashMap<>();
   m.put("thirdperson_righthand",new ItemTransform(new Vector3f(0.0F,0.0F,0.0F),new Vector3f(0.0F,0.40625F,-0.421875F),new Vector3f(1.1F,1.1F,1.1F)));
   m.put("firstperson_righthand",new ItemTransform(new Vector3f(0.0F,0.0F,0.0F),new Vector3f(-0.3125F,0.53125F,0.0F),new Vector3f(0.8F,0.8F,0.8F)));
   m.put("ground",new ItemTransform(new Vector3f(0.0F,0.0F,0.0F),new Vector3f(0.0F,0.3125F,-0.15625F),new Vector3f(1.0F,1.0F,1.0F)));
   m.put("gui",new ItemTransform(new Vector3f(30.0F,225.0F,0.0F),new Vector3f(0.140625F,0.328125F,0.0F),new Vector3f(1.3F,1.3F,1.3F)));
   m.put("fixed",new ItemTransform(new Vector3f(0.0F,90.0F,0.0F),new Vector3f(-0.34375F,0.75F,-0.125F),new Vector3f(2.0F,2.0F,2.0F)));
   TRANSFORMS.put("grenade_launcher",m);}
  {Map<String,ItemTransform> m=new HashMap<>();
   m.put("thirdperson_righthand",new ItemTransform(new Vector3f(0.0F,0.0F,0.0F),new Vector3f(0.0F,0.4375F,-0.46875F),new Vector3f(1.2F,1.2F,1.2F)));
   m.put("firstperson_righthand",new ItemTransform(new Vector3f(0.0F,0.0F,0.0F),new Vector3f(-0.3125F,0.53125F,0.0F),new Vector3f(0.8F,0.8F,0.8F)));
   m.put("ground",new ItemTransform(new Vector3f(0.0F,0.0F,0.0F),new Vector3f(0.0F,0.3125F,-0.203125F),new Vector3f(1.0F,1.0F,1.0F)));
   m.put("gui",new ItemTransform(new Vector3f(30.0F,225.0F,0.0F),new Vector3f(0.078125F,0.15625F,0.0F),new Vector3f(0.9F,0.9F,0.9F)));
   m.put("head",new ItemTransform(new Vector3f(0.0F,180.0F,0.0F),new Vector3f(0.0F,0.0F,0.0F),new Vector3f(1.0F,1.0F,1.0F)));
   m.put("fixed",new ItemTransform(new Vector3f(0.0F,90.0F,0.0F),new Vector3f(-0.578125F,0.71875F,-0.125F),new Vector3f(2.0F,2.0F,2.0F)));
   TRANSFORMS.put("heavy_rifle",m);}
  {Map<String,ItemTransform> m=new HashMap<>();
   m.put("thirdperson_righthand",new ItemTransform(new Vector3f(22.5F,0.0F,0.0F),new Vector3f(0.0F,0.625F,-0.25F),new Vector3f(1.2F,1.2F,1.2F)));
   m.put("firstperson_righthand",new ItemTransform(new Vector3f(0.0F,0.0F,0.0F),new Vector3f(-0.3125F,0.53125F,0.0F),new Vector3f(0.8F,0.8F,0.8F)));
   m.put("ground",new ItemTransform(new Vector3f(0.0F,0.0F,0.0F),new Vector3f(0.0F,0.3125F,-0.34375F),new Vector3f(1.0F,1.0F,1.0F)));
   m.put("gui",new ItemTransform(new Vector3f(30.0F,225.0F,0.0F),new Vector3f(0.3125F,0.265625F,0.0F),new Vector3f(1.3F,1.3F,1.3F)));
   m.put("fixed",new ItemTransform(new Vector3f(0.0F,90.0F,0.0F),new Vector3f(-0.671875F,0.78125F,-0.125F),new Vector3f(2.0F,2.0F,2.0F)));
   TRANSFORMS.put("machine_pistol",m);}
  {Map<String,ItemTransform> m=new HashMap<>();
   m.put("thirdperson_righthand",new ItemTransform(new Vector3f(75.0F,0.0F,0.0F),new Vector3f(0.0F,0.609375F,0.171875F),new Vector3f(1.1F,1.1F,1.1F)));
   m.put("firstperson_righthand",new ItemTransform(new Vector3f(0.0F,0.0F,0.0F),new Vector3f(0.015625F,0.34375F,0.0F),new Vector3f(0.8F,0.8F,0.8F)));
   m.put("ground",new ItemTransform(new Vector3f(0.0F,0.0F,0.0F),new Vector3f(0.0F,0.3125F,0.015625F),new Vector3f(1.0F,1.0F,1.0F)));
   m.put("gui",new ItemTransform(new Vector3f(30.0F,225.0F,0.0F),new Vector3f(-0.015625F,0.21875F,0.0F),new Vector3f(0.8F,0.8F,0.8F)));
   m.put("head",new ItemTransform(new Vector3f(0.0F,180.0F,0.0F),new Vector3f(0.0F,0.0F,0.0F),new Vector3f(1.0F,1.0F,1.0F)));
   m.put("fixed",new ItemTransform(new Vector3f(0.0F,90.0F,0.0F),new Vector3f(0.03125F,0.75F,-0.125F),new Vector3f(2.0F,2.0F,2.0F)));
   TRANSFORMS.put("mini_gun",m);}
  {Map<String,ItemTransform> m=new HashMap<>();
   m.put("thirdperson_righthand",new ItemTransform(new Vector3f(22.5F,0.0F,0.0F),new Vector3f(0.0F,0.625F,-0.25F),new Vector3f(1.2F,1.2F,1.2F)));
   m.put("firstperson_righthand",new ItemTransform(new Vector3f(0.0F,0.0F,0.0F),new Vector3f(-0.3125F,0.53125F,-0.125F),new Vector3f(0.8F,0.8F,0.8F)));
   m.put("ground",new ItemTransform(new Vector3f(0.0F,0.0F,0.0F),new Vector3f(0.0F,0.3125F,-0.359375F),new Vector3f(1.0F,1.0F,1.0F)));
   m.put("gui",new ItemTransform(new Vector3f(30.0F,225.0F,0.0F),new Vector3f(0.46875F,0.3125F,0.0F),new Vector3f(1.8F,1.8F,1.8F)));
   m.put("fixed",new ItemTransform(new Vector3f(0.0F,90.0F,0.0F),new Vector3f(-0.71875F,0.78125F,-0.125F),new Vector3f(2.0F,2.0F,2.0F)));
   TRANSFORMS.put("pistol",m);}
  {Map<String,ItemTransform> m=new HashMap<>();
   m.put("thirdperson_righthand",new ItemTransform(new Vector3f(0.0F,0.0F,0.0F),new Vector3f(0.0F,0.4375F,-0.484375F),new Vector3f(1.2F,1.2F,1.2F)));
   m.put("firstperson_righthand",new ItemTransform(new Vector3f(0.0F,0.0F,0.0F),new Vector3f(-0.3125F,0.53125F,0.03125F),new Vector3f(0.8F,0.8F,0.8F)));
   m.put("ground",new ItemTransform(new Vector3f(0.0F,0.0F,0.0F),new Vector3f(0.0F,0.3125F,0.03125F),new Vector3f(1.0F,1.0F,1.0F)));
   m.put("gui",new ItemTransform(new Vector3f(30.0F,225.0F,0.0F),new Vector3f(-0.03125F,0.265625F,0.0F),new Vector3f(0.9F,0.9F,0.9F)));
   m.put("head",new ItemTransform(new Vector3f(0.0F,180.0F,0.0F),new Vector3f(0.0F,0.0F,0.0F),new Vector3f(1.0F,1.0F,1.0F)));
   m.put("fixed",new ItemTransform(new Vector3f(0.0F,90.0F,0.0F),new Vector3f(-0.265625F,0.6875F,-0.125F),new Vector3f(2.0F,2.0F,2.0F)));
   TRANSFORMS.put("rifle",m);}
  {Map<String,ItemTransform> m=new HashMap<>();
   m.put("thirdperson_righthand",new ItemTransform(new Vector3f(0.0F,0.0F,0.0F),new Vector3f(0.0F,0.375F,-0.46875F),new Vector3f(1.1F,1.1F,1.1F)));
   m.put("firstperson_righthand",new ItemTransform(new Vector3f(0.0F,0.0F,0.0F),new Vector3f(-0.3125F,0.53125F,0.0F),new Vector3f(0.8F,0.8F,0.8F)));
   m.put("ground",new ItemTransform(new Vector3f(0.0F,0.0F,0.0F),new Vector3f(0.0F,0.3125F,-0.203125F),new Vector3f(1.0F,1.0F,1.0F)));
   m.put("gui",new ItemTransform(new Vector3f(30.0F,225.0F,0.0F),new Vector3f(0.125F,0.15625F,0.0F),new Vector3f(0.9F,0.9F,0.9F)));
   m.put("fixed",new ItemTransform(new Vector3f(0.0F,90.0F,0.0F),new Vector3f(-0.390625F,0.75F,-0.125F),new Vector3f(2.0F,2.0F,2.0F)));
   TRANSFORMS.put("shotgun",m);}
 }
 public static void apply(ItemStack stack,ItemDisplayContext context,PoseStack pose) {
  var id=ForgeRegistries.ITEMS.getKey(stack.getItem());
  if(id==null || !id.getNamespace().equals("cgm"))return;
  var transforms=TRANSFORMS.get(id.getPath());if(transforms==null)return;
  String key=context.getSerializedName();
  var transform=transforms.get(key);
  if(transform==null && context.leftHand())transform=transforms.get(key.replace("lefthand","righthand"));
  if(transform==null)return;
  transform.apply(context.leftHand(),pose.last());
  // Attachments and muzzle geometry already center themselves; remove only
  // ItemTransform's final centering, retaining its rotation, scale and offset.
  pose.translate(0.5F,0.5F,0.5F);
 }
}
