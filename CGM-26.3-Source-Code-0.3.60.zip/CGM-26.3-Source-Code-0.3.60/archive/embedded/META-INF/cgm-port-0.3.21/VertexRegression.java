import java.nio.file.*; import java.util.jar.*; import java.lang.reflect.*; import org.objectweb.asm.*; import org.objectweb.asm.tree.*; import com.mojang.blaze3d.vertex.*;
public class VertexRegression {
 static class Strict implements VertexConsumer {
  int mask=0,count=0; void finish(){if(count>0 && mask!=63)throw new IllegalStateException("Missing ENTITY attributes mask="+mask);}
  public VertexConsumer addVertex(org.joml.Matrix4fc p,float x,float y,float z){finish();count++;mask=1;return this;}
  public VertexConsumer setColor(float r,float g,float b,float a){mask|=2;return this;}
  public VertexConsumer setUv(float u,float v){mask|=4;return this;}
  public VertexConsumer setLight(int l){mask|=8;return this;}
  public VertexConsumer setOverlay(int o){if(o!=655360)throw new AssertionError();mask|=16;return this;}
  public VertexConsumer setNormal(PoseStack.Pose p,float x,float y,float z){if(z!=1)throw new AssertionError();mask|=32;return this;}
 }
 static class Loader extends ClassLoader {Class<?> def(byte[] b){return defineClass(null,b,0,b.length);}}
 static void run(byte[] bytes,String name,boolean expectFailure)throws Exception {
  ClassNode c=new ClassNode();new ClassReader(bytes).accept(c,0);MethodNode draw=c.methods.stream().filter(m->m.name.startsWith("lambda$drawMuzzleFlash$")).findFirst().orElseThrow();
  draw.access=Opcodes.ACC_PUBLIC|Opcodes.ACC_STATIC;draw.name="draw";
  ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);w.visit(Opcodes.V17,Opcodes.ACC_PUBLIC,name,null,"java/lang/Object",null);draw.accept(w);w.visitEnd();
  var m=new Loader().def(w.toByteArray()).getDeclaredMethod("draw",float.class,float.class,PoseStack.Pose.class,VertexConsumer.class);
  Strict s=new Strict();boolean failed=false;try{m.invoke(null,.5f,0f,new PoseStack.Pose(),s);s.finish();}catch(InvocationTargetException e){if(!(e.getCause() instanceof IllegalStateException))throw e;failed=true;}
  if(failed!=expectFailure || (!failed&&s.count!=4))throw new AssertionError(name);
  System.out.println(name+": "+(failed?"reproduced missing vertex attributes":"all 4 ENTITY vertices complete"));
 }
 public static void main(String[] a)throws Exception {try(JarFile j=new JarFile(a[0])){run(j.getInputStream(j.getJarEntry("com/mrcrayfish/guns/client/handler/GunRenderingHandler.class")).readAllBytes(),"Original",true);}run(Files.readAllBytes(Path.of(a[1])),"Patched",false);}
}