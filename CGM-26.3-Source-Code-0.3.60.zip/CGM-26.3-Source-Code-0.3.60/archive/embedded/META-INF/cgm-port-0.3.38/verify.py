from pathlib import Path
import subprocess
exec((Path(__file__).parent/'build.py').read_text().split('subprocess.run')[0])
TESTCP=str(ROOT/'classes')+':'+CP
subprocess.run([str(JAVA/'javac'),'-proc:none','-cp',TESTCP,'-d',str(ROOT/'test-classes'),str(ROOT/'tests/Motion38Test.java'),str(ROOT/'Patch38.java')],check=True)
subprocess.run([str(JAVA/'java'),'-cp',str(ROOT/'test-classes')+':'+TESTCP,'com.mrcrayfish.guns.port.Motion38Test'],check=True)
subprocess.run([str(JAVA/'java'),'-cp',str(ROOT/'test-classes')+':'+TESTCP,'Patch38',str(BASE),str(ROOT/'patched')],check=True)
