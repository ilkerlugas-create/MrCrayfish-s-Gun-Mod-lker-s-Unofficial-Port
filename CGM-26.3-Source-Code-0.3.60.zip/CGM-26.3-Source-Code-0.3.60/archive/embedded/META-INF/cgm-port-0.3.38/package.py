from pathlib import Path
import json,hashlib,zipfile
ROOT=Path(__file__).resolve().parent
base=ROOT.parent/'upload/CGM-26.3-Forge66.0.2-0.3.37-OPTIMIZE.jar'
out=ROOT.parent/'output/CGM-26.3-Forge66.0.2-0.3.38-TUTUS-F5.jar'
updates={}
for directory in ['classes','patched']:
 for p in (ROOT/directory).rglob('*.class'):
  updates[p.relative_to(ROOT/directory).as_posix()]=p.read_bytes()
expected={'com/mrcrayfish/guns/port/F5Aim.class','com/mrcrayfish/guns/port/RunAnimation.class','com/mrcrayfish/guns/port/RunAnimation$State.class','com/mrcrayfish/guns/port/PistolHold.class','com/mrcrayfish/guns/client/handler/GunRenderingHandler.class'}
assert set(updates)==expected,set(updates)
for folder in ['src','tests']:
 for p in (ROOT/folder).rglob('*.java'): updates['META-INF/cgm-port-0.3.38/'+p.relative_to(ROOT).as_posix()]=p.read_bytes()
for name in ['build.py','verify.py','package.py','Patch38.java','CheckLinks38.java']:
 updates['META-INF/cgm-port-0.3.38/'+name]=(ROOT/name).read_bytes()
validation={
 'base_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),
 'compiler':'JDK 25, real Minecraft 26.3 client + Forge 66.0.2 APIs (no compile/test stubs)',
 'changed_classes':sorted(expected),
 'checks':['FPS sprint matrices equal 0.3.37 transforms','F5 walk matrices equal Minecraft 26.3 GameRenderer bobView','Torso yaw applied at zero ADS as required by CGM authored poses','Camera/body conversion includes head yaw, pitch, units and axis directions','Both arms and inherited item frame receive the same rigid transform','Repeated render samples at identical time do not advance sprint progress','Single first-person arm wrapper hook; original F5 and pistol hooks retained','All other existing entries compared byte-for-byte, apart from version metadata'],
 'numeric_assertions':17017,
 'verified_methods_against_target_api':21,
 'in_game_test':False,
 'visual_limit':'Model geometry inspected offline; reference is cropped. Final pose and F5 playback still require a Minecraft client visual check.'
}
updates['META-INF/cgm-port-0.3.38/validation.json']=json.dumps(validation,ensure_ascii=False,indent=2).encode()
updates['CGM-0.3.38-OKU.txt']='''0.3.38 — Tabanca tutuşu ve FPS / F5 hareketi
Minecraft 26.3 / Forge 66.0.2
Taban: gönderilen 0.3.37 OPTIMIZE sürümü.

DEĞİŞİKLİKLER
- Tabancanın ana eli kabzaya yaklaştırıldı; önceki ek 10 derece yana dönüş kaldırıldı.
- Tabanca, referanstaki düz namlu yönüyle ekranın sağına yerleşir. ADS sırasında ortak konum düzeltmesi söner; nişangâh hesabı korunur.
- F5 gövde yönü yalnızca nişanda değil, normal tutuşta da silahın kol pozuna göre ayarlanır.
- Minecraft'ın FPS'e uyguladığı yürüme sallanması, aynı oyuncu adım verileriyle F5 kollarına da uygulanır. Görüş sallanması ayarı kapalıysa ikisinde de kapalıdır.
- Koşu geçişi kameralar arasında ortaktır. Hareket, kafa/gövde açıları ve bakış eğimi hesaba katılarak F5 modeline dönüştürülür.
- İki elle tutuşta kollar birlikte hareket eder; silah ana kolun hareketini devralır.
- F5 nişan geçişi FPS'in kullandığı geçiş değerini izler.

KURULUM
Oyunu kapat. mods içindeki önceki CGM JAR'ını kaldır ve bu dosyayı koy; iki CGM sürümü birlikte kalmasın.
Varsayılan eklenti menüsü tuşu Z olarak korunur. Önceden kaydettiğin farklı atama varsa Kontroller ekranından sıfırla.

DOĞRULAMA
Gerçek Minecraft 26.3 / Forge 66.0.2 API'leriyle derlendi.
Gerçek PoseStack ve ModelPart sınıflarıyla hareket ve koordinat hesapları kontrol edildi.
0.3.37'nin diğer sınıfları/varlıkları ile Z menüsü, önbellek, model çizim ve yeniden doldurma değişiklikleri korundu.
Bu ortamda Minecraft açılarak oyun içi görsel test yapılmadı.
FPS ve F5 farklı temel model ve kamera perspektifleri kullanır; eşleştirilen bölüm yürüme/koşu hareketi ve zamanlamasıdır.
'''.encode()
with zipfile.ZipFile(base) as z:
 for n in ['META-INF/MANIFEST.MF','META-INF/mods.toml']:
  updates[n]=z.read(n).replace(b'port-0.3.37',b'port-0.3.38')
 expected_all=set(updates)
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as d:
  for info in z.infolist():d.writestr(info,updates.pop(info.filename,z.read(info.filename)))
  for name,data in updates.items():d.writestr(name,data)
with zipfile.ZipFile(base) as a,zipfile.ZipFile(out) as b:
 assert b.testzip() is None
 assert len(b.namelist())==len(set(b.namelist()))
 changed={n for n in a.namelist() if a.read(n)!=b.read(n)}
 assert changed==expected|{'META-INF/MANIFEST.MF','META-INF/mods.toml'},changed
 assert not any(n.startswith(('net/minecraft/','org/joml/')) for n in b.namelist())
 for name in b.namelist():
  if name.endswith('.json'): json.loads(b.read(name))
 assert b'port-0.3.38' in b.read('META-INF/mods.toml')
 print('PASS: archive CRC, unique entries, JSONs, version metadata; exactly 5 runtime classes changed; all other 0.3.37 entries preserved')
print('SHA256',hashlib.sha256(out.read_bytes()).hexdigest())
print(out)
