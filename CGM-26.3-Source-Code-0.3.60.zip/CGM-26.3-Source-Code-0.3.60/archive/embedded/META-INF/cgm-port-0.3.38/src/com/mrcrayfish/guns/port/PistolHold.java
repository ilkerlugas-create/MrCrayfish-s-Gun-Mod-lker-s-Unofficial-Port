package com.mrcrayfish.guns.port;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mrcrayfish.guns.client.handler.AimingHandler;
import com.mrcrayfish.guns.client.handler.ReloadHandler;
import com.mrcrayfish.guns.client.render.IHeldAnimation;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

public final class PistolHold {
    private PistolHold() {}

    public static void apply(PoseStack pose, ItemStack stack, int side) {
        if (!"pistol".equals(ReloadTiming.kind(stack))) return;
        float ads = (float) AimingHandler.get().getNormalisedAdsProgress();
        float partial = Minecraft.getInstance().getDeltaTracker().getGameTimeDeltaPartialTick(true);
        float weight = (1F - smooth(ads)) * (1F - smooth(ReloadHandler.get().getReloadProgress(partial)));
        // Keep the bore parallel to the view as in the supplied reference.
        // Move the whole assembly; attachments and muzzle effects inherit it.
        pose.translate(-.055F * side * weight, .025F * weight, .04F * weight);
    }

    private static float smooth(float value) {
        value = Math.max(0F, Math.min(1F, value));
        return value * value * (3F - 2F * value);
    }

    public static void renderArms(IHeldAnimation animation, Player player, HumanoidArm hand,
            ItemStack stack, PoseStack pose, SubmitNodeCollector collector, int light, float partial) {
        pose.pushPose();
        if ("pistol".equals(ReloadTiming.kind(stack))) {
            // Position the fist against the grip, not behind it. This correction
            // stays with the hand through ADS/recoil/reload; it never moves sights.
            float side = hand == HumanoidArm.RIGHT ? 1F : -1F;
            pose.translate(-.028F * side, .005F, -.105F);
        }
        animation.renderFirstPersonArms(player, hand, stack, pose, collector, light, partial);
        pose.popPose();
    }
}
