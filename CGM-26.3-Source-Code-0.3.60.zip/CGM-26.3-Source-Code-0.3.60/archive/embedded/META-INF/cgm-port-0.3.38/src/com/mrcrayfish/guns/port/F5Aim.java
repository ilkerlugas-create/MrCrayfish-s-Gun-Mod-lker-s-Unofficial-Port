package com.mrcrayfish.guns.port;

import com.mrcrayfish.guns.Config;
import com.mrcrayfish.guns.client.handler.AimingHandler;
import com.mrcrayfish.guns.common.GripType;
import com.mrcrayfish.guns.item.GunItem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.client.event.RenderLivingEvent;

public final class F5Aim {
    private F5Aim() {}

    public static float progress(Player player, float interpolated) {
        // The tracker is ticked independently of the camera. Keep its transition,
        // rather than snapping the third-person pose to full ADS on the first frame.
        return Mth.clamp(interpolated, 0F, 1F);
    }

    public static float yawOffset(GripType grip, boolean oldAnimations, float aim, boolean left) {
        float offset = grip == GripType.ONE_HANDED ? 0F : grip == GripType.BAZOOKA ? 35F : 45F;
        if (grip == GripType.TWO_HANDED && oldAnimations) offset = 25F + 20F * aim;
        return left ? -offset : offset;
    }

    public static boolean before(RenderLivingEvent.Pre event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || !(event.getState() instanceof AvatarRenderState state)) return false;
        if (!(mc.level.getEntity(state.id) instanceof Player player)) return false;
        if (player.isPassenger() || player.isSleeping() || player.isFallFlying()
                || player.isVisuallySwimming() || state.isUpsideDown) return false;
        var stack = player.getMainHandItem();
        if (!(stack.getItem() instanceof GunItem item)) return false;
        float partial = mc.getDeltaTracker().getGameTimeDeltaPartialTick(true);
        float aim = progress(player, AimingHandler.get().getAimProgress(player, partial));
        var grip = item.getModifiedGun(stack).getGeneral().getGripType();
        float head = Mth.rotLerp(partial, player.yHeadRotO, player.yHeadRot);
        float offset = yawOffset(grip, Config.CLIENT.display.oldAnimations.get(), aim,
                player.getMainArm() == HumanoidArm.LEFT);
        // CGM's authored arm poses require this torso offset even at zero ADS.
        // Change the render state only: never the entity or its shot direction.
        state.bodyRot = head + offset;
        state.yRot = Mth.wrapDegrees(head - state.bodyRot);
        return false;
    }
}
