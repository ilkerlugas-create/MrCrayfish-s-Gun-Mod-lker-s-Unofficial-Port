package com.mrcrayfish.guns.port;

import java.util.Map;
import java.util.WeakHashMap;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mrcrayfish.guns.Config;
import com.mrcrayfish.guns.client.KeyBinds;
import com.mrcrayfish.guns.client.handler.AimingHandler;
import com.mrcrayfish.guns.client.render.IHeldAnimation;
import com.mrcrayfish.guns.common.Gun;
import com.mrcrayfish.guns.common.GripType;
import com.mrcrayfish.guns.init.ModSyncedDataKeys;
import com.mrcrayfish.guns.item.GunItem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.ClientAvatarEntity;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.player.Player;
import org.joml.Matrix4f;
import org.joml.Vector3f;

public final class RunAnimation {
    private static final float DEG = (float) (Math.PI / 180.0);
    private static final Map<Player, State> STATES = new WeakHashMap<>();

    // Scratch objects are owned by each weak player entry and reused every frame.
    // Preserve 0.3.37's no-temporary-matrix-allocation steady state.
    private static final class State {
        double time;
        float progress;
        final Matrix4f sprint = new Matrix4f();
        final Matrix4f cameraMotion = new Matrix4f();
        final Matrix4f cameraToModel = new Matrix4f();
        final Matrix4f modelToCamera = new Matrix4f();
        final Matrix4f modelMotion = new Matrix4f();
        final Matrix4f partRotation = new Matrix4f();
        final Vector3f position = new Vector3f();
        State(double time) { this.time = time; }
    }

    public static float approach(float value, boolean running, float elapsed) {
        float step = Math.max(0F, Math.min(elapsed, 1F)) / 5F;
        return running ? Math.min(1F, value + step) : Math.max(0F, value - step);
    }

    private static State sample(Player player, float partial) {
        double time = player.tickCount + (double) partial;
        State state = STATES.get(player);
        if (state == null) { state = new State(time); STATES.put(player, state); }
        if (time < state.time) { state.time = time; state.progress = 0F; }
        boolean aiming = player.isLocalPlayer() ? AimingHandler.get().isAiming() : ModSyncedDataKeys.AIMING.getValue(player);
        boolean shooting = player.isLocalPlayer() ? KeyBinds.getShootMapping().isDown() : ModSyncedDataKeys.SHOOTING.getValue(player);
        boolean running = Config.CLIENT.display.sprintAnimation.get() && player.isSprinting()
                && !aiming && !shooting && !ModSyncedDataKeys.RELOADING.getValue(player);
        state.progress = approach(state.progress, running, (float) (time - state.time));
        state.time = time;
        return state;
    }

    private static float amount(GripType grip) {
        return grip == GripType.BAZOOKA || grip == GripType.MINI_GUN ? .4F : grip == GripType.ONE_HANDED ? .7F : 1F;
    }

    static void sprint(Matrix4f target, float progress, float amount, float side) {
        float eased = progress * progress * (3F - 2F * progress);
        target.identity().translate(-.08F * side * eased * amount, -.12F * eased, 0F)
                .rotateY(15F * DEG * side * eased * amount).rotateX(-8F * DEG * eased * amount);
    }

    // Minecraft 26.3 GameRenderer.bobView, driven by the SAME avatar state.
    // FPS already receives it from GameRenderer; only the F5 rig needs this copy.
    static void walking(Matrix4f target, float distance, float bob) {
        float phase = distance * (float) Math.PI;
        float sine = Mth.sin(phase);
        target.identity().translate(sine * bob * .5F, -Math.abs(Mth.cos(phase) * bob), 0F)
                .rotateZ(sine * bob * 3F * DEG)
                .rotateX(Math.abs(Mth.cos(phase - .2F) * bob) * 5F * DEG);
    }

    public static void firstPerson(Gun gun, HumanoidArm arm, PoseStack pose, float partial) {
        Player player = Minecraft.getInstance().player;
        if (player == null) return;
        State state = sample(player, partial);
        sprint(state.sprint, state.progress, amount(gun.getGeneral().getGripType()), arm == HumanoidArm.LEFT ? -1F : 1F);
        pose.mulPose(state.sprint);
    }

    public static void thirdPerson(IHeldAnimation animation, Player player, ModelPart right, ModelPart left,
            ModelPart head, InteractionHand hand, float aim) {
        aim = F5Aim.progress(player, aim);
        animation.applyPlayerModelRotation(player, right, left, head, hand, aim);
        var stack = player.getMainHandItem();
        if (!(stack.getItem() instanceof GunItem item)) return;
        if (player.isPassenger() || player.isSleeping() || player.isFallFlying() || player.isVisuallySwimming()) return;
        Minecraft mc = Minecraft.getInstance();
        float partial = mc.getDeltaTracker().getGameTimeDeltaPartialTick(true);
        State state = sample(player, partial);
        GripType grip = item.getModifiedGun(stack).getGeneral().getGripType();
        boolean isRight = (player.getMainArm() == HumanoidArm.RIGHT) == (hand == InteractionHand.MAIN_HAND);
        float side = isRight ? 1F : -1F;
        float distance = 0F, bob = 0F;
        if (mc.options.bobView().get() && player instanceof ClientAvatarEntity client) {
            distance = client.avatarState().getBackwardsInterpolatedWalkDistance(partial);
            bob = client.avatarState().getInterpolatedBob(partial);
        }
        if (state.progress == 0F && bob == 0F) return;
        sprint(state.sprint, state.progress, amount(grip), side);
        walking(state.cameraMotion, distance, bob);
        // Match the FPS order: view bob, held-weapon origin, sprint transform.
        // Conjugation keeps the zero-motion pose unchanged.
        state.cameraMotion.translate(.56F * side, -.52F, -.72F).mul(state.sprint)
                .translate(-.56F * side, .52F, .72F);
        float pitch = Mth.lerp(partial, player.xRotO, player.getXRot()) * DEG;
        // Camera coordinates -> the 16-pixel, Y-down model, accounting for the
        // torso's yaw AND look pitch. F5 front/rear camera choice is irrelevant.
        cameraToModel(state.cameraToModel, head.x, head.y - 2F, head.z, head.yRot, pitch);
        state.cameraToModel.invert(state.modelToCamera);
        state.modelMotion.set(state.cameraToModel).mul(state.cameraMotion).mul(state.modelToCamera);
        transform(isRight ? right : left, state.modelMotion, state.partRotation, state.position);
        if (grip != GripType.ONE_HANDED) {
            transform(isRight ? left : right, state.modelMotion, state.partRotation, state.position);
        }
    }

    static void cameraToModel(Matrix4f target, float x, float y, float z, float headYaw, float pitch) {
        target.identity().translate(x, y, z).rotateY(headYaw).scale(-16F, -16F, 16F).rotateX(-pitch);
    }

    static void transform(ModelPart part, Matrix4f delta, Matrix4f scratch, Vector3f position) {
        delta.transformPosition(position.set(part.x, part.y, part.z));
        part.x = position.x; part.y = position.y; part.z = position.z;
        scratch.set(delta).rotateZ(part.zRot).rotateY(part.yRot).rotateX(part.xRot);
        // Extract Rz * Ry * Rx, the ModelPart convention. Columns are JOML's
        // first matrix index; the gimbal-lock branch remains finite at +/-90°.
        float y = (float) Math.asin(Math.max(-1.0, Math.min(1.0, -scratch.m02())));
        part.yRot = y;
        if (Math.abs(Math.cos(y)) > 1E-5) {
            part.xRot = (float) Math.atan2(scratch.m12(), scratch.m22());
            part.zRot = (float) Math.atan2(scratch.m01(), scratch.m00());
        } else {
            part.xRot = 0F;
            part.zRot = (float) Math.atan2(-scratch.m10(), scratch.m11());
        }
    }

    public static void heldItem(IHeldAnimation animation, Player player, InteractionHand hand, float aim,
            PoseStack pose, SubmitNodeCollector collector) {
        // ItemInHandLayer inherits the already-transformed gripping arm.
        animation.applyHeldItemTransforms(player, hand, F5Aim.progress(player, aim), pose, collector);
    }
}
