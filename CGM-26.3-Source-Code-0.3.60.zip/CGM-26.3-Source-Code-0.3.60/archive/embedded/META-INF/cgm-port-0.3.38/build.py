from pathlib import Path
import subprocess
ROOT=Path(__file__).resolve().parent
JAVA=Path('/workspace/scratch/01db9c6bc1ca/work-0.3.20/toolchain/jdk-25.0.4.1+1/bin')
BASE=ROOT.parent/'upload/CGM-26.3-Forge66.0.2-0.3.37-OPTIMIZE.jar'
GAME=Path('/workspace/scratch/d8b1dcfe2d42/work-validation/api-26.3/client.jar')
DEPS=sorted(Path('/workspace/scratch/f197bc6a9130/deps').glob('*.jar'))
CP=':'.join(str(p) for p in [BASE,GAME,*DEPS])
(ROOT/'classpath.txt').write_text(CP)
subprocess.run([str(JAVA/'javac'),'-proc:none','--release','25','-cp',CP,'-d',str(ROOT/'classes'),*[str(p) for p in (ROOT/'src').rglob('*.java')]],check=True)
