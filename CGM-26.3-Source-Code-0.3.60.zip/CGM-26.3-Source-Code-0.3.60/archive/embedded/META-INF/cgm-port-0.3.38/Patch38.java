import java.nio.file.*;
import java.util.zip.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.tree.analysis.*;

public final class Patch38 implements Opcodes {
    public static void main(String[] args) throws Exception {
        String name = "com/mrcrayfish/guns/client/handler/GunRenderingHandler.class";
        byte[] bytes;
        try (ZipFile jar = new ZipFile(args[0])) { bytes = jar.getInputStream(jar.getEntry(name)).readAllBytes(); }
        ClassNode c = new ClassNode();
        new ClassReader(bytes).accept(c, 0);
        int hooks = 0, aimHooks = 0, f5Hooks = 0;
        for (MethodNode m : c.methods) {
            for (var ins : m.instructions) {
                if (!(ins instanceof MethodInsnNode call)) continue;
                if (call.owner.equals("com/mrcrayfish/guns/port/PistolHold") && call.name.equals("apply")) aimHooks++;
                if (call.owner.equals("com/mrcrayfish/guns/port/F5Aim") && call.name.equals("before")) f5Hooks++;
                if (call.owner.equals("com/mrcrayfish/guns/client/render/IHeldAnimation") && call.name.equals("renderFirstPersonArms")) {
                    call.setOpcode(INVOKESTATIC);
                    call.owner = "com/mrcrayfish/guns/port/PistolHold";
                    call.name = "renderArms";
                    call.desc = "(Lcom/mrcrayfish/guns/client/render/IHeldAnimation;" + call.desc.substring(1);
                    call.itf = false;
                    hooks++;
                }
            }
            if ((m.access & (ACC_ABSTRACT | ACC_NATIVE)) == 0) new Analyzer<>(new BasicVerifier()).analyze(c.name, m);
        }
        if (hooks != 1 || aimHooks != 1 || f5Hooks != 1) throw new AssertionError(hooks+"/"+aimHooks+"/"+f5Hooks);
        ClassWriter writer = new ClassWriter(ClassWriter.COMPUTE_MAXS);
        c.accept(writer);
        Path output = Path.of(args[1], name);
        Files.createDirectories(output.getParent());
        Files.write(output, writer.toByteArray());
        System.out.println("PASS: arm render call replaced once; existing pistol + F5 event hooks present; bytecode stack verification passed");
    }
}
