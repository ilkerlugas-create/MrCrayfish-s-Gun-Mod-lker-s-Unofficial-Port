import java.nio.file.*;
import java.util.*;
import java.util.jar.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.tree.analysis.*;
public class CheckLinks38 {
 static Map<String,ClassNode> all=new HashMap<>();
 static boolean field(String owner,String name,String desc,Set<String> seen) {
 if(!seen.add(owner))return false;ClassNode c=all.get(owner);if(c==null)return false;
 if(c.fields.stream().anyMatch(f->f.name.equals(name)&&f.desc.equals(desc)))return true;
 if(c.superName!=null&&field(c.superName,name,desc,seen))return true;
 for(String i:c.interfaces)if(field(i,name,desc,seen))return true;return false;
 }
 static boolean method(String owner,String name,String desc,Set<String> seen) {
  if(!seen.add(owner))return false;ClassNode c=all.get(owner);if(c==null&&owner.startsWith("java/")) {
   try(var in=ClassLoader.getSystemResourceAsStream(owner+".class")) {
    if(in!=null){c=new ClassNode();new ClassReader(in).accept(c,0);all.put(owner,c);}
   }catch(Exception ex){throw new RuntimeException(ex);}
  }
  if(c==null)return false;
  for(MethodNode m:c.methods)if(m.name.equals(name)&&m.desc.equals(desc))return true;
  if(c.superName!=null&&method(c.superName,name,desc,seen))return true;
  for(String i:c.interfaces)if(method(i,name,desc,seen))return true;return false;
 }
 public static void main(String[] args)throws Exception {
  for(String p:args)try(JarFile j=new JarFile(p)) {
   var es=j.entries();while(es.hasMoreElements()){var e=es.nextElement();if(!e.getName().endsWith(".class"))continue;
    ClassNode c=new ClassNode();new ClassReader(j.getInputStream(e)).accept(c,0);all.put(c.name,c);
   }
  }
  int checked=0;
  for(String name:List.of("com/mrcrayfish/guns/port/RunAnimation","com/mrcrayfish/guns/port/RunAnimation$State","com/mrcrayfish/guns/port/PistolHold","com/mrcrayfish/guns/port/F5Aim")) {
   ClassNode c=all.get(name);
   for(MethodNode m:c.methods) {
    if((m.access&(Opcodes.ACC_ABSTRACT|Opcodes.ACC_NATIVE))==0)new Analyzer<>(new BasicVerifier()).analyze(name,m);
    
    for(var ins:m.instructions) {
     if(ins instanceof MethodInsnNode n && !method(n.owner,n.name,n.desc,new HashSet<>()))throw new IllegalStateException(n.owner+"."+n.name+n.desc);
     if(ins instanceof FieldInsnNode f && !f.owner.startsWith("java/")) {
      ClassNode target=all.get(f.owner);if(!field(f.owner,f.name,f.desc,new HashSet<>()))throw new IllegalStateException(f.owner+"."+f.name);
     }
    }
    checked++;
   }
  }
  System.out.println("PASS: "+checked+" new methods verified; target method/field descriptors match Minecraft 26.3, Forge 66.0.2, and bundled CGM/Framework. Changed source classes pass BasicVerifier.");
 }
}
