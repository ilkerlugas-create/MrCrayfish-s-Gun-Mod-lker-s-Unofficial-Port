package com.mrcrayfish.guns.port;

import java.util.List;
import java.util.Map;
import java.util.Random;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.util.Mth;
import org.joml.Matrix4f;
import org.joml.Vector3f;

public class Motion38Test {
    static int checks;
    static void near(float a, float b, float eps, String label) {
        if (!Float.isFinite(a) || Math.abs(a-b) > eps) throw new AssertionError(label + ": " + a + " != " + b);
        checks++;
    }
    static void matrix(Matrix4f a, Matrix4f b, float eps, String label) {
        float[] aa = a.get(new float[16]), bb = b.get(new float[16]);
        for (int i=0;i<16;i++) near(aa[i],bb[i],eps,label+"["+i+"]");
    }
    static Matrix4f part(ModelPart p) {
        return new Matrix4f().translation(p.x,p.y,p.z).rotateZ(p.zRot).rotateY(p.yRot).rotateX(p.xRot);
    }
    public static void main(String[] args) {
        for (float side : new float[]{-1,1}) for (float amount : new float[]{.4F,.7F,1F}) for (float progress : new float[]{0,.125F,.5F,.9F,1F}) {
            float e = progress*progress*(3-2*progress);
            PoseStack reference = new PoseStack();
            reference.translate(-.08F*side*e*amount,-.12F*e,0);
            reference.rotateDegrees(Axis.YP,15F*side*e*amount);
            reference.rotateDegrees(Axis.XP,-8F*e*amount);
            Matrix4f actual = new Matrix4f();
            RunAnimation.sprint(actual,progress,amount,side);
            matrix(actual,reference.last().pose(),2E-6F,"FPS sprint parity with 0.3.37");
        }
        for (float distance : new float[]{0,.25F,.5F,1F,1.75F,99.2F}) for(float bob : new float[]{0,.02F,.06F,.1F}) {
            float phase = distance * (float)Math.PI;
            PoseStack reference = new PoseStack();
            reference.translate(Mth.sin(phase)*bob*.5F,-Math.abs(Mth.cos(phase)*bob),0);
            reference.rotateDegrees(Axis.ZP,Mth.sin(phase)*bob*3);
            reference.rotateDegrees(Axis.XP,Math.abs(Mth.cos(phase-.2F)*bob)*5);
            Matrix4f actual = new Matrix4f();
            RunAnimation.walking(actual,distance,bob);
            matrix(actual,reference.last().pose(),2E-6F,"GameRenderer walking parity");
        }
        // A previously missed regression: walking alone MUST move the F5 arms.
        Matrix4f walk = new Matrix4f(); RunAnimation.walking(walk,.5F,.08F);
        if (walk.equals(new Matrix4f(),1E-4F)) throw new AssertionError("walking lost");
        checks++;
        // Coordinate conversion checked separately against the actual camera /
        // LivingEntityRenderer conventions, including pitch and torso offset.
        for (float headYaw : new float[]{-45,0,45}) for(float pitch : new float[]{-89,0,89}) {
            Matrix4f a = new Matrix4f();
            RunAnimation.cameraToModel(a,0,-2,0,(float)Math.toRadians(headYaw),(float)Math.toRadians(pitch));
            Matrix4f bodyToWorld = new Matrix4f().rotateY((float)Math.PI).scale(-1,-1,1).scale(1F/16F);
            Matrix4f cameraToWorld = new Matrix4f().rotateY((float)Math.toRadians(180-headYaw)).rotateX((float)Math.toRadians(-pitch));
            Matrix4f expected = bodyToWorld.invert(new Matrix4f()).mul(cameraToWorld);
            a.m30(0).m31(0).m32(0);
            matrix(a,expected,1E-5F,"camera/body axes");
        }
        Random random = new Random(38);
        Matrix4f scratch = new Matrix4f(); Vector3f position = new Vector3f();
        for (int n=0;n<500;n++) {
            Matrix4f axes = new Matrix4f();
            RunAnimation.cameraToModel(axes,0,-2,0,(random.nextFloat()-.5F)*1.6F,(random.nextFloat()-.5F)*3F);
            Matrix4f cam = new Matrix4f(), sprint = new Matrix4f();
            RunAnimation.walking(cam,random.nextFloat()*10,.08F);
            RunAnimation.sprint(sprint,random.nextFloat(),1,n%2==0?1:-1);
            cam.translate(.56F,-.52F,-.72F).mul(sprint).translate(-.56F,.52F,.72F);
            Matrix4f delta = new Matrix4f(axes).mul(cam).mul(new Matrix4f(axes).invert());
            for(int arm=0;arm<2;arm++) {
                ModelPart p = new ModelPart(List.of(),Map.of());
                p.x=arm==0?-5:5; p.y=2; p.z=arm;
                p.xRot=random.nextFloat()*3-1.5F; p.yRot=random.nextFloat()*2-1F; p.zRot=random.nextFloat()-.5F;
                Matrix4f original = part(p);
                Matrix4f expected = new Matrix4f(delta).mul(original);
                RunAnimation.transform(p,delta,scratch,position);
                matrix(part(p),expected,1E-4F,"rigid arm + attached weapon transform");
            }
        }
        for(float value:new float[]{0,.2F,.8F,1}) {
            near(RunAnimation.approach(value,true,0),value,0,"same frame is idempotent");
            near(RunAnimation.approach(value,false,0),value,0,"same frame is idempotent");
        }
        System.out.println("PASS: " + checks + " numeric checks using real Minecraft 26.3 PoseStack/ModelPart and JOML. No in-game visual test.");
    }
}
