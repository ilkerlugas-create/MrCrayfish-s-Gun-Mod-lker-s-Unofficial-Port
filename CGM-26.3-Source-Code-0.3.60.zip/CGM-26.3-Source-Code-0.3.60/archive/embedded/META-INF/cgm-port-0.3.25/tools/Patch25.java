import java.nio.file.*;
import java.util.*;
import java.util.jar.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.tree.analysis.*;
public class Patch25 implements Opcodes {
 static String PORT="com/mrcrayfish/guns/port/";
 static void body(MethodNode m){m.instructions.clear();m.tryCatchBlocks.clear();if(m.localVariables!=null)m.localVariables.clear();}
 static void call(InsnList l,String owner,String name,String desc){l.add(new MethodInsnNode(INVOKESTATIC,owner,name,desc,false));}
 static String menu(String s){return s==null?null:s.replace("net/minecraft/world/inventory/MenuType$MenuSupplier","net/minecraftforge/network/IContainerFactory");}
 public static void main(String[] args)throws Exception {
  int input=0,menu=0,reg=0,setup=0,timing=0,reload=0,arm=0,model=0;
  try(JarFile jar=new JarFile(args[0])) { for(var e:Collections.list(jar.entries())){
   if(!e.getName().endsWith(".class"))continue;
   String n=e.getName().replace(".class","");
   boolean target=n.endsWith("/ShootingHandler")||n.endsWith("/ModItems")||n.endsWith("/GunMod")||n.endsWith("/GunEnchantmentHelper")||n.endsWith("/GunRenderingHandler")||n.endsWith("/ReloadHandler")||n.contains("/render/pose/")||n.endsWith("/SimpleModel");
   if(!target)continue;
   ClassNode c=new ClassNode();new ClassReader(jar.getInputStream(e)).accept(c,0);boolean changed=false;
   if(n.endsWith("/ShootingHandler")) {
    MethodNode shared=c.methods.stream().filter(m->m.name.equals("onMouseClick")).findFirst().orElseThrow();
    var annotations=shared.visibleAnnotations;shared.visibleAnnotations=null;
    String parent="net/minecraftforge/client/event/InputEvent$InteractionKeyMappingTriggered";
    for(String suffix:List.of("Attack","UseItem")) {
     MethodNode wrapper=new MethodNode(ACC_PUBLIC,"cgmOn"+suffix,"(L"+parent+"$"+suffix+";)Z",null,null);
     wrapper.visibleAnnotations=annotations;
     wrapper.instructions.add(new VarInsnNode(ALOAD,0));wrapper.instructions.add(new VarInsnNode(ALOAD,1));
     wrapper.instructions.add(new MethodInsnNode(INVOKEVIRTUAL,n,shared.name,shared.desc,false));wrapper.instructions.add(new InsnNode(IRETURN));
     c.methods.add(wrapper);input++;
    } changed=true;
   }
   for(MethodNode m:c.methods) {
    if(n.endsWith("/ModContainers")) {
     m.desc=menu(m.desc);m.signature=menu(m.signature);
     if(m.localVariables!=null)for(var v:m.localVariables){v.desc=menu(v.desc);v.signature=menu(v.signature);}
     for(var ins:m.instructions) {
      if(ins instanceof MethodInsnNode a)a.desc=menu(a.desc);
      if(ins instanceof TypeInsnNode a)a.desc=menu(a.desc);
      if(ins instanceof InvokeDynamicInsnNode a){a.desc=menu(a.desc);for(int i=0;i<a.bsmArgs.length;i++){
       Object b=a.bsmArgs[i];if(b instanceof Handle h)a.bsmArgs[i]=new Handle(h.getTag(),h.getOwner(),h.getName(),menu(h.getDesc()),h.isInterface());
       else if(b instanceof Type t)a.bsmArgs[i]=Type.getType(menu(t.getDescriptor()));
      }}
     }
     if(m.name.equals("lambda$register$1")) { // identify by MenuType constructor instead of relying on javac numbering below
     }
     if(m.desc.equals("(Lnet/minecraftforge/network/IContainerFactory;)Lnet/minecraft/world/inventory/MenuType;")) {
      body(m);m.instructions.add(new VarInsnNode(ALOAD,0));call(m.instructions,"net/minecraftforge/common/extensions/IForgeMenuType","create",m.desc);m.instructions.add(new InsnNode(ARETURN));menu++;
     }changed=true;
    }
    if(n.endsWith("/ModItems")&&m.name.equals("<clinit>")) {
     for(var ins:m.instructions.toArray())if(ins.getOpcode()==RETURN){InsnList l=new InsnList();l.add(new FieldInsnNode(GETSTATIC,n,"REGISTER","Lnet/minecraftforge/registries/DeferredRegister;"));call(l,PORT+"ExtraAmmo","register","(Lnet/minecraftforge/registries/DeferredRegister;)V");m.instructions.insertBefore(ins,l);reg++;}changed=true;
    }
    if(n.endsWith("/GunMod")&&m.name.startsWith("lambda$onCommonSetup$")&&m.desc.equals("()V")) {
     for(var ins:m.instructions.toArray())if(ins.getOpcode()==RETURN){InsnList l=new InsnList();call(l,PORT+"ExtraAmmo","setup","()V");m.instructions.insertBefore(ins,l);setup++;}changed=true;
    }
    if(n.endsWith("/GunEnchantmentHelper")&&m.name.equals("getReloadInterval")) {
     for(var ins:m.instructions.toArray())if(ins instanceof IntInsnNode a&&a.operand==10){InsnList l=new InsnList();l.add(new VarInsnNode(ALOAD,0));call(l,PORT+"ReloadTiming","baseInterval","(Lnet/minecraft/world/item/ItemStack;)I");m.instructions.insertBefore(ins,l);m.instructions.remove(ins);timing++;break;}changed=true;
    }
    if(n.endsWith("/ReloadHandler")) {
     if(m.name.equals("<init>"))for(var ins:m.instructions.toArray())if(ins.getOpcode()==RETURN){InsnList l=new InsnList();l.add(new VarInsnNode(ALOAD,0));l.add(new InsnNode(ICONST_M1));l.add(new FieldInsnNode(PUTFIELD,n,"startReloadTick","I"));m.instructions.insertBefore(ins,l);changed=true;}
     if(m.name.equals("updateReloadTimer"))for(var ins:m.instructions.toArray())if(ins.getOpcode()==ICONST_5 && ins.getNext()!=null && ins.getNext().getOpcode()==IADD){m.instructions.set(ins,new InsnNode(ICONST_0));changed=true;}
    }
    if(n.endsWith("/GunRenderingHandler")&&m.name.equals("applyReloadTransforms")) {
     body(m);m.instructions.add(new VarInsnNode(ALOAD,1));m.instructions.add(new VarInsnNode(FLOAD,2));call(m.instructions,PORT+"ReloadAnimation","weapon",m.desc);m.instructions.add(new InsnNode(RETURN));reload++;changed=true;
    }
    if(n.endsWith("/GunRenderingHandler")&&m.name.equals("renderReloadArm")) {
     body(m);for(int i=1;i<=7;i++)m.instructions.add(new VarInsnNode(i==3?ILOAD:i==7?FLOAD:ALOAD,i));call(m.instructions,PORT+"ReloadAnimation","supportArm",m.desc);m.instructions.add(new InsnNode(RETURN));reload++;changed=true;
    }
    if(n.contains("/render/pose/"))for(var ins:m.instructions)if(ins instanceof MethodInsnNode a&&a.owner.equals("com/mrcrayfish/guns/client/util/RenderUtil")&&a.name.equals("renderFirstPersonArm")){a.owner=PORT+"ReloadAnimation";a.name="gripArm";arm++;changed=true;}
    if(n.endsWith("/SimpleModel")&&m.name.equals("render")){
     InsnList l=new InsnList();l.add(new VarInsnNode(FLOAD,1));l.add(new VarInsnNode(ALOAD,2));l.add(new VarInsnNode(ALOAD,3));l.add(new VarInsnNode(ALOAD,6));l.add(new VarInsnNode(ALOAD,7));l.add(new VarInsnNode(ILOAD,8));l.add(new VarInsnNode(ILOAD,9));
     call(l,PORT+"ReloadAnimation","model","(FLnet/minecraft/world/item/ItemDisplayContext;Lnet/minecraft/world/item/ItemStack;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;II)Z");
     LabelNode done=new LabelNode();l.add(new JumpInsnNode(IFEQ,done));l.add(new InsnNode(RETURN));l.add(done);l.add(new FrameNode(F_SAME,0,null,0,null));m.instructions.insert(l);model++;changed=true;
    }
   }
   if(changed){ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);byte[] bytes=w.toByteArray();ClassNode v=new ClassNode();new ClassReader(bytes).accept(v,0);for(MethodNode m:v.methods)if((m.access&(ACC_ABSTRACT|ACC_NATIVE))==0)new Analyzer<>(new BasicVerifier()).analyze(v.name,m);
    Path p=Path.of(args[1],e.getName());Files.createDirectories(p.getParent());Files.write(p,bytes);System.out.println("Verified "+n);
   }
  }}
  System.out.println("counts input/menu/ammo/setup/timing/reload/arms/model: "+List.of(input,menu,reg,setup,timing,reload,arm,model));
  if(input!=2||menu!=0||reg!=1||setup!=1||timing!=1||reload!=2||arm!=3||model!=1)throw new IllegalStateException("Unexpected patch counts");
 }
}
