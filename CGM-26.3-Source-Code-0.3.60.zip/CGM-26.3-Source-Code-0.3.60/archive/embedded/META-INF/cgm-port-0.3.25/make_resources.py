import zipfile,json,copy
from pathlib import Path
base=zipfile.ZipFile('upload/CGM-26.3-Forge66.0.2-0.3.24-R-EKLENTI-F5.jar')
def save(path,value):
 p=Path('resources')/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
parts={'assault_rifle':[9],'rifle':[26],'heavy_rifle':[8],'machine_pistol':[8],'pistol':[]}
s=Path('decompiled/com/mrcrayfish/guns/client/SpecialModels.java').read_text()
for gun,ids in parts.items():
 d=json.loads(base.read(f'assets/cgm/models/special/gun/{gun}.json'))
 for part in ['body','magazine']:
  out=copy.deepcopy(d);out.pop('display',None)
  out['elements']=[e for i,e in enumerate(d['elements']) if (i in ids)==(part=='magazine')]
  if gun=='pistol' and part=='magazine':
   e=copy.deepcopy(d['elements'][6]);e['from']=[7.55,-.65,13.9];e['to']=[8.45,1.8,14.85];out['elements']=[e]
  name=f'reload/{gun}_{part}'
  save('assets/cgm/models/special/'+name+'.json',out)
  save('assets/cgm/items/special/'+name+'.json',{'model':{'type':'minecraft:model','model':'cgm:special/'+name}})
  field=f'    public static final FrameworkModelResource<FrameworkBakedModel> RELOAD_{gun.upper()}_{part.upper()} = SpecialModels.model("{name}");\n'
  s=s.replace('    private SpecialModels()',field+'\n    private SpecialModels()')
p=Path('src/com/mrcrayfish/guns/client/SpecialModels.java');p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
# Preserve original weapon stats; reload a whole magazine in one timed exchange.
for n in base.namelist():
 if n.startswith('data/cgm/guns/') and n.endswith('.json'):
  d=json.loads(base.read(n));d['general']['reloadAmount']=1 if n.endswith('/shotgun.json') else d['general']['maxAmmo']
  if n.endswith('/grenade_launcher.json'):d['projectile']['item']='cgm:grenade_round'
  save(n,d)
# Native cuboid ammunition model, reusing the mod's shell texture with new proportions.
shell=json.loads(base.read('assets/cgm/models/item/shell.json'))
print('shell model',shell)
save('assets/cgm/models/item/grenade_round.json',{
 'parent':'minecraft:block/block','textures':{'all':'cgm:item/shell','particle':'cgm:item/shell'},
 'elements':[{'from':[5,1,5],'to':[11,12,11],'faces':{f:{'uv':[0,0,16,16],'texture':'#all'} for f in ['north','south','east','west','up','down']}},
 {'from':[5.5,12,5.5],'to':[10.5,15,10.5],'faces':{f:{'uv':[0,0,8,8],'texture':'#all'} for f in ['north','south','east','west','up','down']}}],
 'display':{'gui':{'rotation':[30,45,0],'scale':[.9,.9,.9]},'ground':{'translation':[0,2,0],'scale':[.4,.4,.4]},'fixed':{'scale':[.6,.6,.6]}}})
save('assets/cgm/items/grenade_round.json',{'model':{'type':'minecraft:model','model':'cgm:item/grenade_round'}})
recipe=json.loads(base.read('data/cgm/recipe/grenade.json'));recipe['result']={'id':'cgm:grenade_round','count':4};save('data/cgm/recipe/grenade_round.json',recipe)
for lang in ['en_us','tr_tr']:
 n='assets/cgm/lang/'+lang+'.json';d=json.loads(base.read(n)) if n in base.namelist() else {}
 d['item.cgm.grenade_round']='Bombaatar Mühimmatı' if lang=='tr_tr' else 'Grenade Launcher Round';save(n,d)
