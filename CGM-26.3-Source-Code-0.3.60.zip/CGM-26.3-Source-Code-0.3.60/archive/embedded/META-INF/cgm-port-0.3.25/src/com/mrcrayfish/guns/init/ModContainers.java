package com.mrcrayfish.guns.init;
import com.mrcrayfish.guns.blockentity.WorkbenchBlockEntity;
import com.mrcrayfish.guns.common.container.AttachmentContainer;
import com.mrcrayfish.guns.common.container.WorkbenchContainer;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.network.IContainerFactory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
public class ModContainers {
 public static final DeferredRegister<MenuType<?>> REGISTER=DeferredRegister.create(ForgeRegistries.MENU_TYPES,"cgm");
 public static final RegistryObject<MenuType<WorkbenchContainer>> WORKBENCH=register("workbench",(id,inventory,data)-> {
  if(data==null||data.readableBytes()<8)throw new IllegalArgumentException("CGM workbench opening data is missing its BlockPos");
  var pos=data.readBlockPos();
  if(!(inventory.player.level().getBlockEntity(pos) instanceof WorkbenchBlockEntity workbench))throw new IllegalStateException("CGM workbench block entity missing at "+pos);
  return new WorkbenchContainer(id,inventory,workbench);
 });
 public static final RegistryObject<MenuType<AttachmentContainer>> ATTACHMENTS=register("attachments",(id,inventory,data)->new AttachmentContainer(id,inventory));
 private static <T extends AbstractContainerMenu> RegistryObject<MenuType<T>> register(String name,IContainerFactory<T> factory){
  return REGISTER.register(name,()->IForgeMenuType.create(factory));
 }
}
