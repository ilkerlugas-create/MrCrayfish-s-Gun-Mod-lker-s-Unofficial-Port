package com.mrcrayfish.guns.port;
import com.mrcrayfish.guns.init.ModItems;
import com.mrcrayfish.guns.item.AmmoItem;
import com.mrcrayfish.guns.common.ProjectileManager;
import net.minecraft.world.item.Item;
import net.minecraft.resources.Identifier;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;
public final class ExtraAmmo {
 public static RegistryObject<Item> GRENADE_ROUND;
 public static void register(DeferredRegister<Item> items) {
  GRENADE_ROUND=items.register("grenade_round", () -> new AmmoItem(new Item.Properties().setId(items.key("grenade_round"))));
 }
 public static void setup() {
  ProjectileManager manager=ProjectileManager.getInstance();
  manager.registerFactory(GRENADE_ROUND.get(),manager.getFactory(Identifier.fromNamespaceAndPath("cgm","grenade")));
 }
}
