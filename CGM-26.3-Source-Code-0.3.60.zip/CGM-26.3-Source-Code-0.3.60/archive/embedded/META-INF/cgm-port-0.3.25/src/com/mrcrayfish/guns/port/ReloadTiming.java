package com.mrcrayfish.guns.port;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.registries.BuiltInRegistries;
public final class ReloadTiming {
 public static String kind(ItemStack stack) { return BuiltInRegistries.ITEM.getKey(stack.getItem()).getPath(); }
 public static int baseInterval(ItemStack stack) {
  return switch(kind(stack)) {
   case "pistol","machine_pistol" -> 36;
   case "assault_rifle" -> 46;
   case "rifle" -> 50;
   case "heavy_rifle","bazooka" -> 60;
   case "mini_gun" -> 70;
   case "shotgun" -> 20;
   case "grenade_launcher" -> 40;
   default -> 10;
  };
 }
}
