/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.resources.Identifier
 */
package com.mrcrayfish.guns.client;

import com.mrcrayfish.framework.api.client.model.FrameworkBakedModel;
import com.mrcrayfish.framework.api.client.model.FrameworkModelResource;
import com.mrcrayfish.framework.api.registry.RegistryContainer;
import net.minecraft.resources.Identifier;

@RegistryContainer(clientOnly=true)
public final class SpecialModels {
    public static final FrameworkModelResource<FrameworkBakedModel> ASSAULT_RIFLE = SpecialModels.model("gun/assault_rifle");
    public static final FrameworkModelResource<FrameworkBakedModel> BAZOOKA = SpecialModels.model("gun/bazooka");
    public static final FrameworkModelResource<FrameworkBakedModel> HEAVY_RIFLE = SpecialModels.model("gun/heavy_rifle");
    public static final FrameworkModelResource<FrameworkBakedModel> MACHINE_PISTOL = SpecialModels.model("gun/machine_pistol");
    public static final FrameworkModelResource<FrameworkBakedModel> PISTOL = SpecialModels.model("gun/pistol");
    public static final FrameworkModelResource<FrameworkBakedModel> RIFLE = SpecialModels.model("gun/rifle");
    public static final FrameworkModelResource<FrameworkBakedModel> SHOTGUN = SpecialModels.model("gun/shotgun");
    public static final FrameworkModelResource<FrameworkBakedModel> FLAME = SpecialModels.model("flame");
    public static final FrameworkModelResource<FrameworkBakedModel> MINI_GUN_BASE = SpecialModels.model("mini_gun_base");
    public static final FrameworkModelResource<FrameworkBakedModel> MINI_GUN_BARRELS = SpecialModels.model("mini_gun_barrels");
    public static final FrameworkModelResource<FrameworkBakedModel> GRENADE_LAUNCHER_BASE = SpecialModels.model("grenade_launcher_base");
    public static final FrameworkModelResource<FrameworkBakedModel> GRENADE_LAUNCHER_CYLINDER = SpecialModels.model("grenade_launcher_cylinder");

    public static final FrameworkModelResource<FrameworkBakedModel> RELOAD_ASSAULT_RIFLE_BODY = SpecialModels.model("reload/assault_rifle_body");

    public static final FrameworkModelResource<FrameworkBakedModel> RELOAD_ASSAULT_RIFLE_MAGAZINE = SpecialModels.model("reload/assault_rifle_magazine");

    public static final FrameworkModelResource<FrameworkBakedModel> RELOAD_RIFLE_BODY = SpecialModels.model("reload/rifle_body");

    public static final FrameworkModelResource<FrameworkBakedModel> RELOAD_RIFLE_MAGAZINE = SpecialModels.model("reload/rifle_magazine");

    public static final FrameworkModelResource<FrameworkBakedModel> RELOAD_HEAVY_RIFLE_BODY = SpecialModels.model("reload/heavy_rifle_body");

    public static final FrameworkModelResource<FrameworkBakedModel> RELOAD_HEAVY_RIFLE_MAGAZINE = SpecialModels.model("reload/heavy_rifle_magazine");

    public static final FrameworkModelResource<FrameworkBakedModel> RELOAD_MACHINE_PISTOL_BODY = SpecialModels.model("reload/machine_pistol_body");

    public static final FrameworkModelResource<FrameworkBakedModel> RELOAD_MACHINE_PISTOL_MAGAZINE = SpecialModels.model("reload/machine_pistol_magazine");

    public static final FrameworkModelResource<FrameworkBakedModel> RELOAD_PISTOL_BODY = SpecialModels.model("reload/pistol_body");

    public static final FrameworkModelResource<FrameworkBakedModel> RELOAD_PISTOL_MAGAZINE = SpecialModels.model("reload/pistol_magazine");

    private SpecialModels() {
    }

    private static FrameworkModelResource<FrameworkBakedModel> model(String name) {
        return FrameworkModelResource.create(Identifier.fromNamespaceAndPath((String)"cgm", (String)("special/" + name)));
    }
}

