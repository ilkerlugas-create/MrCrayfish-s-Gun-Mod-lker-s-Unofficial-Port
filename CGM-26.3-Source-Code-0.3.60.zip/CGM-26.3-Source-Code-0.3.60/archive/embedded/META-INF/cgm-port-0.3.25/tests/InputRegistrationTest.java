import com.mrcrayfish.guns.client.handler.ShootingHandler;
import java.lang.invoke.MethodHandles;
import net.minecraftforge.eventbus.api.bus.BusGroup;
import net.minecraftforge.client.event.InputEvent;
public class InputRegistrationTest {
 public static void main(String[] args) {
  BusGroup.DEFAULT.register(MethodHandles.lookup(),ShootingHandler.get());
  if(!InputEvent.InteractionKeyMappingTriggered.Attack.BUS.hasListeners())throw new AssertionError("No attack listener");
  if(!InputEvent.InteractionKeyMappingTriggered.UseItem.BUS.hasListeners())throw new AssertionError("No use-item listener (flipped controls)");
  System.out.println("PASS: real Forge eventbus registers both attack and use-item listeners");
 }
}
