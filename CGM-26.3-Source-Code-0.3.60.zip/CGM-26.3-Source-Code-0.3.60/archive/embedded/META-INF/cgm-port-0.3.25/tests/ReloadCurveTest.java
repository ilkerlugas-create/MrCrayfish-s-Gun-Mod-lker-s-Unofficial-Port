import com.mrcrayfish.guns.port.ReloadAnimation;
public class ReloadCurveTest {
 public static void main(String[] args){
  for(int i=0;i<=1000;i++){float p=i/1000F,v=ReloadAnimation.travel(p),c=ReloadAnimation.cock(p);
   if(!Float.isFinite(v)||v<0||v>1||!Float.isFinite(c)||c<0||c>1)throw new AssertionError("Invalid animation curve");
   if(i>0&&Math.abs(v-ReloadAnimation.travel(p-.001F))>.01F)throw new AssertionError("Magazine jumps");
  }
  if(ReloadAnimation.travel(0)!=0||ReloadAnimation.travel(1)!=0||ReloadAnimation.travel(.45F)<.99F||ReloadAnimation.cock(.85F)<.99F)throw new AssertionError("Magazine/cocking endpoints");
  System.out.println("PASS: 1001 animation samples finite, continuous; magazine seated at both ends and withdrawn mid-cycle");
 }
}
