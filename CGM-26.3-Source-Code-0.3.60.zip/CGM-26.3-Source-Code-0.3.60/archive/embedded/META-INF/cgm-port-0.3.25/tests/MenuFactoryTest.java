import java.nio.file.*;import java.util.jar.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;
public class MenuFactoryTest {
 public static void main(String[] args)throws Exception {
  byte[] bytes;if(args.length==0)bytes=Files.readAllBytes(Path.of("classes/com/mrcrayfish/guns/init/ModContainers.class"));else try(JarFile j=new JarFile(args[0])){bytes=j.getInputStream(j.getJarEntry("com/mrcrayfish/guns/init/ModContainers.class")).readAllBytes();}
  ClassNode c=new ClassNode();new ClassReader(bytes).accept(c,0);int factories=0;
  for(MethodNode m:c.methods)for(var i:m.instructions)if(i instanceof InvokeDynamicInsnNode d&&d.name.equals("create")){
   if(!d.desc.endsWith("Lnet/minecraftforge/network/IContainerFactory;"))throw new AssertionError("Opening factory cannot consume network data: "+d.desc);
   if(!d.bsmArgs[0].toString().equals("(ILnet/minecraft/world/entity/player/Inventory;Lnet/minecraft/network/FriendlyByteBuf;)Lnet/minecraft/world/inventory/AbstractContainerMenu;"))throw new AssertionError("Bad three-argument SAM: "+d.bsmArgs[0]);factories++;
  }
  if(factories!=2)throw new AssertionError("Expected workbench and attachments factories");
  System.out.println("PASS: workbench and attachments use the correct Forge three-argument opening factories");
 }
}
