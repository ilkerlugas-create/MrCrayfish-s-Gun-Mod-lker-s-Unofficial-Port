from pathlib import Path
import json,zipfile,hashlib
base=Path('upload/CGM-26.3-Forge66.0.2-0.3.24-R-EKLENTI-F5.jar')
out=Path('output/CGM-26.3-Forge66.0.2-0.3.25-RELOAD-ATES-TEZGAH.jar');out.parent.mkdir(exist_ok=True)
repl={}
for root in ['classes','resources']:
 for p in Path(root).rglob('*'):
  if p.is_file():repl[p.relative_to(root).as_posix()]=p.read_bytes()
for root in ['src','tools','tests']:
 for p in Path(root).rglob('*.java'):repl['META-INF/cgm-port-0.3.25/'+p.as_posix()]=p.read_bytes()
for name in ['make_resources.py','build_package.py','linkage.txt']:
 repl['META-INF/cgm-port-0.3.25/'+name]=Path(name).read_bytes()
report={'version':'0.3.25','base_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),
 'checks':{'original_input_regression':'FAIL: no Attack listener','patched_input_regression':'PASS on real Forge eventbus 7.0.1',
 'original_menu_factory':'FAIL: MenuSupplier cannot consume opening data','patched_menu_factory':'PASS: workbench and attachments use IContainerFactory',
 'changed_and_workbench_method_verification':178,'unresolved_method_field_links':0,'curve_samples':1001},
 'interactive_game_test':False,'video_reference':'All Weapon Reload Animations in CS2.mp4',
 'animation':'Original CGM geometry and hand keyframes inspired by the video; not an import of CS2 animation assets',
 'ammo':'cgm:grenade_round, creative tab and workbench recipe; original grenade projectile factory preserved',
 'all_original_entries_retained':True}
repl['META-INF/cgm-port-0.3.25/validation.json']=(json.dumps(report,indent=2)+'\n').encode()
readme='''CGM 26.3 / Forge 66.0.2 / Java 25 — 0.3.25

Kurulum: Eski CGM JAR dosyasını mods klasöründen çıkarıp bu dosyayı koy.
Framework bu pakette zaten mevcut. Sunucu kullanıyorsan iki tarafta da aynı sürümü kullan.

Değişiklikler:
- Tekli atış: gerçek Forge 66 Attack ve UseItem olaylarına kayıt düzeltildi.
  Pompalı, tüfek, ağır tüfek, bazuka, tabanca ve bombaatarın tekli atış yolu kapsanır.
- Tezgâh: konum verisini alan IContainerFactory / IForgeMenuType açılışı düzeltildi.
  Eklenti menüsünün iki argümanlı kurucusu da uygun üç argümanlı fabrika ile sarıldı.
- Bombaatar için ayrı Bombaatar Mühimmatı (cgm:grenade_round) eklendi.
  Yaratıcı sekmede ve silah tezgâhının mühimmat bölümünde bulunur.
- Reload: videodan esinlenen silah eğme, destek eli, şarjör çıkarma/takma ve kurma hareketleri.
  Şarjörlü silahlar tek döngüde doldurulur, pompalı tek tek fişek alır.
  Sunucu dolum süresi ve istemci animasyonu aynı süre hesabını kullanır.
- Önceki içerik, R tuşu, eklenti, F5 ve koşu düzeltmeleri korundu.

Mühimmat:
Tabanca / makineli tabanca / saldırı tüfeği / minigun: temel mermi
Tüfek / ağır tüfek: gelişmiş mermi
Pompalı: fişek
Bazuka: füze
Bombaatar: Bombaatar Mühimmatı

Doğrulama: Java 25 derleme; 178 yöntemin bytecode ve API bağlantı kontrolü;
Forge eventbus tekli atış regresyonu; menü fabrika imzaları; reload eğri sınırları.
Oyun istemcisi burada çalıştırılmadı. Görsel eşleşme ve tam oyun akışı oyun içinde doğrulanmalı.
Tezgâh hatası devam ederse hatadan sonraki .minecraft/logs/latest.log dosyasını gönder.
Kaynak kodlar ve doğrulama raporu META-INF/cgm-port-0.3.25/ içindedir.
'''
repl['CGM-0.3.25-OKU.txt']=readme.encode()
with zipfile.ZipFile(base) as z:
 for n in ['META-INF/MANIFEST.MF','META-INF/mods.toml']:repl[n]=z.read(n).replace(b'port-0.3.24',b'port-0.3.25')
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as w:
  for n in z.namelist():w.writestr(n,repl.pop(n,z.read(n)))
  for n,b in sorted(repl.items()):w.writestr(n,b)
with zipfile.ZipFile(base) as old,zipfile.ZipFile(out) as new:
 assert new.testzip() is None
 assert set(old.namelist())<=set(new.namelist())
 guns=[n for n in new.namelist() if n.startswith('data/cgm/guns/') and n.endswith('.json')];assert len(guns)==9
 for n in new.namelist():
  if n.endswith('.json'):json.loads(new.read(n))
 for gun,index in {'assault_rifle':9,'rifle':26,'heavy_rifle':8,'machine_pistol':8}.items():
  d=json.loads(old.read(f'assets/cgm/models/special/gun/{gun}.json'))
  body=json.loads(new.read(f'assets/cgm/models/special/reload/{gun}_body.json'))
  mag=json.loads(new.read(f'assets/cgm/models/special/reload/{gun}_magazine.json'))
  assert body['elements']==[e for i,e in enumerate(d['elements']) if i!=index]
  assert mag['elements']==[d['elements'][index]]
 assert json.loads(new.read('data/cgm/guns/grenade_launcher.json'))['projectile']['item']=='cgm:grenade_round'
 assert json.loads(new.read('data/cgm/recipe/grenade_round.json'))['result']['id']=='cgm:grenade_round'
print(out.resolve());print('SHA256',hashlib.sha256(out.read_bytes()).hexdigest());print('PASS: archive integrity, all original entries, 9 guns, JSON resources, magazine geometry conservation, grenade ammunition recipe')
