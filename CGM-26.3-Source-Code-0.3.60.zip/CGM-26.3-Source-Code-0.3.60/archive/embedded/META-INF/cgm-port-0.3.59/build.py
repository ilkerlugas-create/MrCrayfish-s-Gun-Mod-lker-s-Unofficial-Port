"""Reproduce the exact-input performance patch with Python 3 and a JDK 17+.
The shipped input retains Java 25 class versions; only fixture-test copies use 17.
No Minecraft/Forge rebuild or in-game client is launched by this script.
"""
from pathlib import Path
import subprocess,sys,os,hashlib,json,zipfile,shutil
P=Path(__file__).resolve().parent
ROOT=P.parent
BASE=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT/'base/CGM-26.3-Forge-Ilker-Unofficial-Port-EU.jar'
EXPECTED='ed394790097595cd05e9c5db821d6df155026497a55660bb5d1d36be2730ad2a'
assert hashlib.sha256(BASE.read_bytes()).hexdigest()==EXPECTED,'Different input JAR; do not apply this patch'
ORIGINAL=ROOT/'input'
with zipfile.ZipFile(BASE) as z:
    for name in z.namelist():
        p=Path(name)
        if name.endswith('/') or p.is_absolute() or '..' in p.parts:continue
        dest=ORIGINAL/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z.read(name))
def run(args,log=None):
    r=subprocess.run(args,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    if log:(P/log).write_text(r.stdout)
    print(r.stdout,end='')
    if r.returncode:raise SystemExit(r.returncode)
exports=[f'--add-exports=java.base/jdk.internal.org.objectweb.asm{s}=ALL-UNNAMED' for s in ('','.tree','.tree.analysis','.util')]
for name in ['classes','tools-classes','patched','test-runtime','test-classes']:
    path=P/name
    if path.exists():shutil.rmtree(path)
run(['python3',str(P/'tests/make_fixtures.py')])
sources=sorted([*P.glob('fixtures/**/*.java'),*P.glob('src/**/*.java')])
run(['java','com.sun.tools.javac.Main','--release','17','-d',str(P/'classes'),*map(str,sources)])
run(['java','com.sun.tools.javac.Main',*exports,'-d',str(P/'tools-classes'),*map(str,(P/'tools').glob('*.java'))])
run(['java',*exports,'-cp',str(P/'tools-classes'),'Patch59',str(ORIGINAL),str(P/'patched')], 'bytecode-verification.txt')
run(['java',*exports,'-cp',str(P/'tools-classes'),'TestRuntime59',str(ORIGINAL),str(P/'patched'),str(P/'classes'),str(P/'test-runtime')])
cp=os.pathsep.join(map(str,[P/'test-runtime/before',P/'classes']))
run(['java','com.sun.tools.javac.Main','--release','17','-cp',cp,'-d',str(P/'test-classes'),str(P/'tests/Regression59.java')])
for side in ['before','after']:
    cp=os.pathsep.join(map(str,[P/f'test-runtime/{side}',P/'test-classes',P/'classes']))
    run(['java','-Xverify:all','-cp',cp,'com.mrcrayfish.guns.port.Regression59',str(side=='after').lower()],side+'-regression.txt')
run(['java',*exports,'-cp',str(P/'tools-classes'),'Verify59',str(ORIGINAL),str(P/'patched'),str(P/'classes')],'integrity-verification.txt')
updates={str(p.relative_to(P/'patched')).replace(os.sep,'/'):p.read_bytes() for p in (P/'patched').rglob('*.class')}
for name in ('GunDefinitionCache','AttachmentDecodeBackoff'):
    for p in (P/'classes/com/mrcrayfish/guns/port').glob(name+'*.class'):
        updates['com/mrcrayfish/guns/port/'+p.name]=p.read_bytes()
output=ROOT/'output';output.mkdir(exist_ok=True)
target=output/'CGM-26.3-Forge-Ilker-Unofficial-Port-EU-0.3.59-PERFORMANCE.jar'
with zipfile.ZipFile(BASE) as old:
    for name in ('META-INF/MANIFEST.MF','META-INF/mods.toml'):
        data=old.read(name);assert b'port-0.3.57' in data
        updates[name]=data.replace(b'port-0.3.57',b'port-0.3.59')
    for folder in ['src','tools','tests','fixtures']:
        for p in (P/folder).rglob('*'):
            if p.is_file() and p.suffix in ('.java','.py'):
                updates['META-INF/cgm-port-0.3.59/'+p.relative_to(P).as_posix()]=p.read_bytes()
    for p in [P/'build.py',*P.glob('*.txt'),*P.glob('*.md')]:
        updates['META-INF/cgm-port-0.3.59/'+p.name]=p.read_bytes()
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as new:
        for info in old.infolist():new.writestr(info,updates.pop(info.filename,old.read(info.filename)))
        for name,data in updates.items():new.writestr(name,data)
with zipfile.ZipFile(BASE) as old,zipfile.ZipFile(target) as new:
    assert new.testzip() is None
    assert len(new.namelist())==len(set(new.namelist()))
    assert not set(old.namelist())-set(new.namelist())
    changed=[n for n in old.namelist() if old.read(n)!=new.read(n)]
    expected={'com/mrcrayfish/guns/'+n+'.class' for n in ('item/GunItem','port/StackReadCache','client/particle/BulletHoleParticle','client/particle/BloodParticle')}
    assert set(changed)==expected|{'META-INF/MANIFEST.MF','META-INF/mods.toml'},changed
    added_classes=[n for n in set(new.namelist())-set(old.namelist()) if n.endswith('.class')]
    assert all(n.startswith(('com/mrcrayfish/guns/port/GunDefinitionCache','com/mrcrayfish/guns/port/AttachmentDecodeBackoff')) for n in added_classes)
    assert len(added_classes)==7,added_classes
    assets=[n for n in old.namelist() if n.startswith(('assets/','data/')) and not n.endswith('/')]
    assert all(old.read(n)==new.read(n) for n in assets)
report={'input_sha256':EXPECTED,'output_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),
    'changed_original_entries':changed,'new_runtime_classes':sorted(added_classes),
    'assets_and_data_preserved_byte_for_byte':len(assets),'in_game_test':False,'full_forge_build':False,
    'fixture_tests_passed':True,'notes':'Structural bytecode checks and before/after tests with API fixtures. Counts are not FPS gains.'}
(output/'validation-0.3.59.json').write_text(json.dumps(report,indent=2))
print('PASS: output archive CRC, unique entries, exact changed-class whitelist, unchanged assets/data.')
print('OUTPUT',target)
