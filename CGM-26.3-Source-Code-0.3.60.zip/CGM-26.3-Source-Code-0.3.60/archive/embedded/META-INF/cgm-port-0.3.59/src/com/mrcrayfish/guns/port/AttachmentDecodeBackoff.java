package com.mrcrayfish.guns.port;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.server.ServerLifecycleHooks;

/** Prevent invalid legacy/custom attachment data from running CODEC every frame. */
public final class AttachmentDecodeBackoff {
    private static final long RETRY_NANOS = 250_000_000L;
    private static final int LIMIT = 128;
    private static final ThreadLocal<State> LOCAL = ThreadLocal.withInitial(State::new);
    private static final class State {
        Object registry;
        final LinkedHashMap<CompoundTag, Long> failures = new LinkedHashMap<>(16, .75F, true) {
            protected boolean removeEldestEntry(Map.Entry<CompoundTag, Long> entry) {
                return size() > LIMIT;
            }
        };
    }

    public static ItemStack read(CompoundTag tag) {
        var server = ServerLifecycleHooks.getCurrentServer();
        Object registry = server == null ? null : server.registryAccess();
        return readAt(tag, registry, System.nanoTime());
    }

    static ItemStack readAt(CompoundTag tag, Object registry, long now) {
        if (tag == null || tag.isEmpty()) return ItemStack.EMPTY;
        State state = LOCAL.get();
        if (state.registry != registry) {
            state.failures.clear();
            state.registry = registry;
        }
        Long failure = state.failures.get(tag);
        if (failure != null && now - failure >= 0L && now - failure < RETRY_NANOS) {
            return ItemStack.EMPTY;
        }
        ItemStack result = AttachmentData.read(tag);
        if (result.isEmpty()) state.failures.put(tag, now);
        else state.failures.remove(tag);
        return result;
    }
}
