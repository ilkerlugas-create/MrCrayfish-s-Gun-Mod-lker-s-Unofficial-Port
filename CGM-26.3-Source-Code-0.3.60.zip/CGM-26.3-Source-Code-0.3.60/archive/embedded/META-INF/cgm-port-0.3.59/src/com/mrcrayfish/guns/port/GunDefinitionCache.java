package com.mrcrayfish.guns.port;

import java.util.LinkedHashMap;
import java.util.Map;
import com.mrcrayfish.guns.GunMod;
import com.mrcrayfish.guns.common.Gun;
import com.mrcrayfish.guns.debug.Debug;
import com.mrcrayfish.guns.item.GunItem;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;

/** Cache only definition inputs, never ammo, paint or weapon-instance metadata. */
public final class GunDefinitionCache {
    private static final int LIMIT = 128;
    private static final ThreadLocal<State> LOCAL = ThreadLocal.withInitial(State::new);
    private record Key(Gun base, boolean custom, CompoundTag definition) {}
    private static final class State {
        final LinkedHashMap<Key, Gun> definitions = new LinkedHashMap<>(16, .75F, true) {
            protected boolean removeEldestEntry(Map.Entry<Key, Gun> entry) {
                return size() > LIMIT;
            }
        };
        CompoundTag lastRoot;
        Gun lastBase, lastResult;
    }

    public static Gun get(GunItem item, ItemStack stack) {
        CompoundTag root = StackReadCache.read(stack);
        if (!root.contains("Gun")) {
            return GunMod.isDebugging() ? Debug.getGun(item) : item.getGun();
        }
        Gun base = item.getGun();
        State state = LOCAL.get();
        if (state.lastRoot == root && state.lastBase == base) return state.lastResult;
        boolean custom = root.getBooleanOr("Custom", false);
        // read() owns an immutable snapshot. Never modify or return this tag.
        CompoundTag definition = root.getCompoundOrEmpty("Gun");
        Key key = new Key(base, custom, definition);
        Gun result = state.definitions.get(key);
        if (result == null) {
            if (custom) result = Gun.create(definition);
            else {
                result = base.copy();
                result.deserializeNBT(definition);
            }
            state.definitions.put(key, result);
        }
        state.lastRoot = root;
        state.lastBase = base;
        state.lastResult = result;
        return result;
    }
}
