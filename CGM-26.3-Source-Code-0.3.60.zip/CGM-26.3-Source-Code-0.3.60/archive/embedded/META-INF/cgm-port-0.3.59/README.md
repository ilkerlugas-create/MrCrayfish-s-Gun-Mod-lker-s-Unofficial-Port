# CGM 26.3 — İlker's Unofficial Port — 0.3.59 performance patch

This is a narrow patch of the exact user-supplied
`CGM-26.3-Forge-Ilker-Unofficial-Port-EU.jar` (internal version 0.3.57).
Input SHA-256: `ed394790097595cd05e9c5db821d6df155026497a55660bb5d1d36be2730ad2a`.
It is not a replacement port, a Forge rebuild or a merge of another 0.3.57/0.3.58 branch.

## Kurulum

Oyunu kapat. `mods` klasöründeki önceki CGM JAR'ını dışarı taşı ve yerine
`CGM-26.3-Forge-Ilker-Unofficial-Port-EU-0.3.59-PERFORMANCE.jar` dosyasını koy.
Aynı anda iki CGM sürümü kullanma. Minecraft 26.3 / Forge 66.0.2 hedefi ve
JAR içindeki Framework 0.13.27 korunur.

## Değişiklikler

- Mermi deliği ve kan parçacıklarının yönlendirme nesneleri her çizim çağrısında
  yeniden oluşturulmaz. Sabit yön dönüşleri tekrar kullanılır; kamera yönüne
  bakma, yere düşme, renk, ömür ve blok kırılınca kaybolma davranışları korunur.
- `Gun` NBT verisi taşıyan silahlarda mermi sayısı, renk veya silah kimliği
  değiştiğinde aynı silah tanımı yeniden oluşturulmaz. Ön hesaplama yalnızca
  tanım verisine, `Custom` bayrağına ve temel silah tanımına bağlıdır.
  Gerçek silah tanımı değişiklikleri ve veri yeniden yükleme dikkate alınır.
  Normal, özel NBT taşımayan silahların seçim davranışı aynıdır.
- Çözülemeyen eklenti verisi her erişimde tekrar CODEC işleminden geçirilmez.
  Başarısız sonuçlar en fazla 250 ms bekletilir; kayıt bağlamı değişince hemen
  tekrar denenir. Başarılı çözümleme önceki önbelleği kullanmaya devam eder.
- Yeni önbellekler iş parçacığına özeldir ve ayrı ayrı en fazla 128 kayıt tutar.

Silah, mühimmat, hasar, şarjör kapasitesi, ateş hızı, reload, Z menüsü, kaplama,
ses, animasyon, ağ mesajları, tarifler ve oyun içi efekt sayıları değiştirilmez.
Mevcut 3D çizim sistemi kaldırılmaz veya sadeleştirilmez.

## Doğrulama ve sınırlar

Girdi JAR'ından alınan gerçek metotlar önce/sonra aynı küçük API test ortamında
çalıştırıldı. Minecraft veya Forge istemcisi burada açılmadı; oyun içi FPS,
frame-time veya GC profili alınmadı. Bu yama doğrulanan gereksiz işleri azaltır;
kullanıcının yaşadığı her drop'un bu nedenlerden kaynaklandığı doğrulanmış değildir.

| Test döngüsü | Önce | Sonra |
| --- | ---: | ---: |
| Aynı tanımla 10.000 mermi/renk/kimlik değişiminde silah oluşturma | 10.000 | 1 |
| 80.000 parçacık çizim çağrısında yeni yönlendirme nesnesi | 80.000 | 0 |
| Aynı çizim çağrılarında yeni sabit yön quaternion nesnesi | 70.000 | 0 |
| 250 ms içindeki 10.000 hatalı eklenti okumasında çözümleme denemesi | 10.000 | 1 |

Bu değerler dar test döngülerinin işlem sayılarıdır; FPS artış oranı değildir.
Özel silahlar arası geçiş, veri yeniden yükleme, debug davranışı, iki iş
parçacığının ayrılması, önbellek sınırları, altı blok yüzü, yerde/havada kan
yönü, blok kaldırma, hatalı eklentinin sonradan düzelmesi ve yeniden deneme
süresi kontrol edildi. JVM `-Xverify:all` ve ASM veri akışı kontrolleri geçti.

Dört mevcut sınıfın hedef metotları değişir; yedi yeni yardımcı sınıf eklenir.
Diğer mevcut metotlar ve tüm `assets/` / `data/` dosyaları korunur.
Yeni Minecraft/Forge çağrıları girdi JAR'ında zaten kullanılan imzalarla
karşılaştırıldı. Bu kontrol tam oyun bağımlılıklarıyla entegrasyon testi değildir.

Drop devam ederse drop yaşanan denemeye ait `logs/latest.log`, ayrılan RAM ve
takılmanın seri atışta mı, hareket ederken mi, yeni bölgeye girerken mi olduğu
gereklidir. Bu sürümde profil kaydı veya sürekli log yazımı eklenmez.

## Rebuild

From the workspace ZIP root, with Python 3 and JDK 17 or newer installed:

```sh
python3 patch-0.3.59/build.py
```

An explicit path to the original input JAR can also be passed as the first
argument. The script checks the exact input hash, compiles helpers, applies
guarded bytecode changes, runs before/after regressions and builds the output.
Existing shipped class versions stay Java 25 (69). New helpers use Java 17
bytecode, also supported by Java 25. Only test copies are adapted to the
available Java 17 runtime. The test fixtures are never installed as runtime
Minecraft/Forge classes; their Java sources are included only for reproducibility.

Existing licensing, authorship and attribution files remain intact.
