import java.nio.file.*;
import java.util.*;
import jdk.internal.org.objectweb.asm.*;
import jdk.internal.org.objectweb.asm.tree.*;
import jdk.internal.org.objectweb.asm.tree.analysis.*;

/** Exact-input patch. All unrelated methods, annotations and class versions stay. */
public final class Patch59 implements Opcodes {
    static final String G = "com/mrcrayfish/guns/";
    static final String MODE = "net/minecraft/client/particle/SingleQuadParticle$FacingCameraMode";
    static Path input, output;
    static MethodNode method(ClassNode c, String name) {
        var found = c.methods.stream().filter(m -> m.name.equals(name)).toList();
        if (found.size() != 1) throw new AssertionError(c.name + "." + name);
        return found.get(0);
    }
    static ClassNode read(String name) throws Exception {
        byte[] b = Files.readAllBytes(input.resolve(name + ".class"));
        int version = (b[6] & 255) << 8 | (b[7] & 255);
        b[6] = 0; b[7] = 61;
        ClassNode c = new ClassNode(); new ClassReader(b).accept(c, 0);
        c.version = version;
        return c;
    }
    static void save(ClassNode c) throws Exception {
        for (MethodNode m : c.methods) {
            if ((m.access & (ACC_NATIVE | ACC_ABSTRACT)) == 0)
                new Analyzer<>(new BasicVerifier()).analyze(c.name, m);
        }
        ClassWriter w = new ClassWriter(ClassWriter.COMPUTE_MAXS); c.accept(w);
        Path p = output.resolve(c.name + ".class"); Files.createDirectories(p.getParent());
        Files.write(p, w.toByteArray());
        System.out.println("VERIFIED " + c.name);
    }
    static void check(boolean b, String message) { if (!b) throw new AssertionError(message); }

    static void particle(String shortName, boolean hole) throws Exception {
        ClassNode c = read(G + "client/particle/" + shortName);
        c.fields.add(new FieldNode(ACC_PRIVATE, "cgmCachedFacing", "L" + MODE + ";", null, null));
        MethodNode getter = method(c, "getFacingCameraMode");
        check(getter.desc.equals("()L" + MODE + ";"), "Facing descriptor");
        // Lazy initialization preserves calls made during superclass construction.
        LabelNode create = new LabelNode();
        InsnList prefix = new InsnList();
        prefix.add(new VarInsnNode(ALOAD, 0));
        prefix.add(new FieldInsnNode(GETFIELD, c.name, "cgmCachedFacing", "L" + MODE + ";"));
        prefix.add(new JumpInsnNode(IFNULL, create));
        prefix.add(new VarInsnNode(ALOAD, 0));
        prefix.add(new FieldInsnNode(GETFIELD, c.name, "cgmCachedFacing", "L" + MODE + ";"));
        prefix.add(new InsnNode(ARETURN)); prefix.add(create);
        prefix.add(new FrameNode(F_SAME, 0, null, 0, null));
        getter.instructions.insert(prefix);
        int stores = 0;
        for (var n : getter.instructions.toArray()) if (n instanceof InvokeDynamicInsnNode) {
            InsnList cache = new InsnList(); cache.add(new InsnNode(DUP));
            cache.add(new VarInsnNode(ALOAD, 0)); cache.add(new InsnNode(SWAP));
            cache.add(new FieldInsnNode(PUTFIELD, c.name, "cgmCachedFacing", "L" + MODE + ";"));
            getter.instructions.insert(n, cache); stores++;
        }
        check(stores == 1, "Expected one facing factory");
        getter.maxStack = Math.max(getter.maxStack, 3);

        // Direction rotations are constant. Hold one per particle (bullet hole)
        // or one per class (grounded blood), rather than allocating per quad.
        String rotation = "Lorg/joml/Quaternionf;";
        c.fields.add(new FieldNode(ACC_PRIVATE | ACC_FINAL | (hole ? 0 : ACC_STATIC),
                "cgmCachedRotation", rotation, null, null));
        MethodNode lambda = method(c, "lambda$getFacingCameraMode$0");
        int rotations = 0;
        for (var n : lambda.instructions.toArray()) if (n instanceof MethodInsnNode call
                && call.owner.equals("net/minecraft/core/Direction") && call.name.equals("getRotation")) {
            var field = call.getPrevious();
            check(field instanceof FieldInsnNode, "Direction field required");
            lambda.instructions.set(field, new FieldInsnNode(hole ? GETFIELD : GETSTATIC,
                    c.name, "cgmCachedRotation", rotation));
            lambda.instructions.remove(call); rotations++;
        }
        check(rotations == 1, "Expected one direction rotation");
        MethodNode init;
        if (hole) init = method(c, "<init>");
        else {
            check(c.methods.stream().noneMatch(m -> m.name.equals("<clinit>")), "Unexpected static initializer");
            init = new MethodNode(ACC_STATIC, "<clinit>", "()V", null, null);
            init.instructions.add(new InsnNode(RETURN)); init.maxStack = 1;
            c.methods.add(init);
        }
        int initialized = 0;
        for (var n : init.instructions.toArray()) if (n.getOpcode() == RETURN) {
            InsnList setup = new InsnList();
            if (hole) {
                setup.add(new VarInsnNode(ALOAD, 0)); setup.add(new VarInsnNode(ALOAD, 0));
                setup.add(new FieldInsnNode(GETFIELD, c.name, "direction", "Lnet/minecraft/core/Direction;"));
            } else setup.add(new FieldInsnNode(GETSTATIC, "net/minecraft/core/Direction", "NORTH", "Lnet/minecraft/core/Direction;"));
            setup.add(new MethodInsnNode(INVOKEVIRTUAL, "net/minecraft/core/Direction", "getRotation", "()" + rotation, false));
            setup.add(new FieldInsnNode(hole ? PUTFIELD : PUTSTATIC, c.name, "cgmCachedRotation", rotation));
            init.instructions.insertBefore(n, setup); initialized++;
        }
        check(initialized == 1, "Expected one constructor return");
        save(c);
    }
    public static void main(String[] args) throws Exception {
        input = Path.of(args[0]); output = Path.of(args[1]);
        ClassNode gun = read(G + "item/GunItem");
        MethodNode get = method(gun, "getModifiedGun");
        get.instructions.clear(); get.tryCatchBlocks.clear();
        if (get.localVariables != null) get.localVariables.clear();
        get.visibleLocalVariableAnnotations = null; get.invisibleLocalVariableAnnotations = null;
        get.instructions.add(new VarInsnNode(ALOAD, 0)); get.instructions.add(new VarInsnNode(ALOAD, 1));
        get.instructions.add(new MethodInsnNode(INVOKESTATIC, G + "port/GunDefinitionCache", "get",
                "(L" + G + "item/GunItem;Lnet/minecraft/world/item/ItemStack;)L" + G + "common/Gun;", false));
        get.instructions.add(new InsnNode(ARETURN)); get.maxStack = 2; get.maxLocals = 2;
        save(gun);
        ClassNode cache = read(G + "port/StackReadCache");
        int changed = 0;
        for (var n : method(cache, "borrowedItem").instructions) if (n instanceof MethodInsnNode call
                && call.owner.equals(G + "port/AttachmentData") && call.name.equals("read")) {
            call.owner = G + "port/AttachmentDecodeBackoff"; changed++;
        }
        check(changed == 1, "Expected one attachment decoder call"); save(cache);
        particle("BulletHoleParticle", true); particle("BloodParticle", false);
    }
}
