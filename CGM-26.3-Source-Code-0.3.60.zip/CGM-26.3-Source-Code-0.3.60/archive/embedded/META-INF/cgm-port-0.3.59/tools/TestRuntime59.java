import java.nio.file.*;
import jdk.internal.org.objectweb.asm.*;
import jdk.internal.org.objectweb.asm.tree.*;

/** Java 17 fixture adapter: only test copies use version 61. Shipped classes retain 69. */
public class TestRuntime59 {
    static ClassNode read(Path p) throws Exception {
        byte[] b=Files.readAllBytes(p);b[6]=0;b[7]=61;
        ClassNode c=new ClassNode();new ClassReader(b).accept(c,0);return c;
    }
    public static void main(String[] args) throws Exception {
        Path original=Path.of(args[0]),patched=Path.of(args[1]),fixtures=Path.of(args[2]),root=Path.of(args[3]);
        String gun="com/mrcrayfish/guns/item/GunItem.class";
        for(int side=0;side<2;side++) {
            Path src=side==0?original:patched,dst=root.resolve(side==0?"before":"after");
            ClassNode target=read(fixtures.resolve(gun)),donor=read(src.resolve(gun));
            target.methods.removeIf(m->m.name.equals("getModifiedGun"));
            for(MethodNode m:donor.methods)if(m.name.equals("getModifiedGun")||m.name.startsWith("lambda$getModifiedGun$"))target.methods.add(m);
            ClassWriter w=new ClassWriter(0);target.accept(w);
            Files.createDirectories(dst.resolve(gun).getParent());Files.write(dst.resolve(gun),w.toByteArray());
            for(String name:new String[]{"BulletHoleParticle","BloodParticle"}){
                String path="com/mrcrayfish/guns/client/particle/"+name+".class";
                ClassNode c=read(src.resolve(path));ClassWriter pw=new ClassWriter(0);c.accept(pw);
                Files.createDirectories(dst.resolve(path).getParent());Files.write(dst.resolve(path),pw.toByteArray());
            }
        }
    }
}
