import java.nio.file.*;
import java.util.*;
import java.io.*;
import jdk.internal.org.objectweb.asm.*;
import jdk.internal.org.objectweb.asm.tree.*;
import jdk.internal.org.objectweb.asm.tree.analysis.*;
import jdk.internal.org.objectweb.asm.util.*;

/** Compare every unchanged method and check new MC/Forge descriptors against input. */
public final class Verify59 implements Opcodes {
    static ClassNode read(Path path) throws Exception {
        byte[] b=Files.readAllBytes(path);b[6]=0;b[7]=61;
        ClassNode c=new ClassNode();new ClassReader(b).accept(c,0);return c;
    }
    static String body(MethodNode m){Textifier p=new Textifier();m.accept(new TraceMethodVisitor(p));StringWriter s=new StringWriter();p.print(new PrintWriter(s));return s.toString();}
    static Set<String> references(ClassNode c){
        Set<String> refs=new HashSet<>();
        for(MethodNode m:c.methods)for(var n:m.instructions){
            if(n instanceof MethodInsnNode i)refs.add(i.owner+" "+i.name+" "+i.desc+" "+i.getOpcode());
            if(n instanceof FieldInsnNode i)refs.add(i.owner+" "+i.name+" "+i.desc+" "+i.getOpcode());
        }return refs;
    }
    public static void main(String[] args) throws Exception {
        Path original=Path.of(args[0]),patched=Path.of(args[1]),compiled=Path.of(args[2]);
        Set<String> known=new HashSet<>();
        try(var walk=Files.walk(original.resolve("com"))){for(Path p:walk.filter(p->p.toString().endsWith(".class")).toList())known.addAll(references(read(p)));}
        Map<String,Set<String>> allowed=Map.of(
            "GunItem",Set.of("getModifiedGun"),"StackReadCache",Set.of("borrowedItem"),
            "BulletHoleParticle",Set.of("<init>","getFacingCameraMode","lambda$getFacingCameraMode$0"),
            "BloodParticle",Set.of("<clinit>","getFacingCameraMode","lambda$getFacingCameraMode$0"));
        int unchanged=0,external=0,classes=0;
        List<Path> inspect=new ArrayList<>();
        try(var walk=Files.walk(patched)){inspect.addAll(walk.filter(p->p.toString().endsWith(".class")).toList());}
        for(Path p:inspect){
            ClassNode after=read(p),before=read(original.resolve(patched.relativize(p)));
            byte[] a=Files.readAllBytes(p),b=Files.readAllBytes(original.resolve(patched.relativize(p)));
            if(a[6]!=b[6]||a[7]!=b[7])throw new AssertionError("Runtime class version changed");
            for(MethodNode old:before.methods){
                MethodNode next=after.methods.stream().filter(m->m.name.equals(old.name)&&m.desc.equals(old.desc)).findFirst().orElseThrow();
                if(!allowed.get(p.getFileName().toString().replace(".class","")).contains(old.name)){
                    if(!body(old).equals(body(next)))throw new AssertionError("Unexpected change "+after.name+"."+old.name);unchanged++;
                }
            }
        }
        try(var walk=Files.walk(compiled.resolve("com/mrcrayfish/guns/port"))){
            inspect.addAll(walk.filter(p->{String n=p.getFileName().toString();return n.endsWith(".class")&&(n.startsWith("GunDefinitionCache")||n.startsWith("AttachmentDecodeBackoff"));}).toList());
        }
        for(Path p:inspect){
            ClassNode c=read(p);classes++;
            for(MethodNode m:c.methods)if((m.access&(ACC_NATIVE|ACC_ABSTRACT))==0)new Analyzer<>(new BasicVerifier()).analyze(c.name,m);
            for(String ref:references(c))if(ref.startsWith("net/minecraft/")||ref.startsWith("net/minecraftforge/")){
                if(!known.contains(ref))throw new AssertionError("Unproven external descriptor "+ref);external++;
            }
        }
        System.out.println("PASS: "+classes+" production classes checked; "+unchanged+" original methods unchanged; "+external+" Minecraft/Forge references already present in the input JAR.");
    }
}
