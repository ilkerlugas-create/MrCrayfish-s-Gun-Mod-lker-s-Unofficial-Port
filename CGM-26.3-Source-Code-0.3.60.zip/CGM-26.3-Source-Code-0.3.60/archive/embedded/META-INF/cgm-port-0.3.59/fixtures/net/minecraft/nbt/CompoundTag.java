package net.minecraft.nbt;
import java.util.*;
public class CompoundTag {
 public boolean getBooleanOr(String k,boolean fallback){return data.get(k) instanceof Boolean b?b:fallback;} public void putBoolean(String k,boolean v){data.put(k,v);}
 public final Map<String,Object> data=new HashMap<>();
 public boolean isEmpty(){return data.isEmpty();} public boolean contains(String k){return data.containsKey(k);}
 public void putInt(String k,int v){data.put(k,v);} public int getIntOr(String k,int v){return data.get(k) instanceof Integer n?n:v;}
 public void putString(String k,String v){data.put(k,v);} public String getStringOr(String k,String v){return data.get(k) instanceof String n?n:v;}
 public void put(String k,CompoundTag v){data.put(k,v);} public void remove(String k){data.remove(k);}
 public CompoundTag copy(){CompoundTag t=new CompoundTag();data.forEach((k,v)->t.data.put(k,v instanceof CompoundTag c?c.copy():v));return t;}
 public CompoundTag getCompoundOrEmpty(String k){return data.get(k) instanceof CompoundTag t?t:new CompoundTag();}
 public int hashCode(){return data.hashCode();}public boolean equals(Object v){return v instanceof CompoundTag t&&data.equals(t.data);}
}