package net.minecraft.client.particle;
import net.minecraft.client.multiplayer.ClientLevel;import net.minecraft.client.renderer.texture.TextureAtlasSprite;import net.minecraft.client.Camera;import org.joml.Quaternionf;import net.minecraft.util.RandomSource;
public class SingleQuadParticle {
public ClientLevel level;public RandomSource random;public TextureAtlasSprite sprite;public int lifetime,age;public boolean hasPhysics,onGround,removed;public float gravity,quadSize,alpha,rCol,gCol,bCol;public double xd,zd;
public SingleQuadParticle(ClientLevel l,double x,double y,double z,TextureAtlasSprite s){level=l;sprite=s;random=l.getRandom();}
public SingleQuadParticle(ClientLevel l,double x,double y,double z,double dx,double dy,double dz,TextureAtlasSprite s){this(l,x,y,z,s);}
public void setColor(float r,float g,float b){rCol=r;gCol=g;bCol=b;}
public void tick(){age++;if(age>=lifetime)remove();}public void remove(){removed=true;}
public enum Layer {TRANSLUCENT_TERRAIN,OPAQUE;}
public interface FacingCameraMode {void setRotation(Quaternionf q,Camera c,float t);}
}
