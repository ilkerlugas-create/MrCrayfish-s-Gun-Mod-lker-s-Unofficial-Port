package net.minecraft.client.multiplayer;
import net.minecraft.world.level.block.state.BlockState;import net.minecraft.core.BlockPos;import net.minecraft.util.RandomSource;
public class ClientLevel implements net.minecraft.client.renderer.block.BlockAndTintGetter {
public BlockState state=new BlockState();public BlockState getBlockState(BlockPos p){return state;}public RandomSource getRandom(){return R;}
static final RandomSource R=new RandomSource(){public float nextFloat(){return .5F;}public int nextInt(int n){return 0;}};}
