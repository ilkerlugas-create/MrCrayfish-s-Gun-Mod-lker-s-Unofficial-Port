package net.minecraft.world.level.block;public class Blocks {public static final Block GRASS_BLOCK=new Block();}
