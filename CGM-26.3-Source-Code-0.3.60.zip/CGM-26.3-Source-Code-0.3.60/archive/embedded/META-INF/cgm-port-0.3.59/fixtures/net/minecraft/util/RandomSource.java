package net.minecraft.util;public interface RandomSource {float nextFloat();int nextInt(int bound);}
