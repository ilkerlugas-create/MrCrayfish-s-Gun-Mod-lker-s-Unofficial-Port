package net.minecraft.client.color.block;import net.minecraft.world.level.block.state.BlockState;public class BlockColors {public BlockTintSource getTintSource(BlockState s,int i){return null;}}
