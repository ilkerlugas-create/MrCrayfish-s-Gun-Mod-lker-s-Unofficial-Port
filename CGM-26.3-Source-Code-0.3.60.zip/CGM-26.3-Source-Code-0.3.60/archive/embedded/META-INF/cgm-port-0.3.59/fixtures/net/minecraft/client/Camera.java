package net.minecraft.client;import org.joml.Quaternionf;public class Camera {public final Quaternionf q=new Quaternionf(40);public Quaternionf rotation(){return q;}}
