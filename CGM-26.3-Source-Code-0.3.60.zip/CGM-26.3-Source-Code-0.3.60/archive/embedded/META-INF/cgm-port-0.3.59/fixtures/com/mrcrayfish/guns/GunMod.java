package com.mrcrayfish.guns; public class GunMod {public static boolean debugging; public static boolean isDebugging(){return debugging;}}
