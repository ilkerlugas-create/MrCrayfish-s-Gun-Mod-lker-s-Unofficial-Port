package com.mrcrayfish.guns.common;
import net.minecraft.nbt.CompoundTag;
public class Gun {public static int copies,creates,decodes; public int damage=3;
 public Gun copy(){copies++;Gun g=new Gun();g.damage=damage;return g;}
 public static Gun create(CompoundTag t){creates++;Gun g=new Gun();g.damage=0;g.deserializeNBT(t);return g;}
 public void deserializeNBT(CompoundTag t){decodes++;damage=t.getIntOr("Damage",damage);}
}
