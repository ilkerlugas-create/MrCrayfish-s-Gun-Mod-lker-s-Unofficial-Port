package com.mrcrayfish.guns.port;
import net.minecraft.nbt.CompoundTag;import net.minecraft.world.item.ItemStack;import net.minecraft.core.component.DataComponents;import net.minecraft.world.item.component.CustomData;
public final class StackReadCache {
 private static final ThreadLocal<java.util.IdentityHashMap<CustomData,CompoundTag>> C=ThreadLocal.withInitial(java.util.IdentityHashMap::new);
 public static CompoundTag read(ItemStack s){var d=s.getOrDefault(DataComponents.CUSTOM_DATA,CustomData.EMPTY);var c=C.get();if(c.size()>256)c.clear();return c.computeIfAbsent(d,k->k.copyTag());}
}
