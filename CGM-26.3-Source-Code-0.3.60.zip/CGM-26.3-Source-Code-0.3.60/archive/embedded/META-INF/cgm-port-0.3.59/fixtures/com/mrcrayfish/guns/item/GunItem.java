package com.mrcrayfish.guns.item;
import com.mrcrayfish.guns.common.Gun;import net.minecraft.nbt.CompoundTag;import net.minecraft.world.item.*;
public class GunItem extends Item {
 public GunItem(){super("weapon");}
 private java.util.WeakHashMap<CompoundTag,Gun> modifiedGunCache=new java.util.WeakHashMap<>();private Gun gun=new Gun();
 public Gun getGun(){return gun;} public void replaceBase(Gun g){gun=g;}
 public Gun getModifiedGun(ItemStack stack){throw new AssertionError("Install original/patched production method first");}
}
