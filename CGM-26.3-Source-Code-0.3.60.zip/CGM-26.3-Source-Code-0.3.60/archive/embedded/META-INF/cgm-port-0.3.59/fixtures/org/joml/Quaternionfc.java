package org.joml; public interface Quaternionfc {float x();}
