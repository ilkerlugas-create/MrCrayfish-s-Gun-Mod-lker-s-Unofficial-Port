"""Small API fixtures for bytecode regression tests; NEVER packaged as runtime classes."""
from pathlib import Path
import shutil
P = Path(__file__).resolve().parent.parent
src = P.parent/'input/META-INF/cgm-port-0.3.51/tests/fixtures'
dst = P/'fixtures'
selected = [
 'net/minecraft/nbt/CompoundTag.java', 'net/minecraft/world/item/ItemStack.java',
 'net/minecraft/world/item/Item.java', 'net/minecraft/world/item/Items.java',
 'net/minecraft/world/item/component/CustomData.java',
 'net/minecraft/core/component/DataComponentType.java', 'net/minecraft/core/component/DataComponents.java',
 'net/minecraft/server/MinecraftServer.java','net/minecraft/core/RegistryAccess.java',
 'net/minecraftforge/server/ServerLifecycleHooks.java',
 'com/mrcrayfish/guns/port/AttachmentData.java']
for name in selected:
 target=dst/name; target.parent.mkdir(parents=True, exist_ok=True);shutil.copyfile(src/name,target)
tag=dst/'net/minecraft/nbt/CompoundTag.java'
s=tag.read_text().replace(' public final Map', ' public boolean getBooleanOr(String k,boolean fallback){return data.get(k) instanceof Boolean b?b:fallback;} public void putBoolean(String k,boolean v){data.put(k,v);}\n public final Map')
tag.write_text(s)
files={
'com/mrcrayfish/guns/port/StackReadCache.java': '''package com.mrcrayfish.guns.port;
import net.minecraft.nbt.CompoundTag;import net.minecraft.world.item.ItemStack;import net.minecraft.core.component.DataComponents;import net.minecraft.world.item.component.CustomData;
public final class StackReadCache {
 private static final ThreadLocal<java.util.IdentityHashMap<CustomData,CompoundTag>> C=ThreadLocal.withInitial(java.util.IdentityHashMap::new);
 public static CompoundTag read(ItemStack s){var d=s.getOrDefault(DataComponents.CUSTOM_DATA,CustomData.EMPTY);var c=C.get();if(c.size()>256)c.clear();return c.computeIfAbsent(d,k->k.copyTag());}
}''',
'com/mrcrayfish/guns/common/Gun.java': '''package com.mrcrayfish.guns.common;
import net.minecraft.nbt.CompoundTag;
public class Gun {public static int copies,creates,decodes; public int damage=3;
 public Gun copy(){copies++;Gun g=new Gun();g.damage=damage;return g;}
 public static Gun create(CompoundTag t){creates++;Gun g=new Gun();g.damage=0;g.deserializeNBT(t);return g;}
 public void deserializeNBT(CompoundTag t){decodes++;damage=t.getIntOr("Damage",damage);}
}''',
'com/mrcrayfish/guns/item/GunItem.java': '''package com.mrcrayfish.guns.item;
import com.mrcrayfish.guns.common.Gun;import net.minecraft.nbt.CompoundTag;import net.minecraft.world.item.*;
public class GunItem extends Item {
 public GunItem(){super("weapon");}
 private java.util.WeakHashMap<CompoundTag,Gun> modifiedGunCache=new java.util.WeakHashMap<>();private Gun gun=new Gun();
 public Gun getGun(){return gun;} public void replaceBase(Gun g){gun=g;}
 public Gun getModifiedGun(ItemStack stack){throw new AssertionError("Install original/patched production method first");}
}''',
'com/mrcrayfish/guns/GunMod.java': 'package com.mrcrayfish.guns; public class GunMod {public static boolean debugging; public static boolean isDebugging(){return debugging;}}',
'com/mrcrayfish/guns/debug/Debug.java': 'package com.mrcrayfish.guns.debug; import com.mrcrayfish.guns.common.Gun;import com.mrcrayfish.guns.item.GunItem; public class Debug {public static Gun value=new Gun();public static Gun getGun(GunItem i){return value;}}',
'org/joml/Quaternionfc.java': 'package org.joml; public interface Quaternionfc {float x();}',
'org/joml/Quaternionf.java': 'package org.joml; public class Quaternionf implements Quaternionfc {public float x; public Quaternionf(){} public Quaternionf(float x){this.x=x;} public float x(){return x;}public Quaternionf set(Quaternionfc q){x=q.x();return this;}}',
'net/minecraft/core/Direction.java': 'package net.minecraft.core;import org.joml.Quaternionf;public enum Direction {DOWN,UP,NORTH,SOUTH,WEST,EAST; public static int rotations;public Quaternionf getRotation(){rotations++;return new Quaternionf(ordinal());}}',
'net/minecraft/core/BlockPos.java': 'package net.minecraft.core;public class BlockPos {}',
'net/minecraft/client/Camera.java': 'package net.minecraft.client;import org.joml.Quaternionf;public class Camera {public final Quaternionf q=new Quaternionf(40);public Quaternionf rotation(){return q;}}',
'net/minecraft/util/RandomSource.java': 'package net.minecraft.util;public interface RandomSource {float nextFloat();int nextInt(int bound);}',
'net/minecraft/client/renderer/texture/TextureAtlasSprite.java': 'package net.minecraft.client.renderer.texture;public class TextureAtlasSprite {public float getU0(){return 0;}public float getV0(){return 0;}public float getU1(){return 1;}public float getV1(){return 1;}}',
'net/minecraft/world/level/block/Block.java': 'package net.minecraft.world.level.block;public class Block {}',
'net/minecraft/world/level/block/Blocks.java': 'package net.minecraft.world.level.block;public class Blocks {public static final Block GRASS_BLOCK=new Block();}',
'net/minecraft/world/level/block/state/BlockState.java': 'package net.minecraft.world.level.block.state;import net.minecraft.world.level.block.Block;public class BlockState {public boolean air; public final Block b=new Block();public boolean isAir(){return air;}public Block getBlock(){return b;}}',
'net/minecraft/client/renderer/block/BlockAndTintGetter.java': 'package net.minecraft.client.renderer.block;public interface BlockAndTintGetter {}',
'net/minecraft/client/multiplayer/ClientLevel.java': '''package net.minecraft.client.multiplayer;
import net.minecraft.world.level.block.state.BlockState;import net.minecraft.core.BlockPos;import net.minecraft.util.RandomSource;
public class ClientLevel implements net.minecraft.client.renderer.block.BlockAndTintGetter {
public BlockState state=new BlockState();public BlockState getBlockState(BlockPos p){return state;}public RandomSource getRandom(){return R;}
static final RandomSource R=new RandomSource(){public float nextFloat(){return .5F;}public int nextInt(int n){return 0;}};}''',
'net/minecraft/client/color/block/BlockTintSource.java': 'package net.minecraft.client.color.block;import net.minecraft.world.level.block.state.BlockState;import net.minecraft.client.renderer.block.BlockAndTintGetter;import net.minecraft.core.BlockPos;public interface BlockTintSource {int colorAsTerrainParticle(BlockState s,BlockAndTintGetter l,BlockPos p);}',
'net/minecraft/client/color/block/BlockColors.java': 'package net.minecraft.client.color.block;import net.minecraft.world.level.block.state.BlockState;public class BlockColors {public BlockTintSource getTintSource(BlockState s,int i){return null;}}',
'net/minecraft/client/resources/model/sprite/Material.java': 'package net.minecraft.client.resources.model.sprite;import net.minecraft.client.renderer.texture.TextureAtlasSprite;public class Material {public static class Baked {public TextureAtlasSprite sprite(){return new TextureAtlasSprite();}}}',
'net/minecraft/client/renderer/block/BlockStateModelSet.java': 'package net.minecraft.client.renderer.block;import net.minecraft.world.level.block.state.BlockState;import net.minecraft.client.resources.model.sprite.Material;public class BlockStateModelSet {public Material.Baked getParticleMaterial(BlockState s){return new Material.Baked();}}',
'net/minecraft/client/resources/model/ModelManager.java': 'package net.minecraft.client.resources.model;import net.minecraft.client.renderer.block.BlockStateModelSet;public class ModelManager {public BlockStateModelSet getBlockStateModelSet(){return new BlockStateModelSet();}}',
'net/minecraft/client/Minecraft.java': 'package net.minecraft.client;import net.minecraft.client.resources.model.ModelManager;import net.minecraft.client.color.block.BlockColors;public class Minecraft {private static final Minecraft M=new Minecraft();public static Minecraft getInstance(){return M;}public ModelManager getModelManager(){return new ModelManager();}public BlockColors getBlockColors(){return new BlockColors();}}',
'net/minecraftforge/common/ForgeConfigSpec.java': 'package net.minecraftforge.common;public class ForgeConfigSpec {public static class IntValue {final int v;public IntValue(int v){this.v=v;}public Object get(){return v;}}public static class DoubleValue {final double v;public DoubleValue(double v){this.v=v;}public Object get(){return v;}}}',
'com/mrcrayfish/guns/Config.java': '''package com.mrcrayfish.guns;import net.minecraftforge.common.ForgeConfigSpec.*;
public class Config {public static final Client CLIENT=new Client();public static class Client {public final Particle particle=new Particle();}public static class Particle {public final IntValue bulletHoleLifeMin=new IntValue(150),bulletHoleLifeMax=new IntValue(200);public final DoubleValue bulletHoleFadeThreshold=new DoubleValue(.98);}}''',
'net/minecraft/client/particle/SpriteSet.java': 'package net.minecraft.client.particle;import net.minecraft.util.RandomSource;import net.minecraft.client.renderer.texture.TextureAtlasSprite;public interface SpriteSet {TextureAtlasSprite get(RandomSource r);}',
'net/minecraft/client/particle/SingleQuadParticle.java': '''package net.minecraft.client.particle;
import net.minecraft.client.multiplayer.ClientLevel;import net.minecraft.client.renderer.texture.TextureAtlasSprite;import net.minecraft.client.Camera;import org.joml.Quaternionf;import net.minecraft.util.RandomSource;
public class SingleQuadParticle {
public ClientLevel level;public RandomSource random;public TextureAtlasSprite sprite;public int lifetime,age;public boolean hasPhysics,onGround,removed;public float gravity,quadSize,alpha,rCol,gCol,bCol;public double xd,zd;
public SingleQuadParticle(ClientLevel l,double x,double y,double z,TextureAtlasSprite s){level=l;sprite=s;random=l.getRandom();}
public SingleQuadParticle(ClientLevel l,double x,double y,double z,double dx,double dy,double dz,TextureAtlasSprite s){this(l,x,y,z,s);}
public void setColor(float r,float g,float b){rCol=r;gCol=g;bCol=b;}
public void tick(){age++;if(age>=lifetime)remove();}public void remove(){removed=true;}
public enum Layer {TRANSLUCENT_TERRAIN,OPAQUE;}
public interface FacingCameraMode {void setRotation(Quaternionf q,Camera c,float t);}
}'''
}
for name,text in files.items():
 p=dst/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text+'\n')
print('Fixture sources prepared (test-only).')
