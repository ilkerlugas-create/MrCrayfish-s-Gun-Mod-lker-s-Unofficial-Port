package com.mrcrayfish.guns.port;

import java.lang.reflect.*;
import java.util.*;
import com.mrcrayfish.guns.GunMod;
import com.mrcrayfish.guns.common.Gun;
import com.mrcrayfish.guns.item.GunItem;
import com.mrcrayfish.guns.client.particle.*;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.*;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.Camera;
import net.minecraft.core.*;
import org.joml.Quaternionf;

public class Regression59 {
    static int checks;
    static void check(boolean ok,String s){checks++;if(!ok)throw new AssertionError(s);}
    static ItemStack weapon(GunItem item,int damage,int ammo,boolean custom) {
        CompoundTag root=new CompoundTag(),definition=new CompoundTag();
        definition.putInt("Damage",damage);root.put("Gun",definition);
        root.putInt("AmmoCount",ammo);root.putInt("Color",ammo*13);
        root.putString("CGMInstance",Integer.toString(ammo));root.putBoolean("Custom",custom);
        ItemStack stack=new ItemStack(item,1);stack.set(DataComponents.CUSTOM_DATA,new CustomData(root));return stack;
    }
    static Object state(Class<?> c) throws Exception {Field f=c.getDeclaredField("LOCAL");f.setAccessible(true);return ((ThreadLocal<?>)f.get(null)).get();}
    static int size(Object o,String name) throws Exception {Field f=o.getClass().getDeclaredField(name);f.setAccessible(true);return ((Map<?,?>)f.get(o)).size();}
    public static void main(String[] args) throws Exception {
        boolean fixed=Boolean.parseBoolean(args[0]);
        GunItem item=new GunItem();Gun.copies=Gun.creates=Gun.decodes=0;
        for(int i=0;i<10000;i++)check(item.getModifiedGun(weapon(item,9,i,false)).damage==9,"definition result after ammo/paint change");
        check(Gun.copies==(fixed?1:10000),"gun construction count: "+Gun.copies);
        System.out.println("Gun reconstruction across 10,000 ammo/paint/instance changes: "+Gun.copies);
        for(int i=0;i<100;i++){
            int damage=i%2==0?5:7;
            check(item.getModifiedGun(weapon(item,damage,i,false)).damage==damage,"interleaved custom weapons");
        }
        ItemStack custom=weapon(item,18,0,true);check(item.getModifiedGun(custom).damage==18,"Custom=true definition");
        ItemStack ordinary=new ItemStack(item,1);check(item.getModifiedGun(ordinary)==item.getGun(),"ordinary default weapon");
        GunMod.debugging=true;check(item.getModifiedGun(ordinary)==com.mrcrayfish.guns.debug.Debug.value,"debug behavior");GunMod.debugging=false;
        if(fixed){
            CompoundTag root=new CompoundTag();root.put("Gun",new CompoundTag());
            ItemStack inherited=new ItemStack(item,1);inherited.set(DataComponents.CUSTOM_DATA,new CustomData(root));
            Gun old=item.getModifiedGun(inherited);Gun base=new Gun();base.damage=67;item.replaceBase(base);
            check(item.getModifiedGun(inherited).damage==67&&item.getModifiedGun(inherited)!=old,"data reload invalidation");
            for(int i=0;i<1000;i++)item.getModifiedGun(weapon(item,i,0,false));
            check(size(state(GunDefinitionCache.class),"definitions")==128,"bounded gun cache");
            ItemStack shared=weapon(item,29,0,false);Gun main=item.getModifiedGun(shared);Gun[] remote=new Gun[1];
            Thread thread=new Thread(()->remote[0]=item.getModifiedGun(shared));thread.start();thread.join();
            check(remote[0]!=main&&remote[0].damage==main.damage,"thread isolation");
        }

        ClientLevel level=new ClientLevel();Camera camera=new Camera();Quaternionf output=new Quaternionf();
        int generated=0,callbacks=0;
        for(Direction direction:Direction.values()){
            BulletHoleParticle p=new BulletHoleParticle(level,0,0,0,direction,new BlockPos());
            check(p.lifetime==175,"original bullet hole lifetime");
            var prev=p.getFacingCameraMode();int before=Direction.rotations;
            for(int i=0;i<10000;i++){
                var mode=p.getFacingCameraMode();if(mode!=prev)callbacks++;prev=mode;
                mode.setRotation(output,camera,.5F);
                check(output.x()==direction.ordinal(),"bullet hole orientation");output.x=900;
            }
            generated+=Direction.rotations-before;
            level.state.air=true;p.tick();check(p.removed,"bullet hole removed after block destroyed");level.state.air=false;
        }
        check(generated==(fixed?0:60000),"bullet hole quaternion allocation count");
        check(callbacks==(fixed?0:60000),"bullet hole facing allocation count");
        BloodParticle blood=new BloodParticle(level,0,0,0,r->new net.minecraft.client.renderer.texture.TextureAtlasSprite());
        var prev=blood.getFacingCameraMode();int bloodCallbacks=0,before=Direction.rotations;
        for(int i=0;i<20000;i++){
            blood.onGround=i%2==0;camera.q.x=40+i;
            var mode=blood.getFacingCameraMode();if(mode!=prev)bloodCallbacks++;prev=mode;
            mode.setRotation(output,camera,.5F);
            check(output.x()==(blood.onGround?Direction.NORTH.ordinal():camera.q.x),"ground/air blood rotation");
        }
        check(bloodCallbacks==(fixed?0:20000),"blood facing allocation count");
        check(Direction.rotations-before==(fixed?0:10000),"blood quaternion allocation count");
        System.out.println("Particle render loop (80,000 draws): facing objects="+(callbacks+bloodCallbacks)+", direction quaternions="+(generated+Direction.rotations-before));

        CompoundTag bad=new CompoundTag();bad.putString("id","bad");Object context=new Object();long now=1_000_000_000L;
        AttachmentData.ready=false;AttachmentData.decodes=0;
        for(int i=0;i<10000;i++){
            ItemStack out=fixed?AttachmentDecodeBackoff.readAt(bad,context,now+i):AttachmentData.read(bad);
            check(out.isEmpty(),"failed data stays empty");
        }
        check(AttachmentData.decodes==(fixed?1:10000),"decode storm prevention");
        System.out.println("Invalid attachment codec attempts across 10,000 reads: "+AttachmentData.decodes);
        if(fixed){
            AttachmentDecodeBackoff.readAt(bad.copy(),context,now+10_000);
            check(AttachmentData.decodes==1,"equivalent snapshot negative cache");
            AttachmentDecodeBackoff.readAt(bad,context,now+250_000_000L);
            check(AttachmentData.decodes==2,"timed retry");
            Object secondContext=new Object();AttachmentDecodeBackoff.readAt(bad,secondContext,now+250_000_001L);
            check(AttachmentData.decodes==3,"registry reload immediate retry");
            AttachmentData.ready=true;AttachmentData.REGISTRY.put("bad",new Item("valid"));
            check(!AttachmentDecodeBackoff.readAt(bad,secondContext,now+500_000_001L).isEmpty(),"registry availability recovers");
            check(!AttachmentDecodeBackoff.readAt(bad,secondContext,now+500_000_002L).isEmpty(),"successful values are not negatively cached");
            AttachmentData.ready=false;
            for(int i=0;i<1000;i++){CompoundTag t=new CompoundTag();t.putString("id","bad"+i);AttachmentDecodeBackoff.readAt(t,secondContext,now);}
            check(size(state(AttachmentDecodeBackoff.class),"failures")==128,"bounded failure cache");
            check(AttachmentDecodeBackoff.readAt(null,context,now).isEmpty(),"null attachment");
        }
        System.out.println("PASS "+(fixed?"after":"before")+": "+checks+" checks; API fixtures, not an in-game FPS measurement.");
    }
}
