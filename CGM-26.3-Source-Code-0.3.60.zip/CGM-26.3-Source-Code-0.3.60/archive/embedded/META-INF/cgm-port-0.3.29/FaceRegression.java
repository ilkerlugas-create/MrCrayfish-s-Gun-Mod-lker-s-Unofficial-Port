import java.util.*;import java.lang.reflect.*;
import com.mojang.blaze3d.vertex.*;
import net.minecraft.client.resources.model.geometry.BakedQuad;
import com.mrcrayfish.framework.api.client.model.renderer.StandaloneModelRenderer;
public class FaceRegression {
 static BakedQuad quad(int tint){return new BakedQuad(null,null,null,null,0,0,0,0,null,new BakedQuad.MaterialInfo(null,null,null,null,null,tint,null,0));}
 public static void main(String[] args)throws Exception {
  List<Integer> colors=new ArrayList<>();
  VertexConsumer consumer=(VertexConsumer)Proxy.newProxyInstance(FaceRegression.class.getClassLoader(),new Class[]{VertexConsumer.class},(p,m,a)->{
   if(m.getName().equals("putBakedQuad"))colors.add(((QuadInstance)a[2]).getColor(0));return p;
  });
  Method m=StandaloneModelRenderer.class.getDeclaredMethod("putQuads",PoseStack.Pose.class,VertexConsumer.class,float.class,float.class,float.class,List.class,int.class,int.class);m.setAccessible(true);
  m.invoke(null,null,consumer,1F,0F,0F,List.of(quad(0),quad(-1),quad(0),quad(-1)),15728880,0);
  if(!colors.equals(List.of(0xFFFF0000,-1,0xFFFF0000,-1)))throw new AssertionError("Lost faces or incorrect tint: "+colors);
  System.out.println("PASS: all 4 faces submitted; paintable faces red, unpainted faces white; real Minecraft quad API");
 }
}
