import zipfile,json,math,itertools,copy,hashlib
from pathlib import Path
base=Path('upload/CGM-26.3-Forge66.0.2-0.3.28-3D-BOYALI-TEZGAH.jar');old=Path('upload/CGM-26.3-Forge66.0.2-0.3.24-R-EKLENTI-F5.jar');out=Path('output/CGM-26.3-Forge66.0.2-0.3.29-ESKI-RELOAD-3D-BOYA-FIX.jar')
updates={p.relative_to('work29/classes').as_posix():p.read_bytes() for p in Path('work29/classes').rglob('*.class')}
def enc(d):return (json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode()
def vertices(e):
 for p in itertools.product(*zip(e['from'],e['to'])):
  p=list(p);rot=e.get('rotation');
  if rot:
   axis='xyz'.index(rot['axis']);u,v=[a for a in range(3) if a!=axis];t=math.radians(rot['angle']);o=rot['origin'];a=p[u]-o[u];b=p[v]-o[v]
   if axis==1:t=-t
   r=1/math.cos(t) if rot.get('rescale') else 1
   p[u]=o[u]+r*(a*math.cos(t)-b*math.sin(t));p[v]=o[v]+r*(a*math.sin(t)+b*math.cos(t))
  yield p
fits={}
with zipfile.ZipFile(base) as z,zipfile.ZipFile(old) as orig:
 for cls in ['client/handler/GunRenderingHandler','client/render/pose/OneHandedPose','client/render/pose/TwoHandedPose','util/GunEnchantmentHelper']:
  n=f'com/mrcrayfish/guns/{cls}.class';updates[n]=orig.read(n)
 for n in z.namelist():
  if n.startswith('data/cgm/guns/') and n.endswith('.json'):
   d=json.loads(z.read(n));o=json.loads(orig.read(n));d['general']['reloadAmount']=o['general'].get('reloadAmount',1);updates[n]=enc(d)
 guns=['pistol','shotgun','rifle','grenade_launcher','bazooka','mini_gun','assault_rifle','machine_pistol','heavy_rifle']
 for gun in guns:
  n=f'assets/cgm/models/workbench_preview/{gun}.json';d=json.loads(z.read(n));points=[v for e in d['elements'] for v in vertices(e)]
  center=[(min(p[a] for p in points)+max(p[a] for p in points))/2 for a in range(3)];shift=[8-c for c in center]
  for e in d['elements']:
   for k in ['from','to']:e[k]=[v+shift[a] for a,v in enumerate(e[k])]
   if 'rotation' in e:e['rotation']['origin']=[v+shift[a] for a,v in enumerate(e['rotation']['origin'])]
  radius=max(math.hypot(p[0]-center[0],p[2]-center[2]) for p in points);halfHeight=max(abs(p[1]-center[1]) for p in points)
  width=2*radius;height=2*(halfHeight*math.cos(math.radians(12))+radius*math.sin(math.radians(12)))
  scale=min(132/(3.6*max(width,.1)),40/(3.6*max(height,.1)))
  d['display']={'gui':{'rotation':[12,100,0],'translation':[0,0,0],'scale':[scale]*3}};d['gui_light']='side';updates[n]=enc(d)
  fits[gun]={'elements':len(d['elements']),'full_rotation_width_px':width*scale*3.6,'full_rotation_height_px':height*scale*3.6}
  assert fits[gun]['full_rotation_width_px']<=132.001 and fits[gun]['full_rotation_height_px']<=40.001
 mixins=json.loads(z.read('cgm.mixins.json'))
 for name in ['client.PreviewLayersAccessor','client.WorkbenchPreviewMixin']:
  if name not in mixins['client']:mixins['client'].append(name)
 updates['cgm.mixins.json']=enc(mixins)
 for n in ['META-INF/MANIFEST.MF','META-INF/mods.toml']:
  import re
  updates[n]=re.sub(rb'port-0\.3\.\d+',b'port-0.3.29',z.read(n))
 notes='''0.3.29 — Eski reload, 3D tezgâh, boya ve doku çizimi
Temel: Kullanıcının yüklediği 0.3.28 JAR.
- Eski reload hareketi, hızı ve dolum miktarları geri alındı.
- Yeni sürümdeki envanter/silah örneği, ateş, tezgâh ve mühimmat düzeltmeleri korundu.
- Boyanabilir ilk yüzeyden sonra kalan yüzeylerin atlanması düzeltildi.
- Minigun gövdesi/namluları ve bombaatar gövdesi/tamburu da boya rengini alır.
- Boyanmayan metal/detay yüzeyleri özgün doku rengini korur.
- Tezgâh önizlemesi gerçek 3D model katmanlarını kendi ekseninde döndürür.
- Dokuz silahın önizlemesi, tüm dönüş açılarında alana sığacak şekilde merkezlendi.
- Orijinal PNG dokuları değiştirilmedi; bozuk görüntüye neden olan çizim düzeltildi.

Eski CGM JAR'ını mods klasöründen çıkarıp bunu koy. Framework dahildir.
Oyun açıksa tamamen kapatıp yeniden başlat. İstemci ve sunucuda aynı JAR'ı kullan.
Kod, API bağlantıları, yüzey/boya ve model sınırları test edildi. Oyun içi görsel test yapılmadı.
'''
 updates['CGM-0.3.29-OKU.txt']=notes.encode()
 for p in Path('work29/src').rglob('*.java'):updates['META-INF/cgm-port-0.3.29/src/'+p.relative_to('work29/src').as_posix()]=p.read_bytes()
 for p in [Path('work29/Patch29.java'),Path('work29/Verify29.java'),Path('work29/package29.py'),Path('work29/tests/FaceRegression.java'),Path('work29/linkage.txt')]:updates['META-INF/cgm-port-0.3.29/'+p.name]=p.read_bytes()
 updates['META-INF/cgm-port-0.3.29/validation.json']=enc({'base_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),'preview_bounds':fits,'face_regression':'PASS: 4/4 faces, red/white/red/white, actual Minecraft quad API','api_linkage':'119 methods; 0 unresolved links','in_game_test':False})
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as w:
  for n in z.namelist():w.writestr(n,updates.pop(n,z.read(n)))
  for n,b in updates.items():w.writestr(n,b)
with zipfile.ZipFile(out) as result,zipfile.ZipFile(base) as original,zipfile.ZipFile(old) as legacy:
 assert result.testzip() is None
 assert set(original.namelist())<=set(result.namelist())
 for n in original.namelist():
  if n.startswith('assets/cgm/textures/'):assert original.read(n)==result.read(n)
 for cls in ['client/handler/GunRenderingHandler','client/render/pose/OneHandedPose','client/render/pose/TwoHandedPose','util/GunEnchantmentHelper']:
  n=f'com/mrcrayfish/guns/{cls}.class';assert result.read(n)==legacy.read(n)
 for cls in ['common/ReloadTracker','port/WeaponInstance','client/handler/ReloadHandler','common/network/ServerPlayHandler','client/screen/WorkbenchScreen','item/IColored','port/DyeBridge']:
  n=f'com/mrcrayfish/guns/{cls}.class';assert result.read(n)==original.read(n)
 for n in result.namelist():
  if n.endswith('.json'):json.loads(result.read(n))
print('PASS archive, preserved latest gameplay/workbench and PNG textures, exact legacy reload renderers/timing, 9 fitted 3D models')
print(out.resolve());print(hashlib.sha256(out.read_bytes()).hexdigest())
