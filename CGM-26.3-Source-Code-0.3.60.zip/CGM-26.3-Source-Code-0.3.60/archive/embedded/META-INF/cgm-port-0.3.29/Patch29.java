import java.nio.file.*;import java.util.*;import java.util.jar.*;import org.objectweb.asm.*;import org.objectweb.asm.tree.*;import org.objectweb.asm.tree.analysis.*;
public class Patch29 implements Opcodes {
 public static void main(String[] args)throws Exception {
  int calls=0;
  try(JarFile latest=new JarFile(args[0]);JarFile original=new JarFile(args[1])){
   for(String path:List.of("client/handler/GunRenderingHandler","client/render/pose/OneHandedPose","client/render/pose/TwoHandedPose","util/GunEnchantmentHelper","client/render/gun/model/SimpleModel","client/render/gun/model/MiniGunModel","client/render/gun/model/GrenadeLauncherModel")){
    String n="com/mrcrayfish/guns/"+path;JarFile source=path.endsWith("MiniGunModel")||path.endsWith("GrenadeLauncherModel")?latest:original;
    ClassNode c=new ClassNode();new ClassReader(source.getInputStream(source.getJarEntry(n+".class"))).accept(c,0);
    if(path.contains("/model/"))for(MethodNode m:c.methods)for(var i:m.instructions.toArray())if(i instanceof MethodInsnNode a&&a.owner.equals("com/mrcrayfish/guns/client/util/SubmitRenderUtil")&&a.name.equals("submitStandalone")){
     m.instructions.insertBefore(i,new VarInsnNode(ALOAD,3));a.owner="com/mrcrayfish/guns/port/ColoredModel";a.name="draw";a.desc=a.desc.replace(")V","Lnet/minecraft/world/item/ItemStack;)V");calls++;
    }
    ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);Path p=Path.of(args[2],n+".class");Files.createDirectories(p.getParent());Files.write(p,w.toByteArray());
   }
  }
  if(calls!=5)throw new AssertionError("Expected five body/moving-part color calls: "+calls);
  int methods=0;
  try(var files=Files.walk(Path.of(args[2]))){for(Path p:files.filter(p->p.toString().endsWith(".class")).toList()){ClassNode c=new ClassNode();new ClassReader(Files.readAllBytes(p)).accept(c,0);for(MethodNode m:c.methods)if((m.access&(ACC_ABSTRACT|ACC_NATIVE))==0){new Analyzer<>(new BasicVerifier()).analyze(c.name,m);methods++;}}}
  System.out.println("PASS: old reload render hooks restored; all five gun render paths tinted; verified "+methods+" methods");
 }
}
