package com.mrcrayfish.guns.mixin.client;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.client.renderer.item.ItemModelResolver;
import net.minecraft.client.renderer.item.ItemStackRenderState;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.ItemOwner;
@Mixin(value=ItemModelResolver.class,remap=false)
public abstract class WorkbenchPreviewMixin {
 @Inject(method="updateForTopItem(Lnet/minecraft/client/renderer/item/ItemStackRenderState;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemDisplayContext;Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/ItemOwner;I)V",at=@At("RETURN"))
 private void cgmPreview(ItemStackRenderState state,ItemStack stack,ItemDisplayContext context,Level world,ItemOwner owner,int seed,CallbackInfo ci){
  if(context==ItemDisplayContext.GUI)com.mrcrayfish.guns.port.WorkbenchPreview.animate(state,stack);
 }
}
