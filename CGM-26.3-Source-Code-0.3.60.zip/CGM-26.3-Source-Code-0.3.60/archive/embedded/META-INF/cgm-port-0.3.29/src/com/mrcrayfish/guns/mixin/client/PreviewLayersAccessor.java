package com.mrcrayfish.guns.mixin.client;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import net.minecraft.client.renderer.item.ItemStackRenderState;
@Mixin(value=ItemStackRenderState.class,remap=false)
public interface PreviewLayersAccessor {
 @Accessor("layers") ItemStackRenderState.LayerRenderState[] cgmPreviewLayers();
 @Accessor("activeLayerCount") int cgmPreviewLayerCount();
}
