import com.google.gson.JsonParser;
import com.mojang.serialization.JsonOps;
import net.minecraft.client.color.item.Dye;
public class TintCodecTest {
 public static void main(String[] args) {
  for(int c:new int[]{16777215,-1}) {
   Dye dye=Dye.MAP_CODEC.codec().parse(JsonOps.INSTANCE,JsonParser.parseString("{\"default\":"+c+"}")).getOrThrow();
   if(dye.defaultColor()!=c)throw new AssertionError("Codec changed color");
   System.out.printf("default=%d alpha=%d%n",c,dye.defaultColor()>>>24);
  }
 }
}
