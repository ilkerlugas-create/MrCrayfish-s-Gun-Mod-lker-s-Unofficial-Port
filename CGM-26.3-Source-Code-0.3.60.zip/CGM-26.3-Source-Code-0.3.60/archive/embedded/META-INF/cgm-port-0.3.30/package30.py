import json,zipfile,re,hashlib
from pathlib import Path
base=Path('output/CGM-26.3-Forge66.0.2-0.3.29-ESKI-RELOAD-3D-BOYA-FIX.jar')
out=Path('output/CGM-26.3-Forge66.0.2-0.3.30-DOKU-3D-TEZGAH-FIX.jar')
updates={}; changed=[]
def fix(node):
 count=0
 if isinstance(node,dict):
  if node.get('type')=='minecraft:dye' and 'default' in node:
   node['default']=-1;count+=1
  for v in node.values():count+=fix(v)
 elif isinstance(node,list):
  for v in node:count+=fix(v)
 return count
with zipfile.ZipFile(base) as z:
 for n in z.namelist():
  if n.startswith('assets/cgm/items/') and n.endswith('.json'):
   d=json.loads(z.read(n));count=fix(d)
   if count:
    updates[n]=(json.dumps(d,indent=2)+'\n').encode();changed.append(n)
 for n in ['META-INF/MANIFEST.MF','META-INF/mods.toml']:
  updates[n]=re.sub(rb'port-0\.3\.29',b'port-0.3.30',z.read(n))
 updates['CGM-0.3.30-OKU.txt']='''0.3.30 — Silah dokuları ve 3D tezgâh görünürlüğü
Boyanmamış silahların varsayılan boya rengi saydam beyazdan opak beyaza düzeltildi.
Bu hata envanterde ve 3D tezgâh önizlemesinde gövde yüzeylerini gizliyordu.
Orijinal PNG dokuları, silah geometrisi, boya desteği ve önceki oyun mekanikleri korundu.
Eski CGM JAR dosyasını mods klasöründen çıkarıp bu dosyayı koy ve oyunu yeniden başlat.
İstemci ve sunucuda aynı sürümü kullan. Framework dahildir.
Gerçek Minecraft renk codec testi ve paket kontrolleri geçti. Oyun içi görsel test yapılmadı.
'''.encode()
 for p in Path('work30').glob('*'):
  if p.suffix in ['.py','.java']:updates['META-INF/cgm-port-0.3.30/'+p.name]=p.read_bytes()
 updates['META-INF/cgm-port-0.3.30/validation.json']=json.dumps({'changed_items':changed,'original_alpha':0,'fixed_alpha':255,'in_game_test':False},indent=2).encode()
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as w:
  for n in z.namelist():w.writestr(n,updates.pop(n,z.read(n)))
  for n,b in updates.items():w.writestr(n,b)
with zipfile.ZipFile(base) as a,zipfile.ZipFile(out) as b:
 assert b.testzip() is None
 for n in a.namelist():
  if n.endswith('.class') or n.startswith('assets/cgm/textures/') or n.startswith('assets/cgm/models/') or n.startswith('data/'):
   assert a.read(n)==b.read(n),n
 assert len(changed)==18,changed
 for n in b.namelist():
  if n.endswith('.json'):json.loads(b.read(n))
print('PASS: 18 item definitions fixed (9 guns + 9 previews); all classes, textures, geometry and gameplay data preserved')
print(out.resolve());print(hashlib.sha256(out.read_bytes()).hexdigest())
