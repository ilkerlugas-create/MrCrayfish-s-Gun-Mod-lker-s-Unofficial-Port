from pathlib import Path
import shutil,subprocess
root=Path('work28/testsrc')
for rel in ['net/minecraft/nbt/CompoundTag.java','net/minecraft/world/item/Item.java','com/mrcrayfish/guns/util/StackData.java']:
 p=root/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(Path('work27/testsrc')/rel,p)
p=root/'net/minecraft/nbt/CompoundTag.java';p.write_text(p.read_text().replace('public CompoundTag copy()', 'public boolean contains(String k){return map.containsKey(k);}public CompoundTag copy()'))
sources={
'net/minecraft/core/component/DataComponentType':'public class DataComponentType<T>{}',
'net/minecraft/core/component/DataComponents':'public class DataComponents{public static final DataComponentType<net.minecraft.world.item.component.DyedItemColor> DYED_COLOR=new DataComponentType<>();}',
'net/minecraft/world/item/component/DyedItemColor':'public record DyedItemColor(int rgb){}',
'net/minecraft/core/NonNullList':'public class NonNullList<T> extends java.util.ArrayList<T>{}',
'net/minecraft/world/item/ItemStack':'''public class ItemStack{public static final ItemStack EMPTY=new ItemStack(new Item());public int count=3;public net.minecraft.nbt.CompoundTag tag=new net.minecraft.nbt.CompoundTag();public java.util.Map<Object,Object> components=new java.util.HashMap<>();public ItemStack(Item i){}public <T>T set(net.minecraft.core.component.DataComponentType<T> t,T v){return (T)components.put(t,v);}public <T>T remove(net.minecraft.core.component.DataComponentType<T> t){return (T)components.remove(t);}public void shrink(int n){count-=n;}public boolean isEmpty(){return count<=0;}}'''
}
for n,b in sources.items():
 p=root/(n+'.java');p.parent.mkdir(parents=True,exist_ok=True);p.write_text('package '+n.rsplit('/',1)[0].replace('/','.')+';'+b)
(root/'DyeTest.java').write_text('''import com.mrcrayfish.guns.port.DyeBridge;import net.minecraft.world.item.*;import net.minecraft.core.component.DataComponents;import net.minecraft.world.item.component.DyedItemColor;
public class DyeTest{public static void main(String[] a){var one=new ItemStack(new Item());var two=new ItemStack(new Item());for(int rgb:new int[]{0,0xFFFFFF,0xB02E26,0x3C44AA,0x5E7C16,0xF9801D,0xC74EBD,0x3AB3DA,0xFED83D,0x80C71F,0xF38BAA,0x474F52,0x9D9D97,0x169C9C,0x8932B8,0x835432}){one.tag.putInt("Color",rgb);DyeBridge.sync(one);if(((DyedItemColor)one.components.get(DataComponents.DYED_COLOR)).rgb()!=rgb||DyeBridge.color(one,0)!=(0xFF000000|rgb))throw new AssertionError();}if(!two.components.isEmpty())throw new AssertionError();one.tag.map.remove("Color");DyeBridge.sync(one);if(one.components.containsKey(DataComponents.DYED_COLOR)||DyeBridge.color(one,0)!=-1)throw new AssertionError();var list=new net.minecraft.core.NonNullList<ItemStack>();list.add(two);DyeBridge.consume(list,0,null);if(two.count!=2)throw new AssertionError();DyeBridge.consume(list,0,null);DyeBridge.consume(list,0,null);if(list.get(0)!=ItemStack.EMPTY)throw new AssertionError();System.out.println("PASS actual DyeBridge bytecode with stubs: 16 RGB colors, alpha, reset, independent stacks, one-dye consumption");}}''')
subprocess.run(['java','-m','jdk.compiler/com.sun.tools.javac.Main','-cp','work28/classes','-d','work28/testclasses',*map(str,root.rglob('*.java'))],check=True)
subprocess.run(['java','-cp','work28/testclasses:work28/classes','DyeTest'],check=True)
