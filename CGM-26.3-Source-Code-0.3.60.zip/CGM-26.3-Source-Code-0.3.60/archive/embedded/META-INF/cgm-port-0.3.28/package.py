from pathlib import Path
import zipfile,json,copy,math,itertools,hashlib
src=Path('output/CGM-26.3-Forge66.0.2-0.3.27-RELOAD-ENVANTER-TEZGAH-FIX.jar')
out=Path('output/CGM-26.3-Forge66.0.2-0.3.28-3D-BOYALI-TEZGAH.jar')
updates={str(p.relative_to('work28/classes')):p.read_bytes() for p in Path('work28/classes').rglob('*.class')}
guns=['pistol','shotgun','rifle','grenade_launcher','bazooka','mini_gun','assault_rifle','machine_pistol','heavy_rifle']
def encode(d):return (json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode()
with zipfile.ZipFile(src) as z:
 def model(name):
  namespace,path=name.split(':');d=json.loads(z.read(f'assets/{namespace}/models/{path}.json'))
  parent=d.pop('parent',None)
  base=model(parent) if parent and parent.startswith('cgm:') else {}
  base['textures']={**base.get('textures',{}),**d.get('textures',{})};base.update({k:v for k,v in d.items() if k!='textures'});return base
 for gun in guns:
  name=f'assets/cgm/items/{gun}.json';item=json.loads(z.read(name));tints=item['model'].get('tints',[])
  item['model']['tints']=[{'type':'minecraft:dye','default':16777215} for _ in tints] or [{'type':'minecraft:dye','default':16777215}]
  updates[name]=encode(item)
  geo=model('cgm:item/'+gun);els=geo['elements'];assert els
  lo=[min(e['from'][a] for e in els) for a in range(3)];hi=[max(e['to'][a] for e in els) for a in range(3)]
  offset=[8-(lo[a]+hi[a])/2 for a in range(3)]
  for e in els:
   for k in ['from','to']:e[k]=[round(e[k][a]+offset[a],6) for a in range(3)]
   if 'rotation' in e:e['rotation']['origin']=[round(e['rotation']['origin'][a]+offset[a],6) for a in range(3)]
  # Side-biased perspective: visible muzzle depth, upright weapon, consistent fit.
  ry=math.radians(100);rx=math.radians(10)
  corners=[]
  for v in itertools.product(*[[-(hi[a]-lo[a])/2,(hi[a]-lo[a])/2] for a in range(3)]):
   x,y,zz=v;y,zz=y*math.cos(rx)-zz*math.sin(rx),y*math.sin(rx)+zz*math.cos(rx)
   x,zz=x*math.cos(ry)+zz*math.sin(ry),-x*math.sin(ry)+zz*math.cos(ry);corners.append((x,y))
  width=max(x for x,y in corners)-min(x for x,y in corners);height=max(y for x,y in corners)-min(y for x,y in corners)
  scale=round(min(96/(3.6*width),36/(3.6*height)),5)
  geo['display']={'gui':{'rotation':[10,100,0],'translation':[0,0,0],'scale':[scale]*3}}
  geo['gui_light']='side';geo.pop('overrides',None)
  updates[f'assets/cgm/models/workbench_preview/{gun}.json']=encode(geo)
  preview=copy.deepcopy(item);preview['model']['model']='cgm:workbench_preview/'+gun
  updates[f'assets/cgm/items/workbench_preview/{gun}.json']=encode(preview)
  assert width*scale*3.6<=96.001 and height*scale*3.6<=36.001
  print(gun, len(els),'3D elements; fitted preview',round(width*scale*3.6,1),round(height*scale*3.6,1))
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as o:
  for e in z.infolist():o.writestr(e,updates.pop(e.filename,z.read(e)))
  for n,b in updates.items():o.writestr(n,b)
  for p in Path('work28/src').rglob('*.java'):o.writestr('META-INF/cgm-port-0.3.28/src/'+str(p.relative_to('work28/src')),p.read_bytes())
  for p in ['work28/Patch28.java','work28/package.py']:o.writestr('META-INF/cgm-port-0.3.28/'+Path(p).name,Path(p).read_bytes())
  o.writestr('META-INF/cgm-port-0.3.28/NOTES.txt','Preview-only item model on a copy: nine original 3D weapon geometries, centered and fitted side perspective. Original inventory and held transforms preserved. Dye Color bridged to DYED_COLOR; item tint sources use minecraft:dye; SimpleModel and reload body/magazine render with saved RGB. Crafting uses the same diffuse dye RGB as preview and consumes one dye instead of deleting the dye stack. Prior fixes retained. ASM BasicVerifier: 79 methods. Model bounds and JSON verified. No in-game test performed.\n')
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 for n in z.namelist():
  if n.endswith('.json'):json.loads(z.read(n))
print('PASS archive and JSON validation',out.stat().st_size,hashlib.sha256(out.read_bytes()).hexdigest())
