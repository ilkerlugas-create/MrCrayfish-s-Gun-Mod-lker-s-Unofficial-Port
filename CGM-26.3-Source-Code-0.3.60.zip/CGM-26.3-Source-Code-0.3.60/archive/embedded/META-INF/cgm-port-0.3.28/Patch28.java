import java.nio.file.*;import java.util.*;import java.util.jar.*;
import org.objectweb.asm.*;import org.objectweb.asm.tree.*;import org.objectweb.asm.tree.analysis.*;
public class Patch28 implements Opcodes{
 static final String P="com/mrcrayfish/guns/port/";
 public static void main(String[] args)throws Exception{
 int changes=0;
 try(JarFile jar=new JarFile(args[0])){
 for(String name:List.of("com/mrcrayfish/guns/item/IColored","com/mrcrayfish/guns/common/network/ServerPlayHandler","com/mrcrayfish/guns/client/util/RenderUtil","com/mrcrayfish/guns/client/render/gun/model/SimpleModel",P+"ReloadAnimation","com/mrcrayfish/guns/client/screen/WorkbenchScreen")){
 ClassNode c=new ClassNode();new ClassReader(jar.getInputStream(jar.getJarEntry(name+".class"))).accept(c,0);
 for(MethodNode m:c.methods){
 if(name.endsWith("IColored")&&(m.name.equals("setColor")||m.name.equals("removeColor")))for(var n:m.instructions.toArray())if(n.getOpcode()==RETURN){InsnList l=new InsnList();l.add(new VarInsnNode(ALOAD,1));l.add(new MethodInsnNode(INVOKESTATIC,P+"DyeBridge","sync","(Lnet/minecraft/world/item/ItemStack;)V",false));m.instructions.insertBefore(n,l);changes++;}
 if(name.endsWith("RenderUtil")&&m.name.equals("getItemStackColor")){
 m.instructions.clear();m.tryCatchBlocks.clear();if(m.localVariables!=null)m.localVariables.clear();m.instructions.add(new VarInsnNode(ALOAD,0));m.instructions.add(new VarInsnNode(ILOAD,1));m.instructions.add(new MethodInsnNode(INVOKESTATIC,P+"DyeBridge","color",m.desc,false));m.instructions.add(new InsnNode(IRETURN));changes++;}
 for(var n:m.instructions.toArray())if(n instanceof MethodInsnNode a){
 if(m.name.equals("handleCraft")&&a.name.equals("getTextColor")){a.name="getTextureDiffuseColor";changes++;}
 if(m.name.equals("handleCraft")&&a.owner.equals("net/minecraft/core/NonNullList")&&a.name.equals("set")){
 m.instructions.set(n,new MethodInsnNode(INVOKESTATIC,P+"DyeBridge","consume","(Lnet/minecraft/core/NonNullList;ILjava/lang/Object;)Ljava/lang/Object;",false));changes++;}
 if(a.name.equals("submitStandalone")&&a.owner.equals("com/mrcrayfish/guns/client/util/SubmitRenderUtil")){
 int slot=name.endsWith("SimpleModel")?3:2;
 m.instructions.insertBefore(n,new VarInsnNode(ALOAD,slot));a.owner=P+"ColoredModel";a.name="draw";a.desc=a.desc.replace(")V","Lnet/minecraft/world/item/ItemStack;)V");changes++;}
 if(name.endsWith("WorkbenchScreen")&&m.name.equals("extractBackground")&&a.name.equals("item")&&a.owner.equals("net/minecraft/client/gui/GuiGraphicsExtractor")){
 // Only the centered preview is called with literal -8, -8.
 AbstractInsnNode b=n.getPrevious(),d=b.getPrevious();
 if(b instanceof IntInsnNode bi&&bi.operand==-8&&d instanceof IntInsnNode di&&di.operand==-8){
 m.instructions.insertBefore(d,new MethodInsnNode(INVOKESTATIC,P+"WorkbenchPreview","create","(Lnet/minecraft/world/item/ItemStack;)Lnet/minecraft/world/item/ItemStack;",false));changes++;}
 }
 }
 }
 ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);Path p=Path.of("work28/classes/"+name+".class");Files.createDirectories(p.getParent());Files.write(p,w.toByteArray());
 }
 }
 if(changes!=9)throw new IllegalStateException("Unexpected edits: "+changes);
 int methods=0;
 try(var paths=Files.walk(Path.of("work28/classes"))){for(Path p:paths.filter(x->x.toString().endsWith(".class")).toList()){
 ClassNode c=new ClassNode();new ClassReader(Files.readAllBytes(p)).accept(c,0);for(MethodNode m:c.methods)if((m.access&(ACC_ABSTRACT|ACC_NATIVE))==0){new Analyzer<BasicValue>(new BasicVerifier()).analyze(c.name,m);methods++;}
 }}
 System.out.println("PASS edits="+changes+", verified methods="+methods);
 }
}
