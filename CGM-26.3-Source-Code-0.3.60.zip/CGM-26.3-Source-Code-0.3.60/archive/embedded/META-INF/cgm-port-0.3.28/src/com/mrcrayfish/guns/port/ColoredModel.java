package com.mrcrayfish.guns.port;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mrcrayfish.framework.api.client.model.renderer.StandaloneModelRenderer;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.block.dispatch.BlockStateModelPart;
import net.minecraft.world.item.ItemStack;
public final class ColoredModel {
 public static void draw(BlockStateModelPart model,PoseStack pose,SubmitNodeCollector collector,int light,int overlay,ItemStack stack) {
  if(model==null)return;
  int color=DyeBridge.color(stack,0);
  StandaloneModelRenderer.submitDraw(collector,model,pose,((color>>16)&255)/255F,((color>>8)&255)/255F,(color&255)/255F,light,overlay);
 }
}
