package com.mrcrayfish.guns.port;
import com.mrcrayfish.guns.util.StackData;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.DyedItemColor;
public final class DyeBridge {
 public static void sync(ItemStack stack) {
  var tag=StackData.copy(stack);
  if(tag.contains("Color")) stack.set(DataComponents.DYED_COLOR,new DyedItemColor(tag.getIntOr("Color",0)&0xFFFFFF));
  else stack.remove(DataComponents.DYED_COLOR);
 }
 public static int color(ItemStack stack,int index) {
  var tag=StackData.copy(stack);
  return tag.contains("Color") ? 0xFF000000 | (tag.getIntOr("Color",0)&0xFFFFFF) : 0xFFFFFFFF;
 }
 public static Object consume(net.minecraft.core.NonNullList<ItemStack> items,int slot,Object ignored) {
  ItemStack dye=items.get(slot);dye.shrink(1);
  if(dye.isEmpty())items.set(slot,ItemStack.EMPTY);
  return dye;
 }
}
