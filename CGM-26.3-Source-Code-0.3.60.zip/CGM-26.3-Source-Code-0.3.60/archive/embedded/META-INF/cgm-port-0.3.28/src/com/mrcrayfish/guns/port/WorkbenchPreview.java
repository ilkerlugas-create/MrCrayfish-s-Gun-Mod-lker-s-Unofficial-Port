package com.mrcrayfish.guns.port;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
public final class WorkbenchPreview {
 public static ItemStack create(ItemStack original) {
  ItemStack result=original.copy();
  var id=BuiltInRegistries.ITEM.getKey(original.getItem());
  if(id.getNamespace().equals("cgm") && java.util.Set.of("pistol","shotgun","rifle","grenade_launcher","bazooka","mini_gun","assault_rifle","machine_pistol","heavy_rifle").contains(id.getPath()))
   result.set(DataComponents.ITEM_MODEL,Identifier.parse("cgm:workbench_preview/"+id.getPath()));
  DyeBridge.sync(result);
  return result;
 }
}
