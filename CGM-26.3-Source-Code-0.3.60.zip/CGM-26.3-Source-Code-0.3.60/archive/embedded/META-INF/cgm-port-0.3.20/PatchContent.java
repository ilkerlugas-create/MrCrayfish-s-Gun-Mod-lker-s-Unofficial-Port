import java.nio.file.*;
import java.util.jar.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.tree.analysis.*;

public class PatchContent implements Opcodes {
 public static void main(String[] args) throws Exception {
  Path root=Path.of(args[1]); int edits=0;
  try(JarFile jar=new JarFile(args[0])) {
   for(String name:new String[]{"com/mrcrayfish/guns/GunMod","com/mrcrayfish/guns/common/NetworkGunManager"}) {
    ClassNode c=new ClassNode(); new ClassReader(jar.getInputStream(jar.getJarEntry(name+".class"))).accept(c,0);
    for(MethodNode m:c.methods) {
     if(name.endsWith("/GunMod") && m.name.equals("<init>")) {
      int found=0;
      for(AbstractInsnNode n=m.instructions.getFirst();n!=null;n=n.getNext()) {
       if(n instanceof MethodInsnNode call && call.owner.equals("net/minecraftforge/fml/javafmlmod/FMLJavaModLoadingContext") && call.name.equals("getModBusGroup")) {
        InsnList add=new InsnList();add.add(new InsnNode(DUP));
        add.add(new MethodInsnNode(INVOKESTATIC,"com/mrcrayfish/guns/port/ContentFix","register","(Lnet/minecraftforge/eventbus/api/bus/BusGroup;)V",false));
        m.instructions.insert(n,add);found++;
       }
      }
      if(found!=1) throw new IllegalStateException("Expected one bus bootstrap, got "+found); edits++;
     }
     if(name.endsWith("/NetworkGunManager") && m.name.equals("onDatapackSync")) {
      m.instructions.clear();m.tryCatchBlocks.clear();if(m.localVariables!=null)m.localVariables.clear();
      m.instructions.add(new VarInsnNode(ALOAD,0));
      m.instructions.add(new MethodInsnNode(INVOKESTATIC,"com/mrcrayfish/guns/port/ContentFix","sync",m.desc,false));
      m.instructions.add(new InsnNode(RETURN)); m.maxStack=1;m.maxLocals=1;edits++;
     }
    }
    ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS); c.accept(w);
    byte[] b=w.toByteArray(); ClassNode checked=new ClassNode();new ClassReader(b).accept(checked,0);
    for(MethodNode m:checked.methods) if((m.access&(ACC_ABSTRACT|ACC_NATIVE))==0) new Analyzer<>(new BasicVerifier()).analyze(checked.name,m);
    Path out=root.resolve(name+".class");Files.createDirectories(out.getParent());Files.write(out,b);
   }
  }
  if(edits!=2)throw new IllegalStateException("Wrong edit count "+edits);
  System.out.println("Two exact hooks patched; modified classes pass ASM BasicVerifier.");
 }
}
