import zipfile, json, pathlib, hashlib, copy, re

BASE=pathlib.Path('upload/CGM-26.3-Forge66.0.2-0.3.19-WORLD-LOAD-FIX-BUNDLED-FRAMEWORK(1).jar')
OUT=pathlib.Path('output/CGM-26.3-Forge66.0.2-0.3.20-CONTENT-FIX.jar')
with zipfile.ZipFile(BASE) as z: original={n:z.read(n) for n in z.namelist()}
data=original.copy()
def read(n): return json.loads(data[n])
def put(n,v): data[n]=(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode()

items=[n.rsplit('/',1)[1][:-5] for n in data if n.startswith('assets/cgm/models/item/') and n.endswith('.json')]
guns=[n.rsplit('/',1)[1][:-5] for n in data if n.startswith('data/cgm/guns/') and n.endswith('.json')]
assert len(items)==25 and len(guns)==9
for gun in guns:
    path=f'assets/cgm/models/item/{gun}.json'
    model=read(path)
    assert model['parent']=='builtin/entity'
    if gun in ('mini_gun','grenade_launcher'):
        parts=['base','barrels'] if gun=='mini_gun' else ['base','cylinder']
        model.pop('parent'); model['elements']=[];model['textures']={}
        for part in parts:
            body=read(f'assets/cgm/models/special/{gun}_{part}.json')
            for k,v in body['textures'].items():
                assert k not in model['textures'] or model['textures'][k]==v
                model['textures'][k]=v
            model['elements']+=body['elements']
        model['textures']['particle']=f'cgm:item/{gun}'
    else:
        model['parent']=f'cgm:special/gun/{gun}'
    put(path,model)

for item in items:
    put(f'assets/cgm/items/{item}.json',{'model':{'type':'minecraft:model','model':f'cgm:item/{item}','tints':[{'type':'minecraft:constant','value':16777215} for _ in range(3)]}})

# 26.3 separates item and block atlases. CGM's standalone renderer and scope
# effects still use the block sheet; item models use the item sheet.
sprites=sorted(n[len('assets/cgm/textures/'):-4] for n in data if n.startswith(('assets/cgm/textures/item/','assets/cgm/textures/effect/','assets/cgm/textures/block/')) and n.endswith('.png'))
for atlas in ('blocks','items'):
    path=f'assets/minecraft/atlases/{atlas}.json'
    model=read(path) if path in data else {'sources':[]}
    present={s.get('resource') for s in model['sources']}
    model['sources'] += [{'type':'minecraft:single','resource':'cgm:'+s} for s in sprites if 'cgm:'+s not in present]
    put(path,model)

for lang in ('en_us','tr_tr'):
    path=f'assets/cgm/lang/{lang}.json';obj=read(path) if path in data else {}
    obj['itemGroup.cgm']="MrCrayfish's Gun Mod";put(path,obj)
for path in pathlib.Path('work/classes').rglob('*.class'):
    data[path.relative_to('work/classes').as_posix()]=path.read_bytes()
data['META-INF/mods.toml']=data['META-INF/mods.toml'].replace(b'version="1.3.7"',b'version="1.3.7-26.3-port-0.3.20"')
for p in ['work/PatchContent.java','work/package_content.py','work/src/com/mrcrayfish/guns/port/ContentFix.java']:
    data['META-INF/cgm-port-0.3.20/'+pathlib.Path(p).name]=pathlib.Path(p).read_bytes()

# Resolve every model and texture reference, including inherited model geometry.
def geometry(name,visited=()):
    assert name not in visited, ('cycle',name)
    m=read(name);parent=m.get('parent');base={}
    if parent:
        ns,p=parent.split(':') if ':' in parent else ('minecraft',parent)
        if ns=='cgm':base=geometry(f'assets/{ns}/models/{p}.json',visited+(name,))
        else: assert parent!='builtin/entity'
    merged={**base,**m};merged['textures']={**base.get('textures',{}),**m.get('textures',{})}
    return merged
counts={}
for item in items:
    model=geometry(f'assets/cgm/models/item/{item}.json')
    assert model.get('elements'),item
    counts[item]=len(model['elements'])
    for texture in model['textures'].values():
        seen=set()
        while texture.startswith('#'):
            assert texture not in seen;seen.add(texture);texture=model['textures'][texture[1:]]
        ns,p=texture.split(':')
        if ns=='cgm':assert f'assets/cgm/textures/{p}.png' in data,(item,texture)
    for element in model['elements']:
        for face in element.get('faces',{}).values():
            t=face['texture']
            if t.startswith('#'):assert t[1:] in model['textures'],(item,t)
            assert face.get('tintindex',-1) <= 2,(item,'tint range')
for n,b in data.items():
    if n.endswith('.json'):json.loads(b)
report={'base_sha256':hashlib.sha256(BASE.read_bytes()).hexdigest(),'version':'0.3.20',
 'items':items,'guns':guns,'resolved_model_element_counts':counts,
 'changed_entries':[n for n in original if data[n]!=original[n]],
 'added_entries':[n for n in data if n not in original],
 'tests':{'all_json':'passed','model_parent_texture_resolution':'passed','item_coverage':'25/25','gun_geometry':'9/9','modified_bytecode_basic_verifier':'passed','forge_client_gameplay':'NOT RUN'},
 'limitations':['Gameplay, menus, animation, dye tint, and multiplayer behavior require in-game verification.','Inventory models include static barrel/cylinder geometry; legacy custom model animation registration remains unported.']}
put('META-INF/cgm-port-0.3.20-validation.json',report)
OUT.parent.mkdir(exist_ok=True)
with zipfile.ZipFile(OUT,'w',zipfile.ZIP_DEFLATED) as z:
    for n,b in data.items():z.writestr(n,b)
with zipfile.ZipFile(OUT) as z:assert z.testzip() is None
print(json.dumps({'output':str(OUT),'items':len(items),'guns':len(guns),'geometry':counts,'changed_classes':[n for n in report['changed_entries'] if n.endswith('.class')],'sha256':hashlib.sha256(OUT.read_bytes()).hexdigest()},indent=2))
