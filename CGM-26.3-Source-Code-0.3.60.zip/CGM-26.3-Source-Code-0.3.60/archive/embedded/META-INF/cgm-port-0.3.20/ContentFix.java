package com.mrcrayfish.guns.port;

import com.mrcrayfish.guns.init.ModItems;
import com.mrcrayfish.guns.network.PacketHandler;
import com.mrcrayfish.guns.network.message.S2CMessageUpdateGuns;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.eventbus.api.bus.BusGroup;
import net.minecraftforge.event.OnDatapackSyncEvent;

/** Content registration and first-login synchronization for the 26.3 port. */
public final class ContentFix {
    private static final DeferredRegister<CreativeModeTab> TABS =
        DeferredRegister.create(Registries.CREATIVE_MODE_TAB, "cgm");
    static {
        TABS.register("guns", () -> CreativeModeTab.builder(CreativeModeTab.Row.TOP, 0)
            .title(Component.translatable("itemGroup.cgm"))
            .icon(() -> new ItemStack(ModItems.PISTOL.get()))
            .displayItems((parameters, output) -> {
                // Includes every registered CGM item, including the workbench BlockItem.
                for (var entry : ModItems.REGISTER.getEntries()) output.accept(entry.get());
            }).build());
    }
    public static void register(BusGroup bus) { TABS.register(bus); }
    public static void sync(OnDatapackSyncEvent event) {
        if (event.getPlayer() == null) {
            PacketHandler.getPlayChannel().sendToAll(new S2CMessageUpdateGuns());
        } else {
            PacketHandler.getPlayChannel().sendToPlayer(event::getPlayer, new S2CMessageUpdateGuns());
        }
    }
}
